(:SOURCE-CONSISTENCY :STABLE :SOURCE-BLOBS-AFTER
 ((:PATH ".github/ISSUE_TEMPLATE/config.yml" :GIT-BLOB
   "0086358db1eb971c0cfa8739c27518bbc18a5ff4")
  (:PATH ".github/ISSUE_TEMPLATE/decisione-architetturale.md" :GIT-BLOB
   "0241da912be93fdf70b9a9749b759efc17aca329")
  (:PATH ".github/PULL_REQUEST_TEMPLATE.md" :GIT-BLOB
   "30f2e951591f8822ce780f77cfa9c4ab93f0a98b")
  (:PATH ".github/actions/setup-sbcl/README.md" :GIT-BLOB
   "86de4c772f5623cde6774e1bb5f2fc2c6e222bf7")
  (:PATH ".github/actions/setup-sbcl/action.yml" :GIT-BLOB
   "80da41aac60230141d5d2d0819c9b6c2c3b3ce91")
  (:PATH ".github/ci-toolchain.lock.lisp" :GIT-BLOB
   "c01b06c5b208014ab30bb000dc10acfc9e72cc89")
  (:PATH ".github/workflows/ci-results.yml" :GIT-BLOB
   "d5029660830b7dbef56d6648bbf0a9bbaa400c56")
  (:PATH ".github/workflows/ci.yml" :GIT-BLOB
   "49fc8ba897e94dc36c31d973e6e12efeab51b715")
  (:PATH ".gitignore" :GIT-BLOB "19bf1ab91a6ed3c89cfff48070fb170b09679360")
  (:PATH "CHANGELOG.md" :GIT-BLOB "ecaebfd73eaa7449fefccaef3bcc6dcbac43b8b5")
  (:PATH "CONTRIBUTING.md" :GIT-BLOB
   "40d7a7ed9a840793c871b91d1fc57f9d682551ac")
  (:PATH "LICENSE" :GIT-BLOB "aa9c159fc3ef804068ce29d1bb990d0010eedb00")
  (:PATH "Makefile" :GIT-BLOB "96001f99c123cc757cc6d2560dc6c4a58f311369")
  (:PATH "README.md" :GIT-BLOB "ddb05457ae89a6dc06d4b4dd7436f8f6031b38ab")
  (:PATH "SECURITY.md" :GIT-BLOB "27fb94691a84b389d72184838e38d2e43a8fcfbb")
  (:PATH "arcdocdb.asd" :GIT-BLOB "da5afc574cc1557ffa3d54f0da6583eaa7c3ff08")
  (:PATH "assets/README.md" :GIT-BLOB
   "933cfee445a3fe85c8b9ca8c7c4e48afda9bdc95")
  (:PATH "assets/img/flow-dark.svg" :GIT-BLOB
   "daae22922420bfde91c8ce8c313343c03c045d17")
  (:PATH "assets/img/flow-light.svg" :GIT-BLOB
   "d3e0bf360226c3d05b603aef74cf022177d9f213")
  (:PATH "assets/img/hero-dark.svg" :GIT-BLOB
   "0e9fe71b160f4ff7fcc61c9695159b00e352b12e")
  (:PATH "assets/img/hero-light.svg" :GIT-BLOB
   "de51c5d5d625caf2ba89581880a7e932a86d2556")
  (:PATH "assets/img/mark-dark.svg" :GIT-BLOB
   "2402f3bf0362118bba64640d64382ac5e86a20e0")
  (:PATH "assets/img/mark-light.svg" :GIT-BLOB
   "58ee962d4dffe098eaff67a88e6533b46d1fae53")
  (:PATH "assets/img/social.png" :GIT-BLOB
   "82582b11d03a6b1e447af3aeec37545fcc4067bd")
  (:PATH "assets/img/social.svg" :GIT-BLOB
   "6a4f2b2dc8c1325ec78b5736df18a97e701709c2")
  (:PATH "data/unicode/18.0.0/CaseFolding.txt" :GIT-BLOB
   "9ee0a2dd654f6fa520cd932be19ac5c00ffacded")
  (:PATH "data/unicode/18.0.0/DerivedNormalizationProps.txt" :GIT-BLOB
   "32227e8f297e96f98954281d99c38839a7834d7c")
  (:PATH "data/unicode/18.0.0/LICENSE.txt" :GIT-BLOB
   "56da58912807030b451a4700687d5bd02c72d6ed")
  (:PATH "data/unicode/18.0.0/NormalizationTest.txt" :GIT-BLOB
   "730c1a013ac78f6a63118e670c72556d4f112eab")
  (:PATH "data/unicode/18.0.0/README.md" :GIT-BLOB
   "68a3ac6a0f1d7a83b23d319a9ccaadeba0d88429")
  (:PATH "data/unicode/18.0.0/ReadMe.txt" :GIT-BLOB
   "aa18f7175c4a46df644c7c6435ad95a8ad3cd724")
  (:PATH "data/unicode/18.0.0/UnicodeData.txt" :GIT-BLOB
   "ebccf021c4fcf31c2ecbb9bd7da3f5eb7ed44851")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakProperty.txt" :GIT-BLOB
   "313ae91aad579445a1e06556a1d7a2edd0c782a2")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakTest.txt" :GIT-BLOB
   "8d734a2690b9f06018e02b0b4f165acc4d0d2853")
  (:PATH "data/unicode/18.0.0/emoji/emoji-data.txt" :GIT-BLOB
   "7a383f0dcfd6ad65a2b7b5e90f701e38485f151f")
  (:PATH "docs/01-visione-e-obiettivi.md" :GIT-BLOB
   "4a3cf72d6c5b7d57383e44f64ba243b966f42f9a")
  (:PATH "docs/02-modello-logico.md" :GIT-BLOB
   "13effbf6dcb8a18756e9d5c953b6438a92a91eff")
  (:PATH "docs/03-storage.md" :GIT-BLOB
   "0c81882c35757d460e55f808fc6d2370f845550d")
  (:PATH "docs/04-wal-e-durability.md" :GIT-BLOB
   "d65d5b12f248347430260c6671017a0894ebd3eb")
  (:PATH "docs/05-transazioni.md" :GIT-BLOB
   "2713de877ed961857868b53bcc346fe62088ec0e")
  (:PATH "docs/06-mvcc-e-snapshot.md" :GIT-BLOB
   "2e82f0c5e993b0547286f0f40137b54cc4001887")
  (:PATH "docs/07-compaction.md" :GIT-BLOB
   "7ee5d31293f024a641ca41a316b9f6095daa51d2")
  (:PATH "docs/08-indici.md" :GIT-BLOB
   "592722eba473e3a8bb1ff99d0113fa9463848f06")
  (:PATH "docs/09-cache.md" :GIT-BLOB
   "3eab0ad4c56c1744c456579c8e773c5d7fe7493a")
  (:PATH "docs/10-concorrenza-e-scheduling.md" :GIT-BLOB
   "6616ed0cfadc71596ae3162affdef4f75f608de5")
  (:PATH "docs/11-recovery.md" :GIT-BLOB
   "99ece25d26c59468aa4dddb8f652986fc4ebcd13")
  (:PATH "docs/12-osservabilita.md" :GIT-BLOB
   "20620fae5746d6acd2c4fc23bab30b740ed9810f")
  (:PATH "docs/13-benchmark.md" :GIT-BLOB
   "4b83247b5082e1b198b929269d3d0308676e78fe")
  (:PATH "docs/14-fault-injection.md" :GIT-BLOB
   "db87b7732e2e42f22c711a89f5deae97f5f00757")
  (:PATH "docs/15-ottimizzazioni-native.md" :GIT-BLOB
   "5c5a08eb804ab6e40b44469d5eab7f9c27e68535")
  (:PATH "docs/16-moduli.md" :GIT-BLOB
   "45067d5f26f743cdbfacc40014218ba8c82f539a")
  (:PATH "docs/README.md" :GIT-BLOB "0a8d0c43545a7f6ee8b5d8d635cefe3f511da0f4")
  (:PATH "docs/adr/0000-modello.md" :GIT-BLOB
   "88eeb77497b6d6124010ad65a71b98e08743131e")
  (:PATH "docs/adr/0001-common-lisp-sbcl.md" :GIT-BLOB
   "a4d7157123f6cad4b92d3722e136bd02f15fa138")
  (:PATH "docs/adr/0002-serie-unita-di-storage-e-parallelismo.md" :GIT-BLOB
   "fe20638b50dffc66f5d5b3497f00e5f526ea046a")
  (:PATH "docs/adr/0003-wal-per-serie.md" :GIT-BLOB
   "2b9f1e16b289ec754c0ac0de79e7823852c4815a")
  (:PATH "docs/adr/0004-storage-append-only-un-solo-active.md" :GIT-BLOB
   "4af05ad11f846d733b3485bfdabac47535f41415")
  (:PATH "docs/adr/0005-writer-logico-per-serie.md" :GIT-BLOB
   "ac6e1e0f042e6ce5622c0b579ff8d0419a707980")
  (:PATH "docs/adr/0006-transazioni-multiserie-2pc.md" :GIT-BLOB
   "ad70fc5e177886b0be609ebc0234c0c7c2fbab90")
  (:PATH "docs/adr/0007-clean-e-merge-distinti.md" :GIT-BLOB
   "7e6590a619252983120f8ef9b5b3fba5bf24659f")
  (:PATH "docs/adr/0008-merge-opportunistico.md" :GIT-BLOB
   "5ae6feb439b1d182febe27d16e6d485183150d6a")
  (:PATH "docs/adr/0009-indici-immutabili-atomic-swap.md" :GIT-BLOB
   "18de49d285e52d25e055397f47c829ba7db45500")
  (:PATH "docs/adr/0010-cache-clock.md" :GIT-BLOB
   "2f04c342ca714f0638dfdf2bed17fe48de54edc9")
  (:PATH "docs/adr/0011-thread-pool-dinamico.md" :GIT-BLOB
   "1a86df3d58358950d8b658b6b8194563288fd0c8")
  (:PATH "docs/adr/0012-simd-guidato-dai-benchmark.md" :GIT-BLOB
   "a5b8fac1dd72d5a213632d47898dca632aa4b72a")
  (:PATH "docs/adr/0013-log-structured-segmento-active-come-log.md" :GIT-BLOB
   "3ca2df1c7beddedd65511d9282a547294cabbff4")
  (:PATH "docs/adr/0014-formato-record-documento-id.md" :GIT-BLOB
   "87931cd80f665581fc43a2b02fc6738ea3d57fb3")
  (:PATH "docs/adr/0015-primary-index-swiss-table-swmr.md" :GIT-BLOB
   "001950113b1fc347642e1939ef060d93a54096e5")
  (:PATH "docs/adr/0016-epoch-based-reclamation.md" :GIT-BLOB
   "5a442b2aeb665be3f23da887ff615bef889e167d")
  (:PATH "docs/adr/0017-piattaforma-e-io.md" :GIT-BLOB
   "250c272e2ddaa4b062b956d5ab3eb66ce610b44a")
  (:PATH "docs/adr/0018-control-log-manifest-swap.md" :GIT-BLOB
   "be9686df1c7ecb762bebac602bab12010d73d0b9")
  (:PATH "docs/adr/0019-durability-e-group-commit-pipelined.md" :GIT-BLOB
   "6fff5ed7db6d11a51f12b167636b7a23a3750068")
  (:PATH "docs/adr/0020-csn-snapshot-isolamento.md" :GIT-BLOB
   "83c6cae3eb56b9edfda572533258d8438132e0ae")
  (:PATH "docs/adr/0021-2pc-intenti-outcome.md" :GIT-BLOB
   "81823c873cf52abafd86a3e8ab35df2e161d1034")
  (:PATH "docs/adr/0022-registri-come-serie-catalogo.md" :GIT-BLOB
   "623209aef44929e1b8397b1f8470dffc20d9bbf8")
  (:PATH "docs/adr/0023-politiche-di-compaction.md" :GIT-BLOB
   "bc3d2144b30022e7ab239c561b6986a18e10ec8c")
  (:PATH "docs/adr/0024-memoria-e-gc.md" :GIT-BLOB
   "470ef1b7f52d571ea5af046ccf06896729a06a13")
  (:PATH "docs/adr/0025-cache-per-location.md" :GIT-BLOB
   "24235615cfaab3821cc38bc9b9979a9928c6dee9")
  (:PATH "docs/adr/0026-indici-secondari-segmentati.md" :GIT-BLOB
   "09512403a6ef9d04a9ad42796fa5c535d6abbbe3")
  (:PATH "docs/adr/0027-dipendenze-e-test.md" :GIT-BLOB
   "127ac9190f647e1d3582a079ccdb798419b2cb2e")
  (:PATH "docs/adr/0028-target-e-obiettivi-di-latenza.md" :GIT-BLOB
   "506080464430c1b9e5f2b09816d186ca95e3fcc9")
  (:PATH "docs/adr/0029-interfacce-protocollo-query-contratto.md" :GIT-BLOB
   "4223207857d168241c613bb2e7ac4aa525687a26")
  (:PATH "docs/adr/0030-scope-v1.md" :GIT-BLOB
   "4c93b3d78c5ac2772c4b2563f44063ea855f1206")
  (:PATH "docs/adr/0031-software-critico-criteri-e-priorita.md" :GIT-BLOB
   "dc8228d1c2dc5e01fa6a5cb6c69ec9e8648427d2")
  (:PATH "docs/adr/0032-seqlock-a-64-bit.md" :GIT-BLOB
   "fc947bb28bdf5a015d7b353f56e0d6fb86a524c6")
  (:PATH "docs/adr/0033-fail-stop-e-integrita-end-to-end.md" :GIT-BLOB
   "4646cd378729d3841b8419b3681477b4e1a80816")
  (:PATH "docs/adr/0034-policy-di-compilazione-e-standard-di-codifica.md"
   :GIT-BLOB "dfeef8dd42d465d1c97830bd6f8304d3f8579416")
  (:PATH "docs/adr/0035-strategia-di-verifica-e-tracciabilita.md" :GIT-BLOB
   "eb3138e9017cc95b7f71fb29ec3a21e4bc44a3c3")
  (:PATH "docs/adr/0036-leggi-di-progetto.md" :GIT-BLOB
   "d4140bc0d14bee6ca7480e94fa96bd8c79e656fd")
  (:PATH "docs/adr/0037-lotto-sigillato.md" :GIT-BLOB
   "aadf427743cc9b511c4fac4952ec1335005b5568")
  (:PATH "docs/adr/0038-orizzonte-di-visibilita.md" :GIT-BLOB
   "fce6228c1a393557b2475a7600cc998246de97d0")
  (:PATH "docs/adr/0039-cornice-unica-dei-record.md" :GIT-BLOB
   "c347b791cfa1e13319894e5c2a9c3c20527a7047")
  (:PATH "docs/adr/0040-manifest-a-record-unico.md" :GIT-BLOB
   "77640ef6687df0ba7a570b682000bd4b2fa042cc")
  (:PATH "docs/adr/0041-multiserie-segmenti-autosufficienti.md" :GIT-BLOB
   "c571f195148361a34fa6bc9d1c6f35836742ab11")
  (:PATH "docs/adr/0042-tombstone-e-indice-dei-vivi.md" :GIT-BLOB
   "ba7550dfd1890a483f313610cadc808142bdddeb")
  (:PATH "docs/adr/0043-primary-index-a-frammenti.md" :GIT-BLOB
   "1f07f3d9c4a9a1b6a0c1250dc09923966b2081d3")
  (:PATH "docs/adr/0044-cache-acceleratore-puro.md" :GIT-BLOB
   "3ada528fa148db73ca09df933265ff82a5e0dd6b")
  (:PATH "docs/adr/0045-modello-di-esecuzione.md" :GIT-BLOB
   "75301c4284016be1da4f6f7a9e4b8a1c00b1fe8c")
  (:PATH "docs/adr/0046-orizzonte-con-registro-limitato.md" :GIT-BLOB
   "2ebb221d1f2e8666fa62910f561728eb6ee0a9f3")
  (:PATH "docs/adr/0047-verifica-csn-dei-record-prepared.md" :GIT-BLOB
   "4c11a9e20d9d7bf315bf7623740addd876019d77")
  (:PATH "docs/adr/0048-limiti-documentali-e-formato-v2.md" :GIT-BLOB
   "f36aeeeab161774fce91906d1ba5d47e6b1a8636")
  (:PATH "docs/adr/0049-capacita-oltre-la-ram.md" :GIT-BLOB
   "47b35236825274bd340b61e4c30b7b38d8349d5a")
  (:PATH "docs/adr/0050-pubblicazione-e-costi-della-directory.md" :GIT-BLOB
   "f393c09cc917be5e4a123befca7bdd3f238ad8eb")
  (:PATH "docs/adr/0051-presentazione-della-documentazione.md" :GIT-BLOB
   "123524e58806fe8cee2727e5ada0b00561583a76")
  (:PATH "docs/adr/0052-header-dei-log-di-controllo.md" :GIT-BLOB
   "817f3f72a09e74d142b160bd8da172b459f327f9")
  (:PATH "docs/adr/0053-ricerca-full-text-indici-invertiti.md" :GIT-BLOB
   "911f33ef505d0d5dd1095947881d25d178c3d97c")
  (:PATH "docs/adr/0054-contratto-e-formato-full-text.md" :GIT-BLOB
   "93bf30e76760bb0ce8b8227758b8b1202f9d34a8")
  (:PATH "docs/adr/0055-interfaccia-locale-unix-socket.md" :GIT-BLOB
   "34dc862714c81665e5d7e997b4ca301b270417e9")
  (:PATH "docs/adr/0056-sessione-locale-m16.md" :GIT-BLOB
   "2787ac485b8ae20cec8f988ca4d8d7bb5862e3ff")
  (:PATH "docs/adr/0057-selezione-automatica-indice.md" :GIT-BLOB
   "d1daf810581a18e8dca610082cc5f1b8b7a9df71")
  (:PATH "docs/adr/0058-pagine-indice-primario.md" :GIT-BLOB
   "d5d74b7af7e7f467070ee84a1bcd717020a93207")
  (:PATH "docs/adr/README.md" :GIT-BLOB
   "a1e7e7a3f1875609a7e1d07c05fbda45689b23a6")
  (:PATH "docs/affidabilita/README.md" :GIT-BLOB
   "83dd5fe0d9323805d7e97e6814129d16841efb80")
  (:PATH "docs/affidabilita/analisi-dei-guasti.md" :GIT-BLOB
   "c031db7bad8fa2f115938e3699e6ce01bc436bec")
  (:PATH "docs/affidabilita/copertura-eccezioni.md" :GIT-BLOB
   "b5d7eaae25d8613da6b2b9bce9348f000a595fd7")
  (:PATH "docs/affidabilita/deviazioni.md" :GIT-BLOB
   "61f400316607e9c47904680e6730c3034ba5897a")
  (:PATH "docs/affidabilita/piano-di-verifica.md" :GIT-BLOB
   "070d76bf87022dfbc3471f3707848b46061cf076")
  (:PATH "docs/affidabilita/standard-di-codifica.md" :GIT-BLOB
   "7800931fe3bc4c8204cd873ccc0ec8ed42af8b50")
  (:PATH "docs/analisi-progettuale.md" :GIT-BLOB
   "7028bc0b2b30b0ad17f9bbae81590519d3775e73")
  (:PATH "docs/architettura.md" :GIT-BLOB
   "6befae2249c1f13b53fbc296abfaa3bb5ada8f37")
  (:PATH "docs/formati-su-disco.md" :GIT-BLOB
   "011476236c57e5904ffb989e78fb958cd71f8e2e")
  (:PATH "docs/formato-indice-full-text.md" :GIT-BLOB
   "28f3f290149d4dfd032f26f0f57a9e7fef5cb987")
  (:PATH "docs/full-text.md" :GIT-BLOB
   "25f8a7e269b51211a1d6a919114d325b6aebd44e")
  (:PATH "docs/glossario.md" :GIT-BLOB
   "08f40903c66b0657317f2f9fd63cf522ea272a4c")
  (:PATH "docs/guida-al-repository.md" :GIT-BLOB
   "2d883ca7e34a8b31f88930e0d266ec0a094e6b0a")
  (:PATH "docs/implementazione/README.md" :GIT-BLOB
   "9729f11b98b6ef79984cbd582ae6ac0a337053e9")
  (:PATH "docs/implementazione/active-recovery-metodo.md" :GIT-BLOB
   "93b6051260c2ccf600bd47b0fb6ac1f828f2cfd4")
  (:PATH "docs/implementazione/active-recuperato-metodo.md" :GIT-BLOB
   "af0204ed53afbd5e27df1103e7d28d587357361f")
  (:PATH "docs/implementazione/active-recuperato-verifica.md" :GIT-BLOB
   "fbeead915b0973a89e4a97914ce997a833c4f72e")
  (:PATH "docs/implementazione/active-recuperato.md" :GIT-BLOB
   "976ca6f9d74cefdcb35b2a71531ecba690a31df2")
  (:PATH "docs/implementazione/adozione-closed-runtime.md" :GIT-BLOB
   "493baf22e54b3d57a6d994b53d1f3b267f25cc56")
  (:PATH "docs/implementazione/adozione-controller-runtime.md" :GIT-BLOB
   "21fc1a955edef5b2702164e340d4bc18f32ac082")
  (:PATH "docs/implementazione/archivi-comandi-lettura.md" :GIT-BLOB
   "00a1f025a375559acf548fb855c59d42e4a21642")
  (:PATH "docs/implementazione/archivio-csn-revisione.md" :GIT-BLOB
   "d4ab7c91922cc266d3f0ec02de3f463de7a24ecd")
  (:PATH "docs/implementazione/archivio-csn-verifica.md" :GIT-BLOB
   "94edca783edd1bb871785fc80a23793d23b23489")
  (:PATH "docs/implementazione/associazione-file.md" :GIT-BLOB
   "26141de9dcbaa24455edf9966cdbdeeec819961f")
  (:PATH "docs/implementazione/cache-record.md" :GIT-BLOB
   "7caa5d05d2225ee7af89a26ce430e33b844960b9")
  (:PATH "docs/implementazione/cbor-array-decisioni.md" :GIT-BLOB
   "60d1ee21f9aa42336c246da92bbe1a69beee91cb")
  (:PATH "docs/implementazione/cbor-array-lettura.md" :GIT-BLOB
   "a317dfc2fa86b653d2705a03513388ddd76e0a60")
  (:PATH "docs/implementazione/cbor-array-metodo.md" :GIT-BLOB
   "2f257c9e8a56a5182142934dada3f3b38b5bef65")
  (:PATH "docs/implementazione/cbor-array-revisione.md" :GIT-BLOB
   "c7a130fc659cdd792f0d0fe58e395fccef26a3b0")
  (:PATH "docs/implementazione/cbor-array-risultati.md" :GIT-BLOB
   "a790237317bf518c29c8f6b34a7e5b47f1df7397")
  (:PATH "docs/implementazione/cbor-array.md" :GIT-BLOB
   "82e60606f0f2c054e0bf52da1d77146e80bce7a8")
  (:PATH "docs/implementazione/cbor-float-scrittura-copertura.md" :GIT-BLOB
   "5995792c928309dc872b85fbfd6aadeace374442")
  (:PATH "docs/implementazione/cbor-float-scrittura-dati.md" :GIT-BLOB
   "193ac30ac7695f057f90d991f612d7bb2aaa8e83")
  (:PATH "docs/implementazione/cbor-float-scrittura-decisioni.md" :GIT-BLOB
   "4a59eea9a4021041b5b6b091bd26a9ce1a359a39")
  (:PATH "docs/implementazione/cbor-float-scrittura-lettura.md" :GIT-BLOB
   "134173468ca2bfd538eb1f6bbeda4dda128e800b")
  (:PATH "docs/implementazione/cbor-float-scrittura-metodo.md" :GIT-BLOB
   "755b13a91ab72f54383d96faee5780da36e750d6")
  (:PATH "docs/implementazione/cbor-float-scrittura-revisione.md" :GIT-BLOB
   "0d644768dc2f8efeb86136a8a4c4206c4c464bb6")
  (:PATH "docs/implementazione/cbor-float-scrittura-risultati.md" :GIT-BLOB
   "9bf9db1e3af901cb6642d63d1aada850dc4294ac")
  (:PATH "docs/implementazione/cbor-float-scrittura.md" :GIT-BLOB
   "551c707affc51a5a18a6ce4a91a017be61e105f1")
  (:PATH "docs/implementazione/cbor-header-decisioni.md" :GIT-BLOB
   "c8182641591fa6f24bddedca56f92145a3c7a038")
  (:PATH "docs/implementazione/cbor-header-lettura.md" :GIT-BLOB
   "b8b2b37a18cb4d01815e07df5e64e763f273a9d0")
  (:PATH "docs/implementazione/cbor-header-metodo.md" :GIT-BLOB
   "325784adbb5cff4121559fd3d50a1ef943443434")
  (:PATH "docs/implementazione/cbor-header-revisione.md" :GIT-BLOB
   "bc95228574813d37b27882f24713e4d834788dd2")
  (:PATH "docs/implementazione/cbor-header-strumenti-review.md" :GIT-BLOB
   "69bf38c64b527b5aeec011f9fe49d9fd3c31d253")
  (:PATH "docs/implementazione/cbor-header.md" :GIT-BLOB
   "9eb64c8428b638f6c0c1f0aaa80c4dbfd0f900b7")
  (:PATH "docs/implementazione/cbor-item-decisioni.md" :GIT-BLOB
   "8b287b49d006db867732eec19574e7fed85e3e7b")
  (:PATH "docs/implementazione/cbor-item-lettura.md" :GIT-BLOB
   "01cefe902960448b80ce8b157e3d8b5192f5238a")
  (:PATH "docs/implementazione/cbor-item-metodo.md" :GIT-BLOB
   "a67a79bf4fefe11c4778cd881eb5279a006966ca")
  (:PATH "docs/implementazione/cbor-item-revisione.md" :GIT-BLOB
   "f0c80bf6534054a6a956e016993b8fb1e9c0aa5b")
  (:PATH "docs/implementazione/cbor-item-risultati.md" :GIT-BLOB
   "938f5c59f7b10e777fcb691f6fe8ad4c8069615e")
  (:PATH "docs/implementazione/cbor-item.md" :GIT-BLOB
   "c31ce79d42d1504977c40039d01041d49fbb6f9f")
  (:PATH "docs/implementazione/cbor-map-decisioni.md" :GIT-BLOB
   "16c6031456225537b6eb1fe961aa8e20d7f5e110")
  (:PATH "docs/implementazione/cbor-map-lettura.md" :GIT-BLOB
   "a522551230d07a1816d08e6da4c7384311e853d4")
  (:PATH "docs/implementazione/cbor-map-metodo.md" :GIT-BLOB
   "636dd2706c2903542978606cf029e7198bf4dbb3")
  (:PATH "docs/implementazione/cbor-map-revisione.md" :GIT-BLOB
   "06f6af70d48553e1b327750fb573f57ebce6fb97")
  (:PATH "docs/implementazione/cbor-map-risultati.md" :GIT-BLOB
   "cc5cb4834d524d83108e1300cb94ec1f0595b4b3")
  (:PATH "docs/implementazione/cbor-map.md" :GIT-BLOB
   "60ea1772c7aadba6831684a01e583ebc431c8523")
  (:PATH "docs/implementazione/cbor-minimo-decisioni.md" :GIT-BLOB
   "e39571136cad9d563a933aa608c011b887f17260")
  (:PATH "docs/implementazione/cbor-minimo-driver-review.md" :GIT-BLOB
   "a83c5cc798dfb87750030781d015eeda260c4ac0")
  (:PATH "docs/implementazione/cbor-minimo-lettura.md" :GIT-BLOB
   "245f95c99a4735fd40a1d9694b4a5826f5ccb5d6")
  (:PATH "docs/implementazione/cbor-minimo-metodo.md" :GIT-BLOB
   "9f6526bf5c135cf43289127c4c1bc5dfdcbb8114")
  (:PATH "docs/implementazione/cbor-minimo-revisione.md" :GIT-BLOB
   "162cd32188a030d6cc3c5d16585054aa36055175")
  (:PATH "docs/implementazione/cbor-minimo-risultati.md" :GIT-BLOB
   "4af8109f8d01f1107791836371720802876ae775")
  (:PATH "docs/implementazione/cbor-minimo-strumenti-review.md" :GIT-BLOB
   "2a9e7f0bf30460b3b7dbbbc1c7776c9259fe545d")
  (:PATH "docs/implementazione/cbor-minimo-struttura-decisioni.md" :GIT-BLOB
   "3935fc5225836a0669664701921ad1bfff3d443e")
  (:PATH "docs/implementazione/cbor-minimo-struttura-driver-review.md"
   :GIT-BLOB "8ba7e4ba06ca958c0be9a5e1128c63419aa7577a")
  (:PATH "docs/implementazione/cbor-minimo-struttura-lettura.md" :GIT-BLOB
   "a83375d3c09898353fc0173f3171884f92319d73")
  (:PATH "docs/implementazione/cbor-minimo-struttura-metodo.md" :GIT-BLOB
   "d379ed246db14204b7632b7b3c31266bfcd46b1e")
  (:PATH "docs/implementazione/cbor-minimo-struttura-revisione.md" :GIT-BLOB
   "ba4d2ed61bf06d0504bb1e0067c8741ef45cc4e0")
  (:PATH "docs/implementazione/cbor-minimo-struttura-risultati.md" :GIT-BLOB
   "8966ac0cdf66fcefd616201cc97017d384b3f0a8")
  (:PATH "docs/implementazione/cbor-minimo-struttura-strumenti-review.md"
   :GIT-BLOB "cd2f1ef9dfcd3f9029549430c21ec553509a62fc")
  (:PATH "docs/implementazione/cbor-minimo-struttura.md" :GIT-BLOB
   "81675040c1c6155f7e3efa669ca62ed4b8a63064")
  (:PATH "docs/implementazione/cbor-minimo.md" :GIT-BLOB
   "d8b22e42e7ab906488cef72d935b71d4a83ba499")
  (:PATH "docs/implementazione/cbor-mutazioni-processi.md" :GIT-BLOB
   "6b4a59954e2d48cc30a044b57cfe43b0b91ae1e8")
  (:PATH "docs/implementazione/cbor-scrittura-decisioni.md" :GIT-BLOB
   "7d44d58d7de6c62b2206a8e35be398bc34811663")
  (:PATH "docs/implementazione/cbor-scrittura-lettura.md" :GIT-BLOB
   "9605de0679e062361f80c5654c5fbb8028765008")
  (:PATH "docs/implementazione/cbor-scrittura-metodo.md" :GIT-BLOB
   "8b79dfa3b7cf5011b66534d02c2a4551232d503c")
  (:PATH "docs/implementazione/cbor-scrittura-revisione.md" :GIT-BLOB
   "e9007f26d323a1ffd2993c461c3f84ad2aee90bc")
  (:PATH "docs/implementazione/cbor-scrittura-risultati.md" :GIT-BLOB
   "a25b46457201e1a7885cc9b21cfb3e66267ec12c")
  (:PATH "docs/implementazione/cbor-scrittura.md" :GIT-BLOB
   "a9e2e9dc6d0d4b968a9940d78abf8ca2de825e98")
  (:PATH "docs/implementazione/cbor-semplici-dati.md" :GIT-BLOB
   "5d0aacab996dc47e2d479d505604d6eda5d42ea2")
  (:PATH "docs/implementazione/cbor-semplici-decisioni.md" :GIT-BLOB
   "3ec66f8edebd79a128969e0b398e7700a2b1c5cd")
  (:PATH "docs/implementazione/cbor-semplici-lettura.md" :GIT-BLOB
   "46a0480b0bc29938f8654ce8f59cdaee5b720a4a")
  (:PATH "docs/implementazione/cbor-semplici-metodo.md" :GIT-BLOB
   "e8864f7c0124f86cebdcdbcb2449800e078e1cc8")
  (:PATH "docs/implementazione/cbor-semplici-revisione.md" :GIT-BLOB
   "d276363cd59d6d1a914a6055b27edce016122323")
  (:PATH "docs/implementazione/cbor-semplici-risultati.md" :GIT-BLOB
   "94d950c644e849103eecb0d74c053df4aa1473dd")
  (:PATH "docs/implementazione/cbor-semplici-verificatori.md" :GIT-BLOB
   "47cfd5c96e2150c42a2a7b716bef117090b0cd86")
  (:PATH "docs/implementazione/cbor-semplici.md" :GIT-BLOB
   "f5817e4d931148aa4f526b93066ab9d1b4bdf783")
  (:PATH "docs/implementazione/cbor-stringa-lettura-decisioni.md" :GIT-BLOB
   "f8cfb0895a3086b0fa0a7c509c7e56559d4b3493")
  (:PATH "docs/implementazione/cbor-stringa-lettura-metodo.md" :GIT-BLOB
   "2d7ad0304f923e3213bc65edd159e16b70202201")
  (:PATH "docs/implementazione/cbor-stringa-lettura-prima-revisione.md"
   :GIT-BLOB "c7232e26023ef8e4ceba49fd6dfcb60be697e921")
  (:PATH "docs/implementazione/cbor-stringa-lettura-risultati.md" :GIT-BLOB
   "d225757b21762809fe0b871ce6abcbe7cc6d5af4")
  (:PATH "docs/implementazione/cbor-stringa-lettura-seconda-revisione.md"
   :GIT-BLOB "fdb6848a04e93a846da2ac9690f1d94975e35f1f")
  (:PATH "docs/implementazione/cbor-stringa-lettura.md" :GIT-BLOB
   "99c7f801c7ac550c6f2d609d71fcc8e76e03948c")
  (:PATH "docs/implementazione/cbor-stringhe-dati.md" :GIT-BLOB
   "0a3a2123e618a8ff39e86dbbb70db36ccf51b133")
  (:PATH "docs/implementazione/cbor-stringhe-decisioni.md" :GIT-BLOB
   "2df0a214fc5cfe64ceb239aab4f7d2a2d1827305")
  (:PATH "docs/implementazione/cbor-stringhe-lettura.md" :GIT-BLOB
   "1c1d617e19c0d74199ef11a56105d3ed90eb0ec0")
  (:PATH "docs/implementazione/cbor-stringhe-metodo.md" :GIT-BLOB
   "56342dae95caf8705e0b28b3c0ea7ac86fdd8fa0")
  (:PATH "docs/implementazione/cbor-stringhe-revisione.md" :GIT-BLOB
   "90bac509af0aff7b7085a2239de6e9dfddfc70ba")
  (:PATH "docs/implementazione/cbor-stringhe-risultati.md" :GIT-BLOB
   "cbcfdba7c5967d5d36e5d9487f6a7b1ab0300a53")
  (:PATH "docs/implementazione/cbor-stringhe.md" :GIT-BLOB
   "278d9413eab7578c99a07b1c614db37c83141097")
  (:PATH "docs/implementazione/cbor-struttura-decisioni.md" :GIT-BLOB
   "8e1b0d0d6066669e1ffb65d95900a3b1aa385c51")
  (:PATH "docs/implementazione/cbor-struttura-driver-review.md" :GIT-BLOB
   "c9808d48a01444ff6faddf2d8389673f91598db4")
  (:PATH "docs/implementazione/cbor-struttura-lettura.md" :GIT-BLOB
   "6b2909a5f56212947dea864584d2f96252fe1b1a")
  (:PATH "docs/implementazione/cbor-struttura-metodo.md" :GIT-BLOB
   "f0a2791f988b0d0c513629824f75ce1842fe059a")
  (:PATH "docs/implementazione/cbor-struttura-revisione.md" :GIT-BLOB
   "cebaf33e7e7cde4efbcbc2ada22fd494577c9e81")
  (:PATH "docs/implementazione/cbor-struttura-risultati.md" :GIT-BLOB
   "7b22c788ecf0d69f84316f39d2f580bfadb7b91f")
  (:PATH "docs/implementazione/cbor-struttura-strumenti-review.md" :GIT-BLOB
   "76509dd8d44a61eff9129d08fb19c289d57fd1e8")
  (:PATH "docs/implementazione/cbor-struttura.md" :GIT-BLOB
   "93f1366c17eca13f37f63927d64779f7afeae658")
  (:PATH "docs/implementazione/cbor-tag-decisioni.md" :GIT-BLOB
   "791a560cf0727d9fcc2653c3ebaa7926487fad9a")
  (:PATH "docs/implementazione/cbor-tag-lettura.md" :GIT-BLOB
   "5f0b9dede29f69e68a75c70d9f5e026ad3d2fece")
  (:PATH "docs/implementazione/cbor-tag-metodo.md" :GIT-BLOB
   "3175390e496173398781bf8b39170cb33892125f")
  (:PATH "docs/implementazione/cbor-tag-revisione.md" :GIT-BLOB
   "11525b2d76a8393cd5ee088c5ab8a016404884a2")
  (:PATH "docs/implementazione/cbor-tag-risultati.md" :GIT-BLOB
   "163d821483988a3fcecc0e16f77b4ae12163b13d")
  (:PATH "docs/implementazione/cbor-tag.md" :GIT-BLOB
   "78785ec855050abdc9bf1dde6edaf69248a07ba1")
  (:PATH "docs/implementazione/checkpoint-control.md" :GIT-BLOB
   "4cb5c18e209211e5cdeaa92b93326549207409b1")
  (:PATH "docs/implementazione/checkpoint-recovery.md" :GIT-BLOB
   "7d5c17d3fa99d0771fd6117c7f83796b90618f19")
  (:PATH "docs/implementazione/ci-provenienza-pr.md" :GIT-BLOB
   "5d1c6dd259445bf25188da1d749b751dcdab7ac4")
  (:PATH "docs/implementazione/ci-statistiche.md" :GIT-BLOB
   "6af171f6d114713569d7db96fbba270b257b8915")
  (:PATH "docs/implementazione/ci-wire-processi.md" :GIT-BLOB
   "65c75747dea41b2fc0ed9a441f694f488fdf54ad")
  (:PATH "docs/implementazione/closed-recuperato-revisione.md" :GIT-BLOB
   "379bc5367c33e4edccf7f2a0fcb763054d5d85c2")
  (:PATH "docs/implementazione/closed-recuperato-verifica.md" :GIT-BLOB
   "da3ec1d1eb9083d7b39724f2839a8dd47c6ad93c")
  (:PATH "docs/implementazione/closed-recuperato.md" :GIT-BLOB
   "993d6ab7e501625f9adfdc7ab095e343c81f9b37")
  (:PATH "docs/implementazione/code-writer-decisioni.md" :GIT-BLOB
   "a48d5b525d2c78fef0399666ebb14c6f8a2342e8")
  (:PATH "docs/implementazione/code-writer-metodo.md" :GIT-BLOB
   "8dfa1cf8533764fdd89014f31cac59d02b248e2e")
  (:PATH "docs/implementazione/code-writer.md" :GIT-BLOB
   "759b72a96a099d18fd353ef8936d63481e25129c")
  (:PATH "docs/implementazione/compiti-lettura.md" :GIT-BLOB
   "b28934a0a4eac77562b07fa8db796c167176ef36")
  (:PATH "docs/implementazione/control-recuperato.md" :GIT-BLOB
   "d995e71b256c3da3a48dfb08abb8e8c93a6ace64")
  (:PATH "docs/implementazione/control-transizione-metodo.md" :GIT-BLOB
   "6f3cd5786454b47d0b4ec8b2546a426050515168")
  (:PATH "docs/implementazione/control-verifica-metodo.md" :GIT-BLOB
   "a5d5443dc3f76815d0829e93e030117866673af2")
  (:PATH "docs/implementazione/controller-serie-decisioni.md" :GIT-BLOB
   "4a2c524c6b1c7be1c1b5d7e43d35d385ee7f5b1d")
  (:PATH "docs/implementazione/controller-serie-metodo.md" :GIT-BLOB
   "f6cadf13877cab21d869993f33e485f1af116806")
  (:PATH "docs/implementazione/controller-serie-revisione.md" :GIT-BLOB
   "8dbbd94b11ca62b266df8e1b58ef8b15487dde9f")
  (:PATH "docs/implementazione/controller-serie-risultati.md" :GIT-BLOB
   "2e1d7abdfe9b4880682ff1da97b526e180d01370")
  (:PATH "docs/implementazione/controller-serie.md" :GIT-BLOB
   "f1ce7efd5d2c04b970a1ea0b0afe03356aa19621")
  (:PATH "docs/implementazione/controllore-pool-decisioni.md" :GIT-BLOB
   "15c6e4b9b671396d935faa3a60015ecdfd57b755")
  (:PATH "docs/implementazione/controllore-pool-metodo.md" :GIT-BLOB
   "30b830f5e01fb9941b7f4f64155865cd10f67bec")
  (:PATH "docs/implementazione/controllore-pool-revisione-2.md" :GIT-BLOB
   "18b67528a581db82aa5fd6c99282ebe3026d3813")
  (:PATH "docs/implementazione/controllore-pool-revisione.md" :GIT-BLOB
   "c11c4866bb2698a43c9707878fc3b635d815daab")
  (:PATH "docs/implementazione/controllore-pool-risultati.md" :GIT-BLOB
   "26a193abf723f9dee7b687d5d3e4d9c6b1c8c80f")
  (:PATH "docs/implementazione/controllore-pool.md" :GIT-BLOB
   "e22552b984aa27cfc53c279b00b0ef1bc3b91ecc")
  (:PATH "docs/implementazione/csn-archivio-recovery.md" :GIT-BLOB
   "3ea3be54ab4d0a50ed6ca9f91be92d4c749329d8")
  (:PATH "docs/implementazione/csn-decisioni.md" :GIT-BLOB
   "a2a8d5bba2c3da3ad6977d6a6f750e468d229693")
  (:PATH "docs/implementazione/csn-metodo.md" :GIT-BLOB
   "1aafc63fa8904a8504ec6fd42d34b606d6505677")
  (:PATH "docs/implementazione/csn-revisione.md" :GIT-BLOB
   "ac23ebc4c1d6ab57116def02bf4ad7df115394d1")
  (:PATH "docs/implementazione/csn-risultati.md" :GIT-BLOB
   "8fe4debab581640b3d1db74b6fa43610c8e547d2")
  (:PATH "docs/implementazione/csn.md" :GIT-BLOB
   "4d34d3381385253150251c9273a5f3d038aafabd")
  (:PATH "docs/implementazione/decisioni-multiserie-decisioni.md" :GIT-BLOB
   "bc99cae302da8bb90c208cfc0d5def111e945269")
  (:PATH "docs/implementazione/decisioni-multiserie-metodo.md" :GIT-BLOB
   "79755fdc3fcc8cdc8459d0cf3d108d06e577bf3f")
  (:PATH "docs/implementazione/decisioni-multiserie.md" :GIT-BLOB
   "c3467fd1f58d977797821581ff127bfb2cfdd5cf")
  (:PATH "docs/implementazione/decisioni-radix-decisioni.md" :GIT-BLOB
   "a0953cd3789ec80e22ec33f445510db6769ad2ed")
  (:PATH "docs/implementazione/decisioni-radix-lettura-autore.md" :GIT-BLOB
   "4474e5ced93e129bae0ae13255e2c56363334f20")
  (:PATH "docs/implementazione/decisioni-radix-metodo.md" :GIT-BLOB
   "5f8fa54b5df938dc51ea2053298baa58413d7e5a")
  (:PATH "docs/implementazione/decisioni-radix-revisione.md" :GIT-BLOB
   "4434a2412cbcc6bab1bc5292331eb2c2eeabeb6a")
  (:PATH "docs/implementazione/decisioni-radix-risultati.md" :GIT-BLOB
   "ae05757ce562c9b2eb5632765cc9da4db8c2fe56")
  (:PATH "docs/implementazione/decisioni-recuperate-revisione.md" :GIT-BLOB
   "3021ee42487972c7eada38b31a3fecaf298a5ff4")
  (:PATH "docs/implementazione/decisioni-recuperate-verifica.md" :GIT-BLOB
   "06f61bdb74ed43eaf52651d41a6f85366c2f73c2")
  (:PATH "docs/implementazione/decisioni-recuperate.md" :GIT-BLOB
   "17802322cd67f981d31f3bc6728c1efe805b570c")
  (:PATH "docs/implementazione/epoche-e-reclaim.md" :GIT-BLOB
   "96a9d6be3614715a434ecfec5808375e06ff6468")
  (:PATH "docs/implementazione/evidenze-parallele.md" :GIT-BLOB
   "98a542ddf7a51a0841d72e931706701c18d8f0c2")
  (:PATH "docs/implementazione/fondazioni-binarie.md" :GIT-BLOB
   "a64f148cb2254e87c649bb16e7bee39aa45eb40d")
  (:PATH "docs/implementazione/fondazioni-decisioni.md" :GIT-BLOB
   "a1631f582d8b3ecaa177cccead8c1e3d0051a822")
  (:PATH "docs/implementazione/fonti-recovery-metodo.md" :GIT-BLOB
   "4e53c912c6ce43b12b3906d298d12205621c08f4")
  (:PATH "docs/implementazione/fonti-recovery.md" :GIT-BLOB
   "91f8c45a10b8ba7dede0a8ebeb1af6a3062ba6c2")
  (:PATH "docs/implementazione/full-text-codec-decisioni.md" :GIT-BLOB
   "1ea5bed7d728efc7495f6e263db3e65fce59381d")
  (:PATH "docs/implementazione/full-text-codec.md" :GIT-BLOB
   "eb7be4924fcc8353b93e97a1ce2ee2ad95e2cfe2")
  (:PATH "docs/implementazione/full-text-decisioni.md" :GIT-BLOB
   "72023e48fac48c6b607744ac4f7fea74922e18c2")
  (:PATH "docs/implementazione/full-text-documenti-decisioni.md" :GIT-BLOB
   "1a1c3ed21978561e8e0f38718ac84e15c1c06540")
  (:PATH "docs/implementazione/full-text-documenti.md" :GIT-BLOB
   "29cad1d30ea2461f9f0afa52df515b86f2badb32")
  (:PATH "docs/implementazione/full-text-put-metodo.md" :GIT-BLOB
   "3b3ae582b30aec20d12e769c9b55655076003bce")
  (:PATH "docs/implementazione/full-text-put.md" :GIT-BLOB
   "a4a1ca03c0ecf8f140e4cddc8cf8a343048ab388")
  (:PATH "docs/implementazione/full-text-riferimenti-metodo.md" :GIT-BLOB
   "62a93dc03c5cce6601d2affd7998f00d497ed7cf")
  (:PATH "docs/implementazione/full-text-riferimenti.md" :GIT-BLOB
   "f82c3b3f7616f128fd5fbf7a334451405e23e1fe")
  (:PATH "docs/implementazione/full-text-righe-metodo.md" :GIT-BLOB
   "90798c4149cda0a26693b3c03a2ba29b36f356bc")
  (:PATH "docs/implementazione/full-text-righe.md" :GIT-BLOB
   "b4f33b71a0c737135e6d545c3d11e1cf81447ec1")
  (:PATH "docs/implementazione/full-text-riserve-metodo.md" :GIT-BLOB
   "43e3f20e580e69629352160621139ccc8907e6c8")
  (:PATH "docs/implementazione/full-text-riserve.md" :GIT-BLOB
   "417263600d172e918cff3ff4ff704e9fc04b3cab")
  (:PATH "docs/implementazione/full-text.md" :GIT-BLOB
   "a880105f9911fe04366359e5cc1619299d81ffe1")
  (:PATH "docs/implementazione/get-active-metodo.md" :GIT-BLOB
   "f5b5b4554c17737bf3db725907bc5990ad46b40c")
  (:PATH "docs/implementazione/get-active-preflight-metodo.md" :GIT-BLOB
   "27c1b922ea41ccb9d1e627328003b90ed86fd459")
  (:PATH "docs/implementazione/get-active-preflight-verifica.md" :GIT-BLOB
   "6df5bed5a7dac4ea53db4c7359ac4c869aff8c93")
  (:PATH "docs/implementazione/get-active-verifica.md" :GIT-BLOB
   "bb55922c280edeb5b714b6d0ecd7cbb026b583d8")
  (:PATH "docs/implementazione/get-active-vuoto.md" :GIT-BLOB
   "c593d25bdee6d29d0eb99e32687153d52636ccde")
  (:PATH "docs/implementazione/get-active.md" :GIT-BLOB
   "dcde23e5fef0237eb003b24c44fb0a9386bdad68")
  (:PATH "docs/implementazione/get-directory-metodo.md" :GIT-BLOB
   "69e50510426fa53d230b64b89da9e64fdc5c6efa")
  (:PATH "docs/implementazione/get-directory-mutazioni.md" :GIT-BLOB
   "542584f7ea490cc7b4639ee42969c17f52a8e559")
  (:PATH "docs/implementazione/get-directory-revisione.md" :GIT-BLOB
   "204a995d2152620792e923275de5abcc5e29bfb3")
  (:PATH "docs/implementazione/get-directory.md" :GIT-BLOB
   "550afaffd56bdaa4b5a16337432ec9ccf655d377")
  (:PATH "docs/implementazione/get-fonti-serie-metodo.md" :GIT-BLOB
   "76ca65cb32040dcf98ca9599d40dfb2f1d4a217e")
  (:PATH "docs/implementazione/get-fonti-serie-revisione.md" :GIT-BLOB
   "a8ac6d02893d0fc74093c1fe42319cdef8adbe4f")
  (:PATH "docs/implementazione/get-fonti-serie.md" :GIT-BLOB
   "fe7dd543a6a8b8a9cdbfd59bef8040a36463aa37")
  (:PATH "docs/implementazione/get-lifetime.md" :GIT-BLOB
   "da763b5ae02443beb467f5834471bb3345725be0")
  (:PATH "docs/implementazione/get-performance-metodo.md" :GIT-BLOB
   "ee84732af73d4d753b211bd9cd33f9c7dd1d2a3f")
  (:PATH "docs/implementazione/get-performance-revisione.md" :GIT-BLOB
   "3932b391102e3b7e0ead521a1fb223ef5ca2129a")
  (:PATH "docs/implementazione/get-record.md" :GIT-BLOB
   "058623adabd6a98f7d7617c4c1ac4fd0b7bce825")
  (:PATH "docs/implementazione/get-resolver-metodo.md" :GIT-BLOB
   "31b568cfe4db29d5d4c6d6d4de82dd0f54747f23")
  (:PATH "docs/implementazione/get-resolver-verifica.md" :GIT-BLOB
   "7751ad4582bf2d9b5402c2430c2aaeb5a6d713bf")
  (:PATH "docs/implementazione/get-resolver.md" :GIT-BLOB
   "a991a37b6a5460941170bce7d951eb86888abe4f")
  (:PATH "docs/implementazione/get-verifica.md" :GIT-BLOB
   "acc39ebcd47f56d31d5ddcf9843ebf8543424f22")
  (:PATH "docs/implementazione/hash-chiavi-decisioni.md" :GIT-BLOB
   "a6b480a9726002150f65443b9a3c97c9039f2012")
  (:PATH "docs/implementazione/hash-chiavi-metodo.md" :GIT-BLOB
   "c799f6cd5399c37daa1687cd0d154ebcfac2cb39")
  (:PATH "docs/implementazione/hash-chiavi-revisione.md" :GIT-BLOB
   "d9de17c5fcd7e7f21555c68db8f3eaa7d7e1b158")
  (:PATH "docs/implementazione/hash-chiavi-risultati.md" :GIT-BLOB
   "b7c4c84c6d688015a43f81b476e58744fbf5d467")
  (:PATH "docs/implementazione/hash-chiavi.md" :GIT-BLOB
   "f103ded38e6cb575820d7fb89d72e47b9fc16693")
  (:PATH "docs/implementazione/header-log-metodo.md" :GIT-BLOB
   "d09dc4f0914935805770cf148cfab99b1ca30eb1")
  (:PATH "docs/implementazione/header-log.md" :GIT-BLOB
   "ac29588884b2f12f2bd67a72f04504d88c2d44a0")
  (:PATH "docs/implementazione/id-directory-recovery.md" :GIT-BLOB
   "207890b1e6ed707e659ae84332b0e87f9e38db1e")
  (:PATH "docs/implementazione/id-segmento-recovery.md" :GIT-BLOB
   "3d7edda639a13ccfdcb7152e2ed823645a5b0f69")
  (:PATH "docs/implementazione/indice-automatico-risultati.md" :GIT-BLOB
   "4d164ab2cc720912c64e7b5ad2dfca4310c7b930")
  (:PATH "docs/implementazione/indice-automatico.md" :GIT-BLOB
   "10900ea8dc3c630dd973bb4e59ede9bff6794908")
  (:PATH "docs/implementazione/indice-da-recovery.md" :GIT-BLOB
   "e3ff0eb2a7f56eca5ed2154722f8bc1c6ad53b74")
  (:PATH "docs/implementazione/indice-primario.md" :GIT-BLOB
   "d4382b97ee69a12235f4c1d445b9b13dd5440684")
  (:PATH "docs/implementazione/indice-ricostruzione-benchmark-metodo.md"
   :GIT-BLOB "4dc9aa9bdfdd5e21a2ef2bf6ab6fc8d2e111a586")
  (:PATH "docs/implementazione/indice-ricostruzione-revisione.md" :GIT-BLOB
   "c88785115dfda86f3e6ce425487638fe514f0e3b")
  (:PATH "docs/implementazione/indice-ricostruzione.md" :GIT-BLOB
   "1950d3f3b38736f7d32e1c3a24fb217bd1dffc86")
  (:PATH "docs/implementazione/inizializzazione-active.md" :GIT-BLOB
   "9631575af9819aa4a98472359393b36bdcde3dc9")
  (:PATH "docs/implementazione/inventario-decisioni.md" :GIT-BLOB
   "a220b68f94b35c81b9bca4420453c4057eded097")
  (:PATH "docs/implementazione/inventario-directory-metodo.md" :GIT-BLOB
   "366ee617039bc6a67de4c989d7df961941854340")
  (:PATH "docs/implementazione/inventario-directory-revisione.md" :GIT-BLOB
   "3c99eb90b20685bad8be3d988553feef589c9132")
  (:PATH "docs/implementazione/inventario-metodo.md" :GIT-BLOB
   "37ff4f5316483960508fa78df1f890ebaff8942e")
  (:PATH "docs/implementazione/inventario.md" :GIT-BLOB
   "deb47c12394f71f9b7efce689912c066b2d2fba5")
  (:PATH "docs/implementazione/io-apertura-relativa-metodo.md" :GIT-BLOB
   "13e7ab0d6eadf2b5188a27bd7049fdf7c4a3dc4d")
  (:PATH "docs/implementazione/io-apertura-relativa-revisione.md" :GIT-BLOB
   "6b66aca0e2bbe154157f4fd07c9fdbc408ffc427")
  (:PATH "docs/implementazione/io-apertura-relativa.md" :GIT-BLOB
   "2673370f421e8bbb5bf788b05a0be138e722ef6a")
  (:PATH "docs/implementazione/io-completamento.md" :GIT-BLOB
   "9e4aef21c7d550b1b26f5811ad2620440834111b")
  (:PATH "docs/implementazione/io-creazione-relativa-metodo.md" :GIT-BLOB
   "0bf34d8a6bda7c480878c858017823e3a60bcce0")
  (:PATH "docs/implementazione/io-creazione-relativa-revisione.md" :GIT-BLOB
   "f14a49852ea6dadeb750bb6621eee702ad4d4783")
  (:PATH "docs/implementazione/io-creazione-relativa.md" :GIT-BLOB
   "25e7d55ed83df48bf5e80d227f00d8733593a3d4")
  (:PATH "docs/implementazione/io-decisioni.md" :GIT-BLOB
   "476e35fca8858a4a4eed163e4a3a42c7ce38bd4a")
  (:PATH "docs/implementazione/io-metodo.md" :GIT-BLOB
   "550c69493fdb363631b83dea4fff765119b6ad5f")
  (:PATH "docs/implementazione/io-pubblicazione-metodo.md" :GIT-BLOB
   "dfeeef612f9001657ae79c9fee0d6daa38af72fa")
  (:PATH "docs/implementazione/io-pubblicazione.md" :GIT-BLOB
   "83359ed1ce8d0f7438c60f1ef6df99e5b94c7ec1")
  (:PATH "docs/implementazione/io-rinomina.md" :GIT-BLOB
   "93c4489ca3f597cb44b5c66d2bc92ca9cda80eb9")
  (:PATH "docs/implementazione/io.md" :GIT-BLOB
   "60bf873451259cd1dd2cf31cad3122195fffdad1")
  (:PATH "docs/implementazione/lettura-verifica.md" :GIT-BLOB
   "656e8162bd3833268a6243e136c2e46b39e548f5")
  (:PATH "docs/implementazione/manifest-control-log-decisioni.md" :GIT-BLOB
   "f779f81d41748e3e9b10596dc9af12b334d4dc23")
  (:PATH "docs/implementazione/manifest-control-log-metodo.md" :GIT-BLOB
   "f755abc620aaad10470143418702e883baf2493a")
  (:PATH "docs/implementazione/manifest-control-log.md" :GIT-BLOB
   "e89ce752e566bd81d276825387514b1f6272b3db")
  (:PATH "docs/implementazione/merge-main-2026-10-23.md" :GIT-BLOB
   "66719ae7c7af0aa4ced66e6046c3d88326116230")
  (:PATH "docs/implementazione/metadati-storage-decisioni.md" :GIT-BLOB
   "cb473b09149385d5d32bb44db1478e5ba7da7640")
  (:PATH "docs/implementazione/metadati-storage-metodo.md" :GIT-BLOB
   "23966839673d2e5931f1822c0c2e0302a189911a")
  (:PATH "docs/implementazione/metadati-storage.md" :GIT-BLOB
   "1b746fefc25d8cd1be1bb44611c7ac5f98e8acb1")
  (:PATH "docs/implementazione/orizzonte-csn.md" :GIT-BLOB
   "c451a24e86e98a2dd3a75cfbae55260625b33dc8")
  (:PATH "docs/implementazione/pagine-indice-risultati.md" :GIT-BLOB
   "b407283c51cca71a1d8d901bceda5741dd271b89")
  (:PATH "docs/implementazione/pagine-indice.md" :GIT-BLOB
   "2d049322290ae12a509d890adf51942f1b03dc71")
  (:PATH "docs/implementazione/pool-begin-metodo.md" :GIT-BLOB
   "0a74eac283903d32bb75e108e95a06462a7f91bd")
  (:PATH "docs/implementazione/pool-begin-revisione.md" :GIT-BLOB
   "10b9ab81741576c65c7862093f0cdc88d1c61de8")
  (:PATH "docs/implementazione/pool-begin-risultati.md" :GIT-BLOB
   "d16baa7861d275df6cae21ddeaf4591617d5c2fc")
  (:PATH "docs/implementazione/pool-begin.md" :GIT-BLOB
   "e0e62896ea19af459f528060672729864f27133a")
  (:PATH "docs/implementazione/pool-catena-metodo.md" :GIT-BLOB
   "c6affaba71aedd2f1e1ac900f01755bcfab90ce6")
  (:PATH "docs/implementazione/pool-catena-risultati.md" :GIT-BLOB
   "3d6b448db14dae6485efcc73de7a49ef85043c22")
  (:PATH "docs/implementazione/pool-dispatch-metodo.md" :GIT-BLOB
   "d94f69542c7685c30f91899889ce7dbb12783a15")
  (:PATH "docs/implementazione/pool-dispatch-revisione.md" :GIT-BLOB
   "33a30b807c66ec62c47fea6124c65126f693c91d")
  (:PATH "docs/implementazione/pool-dispatch-risultati.md" :GIT-BLOB
   "e1eccf0084fccf4c5dd45ef5ab8614618d9e94b4")
  (:PATH "docs/implementazione/pool-dispatch.md" :GIT-BLOB
   "b539520e7efdfad99de69e1473170db427f27031")
  (:PATH "docs/implementazione/pool-prepara-metodo.md" :GIT-BLOB
   "1adf298ac2b0cbcb211f622c5e83cab4e84efbff")
  (:PATH "docs/implementazione/pool-prepara-revisione.md" :GIT-BLOB
   "2eb452c647d55eaa9acb18c2960fd28885735168")
  (:PATH "docs/implementazione/pool-prepara-risultati.md" :GIT-BLOB
   "f0d2ce8787a3228a35e5bde6d3d8f7e805e5b164")
  (:PATH "docs/implementazione/pool-prepara.md" :GIT-BLOB
   "14ff3e1b5cc133a64beace7e116cb850fafb7858")
  (:PATH "docs/implementazione/pool-recycle-metodo.md" :GIT-BLOB
   "023722e1a91e1c0826867fe204eeb9eab72dc72e")
  (:PATH "docs/implementazione/pool-recycle-revisione.md" :GIT-BLOB
   "fd875bca51e4fd0d58251c123cadb6417e82bd76")
  (:PATH "docs/implementazione/pool-recycle-risultati.md" :GIT-BLOB
   "05a9218c57f7f2363925a2bb821f68cdd66b9681")
  (:PATH "docs/implementazione/pool-recycle.md" :GIT-BLOB
   "c38c4f50f84907b380e9f57e291c9f8503efc5c2")
  (:PATH "docs/implementazione/pool-step-metodo.md" :GIT-BLOB
   "b86c360abb0cc4349e4831bf3ba91c1c7a72d386")
  (:PATH "docs/implementazione/pool-step-revisione.md" :GIT-BLOB
   "f16e3beb60d31637d25a07a6d585528bc1ecc6dc")
  (:PATH "docs/implementazione/pool-step-risultati.md" :GIT-BLOB
   "8c41c836edf57e6dfca0a161bed55372c442e76d")
  (:PATH "docs/implementazione/pool-step.md" :GIT-BLOB
   "fc764576920a560b0ec6cdac9800b876191b42f6")
  (:PATH "docs/implementazione/pool-worker-claim-metodo.md" :GIT-BLOB
   "35575db9de839268157d59f2d5cd9de776d46abf")
  (:PATH "docs/implementazione/pool-worker-claim-revisione.md" :GIT-BLOB
   "c2703de72d08d7d0c66a5a45ac587d7c763ca598")
  (:PATH "docs/implementazione/pool-worker-claim-risultati.md" :GIT-BLOB
   "d1b07131d0ef3f831f86860ba6258f6bbc24b799")
  (:PATH "docs/implementazione/pool-worker-claim.md" :GIT-BLOB
   "02681055d4c93e109c70e72cf094fd87a2a8b9e5")
  (:PATH "docs/implementazione/pool-worker-lifecycle-metodo.md" :GIT-BLOB
   "598212501b1d8ecff6b4c90c0f04d551df2ff043")
  (:PATH "docs/implementazione/pool-worker-lifecycle-revisione.md" :GIT-BLOB
   "ce1cbddbfe9605c4eae9a5bcacf3a96d35d344b5")
  (:PATH "docs/implementazione/pool-worker-lifecycle-risultati.md" :GIT-BLOB
   "d3c3c91217d83796fdcd86ae9fbaed5a613c3864")
  (:PATH "docs/implementazione/pool-worker-lifecycle.md" :GIT-BLOB
   "e45c6941e0534180995d60f8882629b427f06f01")
  (:PATH "docs/implementazione/production-engine-bootstrap-metodo.md" :GIT-BLOB
   "e5e3ff0b37f99a2d9e6963a2a7820bf23b0719e2")
  (:PATH "docs/implementazione/production-engine-bootstrap.md" :GIT-BLOB
   "542294cfb5e3114366d6663c921addbe840d6861")
  (:PATH "docs/implementazione/production-unix-m1.md" :GIT-BLOB
   "46bc78baf7b0f4ee52f4f669e42187e00043f139")
  (:PATH "docs/implementazione/prova-verticale.md" :GIT-BLOB
   "797aff287aed7a8d195f04d0dae705680cb76de5")
  (:PATH "docs/implementazione/pubblicazione-control.md" :GIT-BLOB
   "bcf1d925ed557af099405f3c00fa12cf66429c56")
  (:PATH "docs/implementazione/raccolta-comandi-risultati.md" :GIT-BLOB
   "e653875dcf306897bd279f4954c36518dda7e7c8")
  (:PATH "docs/implementazione/raccolta-comandi.md" :GIT-BLOB
   "414f76917ff5c0f7ce2914d9f3be8ba9ac7fc9da")
  (:PATH "docs/implementazione/recovery-archivio.md" :GIT-BLOB
   "4d8c79c6a19463e4a34ef187f2589ae39e0126eb")
  (:PATH "docs/implementazione/recovery-csn.md" :GIT-BLOB
   "b2d8cd7bd92c871500432935e79b400ecc70b1ab")
  (:PATH "docs/implementazione/recovery-serie.md" :GIT-BLOB
   "8c910a172eda549fbdcecf8f269d895fcc3b9b01")
  (:PATH "docs/implementazione/registro-snapshot.md" :GIT-BLOB
   "096b16489aa910182fe01349aa5552ccc1ccd446")
  (:PATH "docs/implementazione/replay-closed.md" :GIT-BLOB
   "78a3700751a8dfdd81e51508027dd7a0f84df2c8")
  (:PATH "docs/implementazione/risultati/2026-10-08-benchmark.lisp" :GIT-BLOB
   "2d404302bc9dd73a3d453d2f32ee9d38b795b25c")
  (:PATH "docs/implementazione/risultati/2026-10-08-copertura.lisp" :GIT-BLOB
   "d2dea0f2d5f23f4b10bbf8f721bd2316d0f74449")
  (:PATH "docs/implementazione/risultati/2026-10-08-mutazioni.lisp" :GIT-BLOB
   "342fcd80e236d28bbf49d44b76278fdfa7099f6d")
  (:PATH "docs/implementazione/routing-worker-decisioni.md" :GIT-BLOB
   "f77e4acc65f3582d76bee6867e7a728757a98d4c")
  (:PATH "docs/implementazione/routing-worker-metodo.md" :GIT-BLOB
   "b6c4a6992ef5ca707c19e08dfbdc7d1e01e1e900")
  (:PATH "docs/implementazione/routing-worker-revisione.md" :GIT-BLOB
   "6fbe1f002e3e18df09a964292f27c3657bb46004")
  (:PATH "docs/implementazione/routing-worker-risultati.md" :GIT-BLOB
   "b275c083f9705d1ed32b4cf282fd0c12c39d98a2")
  (:PATH "docs/implementazione/routing-worker.md" :GIT-BLOB
   "3c2423f187253e7c2c83b3848c7efbd43d269641")
  (:PATH "docs/implementazione/runtime-archivio-revisione.md" :GIT-BLOB
   "9b6f224e4b30df6dce02d77e901d0c4c7e077cd8")
  (:PATH "docs/implementazione/runtime-archivio.md" :GIT-BLOB
   "9eee28d5a66d5fbc822d305381c75874c4c347e4")
  (:PATH "docs/implementazione/scansione-log-decisioni.md" :GIT-BLOB
   "c7780a6798cec4964badc6a5529508898ae4945c")
  (:PATH "docs/implementazione/scansione-log.md" :GIT-BLOB
   "bbc3431b5872adfdee0e23d566caf7d2172a971a")
  (:PATH "docs/implementazione/segmenti-compattati-metodo.md" :GIT-BLOB
   "8101b2da12ae1a60a0663b11ab70590a96c5bcf2")
  (:PATH "docs/implementazione/segmenti-compattati.md" :GIT-BLOB
   "99cf34e5c5c3875ed97414c30ec9b7bef96d30b4")
  (:PATH "docs/implementazione/selezione-versioni-recovery.md" :GIT-BLOB
   "eae7073945c0732696381a2b5147d0a4321f72b8")
  (:PATH "docs/implementazione/sessione-locale.md" :GIT-BLOB
   "3f3710dd36e0af45dd057fd6d774edee3911e69f")
  (:PATH "docs/implementazione/slot-indice-v2.md" :GIT-BLOB
   "0a534e557a3fe8216e0d5fbfc84c354255d081ac")
  (:PATH "docs/implementazione/snapshot-csn.md" :GIT-BLOB
   "d17e9e45a1d4896249d11f2bd474aa05af5222cb")
  (:PATH "docs/implementazione/snapshot-verifica.md" :GIT-BLOB
   "805c6b231d9fd7223ef1b149e75e9c3be0dd0859")
  (:PATH "docs/implementazione/stabilizzazione-archivio-metodo.md" :GIT-BLOB
   "9e03341a2e9bc0d16b7373a0b2652f312aa6a478")
  (:PATH "docs/implementazione/stabilizzazione-archivio.md" :GIT-BLOB
   "212931517e7e7c4e7c1f69a3c7e78f281d46d577")
  (:PATH "docs/implementazione/stabilizzazione-esclusiva-metodo.md" :GIT-BLOB
   "31cc08df54eea7c760e50c1517a384625ee46034")
  (:PATH "docs/implementazione/stabilizzazione-nomi-recovery.md" :GIT-BLOB
   "d31527cf2c0146f8e8bb28029fbcff1fbca00825")
  (:PATH "docs/implementazione/stabilizzazione-serie-metodo.md" :GIT-BLOB
   "e8a54f4e7be1995dd54e0101ae13a8c75672b676")
  (:PATH "docs/implementazione/stabilizzazione-serie.md" :GIT-BLOB
   "d607b2ee3757f200610e339e7e3a5207ff3198dc")
  (:PATH "docs/implementazione/utf8-decisioni.md" :GIT-BLOB
   "d6e2ad12c278d5bb26050c056df4342671c590f5")
  (:PATH "docs/implementazione/utf8-metodo.md" :GIT-BLOB
   "77d0c406a967ebe97f81781f9dd4cc9d68488ee4")
  (:PATH "docs/implementazione/utf8.md" :GIT-BLOB
   "1798cdf9b8916ba74b21d1d86442a49874938e41")
  (:PATH "docs/implementazione/wal-csn-decisioni.md" :GIT-BLOB
   "bc3121e6274d610f56155a1e159d0a8948ee87c5")
  (:PATH "docs/implementazione/wal-csn-metodo.md" :GIT-BLOB
   "73bfef0b478f57c9441a6d0e2ab59c0e7f223fef")
  (:PATH "docs/implementazione/wal-csn-revisione.md" :GIT-BLOB
   "89a767f226693292d6a934970010d6dc5f13bbe7")
  (:PATH "docs/implementazione/wal-csn-risultati.md" :GIT-BLOB
   "d7e1f6e6fd5baa3c0c345507b8c3cd7a71e47f33")
  (:PATH "docs/implementazione/wal-csn.md" :GIT-BLOB
   "497b96ba252c1d223b91c7a958af3a1de6e6bba9")
  (:PATH "docs/implementazione/wal-decisioni.md" :GIT-BLOB
   "4b9535873216af6a4ede0b3d6d31e80c466ad395")
  (:PATH "docs/implementazione/wal-metodo.md" :GIT-BLOB
   "6c46cebd54cacfe7b366932d1be6bd2132346087")
  (:PATH "docs/implementazione/wal.md" :GIT-BLOB
   "c9ec2a33ac47f9811f152032cc6232fb1ccb941a")
  (:PATH "docs/implementazione/worker-cbor-interleaving.md" :GIT-BLOB
   "3c35404cf60cddef14046eba1f99f215b3b3cc2f")
  (:PATH "docs/implementazione/worker-serie-decisioni.md" :GIT-BLOB
   "9cfa2d91655890f50c7a0d83cb14f0bbae650f21")
  (:PATH "docs/implementazione/worker-serie-integrazione.md" :GIT-BLOB
   "08c866115be68fd9e88c2d30fd111017851bbb53")
  (:PATH "docs/implementazione/worker-serie-metodo.md" :GIT-BLOB
   "df02aed3cd659b1b09e746d8315f54e32f526965")
  (:PATH "docs/implementazione/worker-serie-revisione.md" :GIT-BLOB
   "2d2ffb30c9051c58fd7f9b7efb27a487d1c0fd8e")
  (:PATH "docs/implementazione/worker-serie-risultati.md" :GIT-BLOB
   "76b2e79d012ebffcdde4477af9b19fb2e1e54e67")
  (:PATH "docs/implementazione/worker-serie.md" :GIT-BLOB
   "7e470b27c01de9fbfb4d4b532136760ec18afdad")
  (:PATH "docs/implementazione/writer-handoff-decisioni.md" :GIT-BLOB
   "5f0636cde6711769dc13bdaabefb55e6af843147")
  (:PATH "docs/implementazione/writer-handoff-metodo.md" :GIT-BLOB
   "f6eb25d050854b65daa7766d203b3e177dbc8f4a")
  (:PATH "docs/implementazione/writer-handoff-revisione.md" :GIT-BLOB
   "04f64ce2d33e27cc5d40482765223aa6dec062ea")
  (:PATH "docs/implementazione/writer-handoff-risultati.md" :GIT-BLOB
   "e4fa3bae3e265d1ca702c1ecc6aa8e44c676155e")
  (:PATH "docs/implementazione/writer-handoff.md" :GIT-BLOB
   "f76d0c995da17ae17ef8ccc6c68a3045ea461a73")
  (:PATH "docs/implementazione/writer-ready-decisioni.md" :GIT-BLOB
   "a92e30d229b4d76f6220a96ded2c46f4054544a4")
  (:PATH "docs/implementazione/writer-ready-metodo.md" :GIT-BLOB
   "c04cfa11a0b9edaf4b73a251845690cdbb3ee98c")
  (:PATH "docs/implementazione/writer-ready-revisione.md" :GIT-BLOB
   "caafe0a8685e4faf2215bebe5f37fd1a80683f93")
  (:PATH "docs/implementazione/writer-ready-risultati.md" :GIT-BLOB
   "1f01809c914084c4773dd184439d1cf599710f09")
  (:PATH "docs/implementazione/writer-ready.md" :GIT-BLOB
   "ef2ed1ac671dec6c7904174152fdd90dd03c4589")
  (:PATH "docs/implementazione/writer-recycle-decisioni.md" :GIT-BLOB
   "dfd353b4f7544d41a04d916abdb4a0aedaac2c3d")
  (:PATH "docs/implementazione/writer-recycle-metodo.md" :GIT-BLOB
   "b94583da79c1834c306118ebcc013c795b286ce1")
  (:PATH "docs/implementazione/writer-recycle-revisione.md" :GIT-BLOB
   "4d6ff67e6e78c550986e2e953ed8a9a5d8b4ee20")
  (:PATH "docs/implementazione/writer-recycle-risultati.md" :GIT-BLOB
   "db7e38f078621af681d9b5e523f4c91bf4801c6d")
  (:PATH "docs/implementazione/writer-recycle.md" :GIT-BLOB
   "ffd1c9ac47dcab5ab8c1c0301c0c04c3e2686b6e")
  (:PATH "docs/implementazione/writer-worker-decisioni.md" :GIT-BLOB
   "01109f06ce875665dffb11263b80f68a2d3c07ba")
  (:PATH "docs/implementazione/writer-worker-integrazione.md" :GIT-BLOB
   "3249fbcd44f2f2e76a14195461a3a4e43b3031ec")
  (:PATH "docs/implementazione/writer-worker-metodo.md" :GIT-BLOB
   "a12ac9c53969f6755c8cb0de21212f06e7e03e4b")
  (:PATH "docs/implementazione/writer-worker-revisione.md" :GIT-BLOB
   "f500b01def047de7973851144c8196036abf36bb")
  (:PATH "docs/implementazione/writer-worker-risultati.md" :GIT-BLOB
   "2e58b4d0e459495430a6cd1e9540994d8a25a0da")
  (:PATH "docs/implementazione/writer-worker.md" :GIT-BLOB
   "f134e4c3c3cfda195b324e7bb362948b67aa1fd5")
  (:PATH "docs/invarianti.md" :GIT-BLOB
   "534106974f25877b730e1a48d5cd3522bdbe959c")
  (:PATH "docs/limiti.md" :GIT-BLOB "ec2f27b68c809503c2f393f48b6633dc82ad8bc5")
  (:PATH "docs/principi-di-ingegneria.md" :GIT-BLOB
   "4bd3d55870e1b05b12a4a2287de6b5186f2d3b5d")
  (:PATH "docs/questioni-aperte.md" :GIT-BLOB
   "18fbaf5c89b9aa7e5ad460c0fa12d745bacb5bda")
  (:PATH "docs/roadmap.md" :GIT-BLOB
   "212947573e96b6d8ef42c1959667fa911bc72ff5")
  (:PATH "docs/specifica/specifica-originale.md" :GIT-BLOB
   "742c9309d02efe4238c859a3a7c6cd577240cdf2")
  (:PATH "docs/tracciabilita/README.md" :GIT-BLOB
   "70d45ea89536739989e90f7815ed8e89fc1544c6")
  (:PATH "docs/tracciabilita/matrice.md" :GIT-BLOB
   "c7d29d2d734d89899e41ea59801026bbc049a093")
  (:PATH "docs/tracciabilita/requisiti.lisp" :GIT-BLOB
   "07ba9092e7ec056040c9842299797b94aa3ee3ec")
  (:PATH "docs/valutazione/README.md" :GIT-BLOB
   "1d6f0361d14bbf2a79280ef51a866eddd420d655")
  (:PATH "docs/valutazione/analisi-critica.md" :GIT-BLOB
   "c5b7d4f08337ce5b0fa7096b872e21ca8c94462e")
  (:PATH "docs/valutazione/caso-duso-nntp.md" :GIT-BLOB
   "707902f3a4ff419be917a68b2c164cc1f537a988")
  (:PATH "docs/valutazione/conservazione-compatta.md" :GIT-BLOB
   "2709ceddf253b8a53c7726f2fcf33fc0c8d2ecff")
  (:PATH "docs/valutazione/piano-spike.md" :GIT-BLOB
   "fd3c652573a9232c55ae343583983a57d73d16c3")
  (:PATH "docs/valutazione/registro-delle-prove.md" :GIT-BLOB
   "d6421c9d4bd6779acb16af5037b8233ffb15b5d3")
  (:PATH "docs/valutazione/registro-rischi.md" :GIT-BLOB
   "dec33e57f31195ebf30c25d63f3f0a7a8ae5c759")
  (:PATH "docs/valutazione/risultati-2026-10-08.md" :GIT-BLOB
   "0fa9272a2986414342a107ae4c1e5fbde3720958")
  (:PATH "docs/valutazione/risultati-SPK-01-lettura-2026-10-08.md" :GIT-BLOB
   "9647505f8a2ae9cf74348487e9648a6c0dd5d252")
  (:PATH "docs/valutazione/risultati-SPK-04-2026-10-08.md" :GIT-BLOB
   "25d94d78061e6c68007e4316aca4cdc60f9de610")
  (:PATH "docs/valutazione/risultati-SPK-05-2026-10-08.md" :GIT-BLOB
   "a95cb4392328411d9f17c334c149d9c029535102")
  (:PATH "docs/valutazione/risultati-SPK-06-2026-10-08.md" :GIT-BLOB
   "679e74cf6c8051dd57ea1f2fa0584c46aaef47e2")
  (:PATH "docs/valutazione/risultati-SPK-07-08-2026-10-08.md" :GIT-BLOB
   "e8af15a00e7178168116c0138027e820c07e598c")
  (:PATH "docs/valutazione/risultati-SPK-08-bitmap-2026-10-08.md" :GIT-BLOB
   "139d030b0125b61aad567263b7b7db95e830e927")
  (:PATH "docs/valutazione/stime-ordine-di-grandezza.md" :GIT-BLOB
   "2b8c5e98a2f55bc73f2167bb05fde73e09c07a85")
  (:PATH "spikes/README.md" :GIT-BLOB
   "d350aa6335a0f1c76d76ffde25b35ccbb837a199")
  (:PATH "spikes/SPK-01-primary-index/README.md" :GIT-BLOB
   "81c46b7e0a82ca474857d5e5de01dc43c0572bf1")
  (:PATH "spikes/SPK-01-primary-index/bench-lettura-buffer.lisp" :GIT-BLOB
   "2fd1b13855a94dc946f9f1b5e1c7556558b7e0c0")
  (:PATH "spikes/SPK-01-primary-index/check-lettura-buffer.lisp" :GIT-BLOB
   "fd32c5260ffb7c6e96cf1a420765eb01effe70bc")
  (:PATH "spikes/SPK-01-primary-index/core.lisp" :GIT-BLOB
   "c019f6ad53e173a0d336a4dbfaf903e274a66f08")
  (:PATH "spikes/SPK-01-primary-index/lettura-buffer.lisp" :GIT-BLOB
   "34b3574a554ca4e03a34f04b3fc66022abb7893b")
  (:PATH "spikes/SPK-01-primary-index/metodo-bench-lettura-buffer.md" :GIT-BLOB
   "1683f3951361ad60dea42821451a4bea35147b6c")
  (:PATH "spikes/SPK-01-primary-index/metodo-check-lettura-buffer.md" :GIT-BLOB
   "19840c3a15271323546259e5c0aafd7d13489681")
  (:PATH "spikes/SPK-01-primary-index/metodo-integrazione-lettura-buffer.md"
   :GIT-BLOB "54a1982bd08ac27197c3266bb2f883aab405f705")
  (:PATH "spikes/SPK-01-primary-index/metodo-lettura-buffer.md" :GIT-BLOB
   "f7d9674884267ad4d22f962c762e1995b749fb44")
  (:PATH "spikes/SPK-01-primary-index/profile.lisp" :GIT-BLOB
   "a71fde100e32072b6e7b010228683b640ea4ff9a")
  (:PATH "spikes/SPK-01-primary-index/run.lisp" :GIT-BLOB
   "b6e680b0c2d1a96c1d7fc3b0e133c80b6564a01e")
  (:PATH "spikes/SPK-02-gc/README.md" :GIT-BLOB
   "f8480d84bb8e932e0a17719c779ea54709c3c3f4")
  (:PATH "spikes/SPK-02-gc/core.lisp" :GIT-BLOB
   "01f6760c75fa6e96a480fca41b1426941a9f703d")
  (:PATH "spikes/SPK-02-gc/run.lisp" :GIT-BLOB
   "9fbe499100da40c2f7a14072af67c35c734949c5")
  (:PATH "spikes/SPK-03-group-commit/README.md" :GIT-BLOB
   "1c6ae01e442bd3c4d8c829006647aaa59ae1a185")
  (:PATH "spikes/SPK-03-group-commit/core.lisp" :GIT-BLOB
   "d3c58f2866e299ba27b0fa820c20317438774410")
  (:PATH "spikes/SPK-03-group-commit/run.lisp" :GIT-BLOB
   "c0b093e87028dd587c43d3cd52e59492270fdc38")
  (:PATH "spikes/SPK-04-writer-pool/README.md" :GIT-BLOB
   "91732544806c231b77dcbddc9a2e4460a12873ec")
  (:PATH "spikes/SPK-04-writer-pool/core.lisp" :GIT-BLOB
   "557b32e6378290c46c7d9b128fc8e59a0e7e0a44")
  (:PATH "spikes/SPK-04-writer-pool/parcheggi.lisp" :GIT-BLOB
   "c0fee7b738395fcaf3359f297282cd266ce6dfad")
  (:PATH "spikes/SPK-04-writer-pool/pool.lisp" :GIT-BLOB
   "cbec51aad2b64fb8c5be026891eff859ba371c18")
  (:PATH "spikes/SPK-04-writer-pool/run.lisp" :GIT-BLOB
   "77056cc1f695574ed0f4d34795b99aaea736f378")
  (:PATH "spikes/SPK-05-segment-read/README.md" :GIT-BLOB
   "16ebc31ba682d36cf3520086d43f35a310159bec")
  (:PATH "spikes/SPK-05-segment-read/core.lisp" :GIT-BLOB
   "15fad418184ce9969c337b181317b855ede9f5ce")
  (:PATH "spikes/SPK-05-segment-read/io.lisp" :GIT-BLOB
   "ba470bce3cae0ce14888dbec6e26c5656e9bbd1a")
  (:PATH "spikes/SPK-05-segment-read/record.lisp" :GIT-BLOB
   "baea7833c8e6f9a49b5ea2f8ee15f76fe35f93fe")
  (:PATH "spikes/SPK-05-segment-read/run.lisp" :GIT-BLOB
   "c67a3ae8e672f96d9105deb935fb621b07d67afb")
  (:PATH "spikes/SPK-06-compaction-load/README.md" :GIT-BLOB
   "e5d56bb99d2bae3867cacd19d18711f35e6ff8db")
  (:PATH "spikes/SPK-06-compaction-load/controllore.lisp" :GIT-BLOB
   "4602972e2400d31d4d3b771f60703c68e23f0804")
  (:PATH "spikes/SPK-06-compaction-load/core.lisp" :GIT-BLOB
   "375cb97e1490e0252c04fd1a3076a17342cefd68")
  (:PATH "spikes/SPK-06-compaction-load/interferenza.lisp" :GIT-BLOB
   "9ad30ce92bdb643aeb5163e96508bf677996a4ef")
  (:PATH "spikes/SPK-06-compaction-load/run.lisp" :GIT-BLOB
   "b2863cbac49d0988b850bdeeae1713108a21bfca")
  (:PATH "spikes/SPK-07-protocols/README.md" :GIT-BLOB
   "2eca7df2fd82994b4ad13ff58f72ab5efb9edc3a")
  (:PATH "spikes/SPK-07-protocols/byte-crash.lisp" :GIT-BLOB
   "66a6c3b458d808fc214f7c3bd96e09d239312c67")
  (:PATH "spikes/SPK-07-protocols/compaction.lisp" :GIT-BLOB
   "93483f72f3bfe43f0e2afa93b022892114a824e1")
  (:PATH "spikes/SPK-07-protocols/core.lisp" :GIT-BLOB
   "489e2732cf5bfed4cd11251bb686a5d4f4e10b3e")
  (:PATH "spikes/SPK-07-protocols/memoria.lisp" :GIT-BLOB
   "96b6cf64d481643cdba7857f339a7cb7c029b765")
  (:PATH "spikes/SPK-07-protocols/metodo-byte-crash.md" :GIT-BLOB
   "ea4feea4edb0e4a1dd7ad357419b6bf97b415f50")
  (:PATH "spikes/SPK-07-protocols/metodo-compaction.md" :GIT-BLOB
   "51be4a3beb85262d453bd6b283a3b31378615fe7")
  (:PATH "spikes/SPK-07-protocols/metodo-memoria.md" :GIT-BLOB
   "f23f9ecd889437c83c946c88f2bf56a45a73f3ab")
  (:PATH "spikes/SPK-07-protocols/metodo-page-lifetime.md" :GIT-BLOB
   "e316c7eaade10d6dbe72c3fcb66ce294d66d8c67")
  (:PATH "spikes/SPK-07-protocols/metodo-pubblicazione.md" :GIT-BLOB
   "bbeac271ff79f96c0f69d22c60a045a4bfec8f09")
  (:PATH "spikes/SPK-07-protocols/metodo-scadenza.md" :GIT-BLOB
   "9d97ed258355e5afd21edfc1820ee6d68137a02c")
  (:PATH "spikes/SPK-07-protocols/metodo-seqlock-readers.md" :GIT-BLOB
   "729f3500b4f427612b39c02f210c4ac25f45c805")
  (:PATH "spikes/SPK-07-protocols/page-lifetime.lisp" :GIT-BLOB
   "c032387167188be066737f75583738843b12c883")
  (:PATH "spikes/SPK-07-protocols/pubblicazione.lisp" :GIT-BLOB
   "d317849b3f95394a7f604b82fb131495b5b3770c")
  (:PATH "spikes/SPK-07-protocols/run-module.lisp" :GIT-BLOB
   "1ec5a1db56a76daacbc7488d8b7940aa0e16eca0")
  (:PATH "spikes/SPK-07-protocols/run.lisp" :GIT-BLOB
   "95ab6095de30d013dbf5c426f7b6c0a99d5663e6")
  (:PATH "spikes/SPK-07-protocols/scadenza.lisp" :GIT-BLOB
   "05a5e93591e2d6e96c2c7548e90888424cbb1f9f")
  (:PATH "spikes/SPK-07-protocols/seqlock-readers.lisp" :GIT-BLOB
   "b2e704bbe7e699b9df68173319f64d2ae8abc5fc")
  (:PATH "spikes/SPK-07-protocols/suite.lisp" :GIT-BLOB
   "9daf0b57d92db583544653384217105121c8627d")
  (:PATH "spikes/SPK-08-generated-code/README.md" :GIT-BLOB
   "787fa26b0526e179148e958136d709e74c63ba3a")
  (:PATH "spikes/SPK-08-generated-code/bitmap.lisp" :GIT-BLOB
   "cbeff7e2a58f268291b01cb6a1f124533063d5d6")
  (:PATH "spikes/SPK-08-generated-code/comparison.lisp" :GIT-BLOB
   "b8b8ebfa609d6bfe9b710833f22cdff693ef46bd")
  (:PATH "spikes/SPK-08-generated-code/core-bitmap.lisp" :GIT-BLOB
   "a4be2005a702a77a631f35568778673c503c60b5")
  (:PATH "spikes/SPK-08-generated-code/impronte.lisp" :GIT-BLOB
   "d187e3d95f0e85a0a8ae84843a67a326e803cd2c")
  (:PATH "spikes/SPK-08-generated-code/metodo-bitmap.md" :GIT-BLOB
   "6b3bc87d5700e52ca6b861fa562c2b7958248887")
  (:PATH "spikes/SPK-08-generated-code/metodo-impronte.md" :GIT-BLOB
   "9e9121e124a6af86e9ccb8a253f69e1db584e873")
  (:PATH "spikes/SPK-08-generated-code/metodo-simd.md" :GIT-BLOB
   "e6b80fa0165026cd1a89c58786ec35d240bdc6c5")
  (:PATH "spikes/SPK-08-generated-code/run-bitmap.lisp" :GIT-BLOB
   "40c3761959a7759fe2d606d66c0fe5d9efa7aca2")
  (:PATH "spikes/SPK-08-generated-code/run.lisp" :GIT-BLOB
   "7c797afe4a6060782ce58f0cfc06f539006d117a")
  (:PATH "spikes/SPK-08-generated-code/simd.lisp" :GIT-BLOB
   "dbd551322880f1e0ddac6436c8af8f0dd85ddb9f")
  (:PATH "spikes/SPK-09-integrity/README.md" :GIT-BLOB
   "5755794e6b6afeed6f00a698cb337cf4b18730a4")
  (:PATH "spikes/SPK-09-integrity/core.lisp" :GIT-BLOB
   "80cdac4c0e52703618e1f274413b2ecbe00e6b14")
  (:PATH "spikes/SPK-09-integrity/run.lisp" :GIT-BLOB
   "c95660a4df5f2e6f6eb93e1078c2c36df6dabc85")
  (:PATH "spikes/SPK-10-v2-limits/README.md" :GIT-BLOB
   "cb5452eab513ddab4db6eb2955603a0c133d4e77")
  (:PATH "spikes/SPK-10-v2-limits/cbor.lisp" :GIT-BLOB
   "d6a5c93e34a0444d64b206df875a25b380545631")
  (:PATH "spikes/SPK-10-v2-limits/codec.lisp" :GIT-BLOB
   "567c84546d29e1b8ddc5cd9e1a31b4e93519c75d")
  (:PATH "spikes/SPK-10-v2-limits/core.lisp" :GIT-BLOB
   "c5b7cfd27c663734b7d5fae481dde939418566b5")
  (:PATH "spikes/SPK-10-v2-limits/indice.lisp" :GIT-BLOB
   "bc978eb16aa7f0d69e3deac2df86057a650f8551")
  (:PATH "spikes/SPK-10-v2-limits/metodo-cbor.md" :GIT-BLOB
   "8c83b0067a0481759f14733e3c60ca888c6d01d8")
  (:PATH "spikes/SPK-10-v2-limits/metodo-codec.md" :GIT-BLOB
   "69fb5930c2722871c30056b41c13f7919058bfcb")
  (:PATH "spikes/SPK-10-v2-limits/metodo-indice.md" :GIT-BLOB
   "b5cc04cfdf8ff989a5eb6081dd100f8c506b081d")
  (:PATH "spikes/SPK-10-v2-limits/metodo-migrazione.md" :GIT-BLOB
   "e3ebc7594ca6b1ae269579e5e9c7f9fef1b14300")
  (:PATH "spikes/SPK-10-v2-limits/migrazione.lisp" :GIT-BLOB
   "cab850dc32ff9908b487b24edf3e1df2cc90008c")
  (:PATH "spikes/SPK-10-v2-limits/run.lisp" :GIT-BLOB
   "6aa63afeac91c3b75174b76daba61e354bb7fe4d")
  (:PATH "spikes/SPK-11-unix-socket/README.md" :GIT-BLOB
   "cb540daa0c8918a07cfc3214d613e2e45d77db36")
  (:PATH "spikes/SPK-11-unix-socket/codec-inputs.lisp" :GIT-BLOB
   "d0db0b9a40edd8e47d5e758f012bb45d489eaa89")
  (:PATH "spikes/SPK-11-unix-socket/core.lisp" :GIT-BLOB
   "7b526422d5be781d26213e128a49a07bc3e25788")
  (:PATH "spikes/SPK-11-unix-socket/io-checks.lisp" :GIT-BLOB
   "b0bfea2d8042566852c6d23568087db11fd2bfe2")
  (:PATH "spikes/SPK-11-unix-socket/io-state.lisp" :GIT-BLOB
   "30db13814ebed2fb85a10ac1858cd8ec9931a6ee")
  (:PATH "spikes/SPK-11-unix-socket/io-transport.lisp" :GIT-BLOB
   "5a1f26feeae1f415557f28ae62ee1b3297314423")
  (:PATH "spikes/SPK-11-unix-socket/native-io-method.md" :GIT-BLOB
   "9126cd6694a005fb4ee117069eebfa0b9c48fe2a")
  (:PATH "spikes/SPK-11-unix-socket/native-io.lisp" :GIT-BLOB
   "0740e3d5542c6ad5b2d4106fb73c26f4e97ab0c5")
  (:PATH "spikes/SPK-11-unix-socket/run.lisp" :GIT-BLOB
   "3c83e79a935184239c21f02296f262acf4f5c64d")
  (:PATH "spikes/SPK-11-unix-socket/scenarios.lisp" :GIT-BLOB
   "e192b075c58d0b554f1fa1c3b09acf86607ad9e1")
  (:PATH "spikes/SPK-11-unix-socket/session-checks.lisp" :GIT-BLOB
   "75d5e70617a33fa738b911397d8bab22ea3e1faf")
  (:PATH "spikes/SPK-11-unix-socket/session-method.md" :GIT-BLOB
   "4f58dd5447600607e9c9efa9382d19b07aedfb72")
  (:PATH "spikes/SPK-11-unix-socket/session-model.lisp" :GIT-BLOB
   "02b389e0579f4c268bc35afc9e2eb75ab501e88a")
  (:PATH "spikes/SPK-11-unix-socket/session-transport.lisp" :GIT-BLOB
   "a79fed48095bd01e56860372badc1e168ac8eb7a")
  (:PATH "spikes/SPK-11-unix-socket/session-wire.lisp" :GIT-BLOB
   "d3bd3a22eb6ab70554f13ca798b8ea5ab310e863")
  (:PATH "spikes/SPK-11-unix-socket/transport.lisp" :GIT-BLOB
   "413d13844d7fccc8d036832778851ceeb26dbc33")
  (:PATH "src/active/package.lisp" :GIT-BLOB
   "fbd3a32b30808508424c007ece26c9f3ea9ad0a9")
  (:PATH "src/active/preflight.lisp" :GIT-BLOB
   "827f0b580b404ad6c41184a7c9802ce50a8d413c")
  (:PATH "src/active/prepare.lisp" :GIT-BLOB
   "b2a326e3a17de2e1c9d0785d4a86b2137e41fce2")
  (:PATH "src/active/source.lisp" :GIT-BLOB
   "56f258d204b2c1af544f38d15fc1e357977b336f")
  (:PATH "src/active/types.lisp" :GIT-BLOB
   "91238be2c204434cb3583fd96743ebc98e46b503")
  (:PATH "src/cache/build.lisp" :GIT-BLOB
   "45255a912edb4300b1f22c9505d09be5177d1d4b")
  (:PATH "src/cache/clock.lisp" :GIT-BLOB
   "5aca4d48de7bf0d849eafe87ae89f6e7800282d8")
  (:PATH "src/cache/core.lisp" :GIT-BLOB
   "9ab280c17b61b8f98f8299cbfae676942bb3ae47")
  (:PATH "src/cache/package.lisp" :GIT-BLOB
   "c86ef56ec05e92ebc0fa155423289775970eedd2")
  (:PATH "src/cache/read.lisp" :GIT-BLOB
   "5f4f08a4609bd264fa058ec25ba8f6a516c162c8")
  (:PATH "src/cache/types.lisp" :GIT-BLOB
   "b335ea1d241672a3989da65b9a7ec516e7533347")
  (:PATH "src/cache/write.lisp" :GIT-BLOB
   "bcd7de80241f809dcfce472741f120a61ac787b4")
  (:PATH "src/codec/cbor-array-input.lisp" :GIT-BLOB
   "d3b3d07fc18bd2a077c1a2d79020a76263b2779e")
  (:PATH "src/codec/cbor-array-write.lisp" :GIT-BLOB
   "a410297c29c5d043ad60d3804bd3711e22c2833b")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "ca6215b30010d3d2eb90eaa6fd09dd5a9ac7778f")
  (:PATH "src/codec/cbor-float-narrow.lisp" :GIT-BLOB
   "cd5749edc0a757ee3a5b470eda566a6685d32fd8")
  (:PATH "src/codec/cbor-float-write.lisp" :GIT-BLOB
   "03c6aed61e2c243d8b1a6c4332ce1837c4e9a77c")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "db635a50678f2712ec9516be335717ea254d4d09")
  (:PATH "src/codec/cbor-item-read.lisp" :GIT-BLOB
   "b9099dc8a8c96281063811e686deb4dcb2b1d39b")
  (:PATH "src/codec/cbor-map-input.lisp" :GIT-BLOB
   "d7a593badeb6e6b71f28dc4e80c641b07189d0b8")
  (:PATH "src/codec/cbor-map-write.lisp" :GIT-BLOB
   "22e814ea68e606c5bc58033c2a31e945303a9d65")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "761302dad1073c841397f6c88d595b114af8d9ef")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "3e31d60234585442baa5664be96a83915e034397")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "57ffc48cc688a4de8ebec5cb14c1e69c4209704a")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "70272936e323b3e0cb05173c9fb68cb2b614c355")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "f1afe79c7a4d49abd6a6e5f6975dec830ef7b1f6")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "c574e87af5e195ddf3f596a4ae527e69c7a3c6a6")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "e3d7d77407046338d23e26eb0b8a2e8fdc3d699d")
  (:PATH "src/codec/cbor-simple-write.lisp" :GIT-BLOB
   "58c7a3a040ec814fae2dfe636f569b5623cba8f0")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "a8330e50a77b52a6b9044ebbb48f62bb4b3222a3")
  (:PATH "src/codec/cbor-string-read.lisp" :GIT-BLOB
   "d4a4f774c2264c46349e7eda61ee4a2a3118d742")
  (:PATH "src/codec/cbor-string-write.lisp" :GIT-BLOB
   "a2c5c77dd51bff760bff4508e998d94370921eda")
  (:PATH "src/codec/cbor-tag-input.lisp" :GIT-BLOB
   "6dfad07035ac8040b2aec0a455c175ea15dfd9ad")
  (:PATH "src/codec/cbor-tag-write.lisp" :GIT-BLOB
   "16b91fc27eabafd7ff12bfb0a56ed34208c2bd4b")
  (:PATH "src/codec/cbor-write.lisp" :GIT-BLOB
   "61f0d6e2783e4790ed7e19a45bba6407d6e5b3de")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "7139b8ce1a947efe6599f2cbbdf78a02e35a68f1")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "e2339f232be3d432311503cb48f9ad8e2e53e8e8")
  (:PATH "src/control/build.lisp" :GIT-BLOB
   "b20fd8bbde30f47d2b9b6723cd04ee8c57f84ad4")
  (:PATH "src/control/dependency.lisp" :GIT-BLOB
   "70e4b4052d3e787f86273c0a8bec60de38b6163a")
  (:PATH "src/control/package.lisp" :GIT-BLOB
   "e56a6bb83abe9441350baa46573d74c6d55edf4e")
  (:PATH "src/control/preflight.lisp" :GIT-BLOB
   "638bad1673c8fd83876551ab3e7969167f611a1c")
  (:PATH "src/control/prepare.lisp" :GIT-BLOB
   "a75979cadbc8910c4955f2b091bd861150e5a26b")
  (:PATH "src/control/publication-read.lisp" :GIT-BLOB
   "6970c03f6387dad6948121852a9ad04ee9cca48e")
  (:PATH "src/control/publication.lisp" :GIT-BLOB
   "696f6208a139c1362f9cfcdd9be0f2c2396843ff")
  (:PATH "src/control/recovery-publication.lisp" :GIT-BLOB
   "906ea6d3f42c19f20bfde45bc477ba6ee4bc1040")
  (:PATH "src/control/recovery-read.lisp" :GIT-BLOB
   "5ec9c664bbf137e7456a4058dd14a934839fe6b3")
  (:PATH "src/control/recovery-types.lisp" :GIT-BLOB
   "07d3b1273fea4f1c8b2695c9fa563a0579bdb2e5")
  (:PATH "src/control/transfer.lisp" :GIT-BLOB
   "f29a92a80d75718c1bca9d7403c8764cb24399a2")
  (:PATH "src/control/types.lisp" :GIT-BLOB
   "d45ec11a4475dd9ecf32f37e2f656b127f19c98b")
  (:PATH "src/csn/package.lisp" :GIT-BLOB
   "9eb660cca8f097e25ca3c1535cace8c20bc1e238")
  (:PATH "src/csn/registry.lisp" :GIT-BLOB
   "80cb600f6c6d724cf1eaec25c3d2742c8c320906")
  (:PATH "src/dispatch/begin.lisp" :GIT-BLOB
   "1f54e226a0b7d5c796ef09b6336866e1a74b78b1")
  (:PATH "src/dispatch/build.lisp" :GIT-BLOB
   "d1f2397592a8ba9c3af21394f191017e9fd2219c")
  (:PATH "src/dispatch/claim.lisp" :GIT-BLOB
   "f7717c94b765165eae4144042308e3639644ed5e")
  (:PATH "src/dispatch/package.lisp" :GIT-BLOB
   "db21c798588ff4a88be5b69b5fbe72bc84811a46")
  (:PATH "src/dispatch/recycle.lisp" :GIT-BLOB
   "adcd65ee5fd683d70a40b89b31a2edf7fc93994c")
  (:PATH "src/dispatch/start.lisp" :GIT-BLOB
   "9b1964850e91e273ef21f9e371bdd2cd81673825")
  (:PATH "src/dispatch/step.lisp" :GIT-BLOB
   "a4089abcd78bb811ca8279361af027e9822722c0")
  (:PATH "src/dispatch/types.lisp" :GIT-BLOB
   "09b357c8f46c67d8e57994e1fa37affdd25a1695")
  (:PATH "src/engine/adopt.lisp" :GIT-BLOB
   "71862c121995b04b8fa2ecb2998f1d60b4578eb0")
  (:PATH "src/engine/config.lisp" :GIT-BLOB
   "72610668dd6479e482c5a823f80eec82e9bc846c")
  (:PATH "src/engine/files.lisp" :GIT-BLOB
   "591bf1b189c852cc8dbd3d5dd72319fa954b3932")
  (:PATH "src/engine/index.lisp" :GIT-BLOB
   "c7427d58d6457d7d604ae31a3a8fedf373acdb91")
  (:PATH "src/engine/initialize.lisp" :GIT-BLOB
   "456400c5ddfe7a799b5004dd1794ebf449bcb24c")
  (:PATH "src/engine/lifecycle.lisp" :GIT-BLOB
   "7cf82c9fdcc234d309eb45e9d28bfe1d4faac85f")
  (:PATH "src/engine/package.lisp" :GIT-BLOB
   "25064d3500a138b807457135eb768363cee6d661")
  (:PATH "src/engine/preflight.lisp" :GIT-BLOB
   "cb792a8f612fb011426b49e5066e2d22bc427cc2")
  (:PATH "src/engine/read.lisp" :GIT-BLOB
   "a661428c059834a347dae4ea5b94b276292e83ab")
  (:PATH "src/engine/recovery.lisp" :GIT-BLOB
   "487b11c554db8c7ba7a5138844ce097eade5a870")
  (:PATH "src/engine/startup.lisp" :GIT-BLOB
   "1e2c4cf2c3bad15b79359fc386d286bd0a57c6b1")
  (:PATH "src/engine/types.lisp" :GIT-BLOB
   "e0c273d00bb5a01e0a9b83758841ce15659f1cdc")
  (:PATH "src/engine/write.lisp" :GIT-BLOB
   "ebac3a004829725887d5bedfdadc2a47079b7d55")
  (:PATH "src/epochs/core.lisp" :GIT-BLOB
   "9388a84a1beb35cfa2bf016471389c881ad38628")
  (:PATH "src/epochs/package.lisp" :GIT-BLOB
   "43bc1aefdeec0e19e729160b3aa085091634a11a")
  (:PATH "src/epochs/read.lisp" :GIT-BLOB
   "a3dfde4a4780554b88e6e037ab4f70731f9c884a")
  (:PATH "src/epochs/reclaim.lisp" :GIT-BLOB
   "57235763cf556ecd7633a0052f265ce3eb2b0462")
  (:PATH "src/epochs/retire.lisp" :GIT-BLOB
   "f0f1cd22e87892119a4b7768b4efe5e519925dff")
  (:PATH "src/epochs/types.lisp" :GIT-BLOB
   "909dfdbc901c4cbdeae5b47faf52480350372524")
  (:PATH "src/execution/handoff.lisp" :GIT-BLOB
   "34c8add62a6df92446be5234ef013893ebcf6879")
  (:PATH "src/execution/package.lisp" :GIT-BLOB
   "dcdf82cb17b20f6d4e96cc94d3f1522520c3a236")
  (:PATH "src/execution/queue.lisp" :GIT-BLOB
   "bb4d4d6f222aa360ec64ef2f45ee6ba0524dd2f0")
  (:PATH "src/execution/ready-recycle.lisp" :GIT-BLOB
   "58981c7e41ce2694dbfcaed99010a3a53e3c1dea")
  (:PATH "src/execution/ready-types.lisp" :GIT-BLOB
   "5b3c26f78d5c4aa53ca200abdd3e0f753f926b54")
  (:PATH "src/execution/ready.lisp" :GIT-BLOB
   "4119f86231b7d8698fc3558868ff8a5bcbdf3090")
  (:PATH "src/execution/worker-boundary.lisp" :GIT-BLOB
   "720f16e96203f00e308727b430b66b28689dc7bb")
  (:PATH "src/execution/worker-claim.lisp" :GIT-BLOB
   "4f34d18152d77fbf63bf708ebd0aabac178c3ac1")
  (:PATH "src/execution/worker-run.lisp" :GIT-BLOB
   "65a3f3c9e84c83b900c1dd8c9cc2fc21cec36c52")
  (:PATH "src/execution/worker-types.lisp" :GIT-BLOB
   "6d36e1f64d79f24c95209fd70551953e40c62335")
  (:PATH "src/execution/writer.lisp" :GIT-BLOB
   "8e5102497f628796fa8faffa2085a165496af230")
  (:PATH "src/foundation/batch.lisp" :GIT-BLOB
   "2cbd40c539b13dd80070eedf4af82bd1b26f4b28")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "2d514f6fe2e81eecb29fa53de611fa5e28696904")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "edbe5eaa88c50dc13af8e367b73f7f41fd7bd724")
  (:PATH "src/foundation/crc32c.lisp" :GIT-BLOB
   "f9c691d28620427099d1d89a89a1ff5d04cbe257")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "bca6808e75e144ac7e9643df07a1cc6df4f70ed3")
  (:PATH "src/foundation/record.lisp" :GIT-BLOB
   "09185339cab38ab937045b40c52bb1b9092ffb8e")
  (:PATH "src/fulltext-admission/build.lisp" :GIT-BLOB
   "8f2a8791a460f18b0b58c63e07c68226a87bd7be")
  (:PATH "src/fulltext-admission/copy.lisp" :GIT-BLOB
   "da2646ac18d08ce8e417ceaf5474ff4524059fb8")
  (:PATH "src/fulltext-admission/guards.lisp" :GIT-BLOB
   "0b556567ee88c344338404b0939b9ea58ae138bc")
  (:PATH "src/fulltext-admission/lifecycle.lisp" :GIT-BLOB
   "ffdc731b70980208e48e73413ae519e2b4cbdc47")
  (:PATH "src/fulltext-admission/package.lisp" :GIT-BLOB
   "74d06aa6d0d0b263b806f678b23cec40b5db3ef1")
  (:PATH "src/fulltext-admission/preflight.lisp" :GIT-BLOB
   "936cb9ec5d1658f7fe0d8934ff71c032baf469c5")
  (:PATH "src/fulltext-admission/query.lisp" :GIT-BLOB
   "a036e8ce6a8e5295c702e1caa575d42031aec5a9")
  (:PATH "src/fulltext-admission/reserve.lisp" :GIT-BLOB
   "131235c639c7ada51e75fd27ecd3595c5f833182")
  (:PATH "src/fulltext-admission/row-update.lisp" :GIT-BLOB
   "76ec001de033582b7845b665932f53a40d5965a5")
  (:PATH "src/fulltext-admission/rows.lisp" :GIT-BLOB
   "881e0e840fdbabcde946ddc7699ce650bbee3367")
  (:PATH "src/fulltext-admission/types.lisp" :GIT-BLOB
   "115b521e699044b1ebcdb389c38d1f06f718662e")
  (:PATH "src/fulltext-put/append.lisp" :GIT-BLOB
   "bc3f40b0faec4ff058daaaca20e75758a0581470")
  (:PATH "src/fulltext-put/binding.lisp" :GIT-BLOB
   "6144cc61c3ec83f1187dbc5ac249303015f0d0d0")
  (:PATH "src/fulltext-put/build.lisp" :GIT-BLOB
   "f66206063b3d9ae191e1f4854e8efa1da58f150c")
  (:PATH "src/fulltext-put/package.lisp" :GIT-BLOB
   "0ffd3fb459d14ef6da0ab6789930b8ee54b78fe5")
  (:PATH "src/fulltext-put/physical-header.lisp" :GIT-BLOB
   "47120e3399f0d05559f3eb4748768254f1a4eacf")
  (:PATH "src/fulltext-put/physical.lisp" :GIT-BLOB
   "ff4aab62df19debe4f14f892bfb52a3cb1a6f31c")
  (:PATH "src/fulltext-put/prepare.lisp" :GIT-BLOB
   "9c50b6745ef3b2eef9a718fcbf3f611b362e6ba6")
  (:PATH "src/fulltext-put/reserve.lisp" :GIT-BLOB
   "a002173ae2a1d17a1ec90b3b9531c353654f7f57")
  (:PATH "src/fulltext-put/row-reference.lisp" :GIT-BLOB
   "865d9bb30ca6da556223917bffec68e9090a8eca")
  (:PATH "src/fulltext-put/start.lisp" :GIT-BLOB
   "8d936fffbb2193af1cc8bac9ab64bec36294fd52")
  (:PATH "src/fulltext-put/types.lisp" :GIT-BLOB
   "a92b2fc7a3068a0b7205b0407aafc65348d573d3")
  (:PATH "src/fulltext/analysis-emit.lisp" :GIT-BLOB
   "ede43f9e120f37fc2ed4970bd1b0623b07ae2333")
  (:PATH "src/fulltext/analysis-nfc.lisp" :GIT-BLOB
   "580f823c9e33a75e1233ef61eaaaf15b0060137c")
  (:PATH "src/fulltext/analysis-package.lisp" :GIT-BLOB
   "5729cfba660c391cf9dee6fc3d5e6ccbddcd2552")
  (:PATH "src/fulltext/analysis-properties.lisp" :GIT-BLOB
   "f0879979dc318cefa5f8a870a2b8dc4132094f3a")
  (:PATH "src/fulltext/analysis-space.lisp" :GIT-BLOB
   "0f295b4eca162d908746ad5d7f7238480325b00c")
  (:PATH "src/fulltext/analysis-word-context.lisp" :GIT-BLOB
   "e4660d31ae0d6d47adf4e1c9b003c86180275b5d")
  (:PATH "src/fulltext/analysis-word-rules.lisp" :GIT-BLOB
   "227219f9faa098057970f25ea441f1e448ca85c4")
  (:PATH "src/fulltext/analysis.lisp" :GIT-BLOB
   "26ca9e242db4516fbf83ce56464cc7c76e460b07")
  (:PATH "src/fulltext/codec-input.lisp" :GIT-BLOB
   "ec3d8865324e21198ad1ef238907eb22706922a7")
  (:PATH "src/fulltext/codec-package.lisp" :GIT-BLOB
   "3c00fe5b42beae166bad39cb9314dc83c687858f")
  (:PATH "src/fulltext/codec-plan.lisp" :GIT-BLOB
   "60f9c3ca01fb0b29bf992c255bd4e40ce8ad44c4")
  (:PATH "src/fulltext/codec-query.lisp" :GIT-BLOB
   "2e77838f54f12cf998341f494a92127770f05e7f")
  (:PATH "src/fulltext/codec-read-base.lisp" :GIT-BLOB
   "c6fe327a9a49cef8a126350fc45d4ae6260d1afc")
  (:PATH "src/fulltext/codec-read-dict.lisp" :GIT-BLOB
   "70bd43d2e1e50625ad47df827f5615734d15ae61")
  (:PATH "src/fulltext/codec-read-lengths.lisp" :GIT-BLOB
   "a3549d187caf9b6a86ef4126197ab68eb7a177de")
  (:PATH "src/fulltext/codec-read-postings.lisp" :GIT-BLOB
   "79e34c0e71d2e1f2d2b78a7c61c4d85811c9aa8d")
  (:PATH "src/fulltext/codec-read-term.lisp" :GIT-BLOB
   "15178d8d735daff2b162030e815b5e3da6a37cae")
  (:PATH "src/fulltext/codec-run.lisp" :GIT-BLOB
   "73022c24cfe46dfaa93e185153296f1da7adc58a")
  (:PATH "src/fulltext/codec-space.lisp" :GIT-BLOB
   "fcad6ec5ee926a710794e01ee652b8cf7befcebc")
  (:PATH "src/fulltext/codec-view.lisp" :GIT-BLOB
   "b986c8a9eafb72344f640ba5de52bd32643be341")
  (:PATH "src/fulltext/codec-write-entries.lisp" :GIT-BLOB
   "567a7ca7a7ac23f6a5240bdd54b08ed138a56301")
  (:PATH "src/fulltext/codec-write.lisp" :GIT-BLOB
   "2c9fd28d25a840a5e695e92f839f60898122db6a")
  (:PATH "src/fulltext/descriptor.lisp" :GIT-BLOB
   "eef3aa97b7a43a5a0bd6575e6cab2a3f9e54f985")
  (:PATH "src/fulltext/document-analysis.lisp" :GIT-BLOB
   "a7c79f8e9fb4a47e5718db454be405d47e689831")
  (:PATH "src/fulltext/document-bound.lisp" :GIT-BLOB
   "8f3783161f38d67900c0115429255281822ab2cc")
  (:PATH "src/fulltext/document-config-input.lisp" :GIT-BLOB
   "3dc4712c1c1bfe56b97e851baeb7a2b2c8d3afe0")
  (:PATH "src/fulltext/document-config.lisp" :GIT-BLOB
   "c27b728d847fa0e1a0b42c19e04f4f8568379717")
  (:PATH "src/fulltext/document-package.lisp" :GIT-BLOB
   "c95277890c41d43af04cd3db67dedf204c398bc7")
  (:PATH "src/fulltext/document-paths.lisp" :GIT-BLOB
   "d5bb755161e099835faed15bd1ca486a50febd16")
  (:PATH "src/fulltext/document-scan.lisp" :GIT-BLOB
   "7556be1b270ce4e2c63fba26f50c68548d4b72d1")
  (:PATH "src/fulltext/document-space.lisp" :GIT-BLOB
   "b556bbf3f7efe6458883a8146f814b5c02a32fb7")
  (:PATH "src/fulltext/document-start.lisp" :GIT-BLOB
   "876c3d986b427a5664413b940779f37b92e5c099")
  (:PATH "src/fulltext/document.lisp" :GIT-BLOB
   "8e1f972c5b0eaeb3e340b915108af5b49b734208")
  (:PATH "src/fulltext/format-constants.lisp" :GIT-BLOB
   "68c8831f87e45614e05d783e82a3ad0a2585325d")
  (:PATH "src/fulltext/format-input.lisp" :GIT-BLOB
   "92a17dc2bcdfd837d50b969a0f0156ae7709d50a")
  (:PATH "src/fulltext/format-package.lisp" :GIT-BLOB
   "1f72e2d40467a20422c5bfaa2564bb5b84fedf29")
  (:PATH "src/fulltext/format-read.lisp" :GIT-BLOB
   "0eafbb6b7f6644fccb198135fccf1ac9b101e1f2")
  (:PATH "src/fulltext/format-write.lisp" :GIT-BLOB
   "d87702218efa8b4e5992c3ede59674743fa53d3f")
  (:PATH "src/fulltext/index-build.lisp" :GIT-BLOB
   "026cd085b27531258e0828a3da34cd834b866875")
  (:PATH "src/fulltext/index-lookup.lisp" :GIT-BLOB
   "f3125aa4f88279fb0f21431a369e7479c642ea71")
  (:PATH "src/fulltext/index-package.lisp" :GIT-BLOB
   "711bbbc0c7491d10b6c0e411c38099add1230a7b")
  (:PATH "src/fulltext/index-sort.lisp" :GIT-BLOB
   "53447fbf8db853d6b5299875af52f764deded5f7")
  (:PATH "src/fulltext/index-step.lisp" :GIT-BLOB
   "8bbd1228e7ee78435a718ad71c37a4f8095302ff")
  (:PATH "src/fulltext/meta-fields.lisp" :GIT-BLOB
   "0aad5b5452a86ca0f333fed0648e91a264596ecc")
  (:PATH "src/fulltext/meta-read.lisp" :GIT-BLOB
   "b51cb3e7a022d5e95f7aad3ee8c9baacb5ebbce8")
  (:PATH "src/fulltext/unicode-tables.lisp" :GIT-BLOB
   "4b8f977f590d09fd4a2386ef14642b182170cd2c")
  (:PATH "src/get-directory/build.lisp" :GIT-BLOB
   "f1a1a37ccd59a81e7ff91fcb36009d5953d7edd5")
  (:PATH "src/get-directory/package.lisp" :GIT-BLOB
   "8dcddeb0536c1104af92c722ffbfab2059601c74")
  (:PATH "src/get-directory/read.lisp" :GIT-BLOB
   "1d93461227b222a8effc53ec9344c5dab0b531fe")
  (:PATH "src/get-directory/sources-read.lisp" :GIT-BLOB
   "ca171a29008377ec491dce07afd6cf24f12cd8fe")
  (:PATH "src/get-directory/sources-types.lisp" :GIT-BLOB
   "29abe8ab7a3756eb33365ec8c8ffacdc2a7a0564")
  (:PATH "src/get-directory/types.lisp" :GIT-BLOB
   "ec99839d234468298b553e331873a320c8ece53f")
  (:PATH "src/get-resolver/active-build.lisp" :GIT-BLOB
   "d135084116b62ed3b55f81ee5798618919f76ead")
  (:PATH "src/get-resolver/active-directory.lisp" :GIT-BLOB
   "70341c7c32b364603d38bdc42e8b3af1cc631773")
  (:PATH "src/get-resolver/active-init.lisp" :GIT-BLOB
   "b0586a8815a9ad72c1a897ac16d14a3f1ed530ca")
  (:PATH "src/get-resolver/active-preflight.lisp" :GIT-BLOB
   "bd75d3a4b7483900689417ae3eb2dd65e76c8468")
  (:PATH "src/get-resolver/active-read.lisp" :GIT-BLOB
   "0a93acd78d9b8b341011531e23e5663ae1df4f72")
  (:PATH "src/get-resolver/active-scan.lisp" :GIT-BLOB
   "5ae454c03e8a9b9196653c8b28df0727e480d142")
  (:PATH "src/get-resolver/active-types.lisp" :GIT-BLOB
   "590b969dd48f4a789e15d692addb92cd7970bebf")
  (:PATH "src/get-resolver/build.lisp" :GIT-BLOB
   "956b6c7145a25dc64a7247f2e14321876ac08f15")
  (:PATH "src/get-resolver/package.lisp" :GIT-BLOB
   "33d7b898b5f5a7b20c8112484191c14df44b770e")
  (:PATH "src/get-resolver/read.lisp" :GIT-BLOB
   "1177496e5baca7f7c698156e196c60fe1fe2566a")
  (:PATH "src/get-resolver/rows.lisp" :GIT-BLOB
   "e1bf83fbcc737b55eaa71bd6b41a912a901178ce")
  (:PATH "src/get-resolver/scan.lisp" :GIT-BLOB
   "6f54751adb255f49582ff1da62f951965c3860a1")
  (:PATH "src/get-resolver/sort.lisp" :GIT-BLOB
   "9cbbdb6200af813bc9595d0ef964628a9ba0368f")
  (:PATH "src/get-resolver/types.lisp" :GIT-BLOB
   "53438f156d3e1e15f3732ec840223231b308a7a5")
  (:PATH "src/get/build.lisp" :GIT-BLOB
   "cb426426eac6e923224bc57c1dd602405f4bc040")
  (:PATH "src/get/lifecycle.lisp" :GIT-BLOB
   "23f16c3039b71be0bd46d6bf92f05791e444683e")
  (:PATH "src/get/lookup.lisp" :GIT-BLOB
   "5a105a141b43f5585f8e79c2965d59e96cd35ac6")
  (:PATH "src/get/package.lisp" :GIT-BLOB
   "a22de99a63db56417822bb5e66f82e5c89d73bc2")
  (:PATH "src/get/segment.lisp" :GIT-BLOB
   "cf168c44bfe5aedd2e34180ce4f766a6a89500a7")
  (:PATH "src/get/target.lisp" :GIT-BLOB
   "c9b8488d0a1aa7643a6ab1570765ec870aa7c9e4")
  (:PATH "src/get/types.lisp" :GIT-BLOB
   "032ad088b19ec3498a7c80a5e4b96d7777257dad")
  (:PATH "src/hash/arithmetic.lisp" :GIT-BLOB
   "0d8e799b889df829aeb46054ef100377845dd0e0")
  (:PATH "src/hash/blocks.lisp" :GIT-BLOB
   "f115b63c6089960e9857469475f821f3035a5ef2")
  (:PATH "src/hash/hash64.lisp" :GIT-BLOB
   "6d43b042d7d9018f8aa48e88fc58c24b5a089cdf")
  (:PATH "src/hash/package.lisp" :GIT-BLOB
   "0c73ce15b8de3f9173a99f7216ead4e79d04d535")
  (:PATH "src/index/core.lisp" :GIT-BLOB
   "a83ee5a2d8903538f8ba977ef0f5ddbe3a357d6b")
  (:PATH "src/index/hash-digests.lisp" :GIT-BLOB
   "6d05b467aee412f447308eb697daa7f4f5ec6f0d")
  (:PATH "src/index/hash-seed.lisp" :GIT-BLOB
   "5627b4179b115c008379aa3e60a4724e63f9657b")
  (:PATH "src/index/mode-package.lisp" :GIT-BLOB
   "53da3230da115c0d702cc762d3f2ab69e6af253e")
  (:PATH "src/index/mode-policy.lisp" :GIT-BLOB
   "1ebf5692ffba278f0ad0b1bb619859c19d1a37a0")
  (:PATH "src/index/mode-types.lisp" :GIT-BLOB
   "fd6f579fbe760f9f16990994a251947e6da0de89")
  (:PATH "src/index/package.lisp" :GIT-BLOB
   "02d4fd9bf5f1701eefd5e6997b89c1d98a8cef5c")
  (:PATH "src/index/page-body.lisp" :GIT-BLOB
   "c843c54ed389aa921be1043c0ea1b738fd87c26d")
  (:PATH "src/index/page-bucket.lisp" :GIT-BLOB
   "f7a7caa4b3f5099609b274ef065bfc5a84fc5990")
  (:PATH "src/index/page-constants.lisp" :GIT-BLOB
   "50ff778e1f79420d870fdf2112d4c33916771b78")
  (:PATH "src/index/page-package.lisp" :GIT-BLOB
   "e598400a135eb4d45ae233f2a19cb671dda461b4")
  (:PATH "src/index/page-read.lisp" :GIT-BLOB
   "c0eb550031292123eec2968759545784c6e3736c")
  (:PATH "src/index/page-types.lisp" :GIT-BLOB
   "b660297ee9db3d8e91d201021b1d619a46cb3b12")
  (:PATH "src/index/page-validation.lisp" :GIT-BLOB
   "01709aa30036f646e9f3e76c926e74cc42e8fed9")
  (:PATH "src/index/page-write.lisp" :GIT-BLOB
   "005bac26cb67d13f05e631ac59c33d3e556e83d8")
  (:PATH "src/index/primary-arena.lisp" :GIT-BLOB
   "20de8a35a4deaa830348a6db5b5bb033a82c81d2")
  (:PATH "src/index/primary-build.lisp" :GIT-BLOB
   "aa80e1b0b6af77379cfe2f2bd12c0b17e5c6851b")
  (:PATH "src/index/primary-core.lisp" :GIT-BLOB
   "20d4b57b2a7c4b9f11205e753b92301f74f56cfc")
  (:PATH "src/index/primary-directory.lisp" :GIT-BLOB
   "1d7969c842b1f9a4cd0b9eba2ea3496cf914a2c4")
  (:PATH "src/index/primary-package.lisp" :GIT-BLOB
   "099d59bb9acc155380a3baaa3a10816e0902d8ca")
  (:PATH "src/index/primary-probe.lisp" :GIT-BLOB
   "f36b55b9e2d9002ed2ce203a0289c92984c89ac9")
  (:PATH "src/index/primary-read.lisp" :GIT-BLOB
   "b5b8243bc40b44af8c34ba76a5ab732675690af5")
  (:PATH "src/index/primary-relocate.lisp" :GIT-BLOB
   "2282593c0a431f3f73fb47cdfc7a8e530e704ce7")
  (:PATH "src/index/primary-restore.lisp" :GIT-BLOB
   "013c30abc9499729f83ce97230b2a4162ea2263e")
  (:PATH "src/index/primary-types.lisp" :GIT-BLOB
   "b8009b8313054c9abebb70de8f8223fb1df708f3")
  (:PATH "src/index/primary-write.lisp" :GIT-BLOB
   "e4107ea817314364a1ffc38f3e8940c46d7dee8a")
  (:PATH "src/index/read.lisp" :GIT-BLOB
   "abfdeb5397f8be1d390cbdf47f4f02cd2f36bf91")
  (:PATH "src/index/rebuild-budget.lisp" :GIT-BLOB
   "77df997ef72008e7758899a348ae07695bce0b38")
  (:PATH "src/index/rebuild-copy.lisp" :GIT-BLOB
   "8555e14347d05182c99b756a312207019e2f904f")
  (:PATH "src/index/rebuild-scan.lisp" :GIT-BLOB
   "79d794b102c3ebf50679426e7cebbf49f02683ce")
  (:PATH "src/index/rebuild.lisp" :GIT-BLOB
   "321ae3d1fdcda8e34efbdaac4b10dfc08fe9d9a5")
  (:PATH "src/index/relocate.lisp" :GIT-BLOB
   "012c8cff2c265aa7f0daa909a9a0dd01adf7ca3b")
  (:PATH "src/index/types.lisp" :GIT-BLOB
   "3c7cd919b94dd9458422143c18075dd7498fda1f")
  (:PATH "src/index/validation.lisp" :GIT-BLOB
   "a8088783354d2e4e5048d6ac7a3bee7afff92719")
  (:PATH "src/index/write.lisp" :GIT-BLOB
   "80156ca526a341c845fc43fc9963097f8669e65a")
  (:PATH "src/io/create-relative.lisp" :GIT-BLOB
   "4efe755dfbce6df892c864b26e7a2b77f7b6bed3")
  (:PATH "src/io/directory-lock.lisp" :GIT-BLOB
   "d6863617dae77f7f9f098c9c88b6fe0dff1ce584")
  (:PATH "src/io/directory.lisp" :GIT-BLOB
   "2a9b0a14c2b84db07d65374be0cdd5bd71d51768")
  (:PATH "src/io/flush.lisp" :GIT-BLOB
   "99fb51535f9bfbbaf8a2d7831dbd14b5f727b9d6")
  (:PATH "src/io/identity-types.lisp" :GIT-BLOB
   "9c94bab051b318a872d78efa45ba3358bf74f8b6")
  (:PATH "src/io/identity.lisp" :GIT-BLOB
   "326635b36bfa8f47778e7ff6cd1c72354352b5d5")
  (:PATH "src/io/lifecycle.lisp" :GIT-BLOB
   "77e43979548e6343066036c363a3aa2208ac1e10")
  (:PATH "src/io/namespace.lisp" :GIT-BLOB
   "a0625806a917c72ffc5d3a620b23e401c7893e79")
  (:PATH "src/io/native-create-relative.lisp" :GIT-BLOB
   "85c0d583b527933b62208c660788aa5a3bfc8e60")
  (:PATH "src/io/native-directory.lisp" :GIT-BLOB
   "a126ce400de0a058e80b3178198f4af36c96cc90")
  (:PATH "src/io/native-namespace.lisp" :GIT-BLOB
   "72282e6cb1a9702359f7da9758304a5258c83f87")
  (:PATH "src/io/native-open-relative.lisp" :GIT-BLOB
   "3cd9fed0cf0ad49b9bcbcd1cd9457581db6a31b0")
  (:PATH "src/io/native-publish.lisp" :GIT-BLOB
   "ed27c0e81cceb54a1ed25b23518c38253bbe2e91")
  (:PATH "src/io/native.lisp" :GIT-BLOB
   "18b23eba1b6cabfacf4d2c423714408f0b592bd4")
  (:PATH "src/io/open-relative.lisp" :GIT-BLOB
   "aa64c30d62836c92eeb4d9ea2867b44b5fcbe04c")
  (:PATH "src/io/package.lisp" :GIT-BLOB
   "96e470718e84ec7b39f434c3c9b39fdf62b6e736")
  (:PATH "src/io/publish.lisp" :GIT-BLOB
   "eea3d4f347188d6c3db634daed523c6a4ef65cf2")
  (:PATH "src/io/rename.lisp" :GIT-BLOB
   "d39dcf6f17ec5e610190a94e0be165eadce42565")
  (:PATH "src/io/stabilize-preflight.lisp" :GIT-BLOB
   "3fb0be570d263bad2b16718c2808e020614872bd")
  (:PATH "src/io/stabilize.lisp" :GIT-BLOB
   "6f3347177a66162f496767e918d1d697a79debbe")
  (:PATH "src/io/transfer.lisp" :GIT-BLOB
   "5b24bd30aeb12b71b7b1a6a5aa537887a847bf10")
  (:PATH "src/io/types.lisp" :GIT-BLOB
   "38562f77af35124ec7a6390ec409864c8f8cd517")
  (:PATH "src/local/cli.lisp" :GIT-BLOB
   "f1dcd8ffa23398d6a0b4101c4e7cb2c88cc1771d")
  (:PATH "src/local/client.lisp" :GIT-BLOB
   "30a86bf2fdf3d7c1cf835870747e170789e79da8")
  (:PATH "src/local/dispatch.lisp" :GIT-BLOB
   "54bc52d78a5048524aad0fd0ab2029c467346419")
  (:PATH "src/local/native.lisp" :GIT-BLOB
   "e3a3de96e3a99275cecdae650da57a8b77765729")
  (:PATH "src/local/package.lisp" :GIT-BLOB
   "74489fef066b33ac706cb0dd8c757d440e0bfebf")
  (:PATH "src/local/server.lisp" :GIT-BLOB
   "8754ca4dd75d34edba06bdb32f2e14d0c106ddb0")
  (:PATH "src/local/state.lisp" :GIT-BLOB
   "dab6d6bc70c3faa523e5e43d0a0a20c9bdcd4606")
  (:PATH "src/local/wire.lisp" :GIT-BLOB
   "f64a7121a0d1105446eddf67750cb10bdff48244")
  (:PATH "src/mvcc/package.lisp" :GIT-BLOB
   "d45fbf57051e43d0d998f3de9b4177665d24c9d9")
  (:PATH "src/mvcc/snapshots-core.lisp" :GIT-BLOB
   "01875b76743c514ef07346a32587f4dc5c34d2f8")
  (:PATH "src/mvcc/snapshots-csn.lisp" :GIT-BLOB
   "48372f6f09a54cfcee793ac03ec321fca6ad18f5")
  (:PATH "src/mvcc/snapshots-lifecycle.lisp" :GIT-BLOB
   "25d93efc7c604042d09dc84e31baf1f4e2c4c45e")
  (:PATH "src/mvcc/snapshots-read.lisp" :GIT-BLOB
   "09d73425a6e571c8fac6669b14b98e3ceeb7c96b")
  (:PATH "src/mvcc/snapshots-register.lisp" :GIT-BLOB
   "c9cadaabf755add3671cd1cc0408c3ff216df2a5")
  (:PATH "src/mvcc/snapshots-types.lisp" :GIT-BLOB
   "bf80277418243422144cf6ee71eef83d7eff6da5")
  (:PATH "src/mvcc/types.lisp" :GIT-BLOB
   "4cf0edbc70bc9e02ff3b0442cbce4ca44630d3e6")
  (:PATH "src/package.lisp" :GIT-BLOB
   "3d0181717e3f334580bab9a6a507e2dfe57261ff")
  (:PATH "src/read/core.lisp" :GIT-BLOB
   "132e44c138e209d3f8840b098cca0424853d09c3")
  (:PATH "src/read/package.lisp" :GIT-BLOB
   "dd00cd8e7dc8340e2006cfe03b0bf141968223fd")
  (:PATH "src/read/task.lisp" :GIT-BLOB
   "b3601060197a27c6e8a2aaee22b5576c6b0c6e5a")
  (:PATH "src/read/types.lisp" :GIT-BLOB
   "b30795fb7efad5f5313198d345ffabb43249e3fa")
  (:PATH "src/recovery-active/build.lisp" :GIT-BLOB
   "41f1eef0201a63afaf65b74cd54d899f44399153")
  (:PATH "src/recovery-active/closure.lisp" :GIT-BLOB
   "8d2f81d87c79c32f98060e73a84fc4cfdb671970")
  (:PATH "src/recovery-active/csn.lisp" :GIT-BLOB
   "e2cac366c83ae79062f97f74275fe399049c215e")
  (:PATH "src/recovery-active/frames.lisp" :GIT-BLOB
   "157221a830991415d120e19b033f73b2c6c2d946")
  (:PATH "src/recovery-active/package.lisp" :GIT-BLOB
   "474cd54f2a31f4ded95fd723b4170bee8addece4")
  (:PATH "src/recovery-active/publication.lisp" :GIT-BLOB
   "2a8500476de79bd62e395566a7471d0ca050556f")
  (:PATH "src/recovery-active/query.lisp" :GIT-BLOB
   "3e3bb0d5a126adf584ad4c4c77fd1b965c301e70")
  (:PATH "src/recovery-active/read.lisp" :GIT-BLOB
   "909abac62163856136bdfdc1ad30c3da90f884d5")
  (:PATH "src/recovery-active/resolve.lisp" :GIT-BLOB
   "d74f2261aa5ed16cbccb8201707f8f484380a18e")
  (:PATH "src/recovery-active/types.lisp" :GIT-BLOB
   "5d0d4f0219087001fd1df97339a530e64c39476f")
  (:PATH "src/recovery-archive-csn/build.lisp" :GIT-BLOB
   "125980e85ace529df3b36ea9fc83fc2ac7b236fa")
  (:PATH "src/recovery-archive-csn/package.lisp" :GIT-BLOB
   "bacf4fc95e38a8d0416110c6b87b506d561a7e59")
  (:PATH "src/recovery-archive-csn/preflight.lisp" :GIT-BLOB
   "cdc70f16eb9e736ea33d6f794910b9f97afad6df")
  (:PATH "src/recovery-archive-csn/query.lisp" :GIT-BLOB
   "b228e158ba87f83f7591f4a192a9d6b2cbf7b882")
  (:PATH "src/recovery-archive-csn/series.lisp" :GIT-BLOB
   "e6149b810be34b6da2b619c8f62cf02640c0060b")
  (:PATH "src/recovery-archive-csn/types.lisp" :GIT-BLOB
   "895ad3ef063684b8b5cced19cdeddb0e43afc149")
  (:PATH "src/recovery-archive/active.lisp" :GIT-BLOB
   "b61b332de594d6c74d6ed5fd5869face459ac34e")
  (:PATH "src/recovery-archive/build.lisp" :GIT-BLOB
   "454d4cad54c4db3e237d11a6de6304c86fd4e478")
  (:PATH "src/recovery-archive/package.lisp" :GIT-BLOB
   "82c707853b1a5b2b6d657e120c7e0ecb82404134")
  (:PATH "src/recovery-archive/query.lisp" :GIT-BLOB
   "eef7686bdd6ecbc03e3b9e86b73d29ae663742f6")
  (:PATH "src/recovery-archive/read.lisp" :GIT-BLOB
   "b46823a3fdc2d16e19c0c5702759bb198805eae2")
  (:PATH "src/recovery-archive/types.lisp" :GIT-BLOB
   "9aa3830c38b4b55a9b0475f6f3a6515508d7689a")
  (:PATH "src/recovery-bootstrap/build.lisp" :GIT-BLOB
   "ea0d29d1d565f96e1b0cdaa15037f2ae53811aa1")
  (:PATH "src/recovery-bootstrap/package.lisp" :GIT-BLOB
   "29ce39efa53a72cd766810b81a08c9a2f86afc91")
  (:PATH "src/recovery-bootstrap/preflight.lisp" :GIT-BLOB
   "d7dea209c7d520b53f9655d256521bfe07d841d1")
  (:PATH "src/recovery-bootstrap/shape.lisp" :GIT-BLOB
   "a4fdfa2fc1fa8cbdea6dbbb8a28986440e6ef12c")
  (:PATH "src/recovery-bootstrap/stabilize-preflight.lisp" :GIT-BLOB
   "02053562995a46474f515127f616aa38cddf0dd6")
  (:PATH "src/recovery-bootstrap/stabilize-shape.lisp" :GIT-BLOB
   "d845e84ae551c3fef323b923cf7bdabd31ed8ec5")
  (:PATH "src/recovery-bootstrap/stabilize.lisp" :GIT-BLOB
   "8f977e58ef42b424c8710bdde2217b49d5f10ea5")
  (:PATH "src/recovery-checkpoint/build.lisp" :GIT-BLOB
   "585f09fe65c662b3023e563fddbcf4205dffa513")
  (:PATH "src/recovery-checkpoint/order.lisp" :GIT-BLOB
   "318d549b7c52da1e09c2bfb923f2041ffaef020c")
  (:PATH "src/recovery-checkpoint/package.lisp" :GIT-BLOB
   "7b191ecff3dbac6b5f690ad221c68b4762a9f0aa")
  (:PATH "src/recovery-checkpoint/preflight.lisp" :GIT-BLOB
   "2cde31db83995a20c7ec586b5c0e5f131fd7596e")
  (:PATH "src/recovery-checkpoint/sections.lisp" :GIT-BLOB
   "468baa20f0a1059593391018227206228126f0f8")
  (:PATH "src/recovery-closed/build.lisp" :GIT-BLOB
   "7cb2f70d6520df859600eba89a7330a5ce9b3484")
  (:PATH "src/recovery-closed/csn-serie.lisp" :GIT-BLOB
   "1c83dc034e7291254348ce361056afc2896e196e")
  (:PATH "src/recovery-closed/csn.lisp" :GIT-BLOB
   "20a710ad5bdcaa8fde8f1527812ca0881448cf99")
  (:PATH "src/recovery-closed/package.lisp" :GIT-BLOB
   "49ac245e2430e719b1d417b91b0ffcd53555e47d")
  (:PATH "src/recovery-closed/publication.lisp" :GIT-BLOB
   "31152707be3e4d12a6dadf63c8773c3c7c3fe343")
  (:PATH "src/recovery-closed/read.lisp" :GIT-BLOB
   "0947da79acc2bfd8eea7c4e0158913cd03291a1b")
  (:PATH "src/recovery-closed/resolve.lisp" :GIT-BLOB
   "e84f68c5dcb94240966607b2135e9e6f3c8f2711")
  (:PATH "src/recovery-closed/types.lisp" :GIT-BLOB
   "e32d665f9ce6bfba9d3c0ab6c8a8b4f980b4e10e")
  (:PATH "src/recovery-closed/verify.lisp" :GIT-BLOB
   "e7895a628234195e41b5d9f53b2d163bb5f9d199")
  (:PATH "src/recovery-replay/package.lisp" :GIT-BLOB
   "8639d959e29e9f36270a94831eace49f6535a863")
  (:PATH "src/recovery-replay/read.lisp" :GIT-BLOB
   "9b8978d3b16e6dc5f3f045e9bb880a5e6d6de890")
  (:PATH "src/recovery-replay/resolve.lisp" :GIT-BLOB
   "b9cadc7c5b1f6dd6ef04117eb0cde754d11840f1")
  (:PATH "src/recovery-replay/visit.lisp" :GIT-BLOB
   "e42fdbeeeeea7350223f7e44f9872c167e26bdb2")
  (:PATH "src/recovery-selection/frame.lisp" :GIT-BLOB
   "ee9cf191a397f440789d4c81966a39f9541f577e")
  (:PATH "src/recovery-selection/index-preflight.lisp" :GIT-BLOB
   "5bd4143553a64ccad0795f19dc261c8d048150e2")
  (:PATH "src/recovery-selection/index.lisp" :GIT-BLOB
   "a868f4db92eb4b4f9e215c15979e717ee2e6246b")
  (:PATH "src/recovery-selection/key.lisp" :GIT-BLOB
   "481d2100b79d3106601a376c2530d678f31291d8")
  (:PATH "src/recovery-selection/package.lisp" :GIT-BLOB
   "9dd583b4bf868183f7555b1e4f7c29f2a13c244c")
  (:PATH "src/recovery-selection/read.lisp" :GIT-BLOB
   "38d61833af134afa51cec8291ed40666489b4474")
  (:PATH "src/recovery-selection/select.lisp" :GIT-BLOB
   "a048108db401e84267206a89d94e883855d37dd3")
  (:PATH "src/recovery-selection/types.lisp" :GIT-BLOB
   "8dad9f8de00595acb85aa43d6a1830306ead8bc3")
  (:PATH "src/recovery-series/build.lisp" :GIT-BLOB
   "803441bb2f9606a1b210e2948100b6d42fb7fd66")
  (:PATH "src/recovery-series/entry.lisp" :GIT-BLOB
   "2be5f33722d9228b002cea4290e7b5ea5b0332ba")
  (:PATH "src/recovery-series/package.lisp" :GIT-BLOB
   "51f3d64796df1a2180cb977adb8a094e7c7fd94b")
  (:PATH "src/recovery-series/preflight.lisp" :GIT-BLOB
   "375b0b9283f38fef8311f3c7c625a7b709f4d7fb")
  (:PATH "src/recovery-series/read.lisp" :GIT-BLOB
   "52f2c0a0f28f3d1cc400c0426b9c53636940f49b")
  (:PATH "src/recovery-series/stabilize-preflight.lisp" :GIT-BLOB
   "8fa32b9ce777ccc68a115d07ac5b631cf3beb874")
  (:PATH "src/recovery-series/stabilize-set-preflight.lisp" :GIT-BLOB
   "6e85ab3bc6d9374fd12f6077d3b563b9ea9ba059")
  (:PATH "src/recovery-series/stabilize-set.lisp" :GIT-BLOB
   "7441ddf350504d1a8b4277e5ae150d83b868cc58")
  (:PATH "src/recovery-series/stabilize.lisp" :GIT-BLOB
   "48a11dae75b09f70cd7a3af129d30132f8bfe26f")
  (:PATH "src/recovery-series/types.lisp" :GIT-BLOB
   "c732f86b1cabe522e8a411c5c4e1d6e40828b6e0")
  (:PATH "src/recovery/decisions-build.lisp" :GIT-BLOB
   "87cc54024e59757c16e20f3025970b1699b11662")
  (:PATH "src/recovery/decisions-package.lisp" :GIT-BLOB
   "58a3e620a8def39d2b24cd210d9283184c247ed2")
  (:PATH "src/recovery/decisions-query.lisp" :GIT-BLOB
   "bca1698068955fb8de9959e23ee30e55ecc9c699")
  (:PATH "src/recovery/decisions-radix.lisp" :GIT-BLOB
   "e58176890a26751bf5767582b279cb667a29744e")
  (:PATH "src/recovery/decisions-sort.lisp" :GIT-BLOB
   "b133ea00a3b8063e9e934a1b41f10cad024471ae")
  (:PATH "src/recovery/decisions-types.lisp" :GIT-BLOB
   "4a16574f26c35b12db7693804b9b5c35e1b85cb7")
  (:PATH "src/recovery/inventory-build.lisp" :GIT-BLOB
   "60057f6a50c657f016bee3c21c21911b582f86fe")
  (:PATH "src/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "53565668f4d3734dbf9014f929c1c0e953ed3908")
  (:PATH "src/recovery/inventory-directory.lisp" :GIT-BLOB
   "221a2c0e19f551bcae502434e369462af92bd470")
  (:PATH "src/recovery/inventory-id.lisp" :GIT-BLOB
   "752ff8bc2b6a30cfcf2bdcfdb41ecc5d9d3215c4")
  (:PATH "src/recovery/inventory-query.lisp" :GIT-BLOB
   "47810fb2944b4b5c18d9a9c8e60dfdc1c5f19db4")
  (:PATH "src/recovery/inventory-sources-build.lisp" :GIT-BLOB
   "1c36359af628a014efe9f0b090814bc93893edde")
  (:PATH "src/recovery/inventory-sources-query.lisp" :GIT-BLOB
   "006c28cd80e002b87e435d7a5bbbeb506c9f806f")
  (:PATH "src/recovery/inventory-sources-types.lisp" :GIT-BLOB
   "c4596731d1270d3cec38e2ef5a159968efbd4050")
  (:PATH "src/recovery/inventory-sources.lisp" :GIT-BLOB
   "6538cc201d9731a596e830aebf8c9e01495246c8")
  (:PATH "src/recovery/inventory-types.lisp" :GIT-BLOB
   "68c357d2d522fcabe79284c540c2631e5fa87780")
  (:PATH "src/recovery/manifest-build.lisp" :GIT-BLOB
   "e74b806f5116db46f3a385821515c317b2dcb452")
  (:PATH "src/recovery/manifest-decode.lisp" :GIT-BLOB
   "ae5b8e4677fdd1dcee2f2a1baf293f49d9ce2972")
  (:PATH "src/recovery/manifest-fold.lisp" :GIT-BLOB
   "eaddc83c63dce2fde59227e0416917bbc766e325")
  (:PATH "src/recovery/manifest-package.lisp" :GIT-BLOB
   "9754b563a1d0fbfcda0f306e94b1b6d0257dfb0e")
  (:PATH "src/recovery/manifest-query.lisp" :GIT-BLOB
   "55e56d621129d1637eac1a787bad60dd0f0405b1")
  (:PATH "src/recovery/manifest-transition.lisp" :GIT-BLOB
   "1f92455ec8c38c780b6e6455166be5c49ef3fefa")
  (:PATH "src/recovery/manifest-types.lisp" :GIT-BLOB
   "e062c804e68a8f62eddadd5c87db0e7af392744f")
  (:PATH "src/recovery/package.lisp" :GIT-BLOB
   "b97b5c9bca6955e5dc45d9d4257089ab7132f3fb")
  (:PATH "src/recovery/scan.lisp" :GIT-BLOB
   "7ad6b7541397611f1ecbda7dffdda98c4453dbf1")
  (:PATH "src/runtime/active.lisp" :GIT-BLOB
   "6145d557b43cc2e0f8e4a75e5356c7e3b1def45e")
  (:PATH "src/runtime/build.lisp" :GIT-BLOB
   "a0c63b925024e75f3edc917af2739362966db11e")
  (:PATH "src/runtime/closed-preflight.lisp" :GIT-BLOB
   "04f7eff43b919847c4db6ff3c3022282646c2868")
  (:PATH "src/runtime/closed-transfer.lisp" :GIT-BLOB
   "50dfab595a216e2d41faa4d5154ed76915adb958")
  (:PATH "src/runtime/closed.lisp" :GIT-BLOB
   "c75cda368fca40e09d93bd4ee744592be59ec48a")
  (:PATH "src/runtime/package.lisp" :GIT-BLOB
   "5eb61dac53e09bdaf493680967ab65938b6b8f63")
  (:PATH "src/runtime/preflight.lisp" :GIT-BLOB
   "c82afb340fb354ef738866c01ad59595ada09713")
  (:PATH "src/runtime/query.lisp" :GIT-BLOB
   "10cc651efa58bcd71852f9e75b00451a6cce20a6")
  (:PATH "src/runtime/types.lisp" :GIT-BLOB
   "4eeff088a44159541019ed3cfe3048bc36762f7e")
  (:PATH "src/scheduler/build.lisp" :GIT-BLOB
   "a925a9380e48a0d0018e00eb97676679db2e8eba")
  (:PATH "src/scheduler/lifecycle-build.lisp" :GIT-BLOB
   "379a139fdf6d202937a44af3ceae4444a26ed48a")
  (:PATH "src/scheduler/lifecycle-read.lisp" :GIT-BLOB
   "261ef5a3b909b3f552df0eb57fb2124d92be502c")
  (:PATH "src/scheduler/lifecycle-types.lisp" :GIT-BLOB
   "56dc619b46eb6cb3cbe934be586a8fc13e769b34")
  (:PATH "src/scheduler/lifecycle-update.lisp" :GIT-BLOB
   "34d4685b42ec26942109309666d85093a53146fd")
  (:PATH "src/scheduler/lifecycle-worker.lisp" :GIT-BLOB
   "70224b35cb011adbc0caa7738ef61fd0f2564f09")
  (:PATH "src/scheduler/package.lisp" :GIT-BLOB
   "cadff5f2e29e7c5b625b95f9387faf29aad02178")
  (:PATH "src/scheduler/policy.lisp" :GIT-BLOB
   "b9f30d56f58b77c9cf42df9481f37586faf0c4c2")
  (:PATH "src/scheduler/pool-claim.lisp" :GIT-BLOB
   "476372e627724a17b7c86257171ff1d33bd5b809")
  (:PATH "src/scheduler/read.lisp" :GIT-BLOB
   "cabd8cdb2f83333b321653fd63549eb5716d7b59")
  (:PATH "src/scheduler/types.lisp" :GIT-BLOB
   "728f410292749214a020047d8efa744c54ed0a6e")
  (:PATH "src/scheduler/update.lisp" :GIT-BLOB
   "ac1a02b8dcb4432a99ab7f93686b0c02d5c775d8")
  (:PATH "src/series/events.lisp" :GIT-BLOB
   "63fb4a20faeedceb47b8cd550262f1bdca497c06")
  (:PATH "src/series/io-events.lisp" :GIT-BLOB
   "128fe9650a741541b46d1ad0887b872cb2e85012")
  (:PATH "src/series/ownership.lisp" :GIT-BLOB
   "7352a27581b8e2e68407611e65e46773efdc333c")
  (:PATH "src/series/package.lisp" :GIT-BLOB
   "6fd26253982dba01e9eef2702c5f4ede6ba70659")
  (:PATH "src/series/publication.lisp" :GIT-BLOB
   "d5f27e3366e71651a3b41322b68d9ca7ab871fe3")
  (:PATH "src/series/query.lisp" :GIT-BLOB
   "7f91ca22b7f2f339b450db0f4c26c97f86906c58")
  (:PATH "src/series/retirement.lisp" :GIT-BLOB
   "fc42b51a0f8606687881e239ba650a9f1bb58124")
  (:PATH "src/series/routing-build.lisp" :GIT-BLOB
   "6fbe5e4720187be3bcada2dcc9fc40026267da07")
  (:PATH "src/series/routing-select.lisp" :GIT-BLOB
   "f280c35e8f7ed283d30e8f4a43bbf2f172600816")
  (:PATH "src/series/routing-types.lisp" :GIT-BLOB
   "e350df4e2fdc2f651ffbdb136bdbb266ccafcb1c")
  (:PATH "src/series/types.lisp" :GIT-BLOB
   "5630ae60278a168326cf19e7cee4eacb3deacbe6")
  (:PATH "src/series/worker-boundary.lisp" :GIT-BLOB
   "acc9f6ea83a8ef2774b41bdb114165b6bfb54949")
  (:PATH "src/series/worker-package.lisp" :GIT-BLOB
   "d0316128bae48e4251a519d7daab25dbaf52f031")
  (:PATH "src/series/worker-run.lisp" :GIT-BLOB
   "02c219d556a8cd807a0e322667dfb401d8b06fb6")
  (:PATH "src/series/worker-types.lisp" :GIT-BLOB
   "39f28974f3fae098d32d4ad1a056a45b06f777a6")
  (:PATH "src/storage/compaction-scan.lisp" :GIT-BLOB
   "233556c366a99b7b263af1c7bc19b47ceaebf940")
  (:PATH "src/storage/control-payload.lisp" :GIT-BLOB
   "7980cac6cc8070836b9aa49fc8a0d6fb42630749")
  (:PATH "src/storage/formats.lisp" :GIT-BLOB
   "fc942f1c8e30e637abaf13dc26343d40417fc72f")
  (:PATH "src/storage/log-header.lisp" :GIT-BLOB
   "fde8608e6ad3fe062937c48bdcb7d2d5870207bf")
  (:PATH "src/storage/package.lisp" :GIT-BLOB
   "c15553a65171e5dfb2dbadb62c92ed4dc48aee3a")
  (:PATH "src/storage/payload-record.lisp" :GIT-BLOB
   "0012eaf90064c4cc2949834a60e83c9db8ba6308")
  (:PATH "src/storage/payload-write.lisp" :GIT-BLOB
   "6cbbb89f681965173e9b1b95edf3f7f870af1eca")
  (:PATH "src/storage/segment-header.lisp" :GIT-BLOB
   "f1d99b205b1ea5e6ad059ecd7971d3633411b040")
  (:PATH "src/wal/builder.lisp" :GIT-BLOB
   "0b271d0c3d7ef0cbdee8f43784132ae298139c3a")
  (:PATH "src/wal/csn.lisp" :GIT-BLOB
   "f65662b4dea8ef04e4e59ce38b29a94fecea4f6c")
  (:PATH "src/wal/executor.lisp" :GIT-BLOB
   "edc8ce7474365e0885925d557a378779655d2e70")
  (:PATH "src/wal/frame.lisp" :GIT-BLOB
   "b7205104847e4ddc54750b4f38a23a5775476e60")
  (:PATH "src/wal/group.lisp" :GIT-BLOB
   "8245bc10cedafbff8665489fbced6833f078a373")
  (:PATH "src/wal/package.lisp" :GIT-BLOB
   "e0ea179069a7b297c7c26f6c294c7d4aea3db671")
  (:PATH "src/wal/types.lisp" :GIT-BLOB
   "d4bf29cbdbda20de65b650aa9e7bd19cc2d910b1")
  (:PATH "tests/cache/README.md" :GIT-BLOB
   "a963e5f7febd0c2a7f74aeb52cba3d6510c50476")
  (:PATH "tests/cache/guards.lisp" :GIT-BLOB
   "af881fd91c3820ab19d1daa2d56f1fe57257d08f")
  (:PATH "tests/cache/support.lisp" :GIT-BLOB
   "fd829e7352ba878e73df30d979e9558ff6ccba14")
  (:PATH "tests/cache/threads.lisp" :GIT-BLOB
   "ca03c59f0fada09cae8c452fed6490de32d4a3a6")
  (:PATH "tests/ci-catalog.lisp" :GIT-BLOB
   "15b3b3126a8dc57fe98d4dccd5c85d1fcb88204b")
  (:PATH "tests/codec/cbor-array-write-support.lisp" :GIT-BLOB
   "2a47078354c45a5775f48f6dd8f5d784da7de202")
  (:PATH "tests/codec/cbor-array-write-threads.lisp" :GIT-BLOB
   "43bac6c9604140af2594d85b76c14c3101b6925b")
  (:PATH "tests/codec/cbor-array-write.lisp" :GIT-BLOB
   "b13f58264f3cd97e1947ee52936732a7fcebe672")
  (:PATH "tests/codec/cbor-float-write-support.lisp" :GIT-BLOB
   "5416b62340ae8f3332915f8891529d95549a5fba")
  (:PATH "tests/codec/cbor-float-write-threads.lisp" :GIT-BLOB
   "3b0840150945cd4f118516b1d6d61524fa6856fa")
  (:PATH "tests/codec/cbor-float-write.lisp" :GIT-BLOB
   "747cd8a72445a3ea638cd1910bc9faa63f4cdc33")
  (:PATH "tests/codec/cbor-header.lisp" :GIT-BLOB
   "a1541916590304adccc2092c226ef3be9c644168")
  (:PATH "tests/codec/cbor-item-read-support.lisp" :GIT-BLOB
   "0326100362a1c4b24d2c7e511e45357f09a56d33")
  (:PATH "tests/codec/cbor-item-read-threads.lisp" :GIT-BLOB
   "a0da65545ed80ede0a967cadbb337731f6fe1ce9")
  (:PATH "tests/codec/cbor-item-read.lisp" :GIT-BLOB
   "b2cbdcb4255c51d9da4fe73b28939c1cb923fefe")
  (:PATH "tests/codec/cbor-map-write-support.lisp" :GIT-BLOB
   "113bfc4529199f69dea1862baec0aa7403c6fa97")
  (:PATH "tests/codec/cbor-map-write-threads.lisp" :GIT-BLOB
   "892d30fd1c7a8f12430c6caa6f43ee872574eb09")
  (:PATH "tests/codec/cbor-map-write.lisp" :GIT-BLOB
   "6ad0e9b5a48ba9c32c46d720f2f7f1821368d6c8")
  (:PATH "tests/codec/cbor-minimal-edges.lisp" :GIT-BLOB
   "c6f891dff335a37689ddbfabccf793d2e9f2f143")
  (:PATH "tests/codec/cbor-minimal-scan-support.lisp" :GIT-BLOB
   "c2af64af4e5f8b5f669819fd56a00f416b3aaf0d")
  (:PATH "tests/codec/cbor-minimal-scan-threads.lisp" :GIT-BLOB
   "532c3f1d5898083364f17f9fc9cbf0da7b798bda")
  (:PATH "tests/codec/cbor-minimal-scan.lisp" :GIT-BLOB
   "1742189ff6845197ba76996c09c1097d59216fcb")
  (:PATH "tests/codec/cbor-minimal-support.lisp" :GIT-BLOB
   "774e6cd0bec4a9d2242ad4dede878ffa2afca90c")
  (:PATH "tests/codec/cbor-minimal-threads.lisp" :GIT-BLOB
   "d88b573a98689b5e1c0cbade8f8a7ac69470554f")
  (:PATH "tests/codec/cbor-minimal.lisp" :GIT-BLOB
   "b863ace9a22e8b7508b7c9d8f91465ebfbcd4e98")
  (:PATH "tests/codec/cbor-simple-write-support.lisp" :GIT-BLOB
   "0989d7f8e43ec7213df856b842b1e9149df96d9f")
  (:PATH "tests/codec/cbor-simple-write-threads.lisp" :GIT-BLOB
   "186f1772335ce33e4e3d1d933bf4d4e91fe0763f")
  (:PATH "tests/codec/cbor-simple-write.lisp" :GIT-BLOB
   "efaa31b8ea2d74af162fd00a3b4e923ae5f60cdd")
  (:PATH "tests/codec/cbor-string-read-support.lisp" :GIT-BLOB
   "cfd55cd47d782673113e67af625c1360195a345c")
  (:PATH "tests/codec/cbor-string-read-threads.lisp" :GIT-BLOB
   "c3686d6e47ad56e53db556747ee2d49cea527df5")
  (:PATH "tests/codec/cbor-string-read.lisp" :GIT-BLOB
   "8437bdcaa4cf308dbf4614e748cdab4be2ae6d62")
  (:PATH "tests/codec/cbor-string-write-support.lisp" :GIT-BLOB
   "66b5d03695f522cca8013ccdad3ede690cc63412")
  (:PATH "tests/codec/cbor-string-write-threads.lisp" :GIT-BLOB
   "16cc32f2c51d28f75a64b93ead642340f88e9c05")
  (:PATH "tests/codec/cbor-string-write.lisp" :GIT-BLOB
   "ed0f6a67c46498bdc9c721480cb76bc727fc5b4f")
  (:PATH "tests/codec/cbor-structure-support.lisp" :GIT-BLOB
   "e9cc8a08917903cab7b7f5617225884b7d89e6c4")
  (:PATH "tests/codec/cbor-structure-threads.lisp" :GIT-BLOB
   "595d51a96ee3767c13797910ea324061a4788617")
  (:PATH "tests/codec/cbor-structure.lisp" :GIT-BLOB
   "7e9b7a518bc3a260d721e85d62ff986553bb06de")
  (:PATH "tests/codec/cbor-support.lisp" :GIT-BLOB
   "172c4a335b2d504f785b2036532346a24ccf1378")
  (:PATH "tests/codec/cbor-tag-write-support.lisp" :GIT-BLOB
   "e6e1e91e5ed95019e20b11d2dc0e408911acb46e")
  (:PATH "tests/codec/cbor-tag-write-threads.lisp" :GIT-BLOB
   "1c731f7ed83f703e3d2a8a4c57e6c702ef127887")
  (:PATH "tests/codec/cbor-tag-write.lisp" :GIT-BLOB
   "df97950ec8d24157bb6566c7995262f7beea7742")
  (:PATH "tests/codec/cbor-threads.lisp" :GIT-BLOB
   "0f66cc1f8b493598d436b1d62d7211f4196fb430")
  (:PATH "tests/codec/cbor-write-roundtrip.lisp" :GIT-BLOB
   "e225cb69e82ad1038da71e31b6513619f5e09d40")
  (:PATH "tests/codec/cbor-write-support.lisp" :GIT-BLOB
   "92327e4b840b8586c50c32a7732e718ee6e9db98")
  (:PATH "tests/codec/cbor-write-threads.lisp" :GIT-BLOB
   "7717054be474eba254f3f645fc62ec4ef65a511c")
  (:PATH "tests/codec/cbor-write.lisp" :GIT-BLOB
   "903a213c810d99fdefc2af2afa93445574a13be7")
  (:PATH "tests/codec/support.lisp" :GIT-BLOB
   "6b8226ae1b41dc9e47e45986e18287a10a8d54e7")
  (:PATH "tests/codec/threads.lisp" :GIT-BLOB
   "0c1a6d9fbe44a95b951a7e1a9aad90f65cef961b")
  (:PATH "tests/codec/utf8.lisp" :GIT-BLOB
   "59e3ffc9cee96d97ef20d132e3e531aef2f9ddf7")
  (:PATH "tests/control/native.lisp" :GIT-BLOB
   "2107cb66de45ded987c7fb1392155ff6afebbed6")
  (:PATH "tests/control/publication.lisp" :GIT-BLOB
   "f987c9317990ce977ecadb747268b39d2612eba1")
  (:PATH "tests/control/recovery-guards.lisp" :GIT-BLOB
   "b2e877dfcc35468cfafd95f398f33d1415692c1f")
  (:PATH "tests/control/recovery-publication.lisp" :GIT-BLOB
   "cd99169af8aecf204ce9cd2e6e1f2a9fbb081f68")
  (:PATH "tests/control/recovery-read.lisp" :GIT-BLOB
   "21f33af3220a237d7a8dc2ff3a98bfd4c41fa201")
  (:PATH "tests/control/support.lisp" :GIT-BLOB
   "053d81269526d2e7c78181fbe2f8e58ac3f878f3")
  (:PATH "tests/csn/registry.lisp" :GIT-BLOB
   "b5c507d831098b28e6d1fe7880a01e1a3cb8ded2")
  (:PATH "tests/csn/support.lisp" :GIT-BLOB
   "a6c462233eed3bbdf9f08feb0195488688af287c")
  (:PATH "tests/csn/threads.lisp" :GIT-BLOB
   "b198b4936a119a6194e720cd51a6cbe5f49d72c1")
  (:PATH "tests/engine/lifecycle.lisp" :GIT-BLOB
   "55f8a525a7fb68846724b869d15eee8238924fe3")
  (:PATH "tests/engine/processes.lisp" :GIT-BLOB
   "6f26d9267249e8a122de343dffe9830b2f2f8238")
  (:PATH "tests/engine/support.lisp" :GIT-BLOB
   "ca131303ada021ede08046975067682ec7d88377")
  (:PATH "tests/epochs/lifecycle.lisp" :GIT-BLOB
   "6980f8ef0aec2f962d2c85c38ad5b712132ce2be")
  (:PATH "tests/epochs/support.lisp" :GIT-BLOB
   "de53c4db528218c5bb4e074d7cd26a4a38f0ecc5")
  (:PATH "tests/epochs/threads.lisp" :GIT-BLOB
   "a7e34763661de9edd8bd049c817ba961cc1d3104")
  (:PATH "tests/execution/handoff.lisp" :GIT-BLOB
   "ba702352ee63241b9ac993b0aca8f162c3deef1b")
  (:PATH "tests/execution/queue.lisp" :GIT-BLOB
   "546d4215f9f63007f632c522f0f8c1e75ac4bbeb")
  (:PATH "tests/execution/ready-recycle.lisp" :GIT-BLOB
   "1dff8707436ca52f20f62e9946621ca1037f33d2")
  (:PATH "tests/execution/ready.lisp" :GIT-BLOB
   "9f81552333f86fe0b20f2d5e8ba48b20634f5a09")
  (:PATH "tests/execution/support.lisp" :GIT-BLOB
   "b8bac07926727a644f0246f6b57d600332288310")
  (:PATH "tests/execution/threads.lisp" :GIT-BLOB
   "b1e71783b65b85e6253f733098c3153d41c4971c")
  (:PATH "tests/execution/worker.lisp" :GIT-BLOB
   "2a14573906b94b254712a1e9322058ec1081f6f8")
  (:PATH "tests/foundation/batch.lisp" :GIT-BLOB
   "00bb40ad87340ee86f5da281c09207c8da8888a6")
  (:PATH "tests/foundation/binary.lisp" :GIT-BLOB
   "ff6df200a7ace3af204b622969a387ce7a1e1504")
  (:PATH "tests/foundation/record.lisp" :GIT-BLOB
   "4294dcba9b307bddd9cc3636d7e2865f0f7030c5")
  (:PATH "tests/foundation/support.lisp" :GIT-BLOB
   "d383b1cddf929ba0340d1b74eec3ec03673eac09")
  (:PATH "tests/fulltext/admission-concurrency.lisp" :GIT-BLOB
   "fbc2b0294a9369c4812bf206f001399be2af0ff3")
  (:PATH "tests/fulltext/admission-guards.lisp" :GIT-BLOB
   "b3475774a8a7f31269ea0e1b33bb659e230f67c7")
  (:PATH "tests/fulltext/admission-lifecycle.lisp" :GIT-BLOB
   "175c3e3bd33b163bc7593066ade68eb426e8e757")
  (:PATH "tests/fulltext/admission-resources.lisp" :GIT-BLOB
   "29ac6bf4b0b392579997b79c10142b2f491a5eb7")
  (:PATH "tests/fulltext/admission-rows-support.lisp" :GIT-BLOB
   "1713cd556e5e37525af25a15b4f5b36474967d88")
  (:PATH "tests/fulltext/admission-rows.lisp" :GIT-BLOB
   "6e2d6c65c8046ad7dee030a4e95330f3ce3993dd")
  (:PATH "tests/fulltext/admission-support.lisp" :GIT-BLOB
   "1eaef196dc555b086cd53584731041bfb97cda59")
  (:PATH "tests/fulltext/admission.lisp" :GIT-BLOB
   "74ed0e49ce0c839cb5e74d854704d21cb8dbbf68")
  (:PATH "tests/fulltext/allocation-threads.lisp" :GIT-BLOB
   "870a308baeed93e1aabb6dc9a88db443592439c0")
  (:PATH "tests/fulltext/analysis-conformance.lisp" :GIT-BLOB
   "ad704e6457ad7873b3eb2feea241da5129962c8f")
  (:PATH "tests/fulltext/analysis-support.lisp" :GIT-BLOB
   "805f7e60fd3f6aa25b4c53680e5251188e57868e")
  (:PATH "tests/fulltext/analysis.lisp" :GIT-BLOB
   "4d529aef551bd365f0c12eb3dffbb7b2960fae56")
  (:PATH "tests/fulltext/codec-corruption.lisp" :GIT-BLOB
   "c62dd05be34d1f653eed8565cc0b40b950bdb97f")
  (:PATH "tests/fulltext/codec-differential.lisp" :GIT-BLOB
   "91b651930dd7f9da36fd317453686d272e0d2c40")
  (:PATH "tests/fulltext/codec-guards.lisp" :GIT-BLOB
   "9f6b8e823ae25c43b767141e0193b908ca0e763a")
  (:PATH "tests/fulltext/codec-support.lisp" :GIT-BLOB
   "890e176db757eed9e2680f5b247a12922709d4b9")
  (:PATH "tests/fulltext/codec.lisp" :GIT-BLOB
   "50b924b1c0e9127da33413f1100bf04ef2ee500d")
  (:PATH "tests/fulltext/document-differential.lisp" :GIT-BLOB
   "78466a8bc1213d0794155535eb28a990a45a38aa")
  (:PATH "tests/fulltext/document-guards.lisp" :GIT-BLOB
   "608f322bd4ac149abb9ffbb352595b5c94d3d217")
  (:PATH "tests/fulltext/document-support.lisp" :GIT-BLOB
   "57d59f345c6cbe8dba253acce7993409b5bbed94")
  (:PATH "tests/fulltext/document.lisp" :GIT-BLOB
   "ab305e31ece6bf7fd20ac5b7ea119b01c57e7c92")
  (:PATH "tests/fulltext/format-guards.lisp" :GIT-BLOB
   "9a23048572dfa5eee314221ced3425a1ea46c28a")
  (:PATH "tests/fulltext/format-support.lisp" :GIT-BLOB
   "d03bd892800d593a3550bdc709d43c357041bfab")
  (:PATH "tests/fulltext/format-threads.lisp" :GIT-BLOB
   "b8e8eb4491b59c721071396ce656eb09186f988d")
  (:PATH "tests/fulltext/format.lisp" :GIT-BLOB
   "b7cb19b82d4e50d457c603b8708693adf27785f0")
  (:PATH "tests/fulltext/index.lisp" :GIT-BLOB
   "0673c32fe456a9cb77cf4aa5cc4e071a888cccf2")
  (:PATH "tests/fulltext/minimum-v2.hex" :GIT-BLOB
   "c4db496b0e5b920665d1c80bea204f6227da1f0e")
  (:PATH "tests/fulltext/put-concurrency.lisp" :GIT-BLOB
   "613b2e5a89d505701583aa9c68e6273f4163d2e7")
  (:PATH "tests/fulltext/put-guards.lisp" :GIT-BLOB
   "6b531c1b143860a46e84d5c77da982f54fbd413b")
  (:PATH "tests/fulltext/put-lifecycle.lisp" :GIT-BLOB
   "8cba90b629299c8494194a73ef8b819f554ca557")
  (:PATH "tests/fulltext/put-physical-guards.lisp" :GIT-BLOB
   "bd293d0ef1d5596e85859cb85e41639b3a0fd70e")
  (:PATH "tests/fulltext/put-physical-native.lisp" :GIT-BLOB
   "635118c4287ab13b4b98e34d04dc307b97497827")
  (:PATH "tests/fulltext/put-physical-support.lisp" :GIT-BLOB
   "1e81cc2af12f24515debc953d4f7884b07a2e197")
  (:PATH "tests/fulltext/put-physical.lisp" :GIT-BLOB
   "f8d1fa41090aaa40c2146ec9280bff08d968fdce")
  (:PATH "tests/fulltext/put-rows.lisp" :GIT-BLOB
   "0ee39c61cdbb6742eb36d65677030d44c96ad98e")
  (:PATH "tests/fulltext/put-support.lisp" :GIT-BLOB
   "2a3c9b543587b1a9c5402a16f82cfc1c671a6160")
  (:PATH "tests/fulltext/put.lisp" :GIT-BLOB
   "83f9503ec4bd1a6610443bb8eea991e6069c6565")
  (:PATH "tests/get-active/construction.lisp" :GIT-BLOB
   "ec2831edef2e452597ce867b026eb73c84fc5214")
  (:PATH "tests/get-active/directory.lisp" :GIT-BLOB
   "48c9a60e58536170a610844e853eae6f91beeff1")
  (:PATH "tests/get-active/preflight.lisp" :GIT-BLOB
   "7f41c04257e0bab10a2ffbc091b02d660029c4df")
  (:PATH "tests/get-active/read.lisp" :GIT-BLOB
   "0ab8c2b2b639a51b0217876a896d9468f41e22de")
  (:PATH "tests/get-active/support.lisp" :GIT-BLOB
   "0eb0864894f8f8cb32221ff98c75dde5aff80c26")
  (:PATH "tests/get-directory/README.md" :GIT-BLOB
   "24543b1595fbd12972e7073680fde062337b8417")
  (:PATH "tests/get-directory/construction.lisp" :GIT-BLOB
   "537a67a6931f1c7445e68bd30683c08108bf37e7")
  (:PATH "tests/get-directory/lifetime-support.lisp" :GIT-BLOB
   "cd514970e84f8654318dcc23a6b1ef24323be8a9")
  (:PATH "tests/get-directory/lifetime.lisp" :GIT-BLOB
   "c57261d2de469318402d5bf79f5ab5d27108bb46")
  (:PATH "tests/get-directory/read.lisp" :GIT-BLOB
   "04c509eb39d9f552f4d2762630c20861e7b1c48f")
  (:PATH "tests/get-directory/series-read.lisp" :GIT-BLOB
   "b500bb83170622b6d96edbd363ebc85240064c18")
  (:PATH "tests/get-directory/series-support.lisp" :GIT-BLOB
   "ead990e110b588bb4df35ea17d3816db3b79cee5")
  (:PATH "tests/get-directory/support.lisp" :GIT-BLOB
   "a5b09ee5120bedc4e946366239dd5e6c978b27d2")
  (:PATH "tests/get-directory/threads.lisp" :GIT-BLOB
   "832073baa5d1e8aefe89ac42dc60023c96038ba3")
  (:PATH "tests/get-performance/README.md" :GIT-BLOB
   "199d6d77437b8ce90178716c4ca37ebdb85ebc2f")
  (:PATH "tests/get-performance/guards.lisp" :GIT-BLOB
   "9bbf7b2ceb817d6ecf2e7c67b0928373c2c07f70")
  (:PATH "tests/get-performance/paths.lisp" :GIT-BLOB
   "160dae42a9723e9b0e93a085864affa96a4cd6be")
  (:PATH "tests/get-performance/support.lisp" :GIT-BLOB
   "f7eac312809b34fa72dcd3b9a8b67d290cb08cd6")
  (:PATH "tests/get-performance/threads.lisp" :GIT-BLOB
   "5780e3ef9c9e34a4098ddbd72e19cebfa6a34edd")
  (:PATH "tests/get-resolver/construction.lisp" :GIT-BLOB
   "322c63ee6576304ca1ab19e28b902b680bc2acae")
  (:PATH "tests/get-resolver/read.lisp" :GIT-BLOB
   "a1788d1aab3f76b9dc29095676ec42f3a1f936a8")
  (:PATH "tests/get-resolver/sort.lisp" :GIT-BLOB
   "442ce9eef4fac8f593a9d94ed08a76b830773563")
  (:PATH "tests/get-resolver/support.lisp" :GIT-BLOB
   "11d5cf0efe8ee4f5606707cc7eca175442a50190")
  (:PATH "tests/get/lifecycle.lisp" :GIT-BLOB
   "c65090a98c47f89d42ea8e77f00d402afbb9a9bc")
  (:PATH "tests/get/segment.lisp" :GIT-BLOB
   "125d274ba50ba29a9c0d7e1d04ce8e22f7f240f2")
  (:PATH "tests/get/support.lisp" :GIT-BLOB
   "387c1101e92dce8482c3d0e27a47fa42f21e3501")
  (:PATH "tests/hash/guards.lisp" :GIT-BLOB
   "3a4454e0f55fe12ff4c84a44aa60509623621b93")
  (:PATH "tests/hash/hash64.lisp" :GIT-BLOB
   "5044b9d9d2e5872a78bfc81d9ff3c3295b242069")
  (:PATH "tests/hash/support.lisp" :GIT-BLOB
   "be3d132c4eeb9e4ee0892a98174b9e10771a38a9")
  (:PATH "tests/hash/threads.lisp" :GIT-BLOB
   "0b804901ec2c1de69c0781c08a30f8389b2d3d34")
  (:PATH "tests/index/hash-digests.lisp" :GIT-BLOB
   "bee75932d859ac1c3d02147672f9186e53d71b5b")
  (:PATH "tests/index/mode-policy.lisp" :GIT-BLOB
   "4513fb320a9f1ced973820d8a9c58ee9a0d73ea6")
  (:PATH "tests/index/mode-support.lisp" :GIT-BLOB
   "14d4c82bd54795844d14ac1d7f1b7ced320c4233")
  (:PATH "tests/index/page-chains.lisp" :GIT-BLOB
   "265a85cd6aff51dd8a5ceae50f60ff7b8d63660e")
  (:PATH "tests/index/page-corruption.lisp" :GIT-BLOB
   "880775f39ed5c6352c0ae448b7a830ea63b03a85")
  (:PATH "tests/index/page-fixtures.lisp" :GIT-BLOB
   "0ed84fd77dc21375773651e4bb42e56a2c0a5e43")
  (:PATH "tests/index/page-support.lisp" :GIT-BLOB
   "920c631d2763260aec7bcb02d3172d8be1d4b21f")
  (:PATH "tests/index/page-tests.lisp" :GIT-BLOB
   "a18f0315e5480a356504f1f541bffc1ad3484fc6")
  (:PATH "tests/index/primary-support.lisp" :GIT-BLOB
   "38c629112ce062064d66409349f76ba91b26801f")
  (:PATH "tests/index/primary-threads.lisp" :GIT-BLOB
   "289d129a4ae1690c24874714bae3812ee01bad8b")
  (:PATH "tests/index/primary.lisp" :GIT-BLOB
   "d21142f34f3687c35f39c86d962f2c8ffd52c330")
  (:PATH "tests/index/rebuild.lisp" :GIT-BLOB
   "838091c9035b5a489c12467daf3a564de1ca0746")
  (:PATH "tests/index/slot-support.lisp" :GIT-BLOB
   "384a6ac91ac56abfe7db43d587366ba6eaf369aa")
  (:PATH "tests/index/slot-threads.lisp" :GIT-BLOB
   "f7eee8b0026ee742163ab90d31a7b09263820033")
  (:PATH "tests/index/slots.lisp" :GIT-BLOB
   "5f443c496559abe79e0abace6555dc96eb6c4276")
  (:PATH "tests/io/create-relative-native.lisp" :GIT-BLOB
   "fd5e819e2197869a93259857aacfa68bfe9e9a44")
  (:PATH "tests/io/create-relative-support.lisp" :GIT-BLOB
   "8382ffb8f04b6d2fc3e4adb89f995c9c37b0e445")
  (:PATH "tests/io/create-relative.lisp" :GIT-BLOB
   "7fb4c3665ca1b8f6de2dedd2827cfc150dcddf02")
  (:PATH "tests/io/directory-lock.lisp" :GIT-BLOB
   "4cefd15616f4ac2312a669b1242929d2706eb540")
  (:PATH "tests/io/flush-failure.lisp" :GIT-BLOB
   "76a80588d99b441e8c57a97f9a10d4d9d6c7b59b")
  (:PATH "tests/io/native.lisp" :GIT-BLOB
   "bb3f9a460953d5575d7333b8b6eef6ecdb8e1e7d")
  (:PATH "tests/io/open-relative-native.lisp" :GIT-BLOB
   "cdb197bf2760de70e7ec49af76e2954a18006997")
  (:PATH "tests/io/open-relative-support.lisp" :GIT-BLOB
   "4256567b2a10423a41540298317c8ef80e6b5af0")
  (:PATH "tests/io/open-relative.lisp" :GIT-BLOB
   "4bec9451a13db1437e081bda2858d4cb8b1e5de1")
  (:PATH "tests/io/rename-native.lisp" :GIT-BLOB
   "99f79041529d20d0ea774b01e3ed82fc5a274cdd")
  (:PATH "tests/io/rename.lisp" :GIT-BLOB
   "e83443eec6187d53118795c4f6ee797112f27ea2")
  (:PATH "tests/io/support.lisp" :GIT-BLOB
   "0179a0c19bdde944f47fe83716ecc6241e37c686")
  (:PATH "tests/io/transfer-failure.lisp" :GIT-BLOB
   "c87c80fb9c82062bf4d4179d67f710ff10b4f051")
  (:PATH "tests/io/transfer.lisp" :GIT-BLOB
   "40c8f4d5e2d493db090d5d09ab024c67ca6f4037")
  (:PATH "tests/lint-fixtures/bad.lisp" :GIT-BLOB
   "d0d5fd7285428e569d3dd595a0c38de5211e10a5")
  (:PATH "tests/lint-fixtures/good.lisp" :GIT-BLOB
   "35558ab0ab2be7688e9fd55a38be44ebe9a57f37")
  (:PATH "tests/lint-fixtures/keyword-barrier.lisp" :GIT-BLOB
   "b71f5472914b386c88fe6bf079470d19a40a9b96")
  (:PATH "tests/lint-fixtures/qualified-reader.lisp" :GIT-BLOB
   "583969b51a66447b4dfffd6a8fba19e156550e8d")
  (:PATH "tests/local/native.lisp" :GIT-BLOB
   "b8891b57aa6229995b7c6ee5581d9cde650e3c93")
  (:PATH "tests/local/processes.lisp" :GIT-BLOB
   "65cad807de3003796e391c914b348fc7430cdb12")
  (:PATH "tests/local/server.lisp" :GIT-BLOB
   "ee847591e0e200b8c66769a6340666c528cd46d8")
  (:PATH "tests/local/wire.lisp" :GIT-BLOB
   "349d7df061b5871658ad3fa6a14601bd58f1fa2c")
  (:PATH "tests/mvcc/capture.lisp" :GIT-BLOB
   "3e08116a1f53e1b764a2f62d9174ff11037a8399")
  (:PATH "tests/mvcc/lifecycle.lisp" :GIT-BLOB
   "2cc481df77ba8d2353985d5a4fb94644fd0861e2")
  (:PATH "tests/mvcc/support.lisp" :GIT-BLOB
   "ca49c8db671b145088d7acfac77cc28a4777dfc2")
  (:PATH "tests/read/lifecycle.lisp" :GIT-BLOB
   "6b20bd639c91aee4c0011b26ba10487ab0f54cc0")
  (:PATH "tests/read/support.lisp" :GIT-BLOB
   "e7f982fc2737ac7c0985c4881325be2711f30bd1")
  (:PATH "tests/read/threads.lisp" :GIT-BLOB
   "b4961a7cb2455d792430a31e8a7528f4561ddc54")
  (:PATH "tests/recovery-active-checkpoint/guards.lisp" :GIT-BLOB
   "cae7d70c2a5598bb5c3e1256ef4bb8b391656f6f")
  (:PATH "tests/recovery-active-checkpoint/publication.lisp" :GIT-BLOB
   "a996bc5f82f16fe12a74d9bee5962f8d8629f53a")
  (:PATH "tests/recovery-active-checkpoint/semantics.lisp" :GIT-BLOB
   "a4b80a1a678cdc4537ee9d989f178124829e70cb")
  (:PATH "tests/recovery-active-checkpoint/support.lisp" :GIT-BLOB
   "998ab160b939c93797fc90206a9b50f2cf55e452")
  (:PATH "tests/recovery-active/publication.lisp" :GIT-BLOB
   "8a3c4ba88dd7010c65a464d231ebdab2c8c27e67")
  (:PATH "tests/recovery-active/read.lisp" :GIT-BLOB
   "63f52ee0e0ab244ed278562a5d7fbc752b7617e7")
  (:PATH "tests/recovery-active/semantics.lisp" :GIT-BLOB
   "1d3c935a1169904c900461b67adb96f4dfd96b94")
  (:PATH "tests/recovery-active/support.lisp" :GIT-BLOB
   "5ebf9d06ae855b07875aadc10e2a8ac01ba56036")
  (:PATH "tests/recovery-archive-csn/guards.lisp" :GIT-BLOB
   "a6d91274479da64fa689ca370ff495cc96ae0e51")
  (:PATH "tests/recovery-archive-csn/native.lisp" :GIT-BLOB
   "d66af858c855e39c984f1ff8534e6de3c7c7fc88")
  (:PATH "tests/recovery-archive-csn/plan.lisp" :GIT-BLOB
   "b740c77023c500208ff742e02c4d5aebcd44db70")
  (:PATH "tests/recovery-archive-csn/set.lisp" :GIT-BLOB
   "d163bf160241d2225ac3282c1d925aa65e249ab3")
  (:PATH "tests/recovery-archive-csn/support.lisp" :GIT-BLOB
   "0c458a3f6f8aa062c2cc8831834c29159e09762d")
  (:PATH "tests/recovery-archive/active.lisp" :GIT-BLOB
   "ccbaaa3294880905584ad42c0601201fa3a3dc36")
  (:PATH "tests/recovery-archive/guards.lisp" :GIT-BLOB
   "8afea2a3df30099c07badd7d9c0bcf627a5f9a9d")
  (:PATH "tests/recovery-archive/native.lisp" :GIT-BLOB
   "ae8df9ced72f9142ade184ec78bdc576e05593e1")
  (:PATH "tests/recovery-archive/query.lisp" :GIT-BLOB
   "b0a56949ec13ec7c80466ac8b3cecc79c0fc6d63")
  (:PATH "tests/recovery-archive/read.lisp" :GIT-BLOB
   "22d1042700435e2c15e3f610f9ada9c4a8d8d4ed")
  (:PATH "tests/recovery-archive/support.lisp" :GIT-BLOB
   "0cbefaed0f74c8e34e4cea9a359c58f9196f22ad")
  (:PATH "tests/recovery-closed/csn.lisp" :GIT-BLOB
   "754611c3818a0aac26b189392d4024a251439d0c")
  (:PATH "tests/recovery-closed/guards.lisp" :GIT-BLOB
   "344857641ef2206d4d5a800fbb93b834a9f13c4d")
  (:PATH "tests/recovery-closed/publication.lisp" :GIT-BLOB
   "72f179d28936100b91d1847eeb8a24c696552619")
  (:PATH "tests/recovery-closed/read.lisp" :GIT-BLOB
   "0e401337f36768cd63206cbb7b6adf91eeeeb1ef")
  (:PATH "tests/recovery-closed/semantics.lisp" :GIT-BLOB
   "a931be1523c72d49e955aa7708bec6bd3b273be0")
  (:PATH "tests/recovery-closed/support.lisp" :GIT-BLOB
   "15bafc01c04fe1763d9a6580f6ad0bbb1917f40c")
  (:PATH "tests/recovery/corruption.lisp" :GIT-BLOB
   "2f9ead22a4e3b45cb3a680aa3a32a94bfcc6d77f")
  (:PATH "tests/recovery/decisions-audit.lisp" :GIT-BLOB
   "1b79a76515d8b8c2e67c46700cd6968b40047d62")
  (:PATH "tests/recovery/decisions-radix.lisp" :GIT-BLOB
   "232312cdd4ed6b1efcedc33ddda0fd8d1d8545d7")
  (:PATH "tests/recovery/decisions-support.lisp" :GIT-BLOB
   "f67450a9d681512a4b66efe1af1bfc82180e0058")
  (:PATH "tests/recovery/decisions.lisp" :GIT-BLOB
   "28d04d8738f077bf21ac22393a4014b518a6a0f2")
  (:PATH "tests/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "e6f289d77025dce439787287abc6a4dde0ac69f5")
  (:PATH "tests/recovery/inventory-directory-native.lisp" :GIT-BLOB
   "8f89629becea88fdc74c920a59676412c3a7b976")
  (:PATH "tests/recovery/inventory-directory-support.lisp" :GIT-BLOB
   "c316b3647e7ea5391d687917fe802907f2273bb4")
  (:PATH "tests/recovery/inventory-directory.lisp" :GIT-BLOB
   "ead38feadd94f49276596d0abf989f29d13af497")
  (:PATH "tests/recovery/inventory-id.lisp" :GIT-BLOB
   "1f05c46bfc887984c476bd7673d2b2dde998c44d")
  (:PATH "tests/recovery/inventory-sources-native.lisp" :GIT-BLOB
   "86144ee3fe19ef0f2a54c9760ed193860881ced4")
  (:PATH "tests/recovery/inventory-sources-support.lisp" :GIT-BLOB
   "36b79c4091825c32ffc3aa32a146ee5121881ebc")
  (:PATH "tests/recovery/inventory-sources.lisp" :GIT-BLOB
   "3ffd5a9fb098ab4aeb091a6823fcec68d22c19aa")
  (:PATH "tests/recovery/inventory-support.lisp" :GIT-BLOB
   "06eeff2101a97f9abdec6b6f14aa621c2fec29fd")
  (:PATH "tests/recovery/inventory.lisp" :GIT-BLOB
   "0d5722e4f5ba0025d3a6fb38f0bd056a3ea0b8e9")
  (:PATH "tests/recovery/manifest-audit.lisp" :GIT-BLOB
   "9dc9667bdae700ff8ff2afc93bb385c0617eda70")
  (:PATH "tests/recovery/manifest-support.lisp" :GIT-BLOB
   "7d3b1be9964aba5894215f29b7eda3d7a14a797f")
  (:PATH "tests/recovery/manifest-transition.lisp" :GIT-BLOB
   "cdde7b60edddd974153ee670d859a94993afa367")
  (:PATH "tests/recovery/manifest.lisp" :GIT-BLOB
   "085e019e251106f6feecc7452e7b2d471a1a626f")
  (:PATH "tests/recovery/scan.lisp" :GIT-BLOB
   "1c7d71c32d58b05f7e06450680270cb55f6325dc")
  (:PATH "tests/recovery/support.lisp" :GIT-BLOB
   "f784671c59065b4363bcc5e49f06559b11e6562c")
  (:PATH "tests/runtime/adoption.lisp" :GIT-BLOB
   "8fbee7f08a25445b66895ae2e329a217070f67f4")
  (:PATH "tests/runtime/bootstrap.lisp" :GIT-BLOB
   "1398120574f95ebaec3c7431a74a35e0ced01652")
  (:PATH "tests/runtime/guards.lisp" :GIT-BLOB
   "a097cc38e13a1ef7369a2ed996d042718cf7312c")
  (:PATH "tests/runtime/native.lisp" :GIT-BLOB
   "e92ba03fb8184a6c95c44269a26a831b714974a1")
  (:PATH "tests/runtime/support.lisp" :GIT-BLOB
   "7d4dc59eab68672512aed0f4ae578436e669fe2e")
  (:PATH "tests/runtime/threads.lisp" :GIT-BLOB
   "2454593a231d5d6bb9ef4318eb06567ce3192d24")
  (:PATH "tests/scheduler/controller.lisp" :GIT-BLOB
   "8e14282e1f42f3b247a5c578d8a683ddc6147381")
  (:PATH "tests/scheduler/dispatch.lisp" :GIT-BLOB
   "6a493f0022ac8c9b6117c2a62df49fa596194c7b")
  (:PATH "tests/scheduler/lifecycle.lisp" :GIT-BLOB
   "874391809401f42a4db81fe544306165f99ceb5d")
  (:PATH "tests/scheduler/pool-begin.lisp" :GIT-BLOB
   "13a239cf97403806a73242abbd5b545440a17645")
  (:PATH "tests/scheduler/pool-chain-support.lisp" :GIT-BLOB
   "a1ea8258495b9a717e1e0ef164133f6b7140f8a5")
  (:PATH "tests/scheduler/pool-chain.lisp" :GIT-BLOB
   "86675c17ea47eff262cb03cdb41e50bcdb82b78e")
  (:PATH "tests/scheduler/pool-claim.lisp" :GIT-BLOB
   "f636ee873deb2cd5347a50c9aec4a6afa16d13c5")
  (:PATH "tests/scheduler/pool-recycle.lisp" :GIT-BLOB
   "3c779589cd7df6ae1146c2ca50b70320093bbf4a")
  (:PATH "tests/scheduler/pool-start.lisp" :GIT-BLOB
   "ec19bb409799e7956e40c34cc9264d02033cfb22")
  (:PATH "tests/scheduler/pool-step.lisp" :GIT-BLOB
   "d0ff803608990744408749722210e812f6268782")
  (:PATH "tests/scheduler/support.lisp" :GIT-BLOB
   "f2301a1adf44c33284aaa1171acd90c5828b0396")
  (:PATH "tests/series/boundaries.lisp" :GIT-BLOB
   "ca1e85473a76a5255cc591d7d239cedbd35acbe4")
  (:PATH "tests/series/controller.lisp" :GIT-BLOB
   "ef3d4671b3df48b932c1666f8b58fdca4eecbc77")
  (:PATH "tests/series/log-binding.lisp" :GIT-BLOB
   "c116a9169058ddd9e384fda5f52bb5787977e20e")
  (:PATH "tests/series/support.lisp" :GIT-BLOB
   "257c6f8cf28bdd8408a3363041d621497f4a5f67")
  (:PATH "tests/series/threads.lisp" :GIT-BLOB
   "c3eb1ce7870b81944c23efac9b8cb7f8f4888ba9")
  (:PATH "tests/series/worker-bridge.lisp" :GIT-BLOB
   "cb61feecd1f097cfc86af5de8b169d222b84f7a8")
  (:PATH "tests/series/worker-routing.lisp" :GIT-BLOB
   "59722f73f21ad9d5ce59e1b4785c025054a57cc5")
  (:PATH "tests/smoke.lisp" :GIT-BLOB
   "6bd4ab9af1f3d9eedd54822eae10b7f167aa99ed")
  (:PATH "tests/storage/compaction-scan.lisp" :GIT-BLOB
   "16e5c9e5231883844ecd7956c7f790349acd2a05")
  (:PATH "tests/storage/control-payload.lisp" :GIT-BLOB
   "72358c6f324e1c7aaab2bb2c9d03d39ccf78f664")
  (:PATH "tests/storage/log-header.lisp" :GIT-BLOB
   "b3c4c96603ee769429b847569559defda5059744")
  (:PATH "tests/storage/segment-header.lisp" :GIT-BLOB
   "7155aaf2e9c0df4f96533a0be0f6532b54f44590")
  (:PATH "tests/storage/support.lisp" :GIT-BLOB
   "6aa5df3b3cc62b552f5da890583654b82df99431")
  (:PATH "tests/vertical/method.md" :GIT-BLOB
   "19fd4bc2b408c712bf2b2f7f203b6fda9e68988e")
  (:PATH "tests/vertical/processes.lisp" :GIT-BLOB
   "059fbd2bb702e76e986b97edfbe4d3784599d583")
  (:PATH "tests/vertical/resume.lisp" :GIT-BLOB
   "6f80a0d0fec9f725beca54d06d961932bd815043")
  (:PATH "tests/vertical/scenarios.lisp" :GIT-BLOB
   "fcbc7878d56720604f0e86a916d2e42c0f28cffd")
  (:PATH "tests/vertical/support.lisp" :GIT-BLOB
   "37c2e8d1da68eb425cdd11548f8699c888afd7bf")
  (:PATH "tests/wal/builder.lisp" :GIT-BLOB
   "d62777cd09f8c30fc7246f59fd1bca8ea80c4559")
  (:PATH "tests/wal/csn-threads.lisp" :GIT-BLOB
   "25f9b134556bd4f1a842f536ddc89ba64a76892e")
  (:PATH "tests/wal/csn.lisp" :GIT-BLOB
   "da91333751d4b72259cf766e7441065b8c4387ec")
  (:PATH "tests/wal/fault.lisp" :GIT-BLOB
   "6361a87d73ce90f78438008693a7cd9d6461fe9b")
  (:PATH "tests/wal/group.lisp" :GIT-BLOB
   "04281d9ea3837ed2af0e7fa33b7e17df814982d7")
  (:PATH "tests/wal/native.lisp" :GIT-BLOB
   "077a835fb47524d97e449ae87c74461ebb374653")
  (:PATH "tests/wal/support.lisp" :GIT-BLOB
   "638262b264c64b96774ddb0a6095f4e582debe3e")
  (:PATH "tools/build.lisp" :GIT-BLOB
   "40879533738e1fc49e74941a9def5b089c551921")
  (:PATH "tools/cbor-float-write-audit.lisp" :GIT-BLOB
   "485544868eeadff247968b86c2d5da9b3b610295")
  (:PATH "tools/cbor-float-write-bench.lisp" :GIT-BLOB
   "d992c9f8cf6ff0d748fcb77f871fb77969480bca")
  (:PATH "tools/cbor-float-write-mutation.lisp" :GIT-BLOB
   "5d0d6bd46b0286f153ee9c482734c659959396e2")
  (:PATH "tools/cbor-header-bench.lisp" :GIT-BLOB
   "82b7068432790f9883a56c0b03229003d3541f90")
  (:PATH "tools/cbor-header-mutation.lisp" :GIT-BLOB
   "a47d36577af8e249c045096a5f7270cd628f0df8")
  (:PATH "tools/cbor-minimal-bench.lisp" :GIT-BLOB
   "fd85474e6bbc781a0e5df7c6df3a4891b4da29f7")
  (:PATH "tools/cbor-minimal-mutation.lisp" :GIT-BLOB
   "60b1ac184498623d1364df66e1d95f93165af159")
  (:PATH "tools/cbor-minimal-scan-bench.lisp" :GIT-BLOB
   "3cdd34a3dd5747f7fd0e513a1f2daeb7e2c2bbfb")
  (:PATH "tools/cbor-simple-write-audit.lisp" :GIT-BLOB
   "6acfcc656bfed5f8b4c59e487cffb5325d30d790")
  (:PATH "tools/cbor-simple-write-bench.lisp" :GIT-BLOB
   "07e5b0b7773f95ddae9458267b285c0ccb24dba9")
  (:PATH "tools/cbor-simple-write-mutation.lisp" :GIT-BLOB
   "ec2fe6b3235591ec5b3bb82b32046e906b045bf6")
  (:PATH "tools/cbor-string-read-driver.lisp" :GIT-BLOB
   "a6b65bd233dba2a2eec941d96a75b9db948d19f8")
  (:PATH "tools/cbor-string-write-audit.lisp" :GIT-BLOB
   "ae591bf0f2b37d0ed2ae08f16d0270568268a048")
  (:PATH "tools/cbor-string-write-bench.lisp" :GIT-BLOB
   "c4bd98e145d13deb47b7eedb0f4581a241f1d0e1")
  (:PATH "tools/cbor-string-write-mutation.lisp" :GIT-BLOB
   "ac4e1b095c88051cb9425ed023a8be8311b0108e")
  (:PATH "tools/cbor-structure-bench.lisp" :GIT-BLOB
   "a0a676c0107dee9429f27d3fdcdc78bb3d7f2957")
  (:PATH "tools/cbor-structure-mutation.lisp" :GIT-BLOB
   "e43405f5a6825f420364f112de951013d36b85ca")
  (:PATH "tools/cbor-write-bench.lisp" :GIT-BLOB
   "7ebf958bfc54c312cfd7f80146fec2117529b6f1")
  (:PATH "tools/cbor-write-mutation.lisp" :GIT-BLOB
   "a39159a8f63d995166eabec0a6f6e0836af9f799")
  (:PATH "tools/check-command-archive.lisp" :GIT-BLOB
   "4c56e6f317cc0e1a6785c4071126c6cca7dd68b7")
  (:PATH "tools/check-evidence-normalize.lisp" :GIT-BLOB
   "b15b6ab7edaacfc8d78ab0f36a0416af2e1c306d")
  (:PATH "tools/check-evidence-parallel-tests.lisp" :GIT-BLOB
   "a49a03a64a137e66c07c98f981327fc42d9cb508")
  (:PATH "tools/check-evidence-publication.lisp" :GIT-BLOB
   "458e9b82cea915be89180a02c406522f75175f75")
  (:PATH "tools/check-evidence-storage.lisp" :GIT-BLOB
   "76afc9a986beb31ae7ce37443ad3748b7052bdb4")
  (:PATH "tools/check-evidence.lisp" :GIT-BLOB
   "e3df9f52590ce2de86ad75b872c859b81bbcc518")
  (:PATH "tools/check-links.lisp" :GIT-BLOB
   "f3c9c944076b4bb1d7e4ef5360d7098ed44431d4")
  (:PATH "tools/check-trace.lisp" :GIT-BLOB
   "922737e5a8920ca16f0fae9e4b90835053b0396a")
  (:PATH "tools/ci.lisp" :GIT-BLOB "c0b6255982f4299b883992f5829baaebcd2aaa36")
  (:PATH "tools/ci/archive.lisp" :GIT-BLOB
   "d99223f0114956f620647e60b4f0a1452943185b")
  (:PATH "tools/ci/conditions-self-test.lisp" :GIT-BLOB
   "99f857163fa38683871790731b6f72448cf92ffb")
  (:PATH "tools/ci/coverage.lisp" :GIT-BLOB
   "233ae46d6ab9fab6a74046140323eecc64243174")
  (:PATH "tools/ci/data-self-test.lisp" :GIT-BLOB
   "b5d6a8f505604e3c45d228582933af38713cc01a")
  (:PATH "tools/ci/data.lisp" :GIT-BLOB
   "8cec68fa2e6e5d7e4484a53cde13964b875f9222")
  (:PATH "tools/ci/github.lisp" :GIT-BLOB
   "a2ca20ed9c586b104f59091d174028b3454d6a10")
  (:PATH "tools/ci/identity.lisp" :GIT-BLOB
   "abf3cc722957379e1408d629b81a2d1916a0788b")
  (:PATH "tools/ci/measure-self-test.lisp" :GIT-BLOB
   "18959f2608b1be4ef1b77b0a7d3b1a67735c16d4")
  (:PATH "tools/ci/measure.lisp" :GIT-BLOB
   "fb4b201a543d774c587ebbbc228df2a7d59ffc08")
  (:PATH "tools/ci/producer.lisp" :GIT-BLOB
   "a7fab0bcc8dc6a33ed37acb0d391ec1a73674493")
  (:PATH "tools/ci/publish-self-test.lisp" :GIT-BLOB
   "400b9ba4c1c3fd0e6bd158f3f89bcc58e802c595")
  (:PATH "tools/ci/publish.lisp" :GIT-BLOB
   "3cb48fb1bfa56957b74c2a6d67f83ab69a5dc6ee")
  (:PATH "tools/ci/self-test.lisp" :GIT-BLOB
   "00fd9c61039254a7a49835e3bfa84b714f3af304")
  (:PATH "tools/ci/support.lisp" :GIT-BLOB
   "b5fe7c565ed0f885b666d8dba836bec4a7ba4c65")
  (:PATH "tools/ci/test-self-test.lisp" :GIT-BLOB
   "2cd7248feeb0ff089429cee6f29ab12283665ec4")
  (:PATH "tools/ci/tests.lisp" :GIT-BLOB
   "9c81cf6aec5f89896d9e4ccdcd59ccf1d3c65c6f")
  (:PATH "tools/ci/workflow-self-test.lisp" :GIT-BLOB
   "f0278d9bc21245d6890e52011414627376bca5de")
  (:PATH "tools/collect-command-archive-tests.lisp" :GIT-BLOB
   "49da390b7e170acc9ffdafa78285f215aec75f44")
  (:PATH "tools/collect-command-archive.lisp" :GIT-BLOB
   "d2eb1bd8a62b0fd98ec023243b2a768c19988dc7")
  (:PATH "tools/compact-evidence.lisp" :GIT-BLOB
   "72a1c32b1efcb7fd89ff798a669a558ceffb0aa0")
  (:PATH "tools/compaction-bench.lisp" :GIT-BLOB
   "08ed205d82e6df9e1c044ef6ad714568bb140c0b")
  (:PATH "tools/compaction-mutation.lisp" :GIT-BLOB
   "a8d9a27713e0dfd1d98626aa43e05554285e5aa9")
  (:PATH "tools/control-checkpoint-bench.lisp" :GIT-BLOB
   "f631bbb7096359592fde0ae2b4462c2d2067d5a1")
  (:PATH "tools/control-transition-bench.lisp" :GIT-BLOB
   "40fd5a04dc62cced8e688ed30f59e0d810716a43")
  (:PATH "tools/csn-bench.lisp" :GIT-BLOB
   "6bf306166acbe72f0e57849656d4ab4e06f44c38")
  (:PATH "tools/csn-mutation.lisp" :GIT-BLOB
   "6e34a662d052b72eaf3b318365140f8d7d215851")
  (:PATH "tools/decisions-radix-mutation.lisp" :GIT-BLOB
   "1068f3f3ef7d46253c8ff83109791cd8d40a92e9")
  (:PATH "tools/decisions-sort-bench.lisp" :GIT-BLOB
   "a1bee0418d542eae3800213fc23df402ccd75a41")
  (:PATH "tools/engine-crash.lisp" :GIT-BLOB
   "04c4796c05bdcecf6d8fc83d3ee1eafcf969fed9")
  (:PATH "tools/evidence-size-audit.lisp" :GIT-BLOB
   "6c77f9642dc0fb373677dbcdca579c65cc8f4d83")
  (:PATH "tools/evidence-storage.lisp" :GIT-BLOB
   "fa2b5d36dca0837e2ed5e49b282887b2e110b2b7")
  (:PATH "tools/finish-evidence.lisp" :GIT-BLOB
   "c8ebe7bbe4c99a3c712033d0f58e97610914f87f")
  (:PATH "tools/foundation-bench.lisp" :GIT-BLOB
   "7dcbedc52483f6374b0dad9cf00230f9112f952d")
  (:PATH "tools/foundation-coverage.lisp" :GIT-BLOB
   "abd8e62e937c60e9ac68c3ccce904111388bff09")
  (:PATH "tools/foundation-mutation.lisp" :GIT-BLOB
   "f520ecdb46cc94e07d774d39cb73beed380aa867")
  (:PATH "tools/fulltext-codec-fixture.lisp" :GIT-BLOB
   "f6756e030cdde7beaab41a6b38516950f1663c9e")
  (:PATH "tools/fulltext-persistence.lisp" :GIT-BLOB
   "ab0dbf4ec2e5335721818cc03711b92d7d62111d")
  (:PATH "tools/fulltext-qualification.lisp" :GIT-BLOB
   "d649e9cafa96bcb4351bbced5de04bb10352ab85")
  (:PATH "tools/fulltext-unicode-tables.lisp" :GIT-BLOB
   "387086062f9bca26b853e243a4ce4f34f30e9653")
  (:PATH "tools/get-active-init-bench.lisp" :GIT-BLOB
   "c62f2bf8ba96c3e80cdd50ba067e4c4df3e5e957")
  (:PATH "tools/get-active-init-mutation.lisp" :GIT-BLOB
   "b2cd809d99d049757156ddf0141997e3b67903b4")
  (:PATH "tools/get-directory-bench.lisp" :GIT-BLOB
   "a6aea6c5a019aa377c7dc7c0d70a5e58b0050773")
  (:PATH "tools/get-directory-evidence.lisp" :GIT-BLOB
   "fbebdbcdb40b2e96c0098a987b16ba2fe3c9b7b5")
  (:PATH "tools/get-directory-mutation.lisp" :GIT-BLOB
   "7aa626295770df49dc1fb703137542de1c93564c")
  (:PATH "tools/get-performance-bench.lisp" :GIT-BLOB
   "be5fc283b3c06bc60548ea32c240ebf8d9ecafc2")
  (:PATH "tools/get-performance-evidence.lisp" :GIT-BLOB
   "f098cdb4cf5f0447365cf0bf255e1935d04bc53b")
  (:PATH "tools/get-performance-mutation.lisp" :GIT-BLOB
   "231cb906b55b9c92905deefc112f7baebecbd4af")
  (:PATH "tools/get-resolver-coverage.lisp" :GIT-BLOB
   "5ab21d923b68e35adbc177ecd352bb33340f0c07")
  (:PATH "tools/get-series-bench.lisp" :GIT-BLOB
   "2950d4fcb7fc93fbfc7d78c860f0ac43ed984f35")
  (:PATH "tools/get-series-capture.lisp" :GIT-BLOB
   "9c42e23d381751e8140f186f969c6c2ef8d606cf")
  (:PATH "tools/get-series-mutation.lisp" :GIT-BLOB
   "3d3e887ba8e1d90612e561dfffb3d71c486e813b")
  (:PATH "tools/index-rebuild-bench.lisp" :GIT-BLOB
   "0f6143fe0f69d972eb3723adb98cf4c1df1f7033")
  (:PATH "tools/index-rebuild-evidence.lisp" :GIT-BLOB
   "ba2c92a3dd88e2414b5500739eb5622da1d91d6b")
  (:PATH "tools/index-rebuild-mutation.lisp" :GIT-BLOB
   "8d60f445b933c82a6c6dbe98e4c9c3f7b1589340")
  (:PATH "tools/io-bench.lisp" :GIT-BLOB
   "ccb75032fce4765f0db7948cb594ef14f50be36e")
  (:PATH "tools/io-completion-mutation.lisp" :GIT-BLOB
   "7fd59fd86e2d477a6b6ee0f7a2142f8ea6b073c6")
  (:PATH "tools/io-rename-bench.lisp" :GIT-BLOB
   "988d259af126212adc2be8fb9ca9acd8755fdce0")
  (:PATH "tools/io-rename-mutation.lisp" :GIT-BLOB
   "dfc691c88e9ab940a065703a223a1c414454b0f2")
  (:PATH "tools/key-hash-bench.lisp" :GIT-BLOB
   "c86f91b92ba547d6fd0ad4f2b38710281d7c19db")
  (:PATH "tools/key-hash-evidence.lisp" :GIT-BLOB
   "7a54d7baa419f642b610d8d939b9048125e0efe6")
  (:PATH "tools/key-hash-mutation.lisp" :GIT-BLOB
   "5209188cf4f85d6f28b07e8e526ea859da91c083")
  (:PATH "tools/lint.lisp" :GIT-BLOB
   "adf3ca235874a2b950e57ea61a719c4c90e9dda8")
  (:PATH "tools/local-client.lisp" :GIT-BLOB
   "1ab2f474ad7db04a3fc8cc6dd7e84a2441498d20")
  (:PATH "tools/local-fault-server.lisp" :GIT-BLOB
   "92cd3d6164c6000c181374e3b917bbf1bb83aaa6")
  (:PATH "tools/local-server.lisp" :GIT-BLOB
   "517652d80ad2d4fbbe85be42fa110d4c902d8cf8")
  (:PATH "tools/local-tests.lisp" :GIT-BLOB
   "02aace929b7f5e2fd790c02d1557628ea17d7afc")
  (:PATH "tools/log-header-bench.lisp" :GIT-BLOB
   "acf45c9c691752a1f1516ca92d71459a3c94d5bd")
  (:PATH "tools/log-header-mutation.lisp" :GIT-BLOB
   "3c1e7eaa014e7ebf57b42c2bb83b4f448eeec31b")
  (:PATH "tools/measure-pool-begin.lisp" :GIT-BLOB
   "e3094d9f35efdaa647751f19a7acda00c36d515a")
  (:PATH "tools/measure-pool-claim.lisp" :GIT-BLOB
   "712a4a5393b69539f02cd625223918e404b331d3")
  (:PATH "tools/measure-pool-dispatch.lisp" :GIT-BLOB
   "bddb449176d3b7b6ae946e841a0ca3202e6c28ef")
  (:PATH "tools/measure-pool-lifecycle.lisp" :GIT-BLOB
   "3a229eecc3c158cec9af8fad6abd5fc2d980e2dd")
  (:PATH "tools/measure-pool-recycle.lisp" :GIT-BLOB
   "cb20f6d271889a9801106daf230ee934aaa7bf81")
  (:PATH "tools/measure-pool-start.lisp" :GIT-BLOB
   "e6be453833925b89cdc49303b99a23374f3b2689")
  (:PATH "tools/measure-pool-step.lisp" :GIT-BLOB
   "cdcb410e27475282d157b0d64a4656ea6ad069a1")
  (:PATH "tools/normalize-spike-report.lisp" :GIT-BLOB
   "e745f0c67e0abf3a9ea1bbc2981f6331ffc48e4c")
  (:PATH "tools/pool-controller-bench.lisp" :GIT-BLOB
   "cf6f31dd9c7a8d7f4e7cc1f19c4b9c5a48af6d55")
  (:PATH "tools/read-evidence.lisp" :GIT-BLOB
   "c41d27bfad39875f6c80858d451bacfcac862945")
  (:PATH "tools/reader-mutation.lisp" :GIT-BLOB
   "256252a0cdeb1d62bce34cee030093858fd2a5f8")
  (:PATH "tools/record-command.lisp" :GIT-BLOB
   "e52bad14e6bdbadae7cd005488a5ae8bac281d53")
  (:PATH "tools/recovery-active-bench.lisp" :GIT-BLOB
   "9c11d5654a6168c27c64abcc8f852673c5974515")
  (:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "f4951198a9198f32cf064534bbdc42d7bf3be9f8")
  (:PATH "tools/series-controller-bench.lisp" :GIT-BLOB
   "e1150055aeba7db590f07bb4e041094a9816fd4e")
  (:PATH "tools/series-controller-evidence.lisp" :GIT-BLOB
   "48e94f7e3432d29c29ec0ac1c75834769ba93dcd")
  (:PATH "tools/series-controller-mutation.lisp" :GIT-BLOB
   "ac124ab2fdd0d7562c0c8af8dc03153b2abde3f1")
  (:PATH "tools/snapshot-mutation.lisp" :GIT-BLOB
   "b46e9d42dd1c21e28ebbd661afe3ee05a1749fcd")
  (:PATH "tools/storage-bench.lisp" :GIT-BLOB
   "1da33e31673c8ab8458292350ac44fff2a5e96b3")
  (:PATH "tools/utf8-bench.lisp" :GIT-BLOB
   "a5edc926e662d0259712840d502a1f1a13143399")
  (:PATH "tools/utf8-mutation.lisp" :GIT-BLOB
   "27769759bb927e2055d711a6e723a69c468b0a0c")
  (:PATH "tools/vertical-crash.lisp" :GIT-BLOB
   "8f920374d5b1049f5bac1e8dfb441099575de6cd")
  (:PATH "tools/wal-bench.lisp" :GIT-BLOB
   "e6a3c8104fb0b7ebfaaff3e7966ad6d46d8a23ff")
  (:PATH "tools/wal-csn-bench.lisp" :GIT-BLOB
   "686671a5ea321554bbde0bbe6952d1d09a568f65")
  (:PATH "tools/wal-csn-mutation.lisp" :GIT-BLOB
   "b2413c756269e73eb3b08576d42f9584e311ee71")
  (:PATH "tools/worker-routing-bench.lisp" :GIT-BLOB
   "062e8dbbfb0fc912af22d037091d8b1b64f07b1e")
  (:PATH "tools/worker-series-bench.lisp" :GIT-BLOB
   "2d9b7fca164ef84543bb3c0f68c525e6813a8a8c")
  (:PATH "tools/writer-handoff-bench.lisp" :GIT-BLOB
   "7222a4a43a9be50653f8c63b1d09b37a249347c0")
  (:PATH "tools/writer-handoff-mutation.lisp" :GIT-BLOB
   "cafc0dbaedb6671672f994dfd86814d72f3307b8")
  (:PATH "tools/writer-queue-bench.lisp" :GIT-BLOB
   "6eda115b6379e6639aaff706c557f2e0c4e08b3d")
  (:PATH "tools/writer-queue-mutation.lisp" :GIT-BLOB
   "124778bd5b293d0436acf29c1bfa58480de1f701")
  (:PATH "tools/writer-ready-bench.lisp" :GIT-BLOB
   "f666bc8d68738c65c442404ffffc6d342a020c9b")
  (:PATH "tools/writer-ready-mutation.lisp" :GIT-BLOB
   "1401a183d345aedb1eb7eb07e3331180325fb07a")
  (:PATH "tools/writer-recycle-bench.lisp" :GIT-BLOB
   "e41b25ceb84621af27f22f11f7ad4ee11bd4a1b8")
  (:PATH "tools/writer-recycle-mutation.lisp" :GIT-BLOB
   "6ed4f867fd875231189f99367958300b2cecaab7")
  (:PATH "tools/writer-worker-bench.lisp" :GIT-BLOB
   "1208ddc9971179fc3fcb9300a9ba3c22fcd4a8b9")
  (:PATH "tools/writer-worker-mutation.lisp" :GIT-BLOB
   "568bccdb1229b124e43e5c1b756cf726ead6fcbc"))
 :WALL-SECONDS 397.45365d0 :FINISHED-AT-UNIVERSAL-TIME 4001699530
 :SCHEMA-VERSION 1 :KIND :COMMAND-VERIFICATION :ENVIRONMENT
 (:LISP #A((4) BASE-CHAR . "SBCL") :VERSION #A((5) BASE-CHAR . "2.6.9") :OS
  #A((6) BASE-CHAR . "Darwin") :OS-VERSION #A((6) BASE-CHAR . "24.6.0")
  :MACHINE #A((5) BASE-CHAR . "ARM64") :CPU "Apple M1 (Virtual)" :MEMORY-BYTES
  7516192768 :LOGICAL-CPUS 3 :EXTERNAL-LOAD-STATUS :UNCONTROLLED :LOAD-AVERAGE
  "{ 4.74 15.21 10.92 }" :COMMIT "93a2487253763ebb9b7b57c51cc00b4d44bea5ea"
  :WORKING-TREE "" :CWD
  #A((37) BASE-CHAR . "/Users/runner/work/ArcDocDB/ArcDocDB/")
  :DATE-UNIVERSAL-TIME 4001699135)
 :COMMAND
 (#A((66) BASE-CHAR
     . "/Users/runner/work/_temp/arcdocdb-sbcl.lyTUdw3f/installed/bin/sbcl")
  #A((20) BASE-CHAR . "--dynamic-space-size") #A((4) BASE-CHAR . "4096")
  #A((10) BASE-CHAR . "--noinform") #A((13) BASE-CHAR . "--no-userinit")
  #A((12) BASE-CHAR . "--no-sysinit") #A((8) BASE-CHAR . "--script")
  #A((50) BASE-CHAR . "/Users/runner/work/ArcDocDB/ArcDocDB/tools/ci.lisp")
  #A((5) BASE-CHAR . "child") #A((5) BASE-CHAR . "--job")
  #A((12) BASE-CHAR . "verify-macos") #A((5) BASE-CHAR . "--out")
  #A((69) BASE-CHAR
     . "/Users/runner/work/ArcDocDB/ArcDocDB/spikes/out/ci/verify-macos/work/"))
 :STATUS :FAILED :STARTED-AT-UNIVERSAL-TIME 4001699135 :SOURCE-BLOBS-BEFORE
 ((:PATH ".github/ISSUE_TEMPLATE/config.yml" :GIT-BLOB
   "0086358db1eb971c0cfa8739c27518bbc18a5ff4")
  (:PATH ".github/ISSUE_TEMPLATE/decisione-architetturale.md" :GIT-BLOB
   "0241da912be93fdf70b9a9749b759efc17aca329")
  (:PATH ".github/PULL_REQUEST_TEMPLATE.md" :GIT-BLOB
   "30f2e951591f8822ce780f77cfa9c4ab93f0a98b")
  (:PATH ".github/actions/setup-sbcl/README.md" :GIT-BLOB
   "86de4c772f5623cde6774e1bb5f2fc2c6e222bf7")
  (:PATH ".github/actions/setup-sbcl/action.yml" :GIT-BLOB
   "80da41aac60230141d5d2d0819c9b6c2c3b3ce91")
  (:PATH ".github/ci-toolchain.lock.lisp" :GIT-BLOB
   "c01b06c5b208014ab30bb000dc10acfc9e72cc89")
  (:PATH ".github/workflows/ci-results.yml" :GIT-BLOB
   "d5029660830b7dbef56d6648bbf0a9bbaa400c56")
  (:PATH ".github/workflows/ci.yml" :GIT-BLOB
   "49fc8ba897e94dc36c31d973e6e12efeab51b715")
  (:PATH ".gitignore" :GIT-BLOB "19bf1ab91a6ed3c89cfff48070fb170b09679360")
  (:PATH "CHANGELOG.md" :GIT-BLOB "ecaebfd73eaa7449fefccaef3bcc6dcbac43b8b5")
  (:PATH "CONTRIBUTING.md" :GIT-BLOB
   "40d7a7ed9a840793c871b91d1fc57f9d682551ac")
  (:PATH "LICENSE" :GIT-BLOB "aa9c159fc3ef804068ce29d1bb990d0010eedb00")
  (:PATH "Makefile" :GIT-BLOB "96001f99c123cc757cc6d2560dc6c4a58f311369")
  (:PATH "README.md" :GIT-BLOB "ddb05457ae89a6dc06d4b4dd7436f8f6031b38ab")
  (:PATH "SECURITY.md" :GIT-BLOB "27fb94691a84b389d72184838e38d2e43a8fcfbb")
  (:PATH "arcdocdb.asd" :GIT-BLOB "da5afc574cc1557ffa3d54f0da6583eaa7c3ff08")
  (:PATH "assets/README.md" :GIT-BLOB
   "933cfee445a3fe85c8b9ca8c7c4e48afda9bdc95")
  (:PATH "assets/img/flow-dark.svg" :GIT-BLOB
   "daae22922420bfde91c8ce8c313343c03c045d17")
  (:PATH "assets/img/flow-light.svg" :GIT-BLOB
   "d3e0bf360226c3d05b603aef74cf022177d9f213")
  (:PATH "assets/img/hero-dark.svg" :GIT-BLOB
   "0e9fe71b160f4ff7fcc61c9695159b00e352b12e")
  (:PATH "assets/img/hero-light.svg" :GIT-BLOB
   "de51c5d5d625caf2ba89581880a7e932a86d2556")
  (:PATH "assets/img/mark-dark.svg" :GIT-BLOB
   "2402f3bf0362118bba64640d64382ac5e86a20e0")
  (:PATH "assets/img/mark-light.svg" :GIT-BLOB
   "58ee962d4dffe098eaff67a88e6533b46d1fae53")
  (:PATH "assets/img/social.png" :GIT-BLOB
   "82582b11d03a6b1e447af3aeec37545fcc4067bd")
  (:PATH "assets/img/social.svg" :GIT-BLOB
   "6a4f2b2dc8c1325ec78b5736df18a97e701709c2")
  (:PATH "data/unicode/18.0.0/CaseFolding.txt" :GIT-BLOB
   "9ee0a2dd654f6fa520cd932be19ac5c00ffacded")
  (:PATH "data/unicode/18.0.0/DerivedNormalizationProps.txt" :GIT-BLOB
   "32227e8f297e96f98954281d99c38839a7834d7c")
  (:PATH "data/unicode/18.0.0/LICENSE.txt" :GIT-BLOB
   "56da58912807030b451a4700687d5bd02c72d6ed")
  (:PATH "data/unicode/18.0.0/NormalizationTest.txt" :GIT-BLOB
   "730c1a013ac78f6a63118e670c72556d4f112eab")
  (:PATH "data/unicode/18.0.0/README.md" :GIT-BLOB
   "68a3ac6a0f1d7a83b23d319a9ccaadeba0d88429")
  (:PATH "data/unicode/18.0.0/ReadMe.txt" :GIT-BLOB
   "aa18f7175c4a46df644c7c6435ad95a8ad3cd724")
  (:PATH "data/unicode/18.0.0/UnicodeData.txt" :GIT-BLOB
   "ebccf021c4fcf31c2ecbb9bd7da3f5eb7ed44851")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakProperty.txt" :GIT-BLOB
   "313ae91aad579445a1e06556a1d7a2edd0c782a2")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakTest.txt" :GIT-BLOB
   "8d734a2690b9f06018e02b0b4f165acc4d0d2853")
  (:PATH "data/unicode/18.0.0/emoji/emoji-data.txt" :GIT-BLOB
   "7a383f0dcfd6ad65a2b7b5e90f701e38485f151f")
  (:PATH "docs/01-visione-e-obiettivi.md" :GIT-BLOB
   "4a3cf72d6c5b7d57383e44f64ba243b966f42f9a")
  (:PATH "docs/02-modello-logico.md" :GIT-BLOB
   "13effbf6dcb8a18756e9d5c953b6438a92a91eff")
  (:PATH "docs/03-storage.md" :GIT-BLOB
   "0c81882c35757d460e55f808fc6d2370f845550d")
  (:PATH "docs/04-wal-e-durability.md" :GIT-BLOB
   "d65d5b12f248347430260c6671017a0894ebd3eb")
  (:PATH "docs/05-transazioni.md" :GIT-BLOB
   "2713de877ed961857868b53bcc346fe62088ec0e")
  (:PATH "docs/06-mvcc-e-snapshot.md" :GIT-BLOB
   "2e82f0c5e993b0547286f0f40137b54cc4001887")
  (:PATH "docs/07-compaction.md" :GIT-BLOB
   "7ee5d31293f024a641ca41a316b9f6095daa51d2")
  (:PATH "docs/08-indici.md" :GIT-BLOB
   "592722eba473e3a8bb1ff99d0113fa9463848f06")
  (:PATH "docs/09-cache.md" :GIT-BLOB
   "3eab0ad4c56c1744c456579c8e773c5d7fe7493a")
  (:PATH "docs/10-concorrenza-e-scheduling.md" :GIT-BLOB
   "6616ed0cfadc71596ae3162affdef4f75f608de5")
  (:PATH "docs/11-recovery.md" :GIT-BLOB
   "99ece25d26c59468aa4dddb8f652986fc4ebcd13")
  (:PATH "docs/12-osservabilita.md" :GIT-BLOB
   "20620fae5746d6acd2c4fc23bab30b740ed9810f")
  (:PATH "docs/13-benchmark.md" :GIT-BLOB
   "4b83247b5082e1b198b929269d3d0308676e78fe")
  (:PATH "docs/14-fault-injection.md" :GIT-BLOB
   "db87b7732e2e42f22c711a89f5deae97f5f00757")
  (:PATH "docs/15-ottimizzazioni-native.md" :GIT-BLOB
   "5c5a08eb804ab6e40b44469d5eab7f9c27e68535")
  (:PATH "docs/16-moduli.md" :GIT-BLOB
   "45067d5f26f743cdbfacc40014218ba8c82f539a")
  (:PATH "docs/README.md" :GIT-BLOB "0a8d0c43545a7f6ee8b5d8d635cefe3f511da0f4")
  (:PATH "docs/adr/0000-modello.md" :GIT-BLOB
   "88eeb77497b6d6124010ad65a71b98e08743131e")
  (:PATH "docs/adr/0001-common-lisp-sbcl.md" :GIT-BLOB
   "a4d7157123f6cad4b92d3722e136bd02f15fa138")
  (:PATH "docs/adr/0002-serie-unita-di-storage-e-parallelismo.md" :GIT-BLOB
   "fe20638b50dffc66f5d5b3497f00e5f526ea046a")
  (:PATH "docs/adr/0003-wal-per-serie.md" :GIT-BLOB
   "2b9f1e16b289ec754c0ac0de79e7823852c4815a")
  (:PATH "docs/adr/0004-storage-append-only-un-solo-active.md" :GIT-BLOB
   "4af05ad11f846d733b3485bfdabac47535f41415")
  (:PATH "docs/adr/0005-writer-logico-per-serie.md" :GIT-BLOB
   "ac6e1e0f042e6ce5622c0b579ff8d0419a707980")
  (:PATH "docs/adr/0006-transazioni-multiserie-2pc.md" :GIT-BLOB
   "ad70fc5e177886b0be609ebc0234c0c7c2fbab90")
  (:PATH "docs/adr/0007-clean-e-merge-distinti.md" :GIT-BLOB
   "7e6590a619252983120f8ef9b5b3fba5bf24659f")
  (:PATH "docs/adr/0008-merge-opportunistico.md" :GIT-BLOB
   "5ae6feb439b1d182febe27d16e6d485183150d6a")
  (:PATH "docs/adr/0009-indici-immutabili-atomic-swap.md" :GIT-BLOB
   "18de49d285e52d25e055397f47c829ba7db45500")
  (:PATH "docs/adr/0010-cache-clock.md" :GIT-BLOB
   "2f04c342ca714f0638dfdf2bed17fe48de54edc9")
  (:PATH "docs/adr/0011-thread-pool-dinamico.md" :GIT-BLOB
   "1a86df3d58358950d8b658b6b8194563288fd0c8")
  (:PATH "docs/adr/0012-simd-guidato-dai-benchmark.md" :GIT-BLOB
   "a5b8fac1dd72d5a213632d47898dca632aa4b72a")
  (:PATH "docs/adr/0013-log-structured-segmento-active-come-log.md" :GIT-BLOB
   "3ca2df1c7beddedd65511d9282a547294cabbff4")
  (:PATH "docs/adr/0014-formato-record-documento-id.md" :GIT-BLOB
   "87931cd80f665581fc43a2b02fc6738ea3d57fb3")
  (:PATH "docs/adr/0015-primary-index-swiss-table-swmr.md" :GIT-BLOB
   "001950113b1fc347642e1939ef060d93a54096e5")
  (:PATH "docs/adr/0016-epoch-based-reclamation.md" :GIT-BLOB
   "5a442b2aeb665be3f23da887ff615bef889e167d")
  (:PATH "docs/adr/0017-piattaforma-e-io.md" :GIT-BLOB
   "250c272e2ddaa4b062b956d5ab3eb66ce610b44a")
  (:PATH "docs/adr/0018-control-log-manifest-swap.md" :GIT-BLOB
   "be9686df1c7ecb762bebac602bab12010d73d0b9")
  (:PATH "docs/adr/0019-durability-e-group-commit-pipelined.md" :GIT-BLOB
   "6fff5ed7db6d11a51f12b167636b7a23a3750068")
  (:PATH "docs/adr/0020-csn-snapshot-isolamento.md" :GIT-BLOB
   "83c6cae3eb56b9edfda572533258d8438132e0ae")
  (:PATH "docs/adr/0021-2pc-intenti-outcome.md" :GIT-BLOB
   "81823c873cf52abafd86a3e8ab35df2e161d1034")
  (:PATH "docs/adr/0022-registri-come-serie-catalogo.md" :GIT-BLOB
   "623209aef44929e1b8397b1f8470dffc20d9bbf8")
  (:PATH "docs/adr/0023-politiche-di-compaction.md" :GIT-BLOB
   "bc3d2144b30022e7ab239c561b6986a18e10ec8c")
  (:PATH "docs/adr/0024-memoria-e-gc.md" :GIT-BLOB
   "470ef1b7f52d571ea5af046ccf06896729a06a13")
  (:PATH "docs/adr/0025-cache-per-location.md" :GIT-BLOB
   "24235615cfaab3821cc38bc9b9979a9928c6dee9")
  (:PATH "docs/adr/0026-indici-secondari-segmentati.md" :GIT-BLOB
   "09512403a6ef9d04a9ad42796fa5c535d6abbbe3")
  (:PATH "docs/adr/0027-dipendenze-e-test.md" :GIT-BLOB
   "127ac9190f647e1d3582a079ccdb798419b2cb2e")
  (:PATH "docs/adr/0028-target-e-obiettivi-di-latenza.md" :GIT-BLOB
   "506080464430c1b9e5f2b09816d186ca95e3fcc9")
  (:PATH "docs/adr/0029-interfacce-protocollo-query-contratto.md" :GIT-BLOB
   "4223207857d168241c613bb2e7ac4aa525687a26")
  (:PATH "docs/adr/0030-scope-v1.md" :GIT-BLOB
   "4c93b3d78c5ac2772c4b2563f44063ea855f1206")
  (:PATH "docs/adr/0031-software-critico-criteri-e-priorita.md" :GIT-BLOB
   "dc8228d1c2dc5e01fa6a5cb6c69ec9e8648427d2")
  (:PATH "docs/adr/0032-seqlock-a-64-bit.md" :GIT-BLOB
   "fc947bb28bdf5a015d7b353f56e0d6fb86a524c6")
  (:PATH "docs/adr/0033-fail-stop-e-integrita-end-to-end.md" :GIT-BLOB
   "4646cd378729d3841b8419b3681477b4e1a80816")
  (:PATH "docs/adr/0034-policy-di-compilazione-e-standard-di-codifica.md"
   :GIT-BLOB "dfeef8dd42d465d1c97830bd6f8304d3f8579416")
  (:PATH "docs/adr/0035-strategia-di-verifica-e-tracciabilita.md" :GIT-BLOB
   "eb3138e9017cc95b7f71fb29ec3a21e4bc44a3c3")
  (:PATH "docs/adr/0036-leggi-di-progetto.md" :GIT-BLOB
   "d4140bc0d14bee6ca7480e94fa96bd8c79e656fd")
  (:PATH "docs/adr/0037-lotto-sigillato.md" :GIT-BLOB
   "aadf427743cc9b511c4fac4952ec1335005b5568")
  (:PATH "docs/adr/0038-orizzonte-di-visibilita.md" :GIT-BLOB
   "fce6228c1a393557b2475a7600cc998246de97d0")
  (:PATH "docs/adr/0039-cornice-unica-dei-record.md" :GIT-BLOB
   "c347b791cfa1e13319894e5c2a9c3c20527a7047")
  (:PATH "docs/adr/0040-manifest-a-record-unico.md" :GIT-BLOB
   "77640ef6687df0ba7a570b682000bd4b2fa042cc")
  (:PATH "docs/adr/0041-multiserie-segmenti-autosufficienti.md" :GIT-BLOB
   "c571f195148361a34fa6bc9d1c6f35836742ab11")
  (:PATH "docs/adr/0042-tombstone-e-indice-dei-vivi.md" :GIT-BLOB
   "ba7550dfd1890a483f313610cadc808142bdddeb")
  (:PATH "docs/adr/0043-primary-index-a-frammenti.md" :GIT-BLOB
   "1f07f3d9c4a9a1b6a0c1250dc09923966b2081d3")
  (:PATH "docs/adr/0044-cache-acceleratore-puro.md" :GIT-BLOB
   "3ada528fa148db73ca09df933265ff82a5e0dd6b")
  (:PATH "docs/adr/0045-modello-di-esecuzione.md" :GIT-BLOB
   "75301c4284016be1da4f6f7a9e4b8a1c00b1fe8c")
  (:PATH "docs/adr/0046-orizzonte-con-registro-limitato.md" :GIT-BLOB
   "2ebb221d1f2e8666fa62910f561728eb6ee0a9f3")
  (:PATH "docs/adr/0047-verifica-csn-dei-record-prepared.md" :GIT-BLOB
   "4c11a9e20d9d7bf315bf7623740addd876019d77")
  (:PATH "docs/adr/0048-limiti-documentali-e-formato-v2.md" :GIT-BLOB
   "f36aeeeab161774fce91906d1ba5d47e6b1a8636")
  (:PATH "docs/adr/0049-capacita-oltre-la-ram.md" :GIT-BLOB
   "47b35236825274bd340b61e4c30b7b38d8349d5a")
  (:PATH "docs/adr/0050-pubblicazione-e-costi-della-directory.md" :GIT-BLOB
   "f393c09cc917be5e4a123befca7bdd3f238ad8eb")
  (:PATH "docs/adr/0051-presentazione-della-documentazione.md" :GIT-BLOB
   "123524e58806fe8cee2727e5ada0b00561583a76")
  (:PATH "docs/adr/0052-header-dei-log-di-controllo.md" :GIT-BLOB
   "817f3f72a09e74d142b160bd8da172b459f327f9")
  (:PATH "docs/adr/0053-ricerca-full-text-indici-invertiti.md" :GIT-BLOB
   "911f33ef505d0d5dd1095947881d25d178c3d97c")
  (:PATH "docs/adr/0054-contratto-e-formato-full-text.md" :GIT-BLOB
   "93bf30e76760bb0ce8b8227758b8b1202f9d34a8")
  (:PATH "docs/adr/0055-interfaccia-locale-unix-socket.md" :GIT-BLOB
   "34dc862714c81665e5d7e997b4ca301b270417e9")
  (:PATH "docs/adr/0056-sessione-locale-m16.md" :GIT-BLOB
   "2787ac485b8ae20cec8f988ca4d8d7bb5862e3ff")
  (:PATH "docs/adr/0057-selezione-automatica-indice.md" :GIT-BLOB
   "d1daf810581a18e8dca610082cc5f1b8b7a9df71")
  (:PATH "docs/adr/0058-pagine-indice-primario.md" :GIT-BLOB
   "d5d74b7af7e7f467070ee84a1bcd717020a93207")
  (:PATH "docs/adr/README.md" :GIT-BLOB
   "a1e7e7a3f1875609a7e1d07c05fbda45689b23a6")
  (:PATH "docs/affidabilita/README.md" :GIT-BLOB
   "83dd5fe0d9323805d7e97e6814129d16841efb80")
  (:PATH "docs/affidabilita/analisi-dei-guasti.md" :GIT-BLOB
   "c031db7bad8fa2f115938e3699e6ce01bc436bec")
  (:PATH "docs/affidabilita/copertura-eccezioni.md" :GIT-BLOB
   "b5d7eaae25d8613da6b2b9bce9348f000a595fd7")
  (:PATH "docs/affidabilita/deviazioni.md" :GIT-BLOB
   "61f400316607e9c47904680e6730c3034ba5897a")
  (:PATH "docs/affidabilita/piano-di-verifica.md" :GIT-BLOB
   "070d76bf87022dfbc3471f3707848b46061cf076")
  (:PATH "docs/affidabilita/standard-di-codifica.md" :GIT-BLOB
   "7800931fe3bc4c8204cd873ccc0ec8ed42af8b50")
  (:PATH "docs/analisi-progettuale.md" :GIT-BLOB
   "7028bc0b2b30b0ad17f9bbae81590519d3775e73")
  (:PATH "docs/architettura.md" :GIT-BLOB
   "6befae2249c1f13b53fbc296abfaa3bb5ada8f37")
  (:PATH "docs/formati-su-disco.md" :GIT-BLOB
   "011476236c57e5904ffb989e78fb958cd71f8e2e")
  (:PATH "docs/formato-indice-full-text.md" :GIT-BLOB
   "28f3f290149d4dfd032f26f0f57a9e7fef5cb987")
  (:PATH "docs/full-text.md" :GIT-BLOB
   "25f8a7e269b51211a1d6a919114d325b6aebd44e")
  (:PATH "docs/glossario.md" :GIT-BLOB
   "08f40903c66b0657317f2f9fd63cf522ea272a4c")
  (:PATH "docs/guida-al-repository.md" :GIT-BLOB
   "2d883ca7e34a8b31f88930e0d266ec0a094e6b0a")
  (:PATH "docs/implementazione/README.md" :GIT-BLOB
   "9729f11b98b6ef79984cbd582ae6ac0a337053e9")
  (:PATH "docs/implementazione/active-recovery-metodo.md" :GIT-BLOB
   "93b6051260c2ccf600bd47b0fb6ac1f828f2cfd4")
  (:PATH "docs/implementazione/active-recuperato-metodo.md" :GIT-BLOB
   "af0204ed53afbd5e27df1103e7d28d587357361f")
  (:PATH "docs/implementazione/active-recuperato-verifica.md" :GIT-BLOB
   "fbeead915b0973a89e4a97914ce997a833c4f72e")
  (:PATH "docs/implementazione/active-recuperato.md" :GIT-BLOB
   "976ca6f9d74cefdcb35b2a71531ecba690a31df2")
  (:PATH "docs/implementazione/adozione-closed-runtime.md" :GIT-BLOB
   "493baf22e54b3d57a6d994b53d1f3b267f25cc56")
  (:PATH "docs/implementazione/adozione-controller-runtime.md" :GIT-BLOB
   "21fc1a955edef5b2702164e340d4bc18f32ac082")
  (:PATH "docs/implementazione/archivi-comandi-lettura.md" :GIT-BLOB
   "00a1f025a375559acf548fb855c59d42e4a21642")
  (:PATH "docs/implementazione/archivio-csn-revisione.md" :GIT-BLOB
   "d4ab7c91922cc266d3f0ec02de3f463de7a24ecd")
  (:PATH "docs/implementazione/archivio-csn-verifica.md" :GIT-BLOB
   "94edca783edd1bb871785fc80a23793d23b23489")
  (:PATH "docs/implementazione/associazione-file.md" :GIT-BLOB
   "26141de9dcbaa24455edf9966cdbdeeec819961f")
  (:PATH "docs/implementazione/cache-record.md" :GIT-BLOB
   "7caa5d05d2225ee7af89a26ce430e33b844960b9")
  (:PATH "docs/implementazione/cbor-array-decisioni.md" :GIT-BLOB
   "60d1ee21f9aa42336c246da92bbe1a69beee91cb")
  (:PATH "docs/implementazione/cbor-array-lettura.md" :GIT-BLOB
   "a317dfc2fa86b653d2705a03513388ddd76e0a60")
  (:PATH "docs/implementazione/cbor-array-metodo.md" :GIT-BLOB
   "2f257c9e8a56a5182142934dada3f3b38b5bef65")
  (:PATH "docs/implementazione/cbor-array-revisione.md" :GIT-BLOB
   "c7a130fc659cdd792f0d0fe58e395fccef26a3b0")
  (:PATH "docs/implementazione/cbor-array-risultati.md" :GIT-BLOB
   "a790237317bf518c29c8f6b34a7e5b47f1df7397")
  (:PATH "docs/implementazione/cbor-array.md" :GIT-BLOB
   "82e60606f0f2c054e0bf52da1d77146e80bce7a8")
  (:PATH "docs/implementazione/cbor-float-scrittura-copertura.md" :GIT-BLOB
   "5995792c928309dc872b85fbfd6aadeace374442")
  (:PATH "docs/implementazione/cbor-float-scrittura-dati.md" :GIT-BLOB
   "193ac30ac7695f057f90d991f612d7bb2aaa8e83")
  (:PATH "docs/implementazione/cbor-float-scrittura-decisioni.md" :GIT-BLOB
   "4a59eea9a4021041b5b6b091bd26a9ce1a359a39")
  (:PATH "docs/implementazione/cbor-float-scrittura-lettura.md" :GIT-BLOB
   "134173468ca2bfd538eb1f6bbeda4dda128e800b")
  (:PATH "docs/implementazione/cbor-float-scrittura-metodo.md" :GIT-BLOB
   "755b13a91ab72f54383d96faee5780da36e750d6")
  (:PATH "docs/implementazione/cbor-float-scrittura-revisione.md" :GIT-BLOB
   "0d644768dc2f8efeb86136a8a4c4206c4c464bb6")
  (:PATH "docs/implementazione/cbor-float-scrittura-risultati.md" :GIT-BLOB
   "9bf9db1e3af901cb6642d63d1aada850dc4294ac")
  (:PATH "docs/implementazione/cbor-float-scrittura.md" :GIT-BLOB
   "551c707affc51a5a18a6ce4a91a017be61e105f1")
  (:PATH "docs/implementazione/cbor-header-decisioni.md" :GIT-BLOB
   "c8182641591fa6f24bddedca56f92145a3c7a038")
  (:PATH "docs/implementazione/cbor-header-lettura.md" :GIT-BLOB
   "b8b2b37a18cb4d01815e07df5e64e763f273a9d0")
  (:PATH "docs/implementazione/cbor-header-metodo.md" :GIT-BLOB
   "325784adbb5cff4121559fd3d50a1ef943443434")
  (:PATH "docs/implementazione/cbor-header-revisione.md" :GIT-BLOB
   "bc95228574813d37b27882f24713e4d834788dd2")
  (:PATH "docs/implementazione/cbor-header-strumenti-review.md" :GIT-BLOB
   "69bf38c64b527b5aeec011f9fe49d9fd3c31d253")
  (:PATH "docs/implementazione/cbor-header.md" :GIT-BLOB
   "9eb64c8428b638f6c0c1f0aaa80c4dbfd0f900b7")
  (:PATH "docs/implementazione/cbor-item-decisioni.md" :GIT-BLOB
   "8b287b49d006db867732eec19574e7fed85e3e7b")
  (:PATH "docs/implementazione/cbor-item-lettura.md" :GIT-BLOB
   "01cefe902960448b80ce8b157e3d8b5192f5238a")
  (:PATH "docs/implementazione/cbor-item-metodo.md" :GIT-BLOB
   "a67a79bf4fefe11c4778cd881eb5279a006966ca")
  (:PATH "docs/implementazione/cbor-item-revisione.md" :GIT-BLOB
   "f0c80bf6534054a6a956e016993b8fb1e9c0aa5b")
  (:PATH "docs/implementazione/cbor-item-risultati.md" :GIT-BLOB
   "938f5c59f7b10e777fcb691f6fe8ad4c8069615e")
  (:PATH "docs/implementazione/cbor-item.md" :GIT-BLOB
   "c31ce79d42d1504977c40039d01041d49fbb6f9f")
  (:PATH "docs/implementazione/cbor-map-decisioni.md" :GIT-BLOB
   "16c6031456225537b6eb1fe961aa8e20d7f5e110")
  (:PATH "docs/implementazione/cbor-map-lettura.md" :GIT-BLOB
   "a522551230d07a1816d08e6da4c7384311e853d4")
  (:PATH "docs/implementazione/cbor-map-metodo.md" :GIT-BLOB
   "636dd2706c2903542978606cf029e7198bf4dbb3")
  (:PATH "docs/implementazione/cbor-map-revisione.md" :GIT-BLOB
   "06f6af70d48553e1b327750fb573f57ebce6fb97")
  (:PATH "docs/implementazione/cbor-map-risultati.md" :GIT-BLOB
   "cc5cb4834d524d83108e1300cb94ec1f0595b4b3")
  (:PATH "docs/implementazione/cbor-map.md" :GIT-BLOB
   "60ea1772c7aadba6831684a01e583ebc431c8523")
  (:PATH "docs/implementazione/cbor-minimo-decisioni.md" :GIT-BLOB
   "e39571136cad9d563a933aa608c011b887f17260")
  (:PATH "docs/implementazione/cbor-minimo-driver-review.md" :GIT-BLOB
   "a83c5cc798dfb87750030781d015eeda260c4ac0")
  (:PATH "docs/implementazione/cbor-minimo-lettura.md" :GIT-BLOB
   "245f95c99a4735fd40a1d9694b4a5826f5ccb5d6")
  (:PATH "docs/implementazione/cbor-minimo-metodo.md" :GIT-BLOB
   "9f6526bf5c135cf43289127c4c1bc5dfdcbb8114")
  (:PATH "docs/implementazione/cbor-minimo-revisione.md" :GIT-BLOB
   "162cd32188a030d6cc3c5d16585054aa36055175")
  (:PATH "docs/implementazione/cbor-minimo-risultati.md" :GIT-BLOB
   "4af8109f8d01f1107791836371720802876ae775")
  (:PATH "docs/implementazione/cbor-minimo-strumenti-review.md" :GIT-BLOB
   "2a9e7f0bf30460b3b7dbbbc1c7776c9259fe545d")
  (:PATH "docs/implementazione/cbor-minimo-struttura-decisioni.md" :GIT-BLOB
   "3935fc5225836a0669664701921ad1bfff3d443e")
  (:PATH "docs/implementazione/cbor-minimo-struttura-driver-review.md"
   :GIT-BLOB "8ba7e4ba06ca958c0be9a5e1128c63419aa7577a")
  (:PATH "docs/implementazione/cbor-minimo-struttura-lettura.md" :GIT-BLOB
   "a83375d3c09898353fc0173f3171884f92319d73")
  (:PATH "docs/implementazione/cbor-minimo-struttura-metodo.md" :GIT-BLOB
   "d379ed246db14204b7632b7b3c31266bfcd46b1e")
  (:PATH "docs/implementazione/cbor-minimo-struttura-revisione.md" :GIT-BLOB
   "ba4d2ed61bf06d0504bb1e0067c8741ef45cc4e0")
  (:PATH "docs/implementazione/cbor-minimo-struttura-risultati.md" :GIT-BLOB
   "8966ac0cdf66fcefd616201cc97017d384b3f0a8")
  (:PATH "docs/implementazione/cbor-minimo-struttura-strumenti-review.md"
   :GIT-BLOB "cd2f1ef9dfcd3f9029549430c21ec553509a62fc")
  (:PATH "docs/implementazione/cbor-minimo-struttura.md" :GIT-BLOB
   "81675040c1c6155f7e3efa669ca62ed4b8a63064")
  (:PATH "docs/implementazione/cbor-minimo.md" :GIT-BLOB
   "d8b22e42e7ab906488cef72d935b71d4a83ba499")
  (:PATH "docs/implementazione/cbor-mutazioni-processi.md" :GIT-BLOB
   "6b4a59954e2d48cc30a044b57cfe43b0b91ae1e8")
  (:PATH "docs/implementazione/cbor-scrittura-decisioni.md" :GIT-BLOB
   "7d44d58d7de6c62b2206a8e35be398bc34811663")
  (:PATH "docs/implementazione/cbor-scrittura-lettura.md" :GIT-BLOB
   "9605de0679e062361f80c5654c5fbb8028765008")
  (:PATH "docs/implementazione/cbor-scrittura-metodo.md" :GIT-BLOB
   "8b79dfa3b7cf5011b66534d02c2a4551232d503c")
  (:PATH "docs/implementazione/cbor-scrittura-revisione.md" :GIT-BLOB
   "e9007f26d323a1ffd2993c461c3f84ad2aee90bc")
  (:PATH "docs/implementazione/cbor-scrittura-risultati.md" :GIT-BLOB
   "a25b46457201e1a7885cc9b21cfb3e66267ec12c")
  (:PATH "docs/implementazione/cbor-scrittura.md" :GIT-BLOB
   "a9e2e9dc6d0d4b968a9940d78abf8ca2de825e98")
  (:PATH "docs/implementazione/cbor-semplici-dati.md" :GIT-BLOB
   "5d0aacab996dc47e2d479d505604d6eda5d42ea2")
  (:PATH "docs/implementazione/cbor-semplici-decisioni.md" :GIT-BLOB
   "3ec66f8edebd79a128969e0b398e7700a2b1c5cd")
  (:PATH "docs/implementazione/cbor-semplici-lettura.md" :GIT-BLOB
   "46a0480b0bc29938f8654ce8f59cdaee5b720a4a")
  (:PATH "docs/implementazione/cbor-semplici-metodo.md" :GIT-BLOB
   "e8864f7c0124f86cebdcdbcb2449800e078e1cc8")
  (:PATH "docs/implementazione/cbor-semplici-revisione.md" :GIT-BLOB
   "d276363cd59d6d1a914a6055b27edce016122323")
  (:PATH "docs/implementazione/cbor-semplici-risultati.md" :GIT-BLOB
   "94d950c644e849103eecb0d74c053df4aa1473dd")
  (:PATH "docs/implementazione/cbor-semplici-verificatori.md" :GIT-BLOB
   "47cfd5c96e2150c42a2a7b716bef117090b0cd86")
  (:PATH "docs/implementazione/cbor-semplici.md" :GIT-BLOB
   "f5817e4d931148aa4f526b93066ab9d1b4bdf783")
  (:PATH "docs/implementazione/cbor-stringa-lettura-decisioni.md" :GIT-BLOB
   "f8cfb0895a3086b0fa0a7c509c7e56559d4b3493")
  (:PATH "docs/implementazione/cbor-stringa-lettura-metodo.md" :GIT-BLOB
   "2d7ad0304f923e3213bc65edd159e16b70202201")
  (:PATH "docs/implementazione/cbor-stringa-lettura-prima-revisione.md"
   :GIT-BLOB "c7232e26023ef8e4ceba49fd6dfcb60be697e921")
  (:PATH "docs/implementazione/cbor-stringa-lettura-risultati.md" :GIT-BLOB
   "d225757b21762809fe0b871ce6abcbe7cc6d5af4")
  (:PATH "docs/implementazione/cbor-stringa-lettura-seconda-revisione.md"
   :GIT-BLOB "fdb6848a04e93a846da2ac9690f1d94975e35f1f")
  (:PATH "docs/implementazione/cbor-stringa-lettura.md" :GIT-BLOB
   "99c7f801c7ac550c6f2d609d71fcc8e76e03948c")
  (:PATH "docs/implementazione/cbor-stringhe-dati.md" :GIT-BLOB
   "0a3a2123e618a8ff39e86dbbb70db36ccf51b133")
  (:PATH "docs/implementazione/cbor-stringhe-decisioni.md" :GIT-BLOB
   "2df0a214fc5cfe64ceb239aab4f7d2a2d1827305")
  (:PATH "docs/implementazione/cbor-stringhe-lettura.md" :GIT-BLOB
   "1c1d617e19c0d74199ef11a56105d3ed90eb0ec0")
  (:PATH "docs/implementazione/cbor-stringhe-metodo.md" :GIT-BLOB
   "56342dae95caf8705e0b28b3c0ea7ac86fdd8fa0")
  (:PATH "docs/implementazione/cbor-stringhe-revisione.md" :GIT-BLOB
   "90bac509af0aff7b7085a2239de6e9dfddfc70ba")
  (:PATH "docs/implementazione/cbor-stringhe-risultati.md" :GIT-BLOB
   "cbcfdba7c5967d5d36e5d9487f6a7b1ab0300a53")
  (:PATH "docs/implementazione/cbor-stringhe.md" :GIT-BLOB
   "278d9413eab7578c99a07b1c614db37c83141097")
  (:PATH "docs/implementazione/cbor-struttura-decisioni.md" :GIT-BLOB
   "8e1b0d0d6066669e1ffb65d95900a3b1aa385c51")
  (:PATH "docs/implementazione/cbor-struttura-driver-review.md" :GIT-BLOB
   "c9808d48a01444ff6faddf2d8389673f91598db4")
  (:PATH "docs/implementazione/cbor-struttura-lettura.md" :GIT-BLOB
   "6b2909a5f56212947dea864584d2f96252fe1b1a")
  (:PATH "docs/implementazione/cbor-struttura-metodo.md" :GIT-BLOB
   "f0a2791f988b0d0c513629824f75ce1842fe059a")
  (:PATH "docs/implementazione/cbor-struttura-revisione.md" :GIT-BLOB
   "cebaf33e7e7cde4efbcbc2ada22fd494577c9e81")
  (:PATH "docs/implementazione/cbor-struttura-risultati.md" :GIT-BLOB
   "7b22c788ecf0d69f84316f39d2f580bfadb7b91f")
  (:PATH "docs/implementazione/cbor-struttura-strumenti-review.md" :GIT-BLOB
   "76509dd8d44a61eff9129d08fb19c289d57fd1e8")
  (:PATH "docs/implementazione/cbor-struttura.md" :GIT-BLOB
   "93f1366c17eca13f37f63927d64779f7afeae658")
  (:PATH "docs/implementazione/cbor-tag-decisioni.md" :GIT-BLOB
   "791a560cf0727d9fcc2653c3ebaa7926487fad9a")
  (:PATH "docs/implementazione/cbor-tag-lettura.md" :GIT-BLOB
   "5f0b9dede29f69e68a75c70d9f5e026ad3d2fece")
  (:PATH "docs/implementazione/cbor-tag-metodo.md" :GIT-BLOB
   "3175390e496173398781bf8b39170cb33892125f")
  (:PATH "docs/implementazione/cbor-tag-revisione.md" :GIT-BLOB
   "11525b2d76a8393cd5ee088c5ab8a016404884a2")
  (:PATH "docs/implementazione/cbor-tag-risultati.md" :GIT-BLOB
   "163d821483988a3fcecc0e16f77b4ae12163b13d")
  (:PATH "docs/implementazione/cbor-tag.md" :GIT-BLOB
   "78785ec855050abdc9bf1dde6edaf69248a07ba1")
  (:PATH "docs/implementazione/checkpoint-control.md" :GIT-BLOB
   "4cb5c18e209211e5cdeaa92b93326549207409b1")
  (:PATH "docs/implementazione/checkpoint-recovery.md" :GIT-BLOB
   "7d5c17d3fa99d0771fd6117c7f83796b90618f19")
  (:PATH "docs/implementazione/ci-provenienza-pr.md" :GIT-BLOB
   "5d1c6dd259445bf25188da1d749b751dcdab7ac4")
  (:PATH "docs/implementazione/ci-statistiche.md" :GIT-BLOB
   "6af171f6d114713569d7db96fbba270b257b8915")
  (:PATH "docs/implementazione/ci-wire-processi.md" :GIT-BLOB
   "65c75747dea41b2fc0ed9a441f694f488fdf54ad")
  (:PATH "docs/implementazione/closed-recuperato-revisione.md" :GIT-BLOB
   "379bc5367c33e4edccf7f2a0fcb763054d5d85c2")
  (:PATH "docs/implementazione/closed-recuperato-verifica.md" :GIT-BLOB
   "da3ec1d1eb9083d7b39724f2839a8dd47c6ad93c")
  (:PATH "docs/implementazione/closed-recuperato.md" :GIT-BLOB
   "993d6ab7e501625f9adfdc7ab095e343c81f9b37")
  (:PATH "docs/implementazione/code-writer-decisioni.md" :GIT-BLOB
   "a48d5b525d2c78fef0399666ebb14c6f8a2342e8")
  (:PATH "docs/implementazione/code-writer-metodo.md" :GIT-BLOB
   "8dfa1cf8533764fdd89014f31cac59d02b248e2e")
  (:PATH "docs/implementazione/code-writer.md" :GIT-BLOB
   "759b72a96a099d18fd353ef8936d63481e25129c")
  (:PATH "docs/implementazione/compiti-lettura.md" :GIT-BLOB
   "b28934a0a4eac77562b07fa8db796c167176ef36")
  (:PATH "docs/implementazione/control-recuperato.md" :GIT-BLOB
   "d995e71b256c3da3a48dfb08abb8e8c93a6ace64")
  (:PATH "docs/implementazione/control-transizione-metodo.md" :GIT-BLOB
   "6f3cd5786454b47d0b4ec8b2546a426050515168")
  (:PATH "docs/implementazione/control-verifica-metodo.md" :GIT-BLOB
   "a5d5443dc3f76815d0829e93e030117866673af2")
  (:PATH "docs/implementazione/controller-serie-decisioni.md" :GIT-BLOB
   "4a2c524c6b1c7be1c1b5d7e43d35d385ee7f5b1d")
  (:PATH "docs/implementazione/controller-serie-metodo.md" :GIT-BLOB
   "f6cadf13877cab21d869993f33e485f1af116806")
  (:PATH "docs/implementazione/controller-serie-revisione.md" :GIT-BLOB
   "8dbbd94b11ca62b266df8e1b58ef8b15487dde9f")
  (:PATH "docs/implementazione/controller-serie-risultati.md" :GIT-BLOB
   "2e1d7abdfe9b4880682ff1da97b526e180d01370")
  (:PATH "docs/implementazione/controller-serie.md" :GIT-BLOB
   "f1ce7efd5d2c04b970a1ea0b0afe03356aa19621")
  (:PATH "docs/implementazione/controllore-pool-decisioni.md" :GIT-BLOB
   "15c6e4b9b671396d935faa3a60015ecdfd57b755")
  (:PATH "docs/implementazione/controllore-pool-metodo.md" :GIT-BLOB
   "30b830f5e01fb9941b7f4f64155865cd10f67bec")
  (:PATH "docs/implementazione/controllore-pool-revisione-2.md" :GIT-BLOB
   "18b67528a581db82aa5fd6c99282ebe3026d3813")
  (:PATH "docs/implementazione/controllore-pool-revisione.md" :GIT-BLOB
   "c11c4866bb2698a43c9707878fc3b635d815daab")
  (:PATH "docs/implementazione/controllore-pool-risultati.md" :GIT-BLOB
   "26a193abf723f9dee7b687d5d3e4d9c6b1c8c80f")
  (:PATH "docs/implementazione/controllore-pool.md" :GIT-BLOB
   "e22552b984aa27cfc53c279b00b0ef1bc3b91ecc")
  (:PATH "docs/implementazione/csn-archivio-recovery.md" :GIT-BLOB
   "3ea3be54ab4d0a50ed6ca9f91be92d4c749329d8")
  (:PATH "docs/implementazione/csn-decisioni.md" :GIT-BLOB
   "a2a8d5bba2c3da3ad6977d6a6f750e468d229693")
  (:PATH "docs/implementazione/csn-metodo.md" :GIT-BLOB
   "1aafc63fa8904a8504ec6fd42d34b606d6505677")
  (:PATH "docs/implementazione/csn-revisione.md" :GIT-BLOB
   "ac23ebc4c1d6ab57116def02bf4ad7df115394d1")
  (:PATH "docs/implementazione/csn-risultati.md" :GIT-BLOB
   "8fe4debab581640b3d1db74b6fa43610c8e547d2")
  (:PATH "docs/implementazione/csn.md" :GIT-BLOB
   "4d34d3381385253150251c9273a5f3d038aafabd")
  (:PATH "docs/implementazione/decisioni-multiserie-decisioni.md" :GIT-BLOB
   "bc99cae302da8bb90c208cfc0d5def111e945269")
  (:PATH "docs/implementazione/decisioni-multiserie-metodo.md" :GIT-BLOB
   "79755fdc3fcc8cdc8459d0cf3d108d06e577bf3f")
  (:PATH "docs/implementazione/decisioni-multiserie.md" :GIT-BLOB
   "c3467fd1f58d977797821581ff127bfb2cfdd5cf")
  (:PATH "docs/implementazione/decisioni-radix-decisioni.md" :GIT-BLOB
   "a0953cd3789ec80e22ec33f445510db6769ad2ed")
  (:PATH "docs/implementazione/decisioni-radix-lettura-autore.md" :GIT-BLOB
   "4474e5ced93e129bae0ae13255e2c56363334f20")
  (:PATH "docs/implementazione/decisioni-radix-metodo.md" :GIT-BLOB
   "5f8fa54b5df938dc51ea2053298baa58413d7e5a")
  (:PATH "docs/implementazione/decisioni-radix-revisione.md" :GIT-BLOB
   "4434a2412cbcc6bab1bc5292331eb2c2eeabeb6a")
  (:PATH "docs/implementazione/decisioni-radix-risultati.md" :GIT-BLOB
   "ae05757ce562c9b2eb5632765cc9da4db8c2fe56")
  (:PATH "docs/implementazione/decisioni-recuperate-revisione.md" :GIT-BLOB
   "3021ee42487972c7eada38b31a3fecaf298a5ff4")
  (:PATH "docs/implementazione/decisioni-recuperate-verifica.md" :GIT-BLOB
   "06f61bdb74ed43eaf52651d41a6f85366c2f73c2")
  (:PATH "docs/implementazione/decisioni-recuperate.md" :GIT-BLOB
   "17802322cd67f981d31f3bc6728c1efe805b570c")
  (:PATH "docs/implementazione/epoche-e-reclaim.md" :GIT-BLOB
   "96a9d6be3614715a434ecfec5808375e06ff6468")
  (:PATH "docs/implementazione/evidenze-parallele.md" :GIT-BLOB
   "98a542ddf7a51a0841d72e931706701c18d8f0c2")
  (:PATH "docs/implementazione/fondazioni-binarie.md" :GIT-BLOB
   "a64f148cb2254e87c649bb16e7bee39aa45eb40d")
  (:PATH "docs/implementazione/fondazioni-decisioni.md" :GIT-BLOB
   "a1631f582d8b3ecaa177cccead8c1e3d0051a822")
  (:PATH "docs/implementazione/fonti-recovery-metodo.md" :GIT-BLOB
   "4e53c912c6ce43b12b3906d298d12205621c08f4")
  (:PATH "docs/implementazione/fonti-recovery.md" :GIT-BLOB
   "91f8c45a10b8ba7dede0a8ebeb1af6a3062ba6c2")
  (:PATH "docs/implementazione/full-text-codec-decisioni.md" :GIT-BLOB
   "1ea5bed7d728efc7495f6e263db3e65fce59381d")
  (:PATH "docs/implementazione/full-text-codec.md" :GIT-BLOB
   "eb7be4924fcc8353b93e97a1ce2ee2ad95e2cfe2")
  (:PATH "docs/implementazione/full-text-decisioni.md" :GIT-BLOB
   "72023e48fac48c6b607744ac4f7fea74922e18c2")
  (:PATH "docs/implementazione/full-text-documenti-decisioni.md" :GIT-BLOB
   "1a1c3ed21978561e8e0f38718ac84e15c1c06540")
  (:PATH "docs/implementazione/full-text-documenti.md" :GIT-BLOB
   "29cad1d30ea2461f9f0afa52df515b86f2badb32")
  (:PATH "docs/implementazione/full-text-put-metodo.md" :GIT-BLOB
   "3b3ae582b30aec20d12e769c9b55655076003bce")
  (:PATH "docs/implementazione/full-text-put.md" :GIT-BLOB
   "a4a1ca03c0ecf8f140e4cddc8cf8a343048ab388")
  (:PATH "docs/implementazione/full-text-riferimenti-metodo.md" :GIT-BLOB
   "62a93dc03c5cce6601d2affd7998f00d497ed7cf")
  (:PATH "docs/implementazione/full-text-riferimenti.md" :GIT-BLOB
   "f82c3b3f7616f128fd5fbf7a334451405e23e1fe")
  (:PATH "docs/implementazione/full-text-righe-metodo.md" :GIT-BLOB
   "90798c4149cda0a26693b3c03a2ba29b36f356bc")
  (:PATH "docs/implementazione/full-text-righe.md" :GIT-BLOB
   "b4f33b71a0c737135e6d545c3d11e1cf81447ec1")
  (:PATH "docs/implementazione/full-text-riserve-metodo.md" :GIT-BLOB
   "43e3f20e580e69629352160621139ccc8907e6c8")
  (:PATH "docs/implementazione/full-text-riserve.md" :GIT-BLOB
   "417263600d172e918cff3ff4ff704e9fc04b3cab")
  (:PATH "docs/implementazione/full-text.md" :GIT-BLOB
   "a880105f9911fe04366359e5cc1619299d81ffe1")
  (:PATH "docs/implementazione/get-active-metodo.md" :GIT-BLOB
   "f5b5b4554c17737bf3db725907bc5990ad46b40c")
  (:PATH "docs/implementazione/get-active-preflight-metodo.md" :GIT-BLOB
   "27c1b922ea41ccb9d1e627328003b90ed86fd459")
  (:PATH "docs/implementazione/get-active-preflight-verifica.md" :GIT-BLOB
   "6df5bed5a7dac4ea53db4c7359ac4c869aff8c93")
  (:PATH "docs/implementazione/get-active-verifica.md" :GIT-BLOB
   "bb55922c280edeb5b714b6d0ecd7cbb026b583d8")
  (:PATH "docs/implementazione/get-active-vuoto.md" :GIT-BLOB
   "c593d25bdee6d29d0eb99e32687153d52636ccde")
  (:PATH "docs/implementazione/get-active.md" :GIT-BLOB
   "dcde23e5fef0237eb003b24c44fb0a9386bdad68")
  (:PATH "docs/implementazione/get-directory-metodo.md" :GIT-BLOB
   "69e50510426fa53d230b64b89da9e64fdc5c6efa")
  (:PATH "docs/implementazione/get-directory-mutazioni.md" :GIT-BLOB
   "542584f7ea490cc7b4639ee42969c17f52a8e559")
  (:PATH "docs/implementazione/get-directory-revisione.md" :GIT-BLOB
   "204a995d2152620792e923275de5abcc5e29bfb3")
  (:PATH "docs/implementazione/get-directory.md" :GIT-BLOB
   "550afaffd56bdaa4b5a16337432ec9ccf655d377")
  (:PATH "docs/implementazione/get-fonti-serie-metodo.md" :GIT-BLOB
   "76ca65cb32040dcf98ca9599d40dfb2f1d4a217e")
  (:PATH "docs/implementazione/get-fonti-serie-revisione.md" :GIT-BLOB
   "a8ac6d02893d0fc74093c1fe42319cdef8adbe4f")
  (:PATH "docs/implementazione/get-fonti-serie.md" :GIT-BLOB
   "fe7dd543a6a8b8a9cdbfd59bef8040a36463aa37")
  (:PATH "docs/implementazione/get-lifetime.md" :GIT-BLOB
   "da763b5ae02443beb467f5834471bb3345725be0")
  (:PATH "docs/implementazione/get-performance-metodo.md" :GIT-BLOB
   "ee84732af73d4d753b211bd9cd33f9c7dd1d2a3f")
  (:PATH "docs/implementazione/get-performance-revisione.md" :GIT-BLOB
   "3932b391102e3b7e0ead521a1fb223ef5ca2129a")
  (:PATH "docs/implementazione/get-record.md" :GIT-BLOB
   "058623adabd6a98f7d7617c4c1ac4fd0b7bce825")
  (:PATH "docs/implementazione/get-resolver-metodo.md" :GIT-BLOB
   "31b568cfe4db29d5d4c6d6d4de82dd0f54747f23")
  (:PATH "docs/implementazione/get-resolver-verifica.md" :GIT-BLOB
   "7751ad4582bf2d9b5402c2430c2aaeb5a6d713bf")
  (:PATH "docs/implementazione/get-resolver.md" :GIT-BLOB
   "a991a37b6a5460941170bce7d951eb86888abe4f")
  (:PATH "docs/implementazione/get-verifica.md" :GIT-BLOB
   "acc39ebcd47f56d31d5ddcf9843ebf8543424f22")
  (:PATH "docs/implementazione/hash-chiavi-decisioni.md" :GIT-BLOB
   "a6b480a9726002150f65443b9a3c97c9039f2012")
  (:PATH "docs/implementazione/hash-chiavi-metodo.md" :GIT-BLOB
   "c799f6cd5399c37daa1687cd0d154ebcfac2cb39")
  (:PATH "docs/implementazione/hash-chiavi-revisione.md" :GIT-BLOB
   "d9de17c5fcd7e7f21555c68db8f3eaa7d7e1b158")
  (:PATH "docs/implementazione/hash-chiavi-risultati.md" :GIT-BLOB
   "b7c4c84c6d688015a43f81b476e58744fbf5d467")
  (:PATH "docs/implementazione/hash-chiavi.md" :GIT-BLOB
   "f103ded38e6cb575820d7fb89d72e47b9fc16693")
  (:PATH "docs/implementazione/header-log-metodo.md" :GIT-BLOB
   "d09dc4f0914935805770cf148cfab99b1ca30eb1")
  (:PATH "docs/implementazione/header-log.md" :GIT-BLOB
   "ac29588884b2f12f2bd67a72f04504d88c2d44a0")
  (:PATH "docs/implementazione/id-directory-recovery.md" :GIT-BLOB
   "207890b1e6ed707e659ae84332b0e87f9e38db1e")
  (:PATH "docs/implementazione/id-segmento-recovery.md" :GIT-BLOB
   "3d7edda639a13ccfdcb7152e2ed823645a5b0f69")
  (:PATH "docs/implementazione/indice-automatico-risultati.md" :GIT-BLOB
   "4d164ab2cc720912c64e7b5ad2dfca4310c7b930")
  (:PATH "docs/implementazione/indice-automatico.md" :GIT-BLOB
   "10900ea8dc3c630dd973bb4e59ede9bff6794908")
  (:PATH "docs/implementazione/indice-da-recovery.md" :GIT-BLOB
   "e3ff0eb2a7f56eca5ed2154722f8bc1c6ad53b74")
  (:PATH "docs/implementazione/indice-primario.md" :GIT-BLOB
   "d4382b97ee69a12235f4c1d445b9b13dd5440684")
  (:PATH "docs/implementazione/indice-ricostruzione-benchmark-metodo.md"
   :GIT-BLOB "4dc9aa9bdfdd5e21a2ef2bf6ab6fc8d2e111a586")
  (:PATH "docs/implementazione/indice-ricostruzione-revisione.md" :GIT-BLOB
   "c88785115dfda86f3e6ce425487638fe514f0e3b")
  (:PATH "docs/implementazione/indice-ricostruzione.md" :GIT-BLOB
   "1950d3f3b38736f7d32e1c3a24fb217bd1dffc86")
  (:PATH "docs/implementazione/inizializzazione-active.md" :GIT-BLOB
   "9631575af9819aa4a98472359393b36bdcde3dc9")
  (:PATH "docs/implementazione/inventario-decisioni.md" :GIT-BLOB
   "a220b68f94b35c81b9bca4420453c4057eded097")
  (:PATH "docs/implementazione/inventario-directory-metodo.md" :GIT-BLOB
   "366ee617039bc6a67de4c989d7df961941854340")
  (:PATH "docs/implementazione/inventario-directory-revisione.md" :GIT-BLOB
   "3c99eb90b20685bad8be3d988553feef589c9132")
  (:PATH "docs/implementazione/inventario-metodo.md" :GIT-BLOB
   "37ff4f5316483960508fa78df1f890ebaff8942e")
  (:PATH "docs/implementazione/inventario.md" :GIT-BLOB
   "deb47c12394f71f9b7efce689912c066b2d2fba5")
  (:PATH "docs/implementazione/io-apertura-relativa-metodo.md" :GIT-BLOB
   "13e7ab0d6eadf2b5188a27bd7049fdf7c4a3dc4d")
  (:PATH "docs/implementazione/io-apertura-relativa-revisione.md" :GIT-BLOB
   "6b66aca0e2bbe154157f4fd07c9fdbc408ffc427")
  (:PATH "docs/implementazione/io-apertura-relativa.md" :GIT-BLOB
   "2673370f421e8bbb5bf788b05a0be138e722ef6a")
  (:PATH "docs/implementazione/io-completamento.md" :GIT-BLOB
   "9e4aef21c7d550b1b26f5811ad2620440834111b")
  (:PATH "docs/implementazione/io-creazione-relativa-metodo.md" :GIT-BLOB
   "0bf34d8a6bda7c480878c858017823e3a60bcce0")
  (:PATH "docs/implementazione/io-creazione-relativa-revisione.md" :GIT-BLOB
   "f14a49852ea6dadeb750bb6621eee702ad4d4783")
  (:PATH "docs/implementazione/io-creazione-relativa.md" :GIT-BLOB
   "25e7d55ed83df48bf5e80d227f00d8733593a3d4")
  (:PATH "docs/implementazione/io-decisioni.md" :GIT-BLOB
   "476e35fca8858a4a4eed163e4a3a42c7ce38bd4a")
  (:PATH "docs/implementazione/io-metodo.md" :GIT-BLOB
   "550c69493fdb363631b83dea4fff765119b6ad5f")
  (:PATH "docs/implementazione/io-pubblicazione-metodo.md" :GIT-BLOB
   "dfeeef612f9001657ae79c9fee0d6daa38af72fa")
  (:PATH "docs/implementazione/io-pubblicazione.md" :GIT-BLOB
   "83359ed1ce8d0f7438c60f1ef6df99e5b94c7ec1")
  (:PATH "docs/implementazione/io-rinomina.md" :GIT-BLOB
   "93c4489ca3f597cb44b5c66d2bc92ca9cda80eb9")
  (:PATH "docs/implementazione/io.md" :GIT-BLOB
   "60bf873451259cd1dd2cf31cad3122195fffdad1")
  (:PATH "docs/implementazione/lettura-verifica.md" :GIT-BLOB
   "656e8162bd3833268a6243e136c2e46b39e548f5")
  (:PATH "docs/implementazione/manifest-control-log-decisioni.md" :GIT-BLOB
   "f779f81d41748e3e9b10596dc9af12b334d4dc23")
  (:PATH "docs/implementazione/manifest-control-log-metodo.md" :GIT-BLOB
   "f755abc620aaad10470143418702e883baf2493a")
  (:PATH "docs/implementazione/manifest-control-log.md" :GIT-BLOB
   "e89ce752e566bd81d276825387514b1f6272b3db")
  (:PATH "docs/implementazione/merge-main-2026-10-23.md" :GIT-BLOB
   "66719ae7c7af0aa4ced66e6046c3d88326116230")
  (:PATH "docs/implementazione/metadati-storage-decisioni.md" :GIT-BLOB
   "cb473b09149385d5d32bb44db1478e5ba7da7640")
  (:PATH "docs/implementazione/metadati-storage-metodo.md" :GIT-BLOB
   "23966839673d2e5931f1822c0c2e0302a189911a")
  (:PATH "docs/implementazione/metadati-storage.md" :GIT-BLOB
   "1b746fefc25d8cd1be1bb44611c7ac5f98e8acb1")
  (:PATH "docs/implementazione/orizzonte-csn.md" :GIT-BLOB
   "c451a24e86e98a2dd3a75cfbae55260625b33dc8")
  (:PATH "docs/implementazione/pagine-indice-risultati.md" :GIT-BLOB
   "b407283c51cca71a1d8d901bceda5741dd271b89")
  (:PATH "docs/implementazione/pagine-indice.md" :GIT-BLOB
   "2d049322290ae12a509d890adf51942f1b03dc71")
  (:PATH "docs/implementazione/pool-begin-metodo.md" :GIT-BLOB
   "0a74eac283903d32bb75e108e95a06462a7f91bd")
  (:PATH "docs/implementazione/pool-begin-revisione.md" :GIT-BLOB
   "10b9ab81741576c65c7862093f0cdc88d1c61de8")
  (:PATH "docs/implementazione/pool-begin-risultati.md" :GIT-BLOB
   "d16baa7861d275df6cae21ddeaf4591617d5c2fc")
  (:PATH "docs/implementazione/pool-begin.md" :GIT-BLOB
   "e0e62896ea19af459f528060672729864f27133a")
  (:PATH "docs/implementazione/pool-catena-metodo.md" :GIT-BLOB
   "c6affaba71aedd2f1e1ac900f01755bcfab90ce6")
  (:PATH "docs/implementazione/pool-catena-risultati.md" :GIT-BLOB
   "3d6b448db14dae6485efcc73de7a49ef85043c22")
  (:PATH "docs/implementazione/pool-dispatch-metodo.md" :GIT-BLOB
   "d94f69542c7685c30f91899889ce7dbb12783a15")
  (:PATH "docs/implementazione/pool-dispatch-revisione.md" :GIT-BLOB
   "33a30b807c66ec62c47fea6124c65126f693c91d")
  (:PATH "docs/implementazione/pool-dispatch-risultati.md" :GIT-BLOB
   "e1eccf0084fccf4c5dd45ef5ab8614618d9e94b4")
  (:PATH "docs/implementazione/pool-dispatch.md" :GIT-BLOB
   "b539520e7efdfad99de69e1473170db427f27031")
  (:PATH "docs/implementazione/pool-prepara-metodo.md" :GIT-BLOB
   "1adf298ac2b0cbcb211f622c5e83cab4e84efbff")
  (:PATH "docs/implementazione/pool-prepara-revisione.md" :GIT-BLOB
   "2eb452c647d55eaa9acb18c2960fd28885735168")
  (:PATH "docs/implementazione/pool-prepara-risultati.md" :GIT-BLOB
   "f0d2ce8787a3228a35e5bde6d3d8f7e805e5b164")
  (:PATH "docs/implementazione/pool-prepara.md" :GIT-BLOB
   "14ff3e1b5cc133a64beace7e116cb850fafb7858")
  (:PATH "docs/implementazione/pool-recycle-metodo.md" :GIT-BLOB
   "023722e1a91e1c0826867fe204eeb9eab72dc72e")
  (:PATH "docs/implementazione/pool-recycle-revisione.md" :GIT-BLOB
   "fd875bca51e4fd0d58251c123cadb6417e82bd76")
  (:PATH "docs/implementazione/pool-recycle-risultati.md" :GIT-BLOB
   "05a9218c57f7f2363925a2bb821f68cdd66b9681")
  (:PATH "docs/implementazione/pool-recycle.md" :GIT-BLOB
   "c38c4f50f84907b380e9f57e291c9f8503efc5c2")
  (:PATH "docs/implementazione/pool-step-metodo.md" :GIT-BLOB
   "b86c360abb0cc4349e4831bf3ba91c1c7a72d386")
  (:PATH "docs/implementazione/pool-step-revisione.md" :GIT-BLOB
   "f16e3beb60d31637d25a07a6d585528bc1ecc6dc")
  (:PATH "docs/implementazione/pool-step-risultati.md" :GIT-BLOB
   "8c41c836edf57e6dfca0a161bed55372c442e76d")
  (:PATH "docs/implementazione/pool-step.md" :GIT-BLOB
   "fc764576920a560b0ec6cdac9800b876191b42f6")
  (:PATH "docs/implementazione/pool-worker-claim-metodo.md" :GIT-BLOB
   "35575db9de839268157d59f2d5cd9de776d46abf")
  (:PATH "docs/implementazione/pool-worker-claim-revisione.md" :GIT-BLOB
   "c2703de72d08d7d0c66a5a45ac587d7c763ca598")
  (:PATH "docs/implementazione/pool-worker-claim-risultati.md" :GIT-BLOB
   "d1b07131d0ef3f831f86860ba6258f6bbc24b799")
  (:PATH "docs/implementazione/pool-worker-claim.md" :GIT-BLOB
   "02681055d4c93e109c70e72cf094fd87a2a8b9e5")
  (:PATH "docs/implementazione/pool-worker-lifecycle-metodo.md" :GIT-BLOB
   "598212501b1d8ecff6b4c90c0f04d551df2ff043")
  (:PATH "docs/implementazione/pool-worker-lifecycle-revisione.md" :GIT-BLOB
   "ce1cbddbfe9605c4eae9a5bcacf3a96d35d344b5")
  (:PATH "docs/implementazione/pool-worker-lifecycle-risultati.md" :GIT-BLOB
   "d3c3c91217d83796fdcd86ae9fbaed5a613c3864")
  (:PATH "docs/implementazione/pool-worker-lifecycle.md" :GIT-BLOB
   "e45c6941e0534180995d60f8882629b427f06f01")
  (:PATH "docs/implementazione/production-engine-bootstrap-metodo.md" :GIT-BLOB
   "e5e3ff0b37f99a2d9e6963a2a7820bf23b0719e2")
  (:PATH "docs/implementazione/production-engine-bootstrap.md" :GIT-BLOB
   "542294cfb5e3114366d6663c921addbe840d6861")
  (:PATH "docs/implementazione/production-unix-m1.md" :GIT-BLOB
   "46bc78baf7b0f4ee52f4f669e42187e00043f139")
  (:PATH "docs/implementazione/prova-verticale.md" :GIT-BLOB
   "797aff287aed7a8d195f04d0dae705680cb76de5")
  (:PATH "docs/implementazione/pubblicazione-control.md" :GIT-BLOB
   "bcf1d925ed557af099405f3c00fa12cf66429c56")
  (:PATH "docs/implementazione/raccolta-comandi-risultati.md" :GIT-BLOB
   "e653875dcf306897bd279f4954c36518dda7e7c8")
  (:PATH "docs/implementazione/raccolta-comandi.md" :GIT-BLOB
   "414f76917ff5c0f7ce2914d9f3be8ba9ac7fc9da")
  (:PATH "docs/implementazione/recovery-archivio.md" :GIT-BLOB
   "4d8c79c6a19463e4a34ef187f2589ae39e0126eb")
  (:PATH "docs/implementazione/recovery-csn.md" :GIT-BLOB
   "b2d8cd7bd92c871500432935e79b400ecc70b1ab")
  (:PATH "docs/implementazione/recovery-serie.md" :GIT-BLOB
   "8c910a172eda549fbdcecf8f269d895fcc3b9b01")
  (:PATH "docs/implementazione/registro-snapshot.md" :GIT-BLOB
   "096b16489aa910182fe01349aa5552ccc1ccd446")
  (:PATH "docs/implementazione/replay-closed.md" :GIT-BLOB
   "78a3700751a8dfdd81e51508027dd7a0f84df2c8")
  (:PATH "docs/implementazione/risultati/2026-10-08-benchmark.lisp" :GIT-BLOB
   "2d404302bc9dd73a3d453d2f32ee9d38b795b25c")
  (:PATH "docs/implementazione/risultati/2026-10-08-copertura.lisp" :GIT-BLOB
   "d2dea0f2d5f23f4b10bbf8f721bd2316d0f74449")
  (:PATH "docs/implementazione/risultati/2026-10-08-mutazioni.lisp" :GIT-BLOB
   "342fcd80e236d28bbf49d44b76278fdfa7099f6d")
  (:PATH "docs/implementazione/routing-worker-decisioni.md" :GIT-BLOB
   "f77e4acc65f3582d76bee6867e7a728757a98d4c")
  (:PATH "docs/implementazione/routing-worker-metodo.md" :GIT-BLOB
   "b6c4a6992ef5ca707c19e08dfbdc7d1e01e1e900")
  (:PATH "docs/implementazione/routing-worker-revisione.md" :GIT-BLOB
   "6fbe1f002e3e18df09a964292f27c3657bb46004")
  (:PATH "docs/implementazione/routing-worker-risultati.md" :GIT-BLOB
   "b275c083f9705d1ed32b4cf282fd0c12c39d98a2")
  (:PATH "docs/implementazione/routing-worker.md" :GIT-BLOB
   "3c2423f187253e7c2c83b3848c7efbd43d269641")
  (:PATH "docs/implementazione/runtime-archivio-revisione.md" :GIT-BLOB
   "9b6f224e4b30df6dce02d77e901d0c4c7e077cd8")
  (:PATH "docs/implementazione/runtime-archivio.md" :GIT-BLOB
   "9eee28d5a66d5fbc822d305381c75874c4c347e4")
  (:PATH "docs/implementazione/scansione-log-decisioni.md" :GIT-BLOB
   "c7780a6798cec4964badc6a5529508898ae4945c")
  (:PATH "docs/implementazione/scansione-log.md" :GIT-BLOB
   "bbc3431b5872adfdee0e23d566caf7d2172a971a")
  (:PATH "docs/implementazione/segmenti-compattati-metodo.md" :GIT-BLOB
   "8101b2da12ae1a60a0663b11ab70590a96c5bcf2")
  (:PATH "docs/implementazione/segmenti-compattati.md" :GIT-BLOB
   "99cf34e5c5c3875ed97414c30ec9b7bef96d30b4")
  (:PATH "docs/implementazione/selezione-versioni-recovery.md" :GIT-BLOB
   "eae7073945c0732696381a2b5147d0a4321f72b8")
  (:PATH "docs/implementazione/sessione-locale.md" :GIT-BLOB
   "3f3710dd36e0af45dd057fd6d774edee3911e69f")
  (:PATH "docs/implementazione/slot-indice-v2.md" :GIT-BLOB
   "0a534e557a3fe8216e0d5fbfc84c354255d081ac")
  (:PATH "docs/implementazione/snapshot-csn.md" :GIT-BLOB
   "d17e9e45a1d4896249d11f2bd474aa05af5222cb")
  (:PATH "docs/implementazione/snapshot-verifica.md" :GIT-BLOB
   "805c6b231d9fd7223ef1b149e75e9c3be0dd0859")
  (:PATH "docs/implementazione/stabilizzazione-archivio-metodo.md" :GIT-BLOB
   "9e03341a2e9bc0d16b7373a0b2652f312aa6a478")
  (:PATH "docs/implementazione/stabilizzazione-archivio.md" :GIT-BLOB
   "212931517e7e7c4e7c1f69a3c7e78f281d46d577")
  (:PATH "docs/implementazione/stabilizzazione-esclusiva-metodo.md" :GIT-BLOB
   "31cc08df54eea7c760e50c1517a384625ee46034")
  (:PATH "docs/implementazione/stabilizzazione-nomi-recovery.md" :GIT-BLOB
   "d31527cf2c0146f8e8bb28029fbcff1fbca00825")
  (:PATH "docs/implementazione/stabilizzazione-serie-metodo.md" :GIT-BLOB
   "e8a54f4e7be1995dd54e0101ae13a8c75672b676")
  (:PATH "docs/implementazione/stabilizzazione-serie.md" :GIT-BLOB
   "d607b2ee3757f200610e339e7e3a5207ff3198dc")
  (:PATH "docs/implementazione/utf8-decisioni.md" :GIT-BLOB
   "d6e2ad12c278d5bb26050c056df4342671c590f5")
  (:PATH "docs/implementazione/utf8-metodo.md" :GIT-BLOB
   "77d0c406a967ebe97f81781f9dd4cc9d68488ee4")
  (:PATH "docs/implementazione/utf8.md" :GIT-BLOB
   "1798cdf9b8916ba74b21d1d86442a49874938e41")
  (:PATH "docs/implementazione/wal-csn-decisioni.md" :GIT-BLOB
   "bc3121e6274d610f56155a1e159d0a8948ee87c5")
  (:PATH "docs/implementazione/wal-csn-metodo.md" :GIT-BLOB
   "73bfef0b478f57c9441a6d0e2ab59c0e7f223fef")
  (:PATH "docs/implementazione/wal-csn-revisione.md" :GIT-BLOB
   "89a767f226693292d6a934970010d6dc5f13bbe7")
  (:PATH "docs/implementazione/wal-csn-risultati.md" :GIT-BLOB
   "d7e1f6e6fd5baa3c0c345507b8c3cd7a71e47f33")
  (:PATH "docs/implementazione/wal-csn.md" :GIT-BLOB
   "497b96ba252c1d223b91c7a958af3a1de6e6bba9")
  (:PATH "docs/implementazione/wal-decisioni.md" :GIT-BLOB
   "4b9535873216af6a4ede0b3d6d31e80c466ad395")
  (:PATH "docs/implementazione/wal-metodo.md" :GIT-BLOB
   "6c46cebd54cacfe7b366932d1be6bd2132346087")
  (:PATH "docs/implementazione/wal.md" :GIT-BLOB
   "c9ec2a33ac47f9811f152032cc6232fb1ccb941a")
  (:PATH "docs/implementazione/worker-cbor-interleaving.md" :GIT-BLOB
   "3c35404cf60cddef14046eba1f99f215b3b3cc2f")
  (:PATH "docs/implementazione/worker-serie-decisioni.md" :GIT-BLOB
   "9cfa2d91655890f50c7a0d83cb14f0bbae650f21")
  (:PATH "docs/implementazione/worker-serie-integrazione.md" :GIT-BLOB
   "08c866115be68fd9e88c2d30fd111017851bbb53")
  (:PATH "docs/implementazione/worker-serie-metodo.md" :GIT-BLOB
   "df02aed3cd659b1b09e746d8315f54e32f526965")
  (:PATH "docs/implementazione/worker-serie-revisione.md" :GIT-BLOB
   "2d2ffb30c9051c58fd7f9b7efb27a487d1c0fd8e")
  (:PATH "docs/implementazione/worker-serie-risultati.md" :GIT-BLOB
   "76b2e79d012ebffcdde4477af9b19fb2e1e54e67")
  (:PATH "docs/implementazione/worker-serie.md" :GIT-BLOB
   "7e470b27c01de9fbfb4d4b532136760ec18afdad")
  (:PATH "docs/implementazione/writer-handoff-decisioni.md" :GIT-BLOB
   "5f0636cde6711769dc13bdaabefb55e6af843147")
  (:PATH "docs/implementazione/writer-handoff-metodo.md" :GIT-BLOB
   "f6eb25d050854b65daa7766d203b3e177dbc8f4a")
  (:PATH "docs/implementazione/writer-handoff-revisione.md" :GIT-BLOB
   "04f64ce2d33e27cc5d40482765223aa6dec062ea")
  (:PATH "docs/implementazione/writer-handoff-risultati.md" :GIT-BLOB
   "e4fa3bae3e265d1ca702c1ecc6aa8e44c676155e")
  (:PATH "docs/implementazione/writer-handoff.md" :GIT-BLOB
   "f76d0c995da17ae17ef8ccc6c68a3045ea461a73")
  (:PATH "docs/implementazione/writer-ready-decisioni.md" :GIT-BLOB
   "a92e30d229b4d76f6220a96ded2c46f4054544a4")
  (:PATH "docs/implementazione/writer-ready-metodo.md" :GIT-BLOB
   "c04cfa11a0b9edaf4b73a251845690cdbb3ee98c")
  (:PATH "docs/implementazione/writer-ready-revisione.md" :GIT-BLOB
   "caafe0a8685e4faf2215bebe5f37fd1a80683f93")
  (:PATH "docs/implementazione/writer-ready-risultati.md" :GIT-BLOB
   "1f01809c914084c4773dd184439d1cf599710f09")
  (:PATH "docs/implementazione/writer-ready.md" :GIT-BLOB
   "ef2ed1ac671dec6c7904174152fdd90dd03c4589")
  (:PATH "docs/implementazione/writer-recycle-decisioni.md" :GIT-BLOB
   "dfd353b4f7544d41a04d916abdb4a0aedaac2c3d")
  (:PATH "docs/implementazione/writer-recycle-metodo.md" :GIT-BLOB
   "b94583da79c1834c306118ebcc013c795b286ce1")
  (:PATH "docs/implementazione/writer-recycle-revisione.md" :GIT-BLOB
   "4d6ff67e6e78c550986e2e953ed8a9a5d8b4ee20")
  (:PATH "docs/implementazione/writer-recycle-risultati.md" :GIT-BLOB
   "db7e38f078621af681d9b5e523f4c91bf4801c6d")
  (:PATH "docs/implementazione/writer-recycle.md" :GIT-BLOB
   "ffd1c9ac47dcab5ab8c1c0301c0c04c3e2686b6e")
  (:PATH "docs/implementazione/writer-worker-decisioni.md" :GIT-BLOB
   "01109f06ce875665dffb11263b80f68a2d3c07ba")
  (:PATH "docs/implementazione/writer-worker-integrazione.md" :GIT-BLOB
   "3249fbcd44f2f2e76a14195461a3a4e43b3031ec")
  (:PATH "docs/implementazione/writer-worker-metodo.md" :GIT-BLOB
   "a12ac9c53969f6755c8cb0de21212f06e7e03e4b")
  (:PATH "docs/implementazione/writer-worker-revisione.md" :GIT-BLOB
   "f500b01def047de7973851144c8196036abf36bb")
  (:PATH "docs/implementazione/writer-worker-risultati.md" :GIT-BLOB
   "2e58b4d0e459495430a6cd1e9540994d8a25a0da")
  (:PATH "docs/implementazione/writer-worker.md" :GIT-BLOB
   "f134e4c3c3cfda195b324e7bb362948b67aa1fd5")
  (:PATH "docs/invarianti.md" :GIT-BLOB
   "534106974f25877b730e1a48d5cd3522bdbe959c")
  (:PATH "docs/limiti.md" :GIT-BLOB "ec2f27b68c809503c2f393f48b6633dc82ad8bc5")
  (:PATH "docs/principi-di-ingegneria.md" :GIT-BLOB
   "4bd3d55870e1b05b12a4a2287de6b5186f2d3b5d")
  (:PATH "docs/questioni-aperte.md" :GIT-BLOB
   "18fbaf5c89b9aa7e5ad460c0fa12d745bacb5bda")
  (:PATH "docs/roadmap.md" :GIT-BLOB
   "212947573e96b6d8ef42c1959667fa911bc72ff5")
  (:PATH "docs/specifica/specifica-originale.md" :GIT-BLOB
   "742c9309d02efe4238c859a3a7c6cd577240cdf2")
  (:PATH "docs/tracciabilita/README.md" :GIT-BLOB
   "70d45ea89536739989e90f7815ed8e89fc1544c6")
  (:PATH "docs/tracciabilita/matrice.md" :GIT-BLOB
   "c7d29d2d734d89899e41ea59801026bbc049a093")
  (:PATH "docs/tracciabilita/requisiti.lisp" :GIT-BLOB
   "07ba9092e7ec056040c9842299797b94aa3ee3ec")
  (:PATH "docs/valutazione/README.md" :GIT-BLOB
   "1d6f0361d14bbf2a79280ef51a866eddd420d655")
  (:PATH "docs/valutazione/analisi-critica.md" :GIT-BLOB
   "c5b7d4f08337ce5b0fa7096b872e21ca8c94462e")
  (:PATH "docs/valutazione/caso-duso-nntp.md" :GIT-BLOB
   "707902f3a4ff419be917a68b2c164cc1f537a988")
  (:PATH "docs/valutazione/conservazione-compatta.md" :GIT-BLOB
   "2709ceddf253b8a53c7726f2fcf33fc0c8d2ecff")
  (:PATH "docs/valutazione/piano-spike.md" :GIT-BLOB
   "fd3c652573a9232c55ae343583983a57d73d16c3")
  (:PATH "docs/valutazione/registro-delle-prove.md" :GIT-BLOB
   "d6421c9d4bd6779acb16af5037b8233ffb15b5d3")
  (:PATH "docs/valutazione/registro-rischi.md" :GIT-BLOB
   "dec33e57f31195ebf30c25d63f3f0a7a8ae5c759")
  (:PATH "docs/valutazione/risultati-2026-10-08.md" :GIT-BLOB
   "0fa9272a2986414342a107ae4c1e5fbde3720958")
  (:PATH "docs/valutazione/risultati-SPK-01-lettura-2026-10-08.md" :GIT-BLOB
   "9647505f8a2ae9cf74348487e9648a6c0dd5d252")
  (:PATH "docs/valutazione/risultati-SPK-04-2026-10-08.md" :GIT-BLOB
   "25d94d78061e6c68007e4316aca4cdc60f9de610")
  (:PATH "docs/valutazione/risultati-SPK-05-2026-10-08.md" :GIT-BLOB
   "a95cb4392328411d9f17c334c149d9c029535102")
  (:PATH "docs/valutazione/risultati-SPK-06-2026-10-08.md" :GIT-BLOB
   "679e74cf6c8051dd57ea1f2fa0584c46aaef47e2")
  (:PATH "docs/valutazione/risultati-SPK-07-08-2026-10-08.md" :GIT-BLOB
   "e8af15a00e7178168116c0138027e820c07e598c")
  (:PATH "docs/valutazione/risultati-SPK-08-bitmap-2026-10-08.md" :GIT-BLOB
   "139d030b0125b61aad567263b7b7db95e830e927")
  (:PATH "docs/valutazione/stime-ordine-di-grandezza.md" :GIT-BLOB
   "2b8c5e98a2f55bc73f2167bb05fde73e09c07a85")
  (:PATH "spikes/README.md" :GIT-BLOB
   "d350aa6335a0f1c76d76ffde25b35ccbb837a199")
  (:PATH "spikes/SPK-01-primary-index/README.md" :GIT-BLOB
   "81c46b7e0a82ca474857d5e5de01dc43c0572bf1")
  (:PATH "spikes/SPK-01-primary-index/bench-lettura-buffer.lisp" :GIT-BLOB
   "2fd1b13855a94dc946f9f1b5e1c7556558b7e0c0")
  (:PATH "spikes/SPK-01-primary-index/check-lettura-buffer.lisp" :GIT-BLOB
   "fd32c5260ffb7c6e96cf1a420765eb01effe70bc")
  (:PATH "spikes/SPK-01-primary-index/core.lisp" :GIT-BLOB
   "c019f6ad53e173a0d336a4dbfaf903e274a66f08")
  (:PATH "spikes/SPK-01-primary-index/lettura-buffer.lisp" :GIT-BLOB
   "34b3574a554ca4e03a34f04b3fc66022abb7893b")
  (:PATH "spikes/SPK-01-primary-index/metodo-bench-lettura-buffer.md" :GIT-BLOB
   "1683f3951361ad60dea42821451a4bea35147b6c")
  (:PATH "spikes/SPK-01-primary-index/metodo-check-lettura-buffer.md" :GIT-BLOB
   "19840c3a15271323546259e5c0aafd7d13489681")
  (:PATH "spikes/SPK-01-primary-index/metodo-integrazione-lettura-buffer.md"
   :GIT-BLOB "54a1982bd08ac27197c3266bb2f883aab405f705")
  (:PATH "spikes/SPK-01-primary-index/metodo-lettura-buffer.md" :GIT-BLOB
   "f7d9674884267ad4d22f962c762e1995b749fb44")
  (:PATH "spikes/SPK-01-primary-index/profile.lisp" :GIT-BLOB
   "a71fde100e32072b6e7b010228683b640ea4ff9a")
  (:PATH "spikes/SPK-01-primary-index/run.lisp" :GIT-BLOB
   "b6e680b0c2d1a96c1d7fc3b0e133c80b6564a01e")
  (:PATH "spikes/SPK-02-gc/README.md" :GIT-BLOB
   "f8480d84bb8e932e0a17719c779ea54709c3c3f4")
  (:PATH "spikes/SPK-02-gc/core.lisp" :GIT-BLOB
   "01f6760c75fa6e96a480fca41b1426941a9f703d")
  (:PATH "spikes/SPK-02-gc/run.lisp" :GIT-BLOB
   "9fbe499100da40c2f7a14072af67c35c734949c5")
  (:PATH "spikes/SPK-03-group-commit/README.md" :GIT-BLOB
   "1c6ae01e442bd3c4d8c829006647aaa59ae1a185")
  (:PATH "spikes/SPK-03-group-commit/core.lisp" :GIT-BLOB
   "d3c58f2866e299ba27b0fa820c20317438774410")
  (:PATH "spikes/SPK-03-group-commit/run.lisp" :GIT-BLOB
   "c0b093e87028dd587c43d3cd52e59492270fdc38")
  (:PATH "spikes/SPK-04-writer-pool/README.md" :GIT-BLOB
   "91732544806c231b77dcbddc9a2e4460a12873ec")
  (:PATH "spikes/SPK-04-writer-pool/core.lisp" :GIT-BLOB
   "557b32e6378290c46c7d9b128fc8e59a0e7e0a44")
  (:PATH "spikes/SPK-04-writer-pool/parcheggi.lisp" :GIT-BLOB
   "c0fee7b738395fcaf3359f297282cd266ce6dfad")
  (:PATH "spikes/SPK-04-writer-pool/pool.lisp" :GIT-BLOB
   "cbec51aad2b64fb8c5be026891eff859ba371c18")
  (:PATH "spikes/SPK-04-writer-pool/run.lisp" :GIT-BLOB
   "77056cc1f695574ed0f4d34795b99aaea736f378")
  (:PATH "spikes/SPK-05-segment-read/README.md" :GIT-BLOB
   "16ebc31ba682d36cf3520086d43f35a310159bec")
  (:PATH "spikes/SPK-05-segment-read/core.lisp" :GIT-BLOB
   "15fad418184ce9969c337b181317b855ede9f5ce")
  (:PATH "spikes/SPK-05-segment-read/io.lisp" :GIT-BLOB
   "ba470bce3cae0ce14888dbec6e26c5656e9bbd1a")
  (:PATH "spikes/SPK-05-segment-read/record.lisp" :GIT-BLOB
   "baea7833c8e6f9a49b5ea2f8ee15f76fe35f93fe")
  (:PATH "spikes/SPK-05-segment-read/run.lisp" :GIT-BLOB
   "c67a3ae8e672f96d9105deb935fb621b07d67afb")
  (:PATH "spikes/SPK-06-compaction-load/README.md" :GIT-BLOB
   "e5d56bb99d2bae3867cacd19d18711f35e6ff8db")
  (:PATH "spikes/SPK-06-compaction-load/controllore.lisp" :GIT-BLOB
   "4602972e2400d31d4d3b771f60703c68e23f0804")
  (:PATH "spikes/SPK-06-compaction-load/core.lisp" :GIT-BLOB
   "375cb97e1490e0252c04fd1a3076a17342cefd68")
  (:PATH "spikes/SPK-06-compaction-load/interferenza.lisp" :GIT-BLOB
   "9ad30ce92bdb643aeb5163e96508bf677996a4ef")
  (:PATH "spikes/SPK-06-compaction-load/run.lisp" :GIT-BLOB
   "b2863cbac49d0988b850bdeeae1713108a21bfca")
  (:PATH "spikes/SPK-07-protocols/README.md" :GIT-BLOB
   "2eca7df2fd82994b4ad13ff58f72ab5efb9edc3a")
  (:PATH "spikes/SPK-07-protocols/byte-crash.lisp" :GIT-BLOB
   "66a6c3b458d808fc214f7c3bd96e09d239312c67")
  (:PATH "spikes/SPK-07-protocols/compaction.lisp" :GIT-BLOB
   "93483f72f3bfe43f0e2afa93b022892114a824e1")
  (:PATH "spikes/SPK-07-protocols/core.lisp" :GIT-BLOB
   "489e2732cf5bfed4cd11251bb686a5d4f4e10b3e")
  (:PATH "spikes/SPK-07-protocols/memoria.lisp" :GIT-BLOB
   "96b6cf64d481643cdba7857f339a7cb7c029b765")
  (:PATH "spikes/SPK-07-protocols/metodo-byte-crash.md" :GIT-BLOB
   "ea4feea4edb0e4a1dd7ad357419b6bf97b415f50")
  (:PATH "spikes/SPK-07-protocols/metodo-compaction.md" :GIT-BLOB
   "51be4a3beb85262d453bd6b283a3b31378615fe7")
  (:PATH "spikes/SPK-07-protocols/metodo-memoria.md" :GIT-BLOB
   "f23f9ecd889437c83c946c88f2bf56a45a73f3ab")
  (:PATH "spikes/SPK-07-protocols/metodo-page-lifetime.md" :GIT-BLOB
   "e316c7eaade10d6dbe72c3fcb66ce294d66d8c67")
  (:PATH "spikes/SPK-07-protocols/metodo-pubblicazione.md" :GIT-BLOB
   "bbeac271ff79f96c0f69d22c60a045a4bfec8f09")
  (:PATH "spikes/SPK-07-protocols/metodo-scadenza.md" :GIT-BLOB
   "9d97ed258355e5afd21edfc1820ee6d68137a02c")
  (:PATH "spikes/SPK-07-protocols/metodo-seqlock-readers.md" :GIT-BLOB
   "729f3500b4f427612b39c02f210c4ac25f45c805")
  (:PATH "spikes/SPK-07-protocols/page-lifetime.lisp" :GIT-BLOB
   "c032387167188be066737f75583738843b12c883")
  (:PATH "spikes/SPK-07-protocols/pubblicazione.lisp" :GIT-BLOB
   "d317849b3f95394a7f604b82fb131495b5b3770c")
  (:PATH "spikes/SPK-07-protocols/run-module.lisp" :GIT-BLOB
   "1ec5a1db56a76daacbc7488d8b7940aa0e16eca0")
  (:PATH "spikes/SPK-07-protocols/run.lisp" :GIT-BLOB
   "95ab6095de30d013dbf5c426f7b6c0a99d5663e6")
  (:PATH "spikes/SPK-07-protocols/scadenza.lisp" :GIT-BLOB
   "05a5e93591e2d6e96c2c7548e90888424cbb1f9f")
  (:PATH "spikes/SPK-07-protocols/seqlock-readers.lisp" :GIT-BLOB
   "b2e704bbe7e699b9df68173319f64d2ae8abc5fc")
  (:PATH "spikes/SPK-07-protocols/suite.lisp" :GIT-BLOB
   "9daf0b57d92db583544653384217105121c8627d")
  (:PATH "spikes/SPK-08-generated-code/README.md" :GIT-BLOB
   "787fa26b0526e179148e958136d709e74c63ba3a")
  (:PATH "spikes/SPK-08-generated-code/bitmap.lisp" :GIT-BLOB
   "cbeff7e2a58f268291b01cb6a1f124533063d5d6")
  (:PATH "spikes/SPK-08-generated-code/comparison.lisp" :GIT-BLOB
   "b8b8ebfa609d6bfe9b710833f22cdff693ef46bd")
  (:PATH "spikes/SPK-08-generated-code/core-bitmap.lisp" :GIT-BLOB
   "a4be2005a702a77a631f35568778673c503c60b5")
  (:PATH "spikes/SPK-08-generated-code/impronte.lisp" :GIT-BLOB
   "d187e3d95f0e85a0a8ae84843a67a326e803cd2c")
  (:PATH "spikes/SPK-08-generated-code/metodo-bitmap.md" :GIT-BLOB
   "6b3bc87d5700e52ca6b861fa562c2b7958248887")
  (:PATH "spikes/SPK-08-generated-code/metodo-impronte.md" :GIT-BLOB
   "9e9121e124a6af86e9ccb8a253f69e1db584e873")
  (:PATH "spikes/SPK-08-generated-code/metodo-simd.md" :GIT-BLOB
   "e6b80fa0165026cd1a89c58786ec35d240bdc6c5")
  (:PATH "spikes/SPK-08-generated-code/run-bitmap.lisp" :GIT-BLOB
   "40c3761959a7759fe2d606d66c0fe5d9efa7aca2")
  (:PATH "spikes/SPK-08-generated-code/run.lisp" :GIT-BLOB
   "7c797afe4a6060782ce58f0cfc06f539006d117a")
  (:PATH "spikes/SPK-08-generated-code/simd.lisp" :GIT-BLOB
   "dbd551322880f1e0ddac6436c8af8f0dd85ddb9f")
  (:PATH "spikes/SPK-09-integrity/README.md" :GIT-BLOB
   "5755794e6b6afeed6f00a698cb337cf4b18730a4")
  (:PATH "spikes/SPK-09-integrity/core.lisp" :GIT-BLOB
   "80cdac4c0e52703618e1f274413b2ecbe00e6b14")
  (:PATH "spikes/SPK-09-integrity/run.lisp" :GIT-BLOB
   "c95660a4df5f2e6f6eb93e1078c2c36df6dabc85")
  (:PATH "spikes/SPK-10-v2-limits/README.md" :GIT-BLOB
   "cb5452eab513ddab4db6eb2955603a0c133d4e77")
  (:PATH "spikes/SPK-10-v2-limits/cbor.lisp" :GIT-BLOB
   "d6a5c93e34a0444d64b206df875a25b380545631")
  (:PATH "spikes/SPK-10-v2-limits/codec.lisp" :GIT-BLOB
   "567c84546d29e1b8ddc5cd9e1a31b4e93519c75d")
  (:PATH "spikes/SPK-10-v2-limits/core.lisp" :GIT-BLOB
   "c5b7cfd27c663734b7d5fae481dde939418566b5")
  (:PATH "spikes/SPK-10-v2-limits/indice.lisp" :GIT-BLOB
   "bc978eb16aa7f0d69e3deac2df86057a650f8551")
  (:PATH "spikes/SPK-10-v2-limits/metodo-cbor.md" :GIT-BLOB
   "8c83b0067a0481759f14733e3c60ca888c6d01d8")
  (:PATH "spikes/SPK-10-v2-limits/metodo-codec.md" :GIT-BLOB
   "69fb5930c2722871c30056b41c13f7919058bfcb")
  (:PATH "spikes/SPK-10-v2-limits/metodo-indice.md" :GIT-BLOB
   "b5cc04cfdf8ff989a5eb6081dd100f8c506b081d")
  (:PATH "spikes/SPK-10-v2-limits/metodo-migrazione.md" :GIT-BLOB
   "e3ebc7594ca6b1ae269579e5e9c7f9fef1b14300")
  (:PATH "spikes/SPK-10-v2-limits/migrazione.lisp" :GIT-BLOB
   "cab850dc32ff9908b487b24edf3e1df2cc90008c")
  (:PATH "spikes/SPK-10-v2-limits/run.lisp" :GIT-BLOB
   "6aa63afeac91c3b75174b76daba61e354bb7fe4d")
  (:PATH "spikes/SPK-11-unix-socket/README.md" :GIT-BLOB
   "cb540daa0c8918a07cfc3214d613e2e45d77db36")
  (:PATH "spikes/SPK-11-unix-socket/codec-inputs.lisp" :GIT-BLOB
   "d0db0b9a40edd8e47d5e758f012bb45d489eaa89")
  (:PATH "spikes/SPK-11-unix-socket/core.lisp" :GIT-BLOB
   "7b526422d5be781d26213e128a49a07bc3e25788")
  (:PATH "spikes/SPK-11-unix-socket/io-checks.lisp" :GIT-BLOB
   "b0bfea2d8042566852c6d23568087db11fd2bfe2")
  (:PATH "spikes/SPK-11-unix-socket/io-state.lisp" :GIT-BLOB
   "30db13814ebed2fb85a10ac1858cd8ec9931a6ee")
  (:PATH "spikes/SPK-11-unix-socket/io-transport.lisp" :GIT-BLOB
   "5a1f26feeae1f415557f28ae62ee1b3297314423")
  (:PATH "spikes/SPK-11-unix-socket/native-io-method.md" :GIT-BLOB
   "9126cd6694a005fb4ee117069eebfa0b9c48fe2a")
  (:PATH "spikes/SPK-11-unix-socket/native-io.lisp" :GIT-BLOB
   "0740e3d5542c6ad5b2d4106fb73c26f4e97ab0c5")
  (:PATH "spikes/SPK-11-unix-socket/run.lisp" :GIT-BLOB
   "3c83e79a935184239c21f02296f262acf4f5c64d")
  (:PATH "spikes/SPK-11-unix-socket/scenarios.lisp" :GIT-BLOB
   "e192b075c58d0b554f1fa1c3b09acf86607ad9e1")
  (:PATH "spikes/SPK-11-unix-socket/session-checks.lisp" :GIT-BLOB
   "75d5e70617a33fa738b911397d8bab22ea3e1faf")
  (:PATH "spikes/SPK-11-unix-socket/session-method.md" :GIT-BLOB
   "4f58dd5447600607e9c9efa9382d19b07aedfb72")
  (:PATH "spikes/SPK-11-unix-socket/session-model.lisp" :GIT-BLOB
   "02b389e0579f4c268bc35afc9e2eb75ab501e88a")
  (:PATH "spikes/SPK-11-unix-socket/session-transport.lisp" :GIT-BLOB
   "a79fed48095bd01e56860372badc1e168ac8eb7a")
  (:PATH "spikes/SPK-11-unix-socket/session-wire.lisp" :GIT-BLOB
   "d3bd3a22eb6ab70554f13ca798b8ea5ab310e863")
  (:PATH "spikes/SPK-11-unix-socket/transport.lisp" :GIT-BLOB
   "413d13844d7fccc8d036832778851ceeb26dbc33")
  (:PATH "src/active/package.lisp" :GIT-BLOB
   "fbd3a32b30808508424c007ece26c9f3ea9ad0a9")
  (:PATH "src/active/preflight.lisp" :GIT-BLOB
   "827f0b580b404ad6c41184a7c9802ce50a8d413c")
  (:PATH "src/active/prepare.lisp" :GIT-BLOB
   "b2a326e3a17de2e1c9d0785d4a86b2137e41fce2")
  (:PATH "src/active/source.lisp" :GIT-BLOB
   "56f258d204b2c1af544f38d15fc1e357977b336f")
  (:PATH "src/active/types.lisp" :GIT-BLOB
   "91238be2c204434cb3583fd96743ebc98e46b503")
  (:PATH "src/cache/build.lisp" :GIT-BLOB
   "45255a912edb4300b1f22c9505d09be5177d1d4b")
  (:PATH "src/cache/clock.lisp" :GIT-BLOB
   "5aca4d48de7bf0d849eafe87ae89f6e7800282d8")
  (:PATH "src/cache/core.lisp" :GIT-BLOB
   "9ab280c17b61b8f98f8299cbfae676942bb3ae47")
  (:PATH "src/cache/package.lisp" :GIT-BLOB
   "c86ef56ec05e92ebc0fa155423289775970eedd2")
  (:PATH "src/cache/read.lisp" :GIT-BLOB
   "5f4f08a4609bd264fa058ec25ba8f6a516c162c8")
  (:PATH "src/cache/types.lisp" :GIT-BLOB
   "b335ea1d241672a3989da65b9a7ec516e7533347")
  (:PATH "src/cache/write.lisp" :GIT-BLOB
   "bcd7de80241f809dcfce472741f120a61ac787b4")
  (:PATH "src/codec/cbor-array-input.lisp" :GIT-BLOB
   "d3b3d07fc18bd2a077c1a2d79020a76263b2779e")
  (:PATH "src/codec/cbor-array-write.lisp" :GIT-BLOB
   "a410297c29c5d043ad60d3804bd3711e22c2833b")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "ca6215b30010d3d2eb90eaa6fd09dd5a9ac7778f")
  (:PATH "src/codec/cbor-float-narrow.lisp" :GIT-BLOB
   "cd5749edc0a757ee3a5b470eda566a6685d32fd8")
  (:PATH "src/codec/cbor-float-write.lisp" :GIT-BLOB
   "03c6aed61e2c243d8b1a6c4332ce1837c4e9a77c")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "db635a50678f2712ec9516be335717ea254d4d09")
  (:PATH "src/codec/cbor-item-read.lisp" :GIT-BLOB
   "b9099dc8a8c96281063811e686deb4dcb2b1d39b")
  (:PATH "src/codec/cbor-map-input.lisp" :GIT-BLOB
   "d7a593badeb6e6b71f28dc4e80c641b07189d0b8")
  (:PATH "src/codec/cbor-map-write.lisp" :GIT-BLOB
   "22e814ea68e606c5bc58033c2a31e945303a9d65")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "761302dad1073c841397f6c88d595b114af8d9ef")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "3e31d60234585442baa5664be96a83915e034397")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "57ffc48cc688a4de8ebec5cb14c1e69c4209704a")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "70272936e323b3e0cb05173c9fb68cb2b614c355")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "f1afe79c7a4d49abd6a6e5f6975dec830ef7b1f6")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "c574e87af5e195ddf3f596a4ae527e69c7a3c6a6")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "e3d7d77407046338d23e26eb0b8a2e8fdc3d699d")
  (:PATH "src/codec/cbor-simple-write.lisp" :GIT-BLOB
   "58c7a3a040ec814fae2dfe636f569b5623cba8f0")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "a8330e50a77b52a6b9044ebbb48f62bb4b3222a3")
  (:PATH "src/codec/cbor-string-read.lisp" :GIT-BLOB
   "d4a4f774c2264c46349e7eda61ee4a2a3118d742")
  (:PATH "src/codec/cbor-string-write.lisp" :GIT-BLOB
   "a2c5c77dd51bff760bff4508e998d94370921eda")
  (:PATH "src/codec/cbor-tag-input.lisp" :GIT-BLOB
   "6dfad07035ac8040b2aec0a455c175ea15dfd9ad")
  (:PATH "src/codec/cbor-tag-write.lisp" :GIT-BLOB
   "16b91fc27eabafd7ff12bfb0a56ed34208c2bd4b")
  (:PATH "src/codec/cbor-write.lisp" :GIT-BLOB
   "61f0d6e2783e4790ed7e19a45bba6407d6e5b3de")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "7139b8ce1a947efe6599f2cbbdf78a02e35a68f1")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "e2339f232be3d432311503cb48f9ad8e2e53e8e8")
  (:PATH "src/control/build.lisp" :GIT-BLOB
   "b20fd8bbde30f47d2b9b6723cd04ee8c57f84ad4")
  (:PATH "src/control/dependency.lisp" :GIT-BLOB
   "70e4b4052d3e787f86273c0a8bec60de38b6163a")
  (:PATH "src/control/package.lisp" :GIT-BLOB
   "e56a6bb83abe9441350baa46573d74c6d55edf4e")
  (:PATH "src/control/preflight.lisp" :GIT-BLOB
   "638bad1673c8fd83876551ab3e7969167f611a1c")
  (:PATH "src/control/prepare.lisp" :GIT-BLOB
   "a75979cadbc8910c4955f2b091bd861150e5a26b")
  (:PATH "src/control/publication-read.lisp" :GIT-BLOB
   "6970c03f6387dad6948121852a9ad04ee9cca48e")
  (:PATH "src/control/publication.lisp" :GIT-BLOB
   "696f6208a139c1362f9cfcdd9be0f2c2396843ff")
  (:PATH "src/control/recovery-publication.lisp" :GIT-BLOB
   "906ea6d3f42c19f20bfde45bc477ba6ee4bc1040")
  (:PATH "src/control/recovery-read.lisp" :GIT-BLOB
   "5ec9c664bbf137e7456a4058dd14a934839fe6b3")
  (:PATH "src/control/recovery-types.lisp" :GIT-BLOB
   "07d3b1273fea4f1c8b2695c9fa563a0579bdb2e5")
  (:PATH "src/control/transfer.lisp" :GIT-BLOB
   "f29a92a80d75718c1bca9d7403c8764cb24399a2")
  (:PATH "src/control/types.lisp" :GIT-BLOB
   "d45ec11a4475dd9ecf32f37e2f656b127f19c98b")
  (:PATH "src/csn/package.lisp" :GIT-BLOB
   "9eb660cca8f097e25ca3c1535cace8c20bc1e238")
  (:PATH "src/csn/registry.lisp" :GIT-BLOB
   "80cb600f6c6d724cf1eaec25c3d2742c8c320906")
  (:PATH "src/dispatch/begin.lisp" :GIT-BLOB
   "1f54e226a0b7d5c796ef09b6336866e1a74b78b1")
  (:PATH "src/dispatch/build.lisp" :GIT-BLOB
   "d1f2397592a8ba9c3af21394f191017e9fd2219c")
  (:PATH "src/dispatch/claim.lisp" :GIT-BLOB
   "f7717c94b765165eae4144042308e3639644ed5e")
  (:PATH "src/dispatch/package.lisp" :GIT-BLOB
   "db21c798588ff4a88be5b69b5fbe72bc84811a46")
  (:PATH "src/dispatch/recycle.lisp" :GIT-BLOB
   "adcd65ee5fd683d70a40b89b31a2edf7fc93994c")
  (:PATH "src/dispatch/start.lisp" :GIT-BLOB
   "9b1964850e91e273ef21f9e371bdd2cd81673825")
  (:PATH "src/dispatch/step.lisp" :GIT-BLOB
   "a4089abcd78bb811ca8279361af027e9822722c0")
  (:PATH "src/dispatch/types.lisp" :GIT-BLOB
   "09b357c8f46c67d8e57994e1fa37affdd25a1695")
  (:PATH "src/engine/adopt.lisp" :GIT-BLOB
   "71862c121995b04b8fa2ecb2998f1d60b4578eb0")
  (:PATH "src/engine/config.lisp" :GIT-BLOB
   "72610668dd6479e482c5a823f80eec82e9bc846c")
  (:PATH "src/engine/files.lisp" :GIT-BLOB
   "591bf1b189c852cc8dbd3d5dd72319fa954b3932")
  (:PATH "src/engine/index.lisp" :GIT-BLOB
   "c7427d58d6457d7d604ae31a3a8fedf373acdb91")
  (:PATH "src/engine/initialize.lisp" :GIT-BLOB
   "456400c5ddfe7a799b5004dd1794ebf449bcb24c")
  (:PATH "src/engine/lifecycle.lisp" :GIT-BLOB
   "7cf82c9fdcc234d309eb45e9d28bfe1d4faac85f")
  (:PATH "src/engine/package.lisp" :GIT-BLOB
   "25064d3500a138b807457135eb768363cee6d661")
  (:PATH "src/engine/preflight.lisp" :GIT-BLOB
   "cb792a8f612fb011426b49e5066e2d22bc427cc2")
  (:PATH "src/engine/read.lisp" :GIT-BLOB
   "a661428c059834a347dae4ea5b94b276292e83ab")
  (:PATH "src/engine/recovery.lisp" :GIT-BLOB
   "487b11c554db8c7ba7a5138844ce097eade5a870")
  (:PATH "src/engine/startup.lisp" :GIT-BLOB
   "1e2c4cf2c3bad15b79359fc386d286bd0a57c6b1")
  (:PATH "src/engine/types.lisp" :GIT-BLOB
   "e0c273d00bb5a01e0a9b83758841ce15659f1cdc")
  (:PATH "src/engine/write.lisp" :GIT-BLOB
   "ebac3a004829725887d5bedfdadc2a47079b7d55")
  (:PATH "src/epochs/core.lisp" :GIT-BLOB
   "9388a84a1beb35cfa2bf016471389c881ad38628")
  (:PATH "src/epochs/package.lisp" :GIT-BLOB
   "43bc1aefdeec0e19e729160b3aa085091634a11a")
  (:PATH "src/epochs/read.lisp" :GIT-BLOB
   "a3dfde4a4780554b88e6e037ab4f70731f9c884a")
  (:PATH "src/epochs/reclaim.lisp" :GIT-BLOB
   "57235763cf556ecd7633a0052f265ce3eb2b0462")
  (:PATH "src/epochs/retire.lisp" :GIT-BLOB
   "f0f1cd22e87892119a4b7768b4efe5e519925dff")
  (:PATH "src/epochs/types.lisp" :GIT-BLOB
   "909dfdbc901c4cbdeae5b47faf52480350372524")
  (:PATH "src/execution/handoff.lisp" :GIT-BLOB
   "34c8add62a6df92446be5234ef013893ebcf6879")
  (:PATH "src/execution/package.lisp" :GIT-BLOB
   "dcdf82cb17b20f6d4e96cc94d3f1522520c3a236")
  (:PATH "src/execution/queue.lisp" :GIT-BLOB
   "bb4d4d6f222aa360ec64ef2f45ee6ba0524dd2f0")
  (:PATH "src/execution/ready-recycle.lisp" :GIT-BLOB
   "58981c7e41ce2694dbfcaed99010a3a53e3c1dea")
  (:PATH "src/execution/ready-types.lisp" :GIT-BLOB
   "5b3c26f78d5c4aa53ca200abdd3e0f753f926b54")
  (:PATH "src/execution/ready.lisp" :GIT-BLOB
   "4119f86231b7d8698fc3558868ff8a5bcbdf3090")
  (:PATH "src/execution/worker-boundary.lisp" :GIT-BLOB
   "720f16e96203f00e308727b430b66b28689dc7bb")
  (:PATH "src/execution/worker-claim.lisp" :GIT-BLOB
   "4f34d18152d77fbf63bf708ebd0aabac178c3ac1")
  (:PATH "src/execution/worker-run.lisp" :GIT-BLOB
   "65a3f3c9e84c83b900c1dd8c9cc2fc21cec36c52")
  (:PATH "src/execution/worker-types.lisp" :GIT-BLOB
   "6d36e1f64d79f24c95209fd70551953e40c62335")
  (:PATH "src/execution/writer.lisp" :GIT-BLOB
   "8e5102497f628796fa8faffa2085a165496af230")
  (:PATH "src/foundation/batch.lisp" :GIT-BLOB
   "2cbd40c539b13dd80070eedf4af82bd1b26f4b28")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "2d514f6fe2e81eecb29fa53de611fa5e28696904")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "edbe5eaa88c50dc13af8e367b73f7f41fd7bd724")
  (:PATH "src/foundation/crc32c.lisp" :GIT-BLOB
   "f9c691d28620427099d1d89a89a1ff5d04cbe257")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "bca6808e75e144ac7e9643df07a1cc6df4f70ed3")
  (:PATH "src/foundation/record.lisp" :GIT-BLOB
   "09185339cab38ab937045b40c52bb1b9092ffb8e")
  (:PATH "src/fulltext-admission/build.lisp" :GIT-BLOB
   "8f2a8791a460f18b0b58c63e07c68226a87bd7be")
  (:PATH "src/fulltext-admission/copy.lisp" :GIT-BLOB
   "da2646ac18d08ce8e417ceaf5474ff4524059fb8")
  (:PATH "src/fulltext-admission/guards.lisp" :GIT-BLOB
   "0b556567ee88c344338404b0939b9ea58ae138bc")
  (:PATH "src/fulltext-admission/lifecycle.lisp" :GIT-BLOB
   "ffdc731b70980208e48e73413ae519e2b4cbdc47")
  (:PATH "src/fulltext-admission/package.lisp" :GIT-BLOB
   "74d06aa6d0d0b263b806f678b23cec40b5db3ef1")
  (:PATH "src/fulltext-admission/preflight.lisp" :GIT-BLOB
   "936cb9ec5d1658f7fe0d8934ff71c032baf469c5")
  (:PATH "src/fulltext-admission/query.lisp" :GIT-BLOB
   "a036e8ce6a8e5295c702e1caa575d42031aec5a9")
  (:PATH "src/fulltext-admission/reserve.lisp" :GIT-BLOB
   "131235c639c7ada51e75fd27ecd3595c5f833182")
  (:PATH "src/fulltext-admission/row-update.lisp" :GIT-BLOB
   "76ec001de033582b7845b665932f53a40d5965a5")
  (:PATH "src/fulltext-admission/rows.lisp" :GIT-BLOB
   "881e0e840fdbabcde946ddc7699ce650bbee3367")
  (:PATH "src/fulltext-admission/types.lisp" :GIT-BLOB
   "115b521e699044b1ebcdb389c38d1f06f718662e")
  (:PATH "src/fulltext-put/append.lisp" :GIT-BLOB
   "bc3f40b0faec4ff058daaaca20e75758a0581470")
  (:PATH "src/fulltext-put/binding.lisp" :GIT-BLOB
   "6144cc61c3ec83f1187dbc5ac249303015f0d0d0")
  (:PATH "src/fulltext-put/build.lisp" :GIT-BLOB
   "f66206063b3d9ae191e1f4854e8efa1da58f150c")
  (:PATH "src/fulltext-put/package.lisp" :GIT-BLOB
   "0ffd3fb459d14ef6da0ab6789930b8ee54b78fe5")
  (:PATH "src/fulltext-put/physical-header.lisp" :GIT-BLOB
   "47120e3399f0d05559f3eb4748768254f1a4eacf")
  (:PATH "src/fulltext-put/physical.lisp" :GIT-BLOB
   "ff4aab62df19debe4f14f892bfb52a3cb1a6f31c")
  (:PATH "src/fulltext-put/prepare.lisp" :GIT-BLOB
   "9c50b6745ef3b2eef9a718fcbf3f611b362e6ba6")
  (:PATH "src/fulltext-put/reserve.lisp" :GIT-BLOB
   "a002173ae2a1d17a1ec90b3b9531c353654f7f57")
  (:PATH "src/fulltext-put/row-reference.lisp" :GIT-BLOB
   "865d9bb30ca6da556223917bffec68e9090a8eca")
  (:PATH "src/fulltext-put/start.lisp" :GIT-BLOB
   "8d936fffbb2193af1cc8bac9ab64bec36294fd52")
  (:PATH "src/fulltext-put/types.lisp" :GIT-BLOB
   "a92b2fc7a3068a0b7205b0407aafc65348d573d3")
  (:PATH "src/fulltext/analysis-emit.lisp" :GIT-BLOB
   "ede43f9e120f37fc2ed4970bd1b0623b07ae2333")
  (:PATH "src/fulltext/analysis-nfc.lisp" :GIT-BLOB
   "580f823c9e33a75e1233ef61eaaaf15b0060137c")
  (:PATH "src/fulltext/analysis-package.lisp" :GIT-BLOB
   "5729cfba660c391cf9dee6fc3d5e6ccbddcd2552")
  (:PATH "src/fulltext/analysis-properties.lisp" :GIT-BLOB
   "f0879979dc318cefa5f8a870a2b8dc4132094f3a")
  (:PATH "src/fulltext/analysis-space.lisp" :GIT-BLOB
   "0f295b4eca162d908746ad5d7f7238480325b00c")
  (:PATH "src/fulltext/analysis-word-context.lisp" :GIT-BLOB
   "e4660d31ae0d6d47adf4e1c9b003c86180275b5d")
  (:PATH "src/fulltext/analysis-word-rules.lisp" :GIT-BLOB
   "227219f9faa098057970f25ea441f1e448ca85c4")
  (:PATH "src/fulltext/analysis.lisp" :GIT-BLOB
   "26ca9e242db4516fbf83ce56464cc7c76e460b07")
  (:PATH "src/fulltext/codec-input.lisp" :GIT-BLOB
   "ec3d8865324e21198ad1ef238907eb22706922a7")
  (:PATH "src/fulltext/codec-package.lisp" :GIT-BLOB
   "3c00fe5b42beae166bad39cb9314dc83c687858f")
  (:PATH "src/fulltext/codec-plan.lisp" :GIT-BLOB
   "60f9c3ca01fb0b29bf992c255bd4e40ce8ad44c4")
  (:PATH "src/fulltext/codec-query.lisp" :GIT-BLOB
   "2e77838f54f12cf998341f494a92127770f05e7f")
  (:PATH "src/fulltext/codec-read-base.lisp" :GIT-BLOB
   "c6fe327a9a49cef8a126350fc45d4ae6260d1afc")
  (:PATH "src/fulltext/codec-read-dict.lisp" :GIT-BLOB
   "70bd43d2e1e50625ad47df827f5615734d15ae61")
  (:PATH "src/fulltext/codec-read-lengths.lisp" :GIT-BLOB
   "a3549d187caf9b6a86ef4126197ab68eb7a177de")
  (:PATH "src/fulltext/codec-read-postings.lisp" :GIT-BLOB
   "79e34c0e71d2e1f2d2b78a7c61c4d85811c9aa8d")
  (:PATH "src/fulltext/codec-read-term.lisp" :GIT-BLOB
   "15178d8d735daff2b162030e815b5e3da6a37cae")
  (:PATH "src/fulltext/codec-run.lisp" :GIT-BLOB
   "73022c24cfe46dfaa93e185153296f1da7adc58a")
  (:PATH "src/fulltext/codec-space.lisp" :GIT-BLOB
   "fcad6ec5ee926a710794e01ee652b8cf7befcebc")
  (:PATH "src/fulltext/codec-view.lisp" :GIT-BLOB
   "b986c8a9eafb72344f640ba5de52bd32643be341")
  (:PATH "src/fulltext/codec-write-entries.lisp" :GIT-BLOB
   "567a7ca7a7ac23f6a5240bdd54b08ed138a56301")
  (:PATH "src/fulltext/codec-write.lisp" :GIT-BLOB
   "2c9fd28d25a840a5e695e92f839f60898122db6a")
  (:PATH "src/fulltext/descriptor.lisp" :GIT-BLOB
   "eef3aa97b7a43a5a0bd6575e6cab2a3f9e54f985")
  (:PATH "src/fulltext/document-analysis.lisp" :GIT-BLOB
   "a7c79f8e9fb4a47e5718db454be405d47e689831")
  (:PATH "src/fulltext/document-bound.lisp" :GIT-BLOB
   "8f3783161f38d67900c0115429255281822ab2cc")
  (:PATH "src/fulltext/document-config-input.lisp" :GIT-BLOB
   "3dc4712c1c1bfe56b97e851baeb7a2b2c8d3afe0")
  (:PATH "src/fulltext/document-config.lisp" :GIT-BLOB
   "c27b728d847fa0e1a0b42c19e04f4f8568379717")
  (:PATH "src/fulltext/document-package.lisp" :GIT-BLOB
   "c95277890c41d43af04cd3db67dedf204c398bc7")
  (:PATH "src/fulltext/document-paths.lisp" :GIT-BLOB
   "d5bb755161e099835faed15bd1ca486a50febd16")
  (:PATH "src/fulltext/document-scan.lisp" :GIT-BLOB
   "7556be1b270ce4e2c63fba26f50c68548d4b72d1")
  (:PATH "src/fulltext/document-space.lisp" :GIT-BLOB
   "b556bbf3f7efe6458883a8146f814b5c02a32fb7")
  (:PATH "src/fulltext/document-start.lisp" :GIT-BLOB
   "876c3d986b427a5664413b940779f37b92e5c099")
  (:PATH "src/fulltext/document.lisp" :GIT-BLOB
   "8e1f972c5b0eaeb3e340b915108af5b49b734208")
  (:PATH "src/fulltext/format-constants.lisp" :GIT-BLOB
   "68c8831f87e45614e05d783e82a3ad0a2585325d")
  (:PATH "src/fulltext/format-input.lisp" :GIT-BLOB
   "92a17dc2bcdfd837d50b969a0f0156ae7709d50a")
  (:PATH "src/fulltext/format-package.lisp" :GIT-BLOB
   "1f72e2d40467a20422c5bfaa2564bb5b84fedf29")
  (:PATH "src/fulltext/format-read.lisp" :GIT-BLOB
   "0eafbb6b7f6644fccb198135fccf1ac9b101e1f2")
  (:PATH "src/fulltext/format-write.lisp" :GIT-BLOB
   "d87702218efa8b4e5992c3ede59674743fa53d3f")
  (:PATH "src/fulltext/index-build.lisp" :GIT-BLOB
   "026cd085b27531258e0828a3da34cd834b866875")
  (:PATH "src/fulltext/index-lookup.lisp" :GIT-BLOB
   "f3125aa4f88279fb0f21431a369e7479c642ea71")
  (:PATH "src/fulltext/index-package.lisp" :GIT-BLOB
   "711bbbc0c7491d10b6c0e411c38099add1230a7b")
  (:PATH "src/fulltext/index-sort.lisp" :GIT-BLOB
   "53447fbf8db853d6b5299875af52f764deded5f7")
  (:PATH "src/fulltext/index-step.lisp" :GIT-BLOB
   "8bbd1228e7ee78435a718ad71c37a4f8095302ff")
  (:PATH "src/fulltext/meta-fields.lisp" :GIT-BLOB
   "0aad5b5452a86ca0f333fed0648e91a264596ecc")
  (:PATH "src/fulltext/meta-read.lisp" :GIT-BLOB
   "b51cb3e7a022d5e95f7aad3ee8c9baacb5ebbce8")
  (:PATH "src/fulltext/unicode-tables.lisp" :GIT-BLOB
   "4b8f977f590d09fd4a2386ef14642b182170cd2c")
  (:PATH "src/get-directory/build.lisp" :GIT-BLOB
   "f1a1a37ccd59a81e7ff91fcb36009d5953d7edd5")
  (:PATH "src/get-directory/package.lisp" :GIT-BLOB
   "8dcddeb0536c1104af92c722ffbfab2059601c74")
  (:PATH "src/get-directory/read.lisp" :GIT-BLOB
   "1d93461227b222a8effc53ec9344c5dab0b531fe")
  (:PATH "src/get-directory/sources-read.lisp" :GIT-BLOB
   "ca171a29008377ec491dce07afd6cf24f12cd8fe")
  (:PATH "src/get-directory/sources-types.lisp" :GIT-BLOB
   "29abe8ab7a3756eb33365ec8c8ffacdc2a7a0564")
  (:PATH "src/get-directory/types.lisp" :GIT-BLOB
   "ec99839d234468298b553e331873a320c8ece53f")
  (:PATH "src/get-resolver/active-build.lisp" :GIT-BLOB
   "d135084116b62ed3b55f81ee5798618919f76ead")
  (:PATH "src/get-resolver/active-directory.lisp" :GIT-BLOB
   "70341c7c32b364603d38bdc42e8b3af1cc631773")
  (:PATH "src/get-resolver/active-init.lisp" :GIT-BLOB
   "b0586a8815a9ad72c1a897ac16d14a3f1ed530ca")
  (:PATH "src/get-resolver/active-preflight.lisp" :GIT-BLOB
   "bd75d3a4b7483900689417ae3eb2dd65e76c8468")
  (:PATH "src/get-resolver/active-read.lisp" :GIT-BLOB
   "0a93acd78d9b8b341011531e23e5663ae1df4f72")
  (:PATH "src/get-resolver/active-scan.lisp" :GIT-BLOB
   "5ae454c03e8a9b9196653c8b28df0727e480d142")
  (:PATH "src/get-resolver/active-types.lisp" :GIT-BLOB
   "590b969dd48f4a789e15d692addb92cd7970bebf")
  (:PATH "src/get-resolver/build.lisp" :GIT-BLOB
   "956b6c7145a25dc64a7247f2e14321876ac08f15")
  (:PATH "src/get-resolver/package.lisp" :GIT-BLOB
   "33d7b898b5f5a7b20c8112484191c14df44b770e")
  (:PATH "src/get-resolver/read.lisp" :GIT-BLOB
   "1177496e5baca7f7c698156e196c60fe1fe2566a")
  (:PATH "src/get-resolver/rows.lisp" :GIT-BLOB
   "e1bf83fbcc737b55eaa71bd6b41a912a901178ce")
  (:PATH "src/get-resolver/scan.lisp" :GIT-BLOB
   "6f54751adb255f49582ff1da62f951965c3860a1")
  (:PATH "src/get-resolver/sort.lisp" :GIT-BLOB
   "9cbbdb6200af813bc9595d0ef964628a9ba0368f")
  (:PATH "src/get-resolver/types.lisp" :GIT-BLOB
   "53438f156d3e1e15f3732ec840223231b308a7a5")
  (:PATH "src/get/build.lisp" :GIT-BLOB
   "cb426426eac6e923224bc57c1dd602405f4bc040")
  (:PATH "src/get/lifecycle.lisp" :GIT-BLOB
   "23f16c3039b71be0bd46d6bf92f05791e444683e")
  (:PATH "src/get/lookup.lisp" :GIT-BLOB
   "5a105a141b43f5585f8e79c2965d59e96cd35ac6")
  (:PATH "src/get/package.lisp" :GIT-BLOB
   "a22de99a63db56417822bb5e66f82e5c89d73bc2")
  (:PATH "src/get/segment.lisp" :GIT-BLOB
   "cf168c44bfe5aedd2e34180ce4f766a6a89500a7")
  (:PATH "src/get/target.lisp" :GIT-BLOB
   "c9b8488d0a1aa7643a6ab1570765ec870aa7c9e4")
  (:PATH "src/get/types.lisp" :GIT-BLOB
   "032ad088b19ec3498a7c80a5e4b96d7777257dad")
  (:PATH "src/hash/arithmetic.lisp" :GIT-BLOB
   "0d8e799b889df829aeb46054ef100377845dd0e0")
  (:PATH "src/hash/blocks.lisp" :GIT-BLOB
   "f115b63c6089960e9857469475f821f3035a5ef2")
  (:PATH "src/hash/hash64.lisp" :GIT-BLOB
   "6d43b042d7d9018f8aa48e88fc58c24b5a089cdf")
  (:PATH "src/hash/package.lisp" :GIT-BLOB
   "0c73ce15b8de3f9173a99f7216ead4e79d04d535")
  (:PATH "src/index/core.lisp" :GIT-BLOB
   "a83ee5a2d8903538f8ba977ef0f5ddbe3a357d6b")
  (:PATH "src/index/hash-digests.lisp" :GIT-BLOB
   "6d05b467aee412f447308eb697daa7f4f5ec6f0d")
  (:PATH "src/index/hash-seed.lisp" :GIT-BLOB
   "5627b4179b115c008379aa3e60a4724e63f9657b")
  (:PATH "src/index/mode-package.lisp" :GIT-BLOB
   "53da3230da115c0d702cc762d3f2ab69e6af253e")
  (:PATH "src/index/mode-policy.lisp" :GIT-BLOB
   "1ebf5692ffba278f0ad0b1bb619859c19d1a37a0")
  (:PATH "src/index/mode-types.lisp" :GIT-BLOB
   "fd6f579fbe760f9f16990994a251947e6da0de89")
  (:PATH "src/index/package.lisp" :GIT-BLOB
   "02d4fd9bf5f1701eefd5e6997b89c1d98a8cef5c")
  (:PATH "src/index/page-body.lisp" :GIT-BLOB
   "c843c54ed389aa921be1043c0ea1b738fd87c26d")
  (:PATH "src/index/page-bucket.lisp" :GIT-BLOB
   "f7a7caa4b3f5099609b274ef065bfc5a84fc5990")
  (:PATH "src/index/page-constants.lisp" :GIT-BLOB
   "50ff778e1f79420d870fdf2112d4c33916771b78")
  (:PATH "src/index/page-package.lisp" :GIT-BLOB
   "e598400a135eb4d45ae233f2a19cb671dda461b4")
  (:PATH "src/index/page-read.lisp" :GIT-BLOB
   "c0eb550031292123eec2968759545784c6e3736c")
  (:PATH "src/index/page-types.lisp" :GIT-BLOB
   "b660297ee9db3d8e91d201021b1d619a46cb3b12")
  (:PATH "src/index/page-validation.lisp" :GIT-BLOB
   "01709aa30036f646e9f3e76c926e74cc42e8fed9")
  (:PATH "src/index/page-write.lisp" :GIT-BLOB
   "005bac26cb67d13f05e631ac59c33d3e556e83d8")
  (:PATH "src/index/primary-arena.lisp" :GIT-BLOB
   "20de8a35a4deaa830348a6db5b5bb033a82c81d2")
  (:PATH "src/index/primary-build.lisp" :GIT-BLOB
   "aa80e1b0b6af77379cfe2f2bd12c0b17e5c6851b")
  (:PATH "src/index/primary-core.lisp" :GIT-BLOB
   "20d4b57b2a7c4b9f11205e753b92301f74f56cfc")
  (:PATH "src/index/primary-directory.lisp" :GIT-BLOB
   "1d7969c842b1f9a4cd0b9eba2ea3496cf914a2c4")
  (:PATH "src/index/primary-package.lisp" :GIT-BLOB
   "099d59bb9acc155380a3baaa3a10816e0902d8ca")
  (:PATH "src/index/primary-probe.lisp" :GIT-BLOB
   "f36b55b9e2d9002ed2ce203a0289c92984c89ac9")
  (:PATH "src/index/primary-read.lisp" :GIT-BLOB
   "b5b8243bc40b44af8c34ba76a5ab732675690af5")
  (:PATH "src/index/primary-relocate.lisp" :GIT-BLOB
   "2282593c0a431f3f73fb47cdfc7a8e530e704ce7")
  (:PATH "src/index/primary-restore.lisp" :GIT-BLOB
   "013c30abc9499729f83ce97230b2a4162ea2263e")
  (:PATH "src/index/primary-types.lisp" :GIT-BLOB
   "b8009b8313054c9abebb70de8f8223fb1df708f3")
  (:PATH "src/index/primary-write.lisp" :GIT-BLOB
   "e4107ea817314364a1ffc38f3e8940c46d7dee8a")
  (:PATH "src/index/read.lisp" :GIT-BLOB
   "abfdeb5397f8be1d390cbdf47f4f02cd2f36bf91")
  (:PATH "src/index/rebuild-budget.lisp" :GIT-BLOB
   "77df997ef72008e7758899a348ae07695bce0b38")
  (:PATH "src/index/rebuild-copy.lisp" :GIT-BLOB
   "8555e14347d05182c99b756a312207019e2f904f")
  (:PATH "src/index/rebuild-scan.lisp" :GIT-BLOB
   "79d794b102c3ebf50679426e7cebbf49f02683ce")
  (:PATH "src/index/rebuild.lisp" :GIT-BLOB
   "321ae3d1fdcda8e34efbdaac4b10dfc08fe9d9a5")
  (:PATH "src/index/relocate.lisp" :GIT-BLOB
   "012c8cff2c265aa7f0daa909a9a0dd01adf7ca3b")
  (:PATH "src/index/types.lisp" :GIT-BLOB
   "3c7cd919b94dd9458422143c18075dd7498fda1f")
  (:PATH "src/index/validation.lisp" :GIT-BLOB
   "a8088783354d2e4e5048d6ac7a3bee7afff92719")
  (:PATH "src/index/write.lisp" :GIT-BLOB
   "80156ca526a341c845fc43fc9963097f8669e65a")
  (:PATH "src/io/create-relative.lisp" :GIT-BLOB
   "4efe755dfbce6df892c864b26e7a2b77f7b6bed3")
  (:PATH "src/io/directory-lock.lisp" :GIT-BLOB
   "d6863617dae77f7f9f098c9c88b6fe0dff1ce584")
  (:PATH "src/io/directory.lisp" :GIT-BLOB
   "2a9b0a14c2b84db07d65374be0cdd5bd71d51768")
  (:PATH "src/io/flush.lisp" :GIT-BLOB
   "99fb51535f9bfbbaf8a2d7831dbd14b5f727b9d6")
  (:PATH "src/io/identity-types.lisp" :GIT-BLOB
   "9c94bab051b318a872d78efa45ba3358bf74f8b6")
  (:PATH "src/io/identity.lisp" :GIT-BLOB
   "326635b36bfa8f47778e7ff6cd1c72354352b5d5")
  (:PATH "src/io/lifecycle.lisp" :GIT-BLOB
   "77e43979548e6343066036c363a3aa2208ac1e10")
  (:PATH "src/io/namespace.lisp" :GIT-BLOB
   "a0625806a917c72ffc5d3a620b23e401c7893e79")
  (:PATH "src/io/native-create-relative.lisp" :GIT-BLOB
   "85c0d583b527933b62208c660788aa5a3bfc8e60")
  (:PATH "src/io/native-directory.lisp" :GIT-BLOB
   "a126ce400de0a058e80b3178198f4af36c96cc90")
  (:PATH "src/io/native-namespace.lisp" :GIT-BLOB
   "72282e6cb1a9702359f7da9758304a5258c83f87")
  (:PATH "src/io/native-open-relative.lisp" :GIT-BLOB
   "3cd9fed0cf0ad49b9bcbcd1cd9457581db6a31b0")
  (:PATH "src/io/native-publish.lisp" :GIT-BLOB
   "ed27c0e81cceb54a1ed25b23518c38253bbe2e91")
  (:PATH "src/io/native.lisp" :GIT-BLOB
   "18b23eba1b6cabfacf4d2c423714408f0b592bd4")
  (:PATH "src/io/open-relative.lisp" :GIT-BLOB
   "aa64c30d62836c92eeb4d9ea2867b44b5fcbe04c")
  (:PATH "src/io/package.lisp" :GIT-BLOB
   "96e470718e84ec7b39f434c3c9b39fdf62b6e736")
  (:PATH "src/io/publish.lisp" :GIT-BLOB
   "eea3d4f347188d6c3db634daed523c6a4ef65cf2")
  (:PATH "src/io/rename.lisp" :GIT-BLOB
   "d39dcf6f17ec5e610190a94e0be165eadce42565")
  (:PATH "src/io/stabilize-preflight.lisp" :GIT-BLOB
   "3fb0be570d263bad2b16718c2808e020614872bd")
  (:PATH "src/io/stabilize.lisp" :GIT-BLOB
   "6f3347177a66162f496767e918d1d697a79debbe")
  (:PATH "src/io/transfer.lisp" :GIT-BLOB
   "5b24bd30aeb12b71b7b1a6a5aa537887a847bf10")
  (:PATH "src/io/types.lisp" :GIT-BLOB
   "38562f77af35124ec7a6390ec409864c8f8cd517")
  (:PATH "src/local/cli.lisp" :GIT-BLOB
   "f1dcd8ffa23398d6a0b4101c4e7cb2c88cc1771d")
  (:PATH "src/local/client.lisp" :GIT-BLOB
   "30a86bf2fdf3d7c1cf835870747e170789e79da8")
  (:PATH "src/local/dispatch.lisp" :GIT-BLOB
   "54bc52d78a5048524aad0fd0ab2029c467346419")
  (:PATH "src/local/native.lisp" :GIT-BLOB
   "e3a3de96e3a99275cecdae650da57a8b77765729")
  (:PATH "src/local/package.lisp" :GIT-BLOB
   "74489fef066b33ac706cb0dd8c757d440e0bfebf")
  (:PATH "src/local/server.lisp" :GIT-BLOB
   "8754ca4dd75d34edba06bdb32f2e14d0c106ddb0")
  (:PATH "src/local/state.lisp" :GIT-BLOB
   "dab6d6bc70c3faa523e5e43d0a0a20c9bdcd4606")
  (:PATH "src/local/wire.lisp" :GIT-BLOB
   "f64a7121a0d1105446eddf67750cb10bdff48244")
  (:PATH "src/mvcc/package.lisp" :GIT-BLOB
   "d45fbf57051e43d0d998f3de9b4177665d24c9d9")
  (:PATH "src/mvcc/snapshots-core.lisp" :GIT-BLOB
   "01875b76743c514ef07346a32587f4dc5c34d2f8")
  (:PATH "src/mvcc/snapshots-csn.lisp" :GIT-BLOB
   "48372f6f09a54cfcee793ac03ec321fca6ad18f5")
  (:PATH "src/mvcc/snapshots-lifecycle.lisp" :GIT-BLOB
   "25d93efc7c604042d09dc84e31baf1f4e2c4c45e")
  (:PATH "src/mvcc/snapshots-read.lisp" :GIT-BLOB
   "09d73425a6e571c8fac6669b14b98e3ceeb7c96b")
  (:PATH "src/mvcc/snapshots-register.lisp" :GIT-BLOB
   "c9cadaabf755add3671cd1cc0408c3ff216df2a5")
  (:PATH "src/mvcc/snapshots-types.lisp" :GIT-BLOB
   "bf80277418243422144cf6ee71eef83d7eff6da5")
  (:PATH "src/mvcc/types.lisp" :GIT-BLOB
   "4cf0edbc70bc9e02ff3b0442cbce4ca44630d3e6")
  (:PATH "src/package.lisp" :GIT-BLOB
   "3d0181717e3f334580bab9a6a507e2dfe57261ff")
  (:PATH "src/read/core.lisp" :GIT-BLOB
   "132e44c138e209d3f8840b098cca0424853d09c3")
  (:PATH "src/read/package.lisp" :GIT-BLOB
   "dd00cd8e7dc8340e2006cfe03b0bf141968223fd")
  (:PATH "src/read/task.lisp" :GIT-BLOB
   "b3601060197a27c6e8a2aaee22b5576c6b0c6e5a")
  (:PATH "src/read/types.lisp" :GIT-BLOB
   "b30795fb7efad5f5313198d345ffabb43249e3fa")
  (:PATH "src/recovery-active/build.lisp" :GIT-BLOB
   "41f1eef0201a63afaf65b74cd54d899f44399153")
  (:PATH "src/recovery-active/closure.lisp" :GIT-BLOB
   "8d2f81d87c79c32f98060e73a84fc4cfdb671970")
  (:PATH "src/recovery-active/csn.lisp" :GIT-BLOB
   "e2cac366c83ae79062f97f74275fe399049c215e")
  (:PATH "src/recovery-active/frames.lisp" :GIT-BLOB
   "157221a830991415d120e19b033f73b2c6c2d946")
  (:PATH "src/recovery-active/package.lisp" :GIT-BLOB
   "474cd54f2a31f4ded95fd723b4170bee8addece4")
  (:PATH "src/recovery-active/publication.lisp" :GIT-BLOB
   "2a8500476de79bd62e395566a7471d0ca050556f")
  (:PATH "src/recovery-active/query.lisp" :GIT-BLOB
   "3e3bb0d5a126adf584ad4c4c77fd1b965c301e70")
  (:PATH "src/recovery-active/read.lisp" :GIT-BLOB
   "909abac62163856136bdfdc1ad30c3da90f884d5")
  (:PATH "src/recovery-active/resolve.lisp" :GIT-BLOB
   "d74f2261aa5ed16cbccb8201707f8f484380a18e")
  (:PATH "src/recovery-active/types.lisp" :GIT-BLOB
   "5d0d4f0219087001fd1df97339a530e64c39476f")
  (:PATH "src/recovery-archive-csn/build.lisp" :GIT-BLOB
   "125980e85ace529df3b36ea9fc83fc2ac7b236fa")
  (:PATH "src/recovery-archive-csn/package.lisp" :GIT-BLOB
   "bacf4fc95e38a8d0416110c6b87b506d561a7e59")
  (:PATH "src/recovery-archive-csn/preflight.lisp" :GIT-BLOB
   "cdc70f16eb9e736ea33d6f794910b9f97afad6df")
  (:PATH "src/recovery-archive-csn/query.lisp" :GIT-BLOB
   "b228e158ba87f83f7591f4a192a9d6b2cbf7b882")
  (:PATH "src/recovery-archive-csn/series.lisp" :GIT-BLOB
   "e6149b810be34b6da2b619c8f62cf02640c0060b")
  (:PATH "src/recovery-archive-csn/types.lisp" :GIT-BLOB
   "895ad3ef063684b8b5cced19cdeddb0e43afc149")
  (:PATH "src/recovery-archive/active.lisp" :GIT-BLOB
   "b61b332de594d6c74d6ed5fd5869face459ac34e")
  (:PATH "src/recovery-archive/build.lisp" :GIT-BLOB
   "454d4cad54c4db3e237d11a6de6304c86fd4e478")
  (:PATH "src/recovery-archive/package.lisp" :GIT-BLOB
   "82c707853b1a5b2b6d657e120c7e0ecb82404134")
  (:PATH "src/recovery-archive/query.lisp" :GIT-BLOB
   "eef7686bdd6ecbc03e3b9e86b73d29ae663742f6")
  (:PATH "src/recovery-archive/read.lisp" :GIT-BLOB
   "b46823a3fdc2d16e19c0c5702759bb198805eae2")
  (:PATH "src/recovery-archive/types.lisp" :GIT-BLOB
   "9aa3830c38b4b55a9b0475f6f3a6515508d7689a")
  (:PATH "src/recovery-bootstrap/build.lisp" :GIT-BLOB
   "ea0d29d1d565f96e1b0cdaa15037f2ae53811aa1")
  (:PATH "src/recovery-bootstrap/package.lisp" :GIT-BLOB
   "29ce39efa53a72cd766810b81a08c9a2f86afc91")
  (:PATH "src/recovery-bootstrap/preflight.lisp" :GIT-BLOB
   "d7dea209c7d520b53f9655d256521bfe07d841d1")
  (:PATH "src/recovery-bootstrap/shape.lisp" :GIT-BLOB
   "a4fdfa2fc1fa8cbdea6dbbb8a28986440e6ef12c")
  (:PATH "src/recovery-bootstrap/stabilize-preflight.lisp" :GIT-BLOB
   "02053562995a46474f515127f616aa38cddf0dd6")
  (:PATH "src/recovery-bootstrap/stabilize-shape.lisp" :GIT-BLOB
   "d845e84ae551c3fef323b923cf7bdabd31ed8ec5")
  (:PATH "src/recovery-bootstrap/stabilize.lisp" :GIT-BLOB
   "8f977e58ef42b424c8710bdde2217b49d5f10ea5")
  (:PATH "src/recovery-checkpoint/build.lisp" :GIT-BLOB
   "585f09fe65c662b3023e563fddbcf4205dffa513")
  (:PATH "src/recovery-checkpoint/order.lisp" :GIT-BLOB
   "318d549b7c52da1e09c2bfb923f2041ffaef020c")
  (:PATH "src/recovery-checkpoint/package.lisp" :GIT-BLOB
   "7b191ecff3dbac6b5f690ad221c68b4762a9f0aa")
  (:PATH "src/recovery-checkpoint/preflight.lisp" :GIT-BLOB
   "2cde31db83995a20c7ec586b5c0e5f131fd7596e")
  (:PATH "src/recovery-checkpoint/sections.lisp" :GIT-BLOB
   "468baa20f0a1059593391018227206228126f0f8")
  (:PATH "src/recovery-closed/build.lisp" :GIT-BLOB
   "7cb2f70d6520df859600eba89a7330a5ce9b3484")
  (:PATH "src/recovery-closed/csn-serie.lisp" :GIT-BLOB
   "1c83dc034e7291254348ce361056afc2896e196e")
  (:PATH "src/recovery-closed/csn.lisp" :GIT-BLOB
   "20a710ad5bdcaa8fde8f1527812ca0881448cf99")
  (:PATH "src/recovery-closed/package.lisp" :GIT-BLOB
   "49ac245e2430e719b1d417b91b0ffcd53555e47d")
  (:PATH "src/recovery-closed/publication.lisp" :GIT-BLOB
   "31152707be3e4d12a6dadf63c8773c3c7c3fe343")
  (:PATH "src/recovery-closed/read.lisp" :GIT-BLOB
   "0947da79acc2bfd8eea7c4e0158913cd03291a1b")
  (:PATH "src/recovery-closed/resolve.lisp" :GIT-BLOB
   "e84f68c5dcb94240966607b2135e9e6f3c8f2711")
  (:PATH "src/recovery-closed/types.lisp" :GIT-BLOB
   "e32d665f9ce6bfba9d3c0ab6c8a8b4f980b4e10e")
  (:PATH "src/recovery-closed/verify.lisp" :GIT-BLOB
   "e7895a628234195e41b5d9f53b2d163bb5f9d199")
  (:PATH "src/recovery-replay/package.lisp" :GIT-BLOB
   "8639d959e29e9f36270a94831eace49f6535a863")
  (:PATH "src/recovery-replay/read.lisp" :GIT-BLOB
   "9b8978d3b16e6dc5f3f045e9bb880a5e6d6de890")
  (:PATH "src/recovery-replay/resolve.lisp" :GIT-BLOB
   "b9cadc7c5b1f6dd6ef04117eb0cde754d11840f1")
  (:PATH "src/recovery-replay/visit.lisp" :GIT-BLOB
   "e42fdbeeeeea7350223f7e44f9872c167e26bdb2")
  (:PATH "src/recovery-selection/frame.lisp" :GIT-BLOB
   "ee9cf191a397f440789d4c81966a39f9541f577e")
  (:PATH "src/recovery-selection/index-preflight.lisp" :GIT-BLOB
   "5bd4143553a64ccad0795f19dc261c8d048150e2")
  (:PATH "src/recovery-selection/index.lisp" :GIT-BLOB
   "a868f4db92eb4b4f9e215c15979e717ee2e6246b")
  (:PATH "src/recovery-selection/key.lisp" :GIT-BLOB
   "481d2100b79d3106601a376c2530d678f31291d8")
  (:PATH "src/recovery-selection/package.lisp" :GIT-BLOB
   "9dd583b4bf868183f7555b1e4f7c29f2a13c244c")
  (:PATH "src/recovery-selection/read.lisp" :GIT-BLOB
   "38d61833af134afa51cec8291ed40666489b4474")
  (:PATH "src/recovery-selection/select.lisp" :GIT-BLOB
   "a048108db401e84267206a89d94e883855d37dd3")
  (:PATH "src/recovery-selection/types.lisp" :GIT-BLOB
   "8dad9f8de00595acb85aa43d6a1830306ead8bc3")
  (:PATH "src/recovery-series/build.lisp" :GIT-BLOB
   "803441bb2f9606a1b210e2948100b6d42fb7fd66")
  (:PATH "src/recovery-series/entry.lisp" :GIT-BLOB
   "2be5f33722d9228b002cea4290e7b5ea5b0332ba")
  (:PATH "src/recovery-series/package.lisp" :GIT-BLOB
   "51f3d64796df1a2180cb977adb8a094e7c7fd94b")
  (:PATH "src/recovery-series/preflight.lisp" :GIT-BLOB
   "375b0b9283f38fef8311f3c7c625a7b709f4d7fb")
  (:PATH "src/recovery-series/read.lisp" :GIT-BLOB
   "52f2c0a0f28f3d1cc400c0426b9c53636940f49b")
  (:PATH "src/recovery-series/stabilize-preflight.lisp" :GIT-BLOB
   "8fa32b9ce777ccc68a115d07ac5b631cf3beb874")
  (:PATH "src/recovery-series/stabilize-set-preflight.lisp" :GIT-BLOB
   "6e85ab3bc6d9374fd12f6077d3b563b9ea9ba059")
  (:PATH "src/recovery-series/stabilize-set.lisp" :GIT-BLOB
   "7441ddf350504d1a8b4277e5ae150d83b868cc58")
  (:PATH "src/recovery-series/stabilize.lisp" :GIT-BLOB
   "48a11dae75b09f70cd7a3af129d30132f8bfe26f")
  (:PATH "src/recovery-series/types.lisp" :GIT-BLOB
   "c732f86b1cabe522e8a411c5c4e1d6e40828b6e0")
  (:PATH "src/recovery/decisions-build.lisp" :GIT-BLOB
   "87cc54024e59757c16e20f3025970b1699b11662")
  (:PATH "src/recovery/decisions-package.lisp" :GIT-BLOB
   "58a3e620a8def39d2b24cd210d9283184c247ed2")
  (:PATH "src/recovery/decisions-query.lisp" :GIT-BLOB
   "bca1698068955fb8de9959e23ee30e55ecc9c699")
  (:PATH "src/recovery/decisions-radix.lisp" :GIT-BLOB
   "e58176890a26751bf5767582b279cb667a29744e")
  (:PATH "src/recovery/decisions-sort.lisp" :GIT-BLOB
   "b133ea00a3b8063e9e934a1b41f10cad024471ae")
  (:PATH "src/recovery/decisions-types.lisp" :GIT-BLOB
   "4a16574f26c35b12db7693804b9b5c35e1b85cb7")
  (:PATH "src/recovery/inventory-build.lisp" :GIT-BLOB
   "60057f6a50c657f016bee3c21c21911b582f86fe")
  (:PATH "src/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "53565668f4d3734dbf9014f929c1c0e953ed3908")
  (:PATH "src/recovery/inventory-directory.lisp" :GIT-BLOB
   "221a2c0e19f551bcae502434e369462af92bd470")
  (:PATH "src/recovery/inventory-id.lisp" :GIT-BLOB
   "752ff8bc2b6a30cfcf2bdcfdb41ecc5d9d3215c4")
  (:PATH "src/recovery/inventory-query.lisp" :GIT-BLOB
   "47810fb2944b4b5c18d9a9c8e60dfdc1c5f19db4")
  (:PATH "src/recovery/inventory-sources-build.lisp" :GIT-BLOB
   "1c36359af628a014efe9f0b090814bc93893edde")
  (:PATH "src/recovery/inventory-sources-query.lisp" :GIT-BLOB
   "006c28cd80e002b87e435d7a5bbbeb506c9f806f")
  (:PATH "src/recovery/inventory-sources-types.lisp" :GIT-BLOB
   "c4596731d1270d3cec38e2ef5a159968efbd4050")
  (:PATH "src/recovery/inventory-sources.lisp" :GIT-BLOB
   "6538cc201d9731a596e830aebf8c9e01495246c8")
  (:PATH "src/recovery/inventory-types.lisp" :GIT-BLOB
   "68c357d2d522fcabe79284c540c2631e5fa87780")
  (:PATH "src/recovery/manifest-build.lisp" :GIT-BLOB
   "e74b806f5116db46f3a385821515c317b2dcb452")
  (:PATH "src/recovery/manifest-decode.lisp" :GIT-BLOB
   "ae5b8e4677fdd1dcee2f2a1baf293f49d9ce2972")
  (:PATH "src/recovery/manifest-fold.lisp" :GIT-BLOB
   "eaddc83c63dce2fde59227e0416917bbc766e325")
  (:PATH "src/recovery/manifest-package.lisp" :GIT-BLOB
   "9754b563a1d0fbfcda0f306e94b1b6d0257dfb0e")
  (:PATH "src/recovery/manifest-query.lisp" :GIT-BLOB
   "55e56d621129d1637eac1a787bad60dd0f0405b1")
  (:PATH "src/recovery/manifest-transition.lisp" :GIT-BLOB
   "1f92455ec8c38c780b6e6455166be5c49ef3fefa")
  (:PATH "src/recovery/manifest-types.lisp" :GIT-BLOB
   "e062c804e68a8f62eddadd5c87db0e7af392744f")
  (:PATH "src/recovery/package.lisp" :GIT-BLOB
   "b97b5c9bca6955e5dc45d9d4257089ab7132f3fb")
  (:PATH "src/recovery/scan.lisp" :GIT-BLOB
   "7ad6b7541397611f1ecbda7dffdda98c4453dbf1")
  (:PATH "src/runtime/active.lisp" :GIT-BLOB
   "6145d557b43cc2e0f8e4a75e5356c7e3b1def45e")
  (:PATH "src/runtime/build.lisp" :GIT-BLOB
   "a0c63b925024e75f3edc917af2739362966db11e")
  (:PATH "src/runtime/closed-preflight.lisp" :GIT-BLOB
   "04f7eff43b919847c4db6ff3c3022282646c2868")
  (:PATH "src/runtime/closed-transfer.lisp" :GIT-BLOB
   "50dfab595a216e2d41faa4d5154ed76915adb958")
  (:PATH "src/runtime/closed.lisp" :GIT-BLOB
   "c75cda368fca40e09d93bd4ee744592be59ec48a")
  (:PATH "src/runtime/package.lisp" :GIT-BLOB
   "5eb61dac53e09bdaf493680967ab65938b6b8f63")
  (:PATH "src/runtime/preflight.lisp" :GIT-BLOB
   "c82afb340fb354ef738866c01ad59595ada09713")
  (:PATH "src/runtime/query.lisp" :GIT-BLOB
   "10cc651efa58bcd71852f9e75b00451a6cce20a6")
  (:PATH "src/runtime/types.lisp" :GIT-BLOB
   "4eeff088a44159541019ed3cfe3048bc36762f7e")
  (:PATH "src/scheduler/build.lisp" :GIT-BLOB
   "a925a9380e48a0d0018e00eb97676679db2e8eba")
  (:PATH "src/scheduler/lifecycle-build.lisp" :GIT-BLOB
   "379a139fdf6d202937a44af3ceae4444a26ed48a")
  (:PATH "src/scheduler/lifecycle-read.lisp" :GIT-BLOB
   "261ef5a3b909b3f552df0eb57fb2124d92be502c")
  (:PATH "src/scheduler/lifecycle-types.lisp" :GIT-BLOB
   "56dc619b46eb6cb3cbe934be586a8fc13e769b34")
  (:PATH "src/scheduler/lifecycle-update.lisp" :GIT-BLOB
   "34d4685b42ec26942109309666d85093a53146fd")
  (:PATH "src/scheduler/lifecycle-worker.lisp" :GIT-BLOB
   "70224b35cb011adbc0caa7738ef61fd0f2564f09")
  (:PATH "src/scheduler/package.lisp" :GIT-BLOB
   "cadff5f2e29e7c5b625b95f9387faf29aad02178")
  (:PATH "src/scheduler/policy.lisp" :GIT-BLOB
   "b9f30d56f58b77c9cf42df9481f37586faf0c4c2")
  (:PATH "src/scheduler/pool-claim.lisp" :GIT-BLOB
   "476372e627724a17b7c86257171ff1d33bd5b809")
  (:PATH "src/scheduler/read.lisp" :GIT-BLOB
   "cabd8cdb2f83333b321653fd63549eb5716d7b59")
  (:PATH "src/scheduler/types.lisp" :GIT-BLOB
   "728f410292749214a020047d8efa744c54ed0a6e")
  (:PATH "src/scheduler/update.lisp" :GIT-BLOB
   "ac1a02b8dcb4432a99ab7f93686b0c02d5c775d8")
  (:PATH "src/series/events.lisp" :GIT-BLOB
   "63fb4a20faeedceb47b8cd550262f1bdca497c06")
  (:PATH "src/series/io-events.lisp" :GIT-BLOB
   "128fe9650a741541b46d1ad0887b872cb2e85012")
  (:PATH "src/series/ownership.lisp" :GIT-BLOB
   "7352a27581b8e2e68407611e65e46773efdc333c")
  (:PATH "src/series/package.lisp" :GIT-BLOB
   "6fd26253982dba01e9eef2702c5f4ede6ba70659")
  (:PATH "src/series/publication.lisp" :GIT-BLOB
   "d5f27e3366e71651a3b41322b68d9ca7ab871fe3")
  (:PATH "src/series/query.lisp" :GIT-BLOB
   "7f91ca22b7f2f339b450db0f4c26c97f86906c58")
  (:PATH "src/series/retirement.lisp" :GIT-BLOB
   "fc42b51a0f8606687881e239ba650a9f1bb58124")
  (:PATH "src/series/routing-build.lisp" :GIT-BLOB
   "6fbe5e4720187be3bcada2dcc9fc40026267da07")
  (:PATH "src/series/routing-select.lisp" :GIT-BLOB
   "f280c35e8f7ed283d30e8f4a43bbf2f172600816")
  (:PATH "src/series/routing-types.lisp" :GIT-BLOB
   "e350df4e2fdc2f651ffbdb136bdbb266ccafcb1c")
  (:PATH "src/series/types.lisp" :GIT-BLOB
   "5630ae60278a168326cf19e7cee4eacb3deacbe6")
  (:PATH "src/series/worker-boundary.lisp" :GIT-BLOB
   "acc9f6ea83a8ef2774b41bdb114165b6bfb54949")
  (:PATH "src/series/worker-package.lisp" :GIT-BLOB
   "d0316128bae48e4251a519d7daab25dbaf52f031")
  (:PATH "src/series/worker-run.lisp" :GIT-BLOB
   "02c219d556a8cd807a0e322667dfb401d8b06fb6")
  (:PATH "src/series/worker-types.lisp" :GIT-BLOB
   "39f28974f3fae098d32d4ad1a056a45b06f777a6")
  (:PATH "src/storage/compaction-scan.lisp" :GIT-BLOB
   "233556c366a99b7b263af1c7bc19b47ceaebf940")
  (:PATH "src/storage/control-payload.lisp" :GIT-BLOB
   "7980cac6cc8070836b9aa49fc8a0d6fb42630749")
  (:PATH "src/storage/formats.lisp" :GIT-BLOB
   "fc942f1c8e30e637abaf13dc26343d40417fc72f")
  (:PATH "src/storage/log-header.lisp" :GIT-BLOB
   "fde8608e6ad3fe062937c48bdcb7d2d5870207bf")
  (:PATH "src/storage/package.lisp" :GIT-BLOB
   "c15553a65171e5dfb2dbadb62c92ed4dc48aee3a")
  (:PATH "src/storage/payload-record.lisp" :GIT-BLOB
   "0012eaf90064c4cc2949834a60e83c9db8ba6308")
  (:PATH "src/storage/payload-write.lisp" :GIT-BLOB
   "6cbbb89f681965173e9b1b95edf3f7f870af1eca")
  (:PATH "src/storage/segment-header.lisp" :GIT-BLOB
   "f1d99b205b1ea5e6ad059ecd7971d3633411b040")
  (:PATH "src/wal/builder.lisp" :GIT-BLOB
   "0b271d0c3d7ef0cbdee8f43784132ae298139c3a")
  (:PATH "src/wal/csn.lisp" :GIT-BLOB
   "f65662b4dea8ef04e4e59ce38b29a94fecea4f6c")
  (:PATH "src/wal/executor.lisp" :GIT-BLOB
   "edc8ce7474365e0885925d557a378779655d2e70")
  (:PATH "src/wal/frame.lisp" :GIT-BLOB
   "b7205104847e4ddc54750b4f38a23a5775476e60")
  (:PATH "src/wal/group.lisp" :GIT-BLOB
   "8245bc10cedafbff8665489fbced6833f078a373")
  (:PATH "src/wal/package.lisp" :GIT-BLOB
   "e0ea179069a7b297c7c26f6c294c7d4aea3db671")
  (:PATH "src/wal/types.lisp" :GIT-BLOB
   "d4bf29cbdbda20de65b650aa9e7bd19cc2d910b1")
  (:PATH "tests/cache/README.md" :GIT-BLOB
   "a963e5f7febd0c2a7f74aeb52cba3d6510c50476")
  (:PATH "tests/cache/guards.lisp" :GIT-BLOB
   "af881fd91c3820ab19d1daa2d56f1fe57257d08f")
  (:PATH "tests/cache/support.lisp" :GIT-BLOB
   "fd829e7352ba878e73df30d979e9558ff6ccba14")
  (:PATH "tests/cache/threads.lisp" :GIT-BLOB
   "ca03c59f0fada09cae8c452fed6490de32d4a3a6")
  (:PATH "tests/ci-catalog.lisp" :GIT-BLOB
   "15b3b3126a8dc57fe98d4dccd5c85d1fcb88204b")
  (:PATH "tests/codec/cbor-array-write-support.lisp" :GIT-BLOB
   "2a47078354c45a5775f48f6dd8f5d784da7de202")
  (:PATH "tests/codec/cbor-array-write-threads.lisp" :GIT-BLOB
   "43bac6c9604140af2594d85b76c14c3101b6925b")
  (:PATH "tests/codec/cbor-array-write.lisp" :GIT-BLOB
   "b13f58264f3cd97e1947ee52936732a7fcebe672")
  (:PATH "tests/codec/cbor-float-write-support.lisp" :GIT-BLOB
   "5416b62340ae8f3332915f8891529d95549a5fba")
  (:PATH "tests/codec/cbor-float-write-threads.lisp" :GIT-BLOB
   "3b0840150945cd4f118516b1d6d61524fa6856fa")
  (:PATH "tests/codec/cbor-float-write.lisp" :GIT-BLOB
   "747cd8a72445a3ea638cd1910bc9faa63f4cdc33")
  (:PATH "tests/codec/cbor-header.lisp" :GIT-BLOB
   "a1541916590304adccc2092c226ef3be9c644168")
  (:PATH "tests/codec/cbor-item-read-support.lisp" :GIT-BLOB
   "0326100362a1c4b24d2c7e511e45357f09a56d33")
  (:PATH "tests/codec/cbor-item-read-threads.lisp" :GIT-BLOB
   "a0da65545ed80ede0a967cadbb337731f6fe1ce9")
  (:PATH "tests/codec/cbor-item-read.lisp" :GIT-BLOB
   "b2cbdcb4255c51d9da4fe73b28939c1cb923fefe")
  (:PATH "tests/codec/cbor-map-write-support.lisp" :GIT-BLOB
   "113bfc4529199f69dea1862baec0aa7403c6fa97")
  (:PATH "tests/codec/cbor-map-write-threads.lisp" :GIT-BLOB
   "892d30fd1c7a8f12430c6caa6f43ee872574eb09")
  (:PATH "tests/codec/cbor-map-write.lisp" :GIT-BLOB
   "6ad0e9b5a48ba9c32c46d720f2f7f1821368d6c8")
  (:PATH "tests/codec/cbor-minimal-edges.lisp" :GIT-BLOB
   "c6f891dff335a37689ddbfabccf793d2e9f2f143")
  (:PATH "tests/codec/cbor-minimal-scan-support.lisp" :GIT-BLOB
   "c2af64af4e5f8b5f669819fd56a00f416b3aaf0d")
  (:PATH "tests/codec/cbor-minimal-scan-threads.lisp" :GIT-BLOB
   "532c3f1d5898083364f17f9fc9cbf0da7b798bda")
  (:PATH "tests/codec/cbor-minimal-scan.lisp" :GIT-BLOB
   "1742189ff6845197ba76996c09c1097d59216fcb")
  (:PATH "tests/codec/cbor-minimal-support.lisp" :GIT-BLOB
   "774e6cd0bec4a9d2242ad4dede878ffa2afca90c")
  (:PATH "tests/codec/cbor-minimal-threads.lisp" :GIT-BLOB
   "d88b573a98689b5e1c0cbade8f8a7ac69470554f")
  (:PATH "tests/codec/cbor-minimal.lisp" :GIT-BLOB
   "b863ace9a22e8b7508b7c9d8f91465ebfbcd4e98")
  (:PATH "tests/codec/cbor-simple-write-support.lisp" :GIT-BLOB
   "0989d7f8e43ec7213df856b842b1e9149df96d9f")
  (:PATH "tests/codec/cbor-simple-write-threads.lisp" :GIT-BLOB
   "186f1772335ce33e4e3d1d933bf4d4e91fe0763f")
  (:PATH "tests/codec/cbor-simple-write.lisp" :GIT-BLOB
   "efaa31b8ea2d74af162fd00a3b4e923ae5f60cdd")
  (:PATH "tests/codec/cbor-string-read-support.lisp" :GIT-BLOB
   "cfd55cd47d782673113e67af625c1360195a345c")
  (:PATH "tests/codec/cbor-string-read-threads.lisp" :GIT-BLOB
   "c3686d6e47ad56e53db556747ee2d49cea527df5")
  (:PATH "tests/codec/cbor-string-read.lisp" :GIT-BLOB
   "8437bdcaa4cf308dbf4614e748cdab4be2ae6d62")
  (:PATH "tests/codec/cbor-string-write-support.lisp" :GIT-BLOB
   "66b5d03695f522cca8013ccdad3ede690cc63412")
  (:PATH "tests/codec/cbor-string-write-threads.lisp" :GIT-BLOB
   "16cc32f2c51d28f75a64b93ead642340f88e9c05")
  (:PATH "tests/codec/cbor-string-write.lisp" :GIT-BLOB
   "ed0f6a67c46498bdc9c721480cb76bc727fc5b4f")
  (:PATH "tests/codec/cbor-structure-support.lisp" :GIT-BLOB
   "e9cc8a08917903cab7b7f5617225884b7d89e6c4")
  (:PATH "tests/codec/cbor-structure-threads.lisp" :GIT-BLOB
   "595d51a96ee3767c13797910ea324061a4788617")
  (:PATH "tests/codec/cbor-structure.lisp" :GIT-BLOB
   "7e9b7a518bc3a260d721e85d62ff986553bb06de")
  (:PATH "tests/codec/cbor-support.lisp" :GIT-BLOB
   "172c4a335b2d504f785b2036532346a24ccf1378")
  (:PATH "tests/codec/cbor-tag-write-support.lisp" :GIT-BLOB
   "e6e1e91e5ed95019e20b11d2dc0e408911acb46e")
  (:PATH "tests/codec/cbor-tag-write-threads.lisp" :GIT-BLOB
   "1c731f7ed83f703e3d2a8a4c57e6c702ef127887")
  (:PATH "tests/codec/cbor-tag-write.lisp" :GIT-BLOB
   "df97950ec8d24157bb6566c7995262f7beea7742")
  (:PATH "tests/codec/cbor-threads.lisp" :GIT-BLOB
   "0f66cc1f8b493598d436b1d62d7211f4196fb430")
  (:PATH "tests/codec/cbor-write-roundtrip.lisp" :GIT-BLOB
   "e225cb69e82ad1038da71e31b6513619f5e09d40")
  (:PATH "tests/codec/cbor-write-support.lisp" :GIT-BLOB
   "92327e4b840b8586c50c32a7732e718ee6e9db98")
  (:PATH "tests/codec/cbor-write-threads.lisp" :GIT-BLOB
   "7717054be474eba254f3f645fc62ec4ef65a511c")
  (:PATH "tests/codec/cbor-write.lisp" :GIT-BLOB
   "903a213c810d99fdefc2af2afa93445574a13be7")
  (:PATH "tests/codec/support.lisp" :GIT-BLOB
   "6b8226ae1b41dc9e47e45986e18287a10a8d54e7")
  (:PATH "tests/codec/threads.lisp" :GIT-BLOB
   "0c1a6d9fbe44a95b951a7e1a9aad90f65cef961b")
  (:PATH "tests/codec/utf8.lisp" :GIT-BLOB
   "59e3ffc9cee96d97ef20d132e3e531aef2f9ddf7")
  (:PATH "tests/control/native.lisp" :GIT-BLOB
   "2107cb66de45ded987c7fb1392155ff6afebbed6")
  (:PATH "tests/control/publication.lisp" :GIT-BLOB
   "f987c9317990ce977ecadb747268b39d2612eba1")
  (:PATH "tests/control/recovery-guards.lisp" :GIT-BLOB
   "b2e877dfcc35468cfafd95f398f33d1415692c1f")
  (:PATH "tests/control/recovery-publication.lisp" :GIT-BLOB
   "cd99169af8aecf204ce9cd2e6e1f2a9fbb081f68")
  (:PATH "tests/control/recovery-read.lisp" :GIT-BLOB
   "21f33af3220a237d7a8dc2ff3a98bfd4c41fa201")
  (:PATH "tests/control/support.lisp" :GIT-BLOB
   "053d81269526d2e7c78181fbe2f8e58ac3f878f3")
  (:PATH "tests/csn/registry.lisp" :GIT-BLOB
   "b5c507d831098b28e6d1fe7880a01e1a3cb8ded2")
  (:PATH "tests/csn/support.lisp" :GIT-BLOB
   "a6c462233eed3bbdf9f08feb0195488688af287c")
  (:PATH "tests/csn/threads.lisp" :GIT-BLOB
   "b198b4936a119a6194e720cd51a6cbe5f49d72c1")
  (:PATH "tests/engine/lifecycle.lisp" :GIT-BLOB
   "55f8a525a7fb68846724b869d15eee8238924fe3")
  (:PATH "tests/engine/processes.lisp" :GIT-BLOB
   "6f26d9267249e8a122de343dffe9830b2f2f8238")
  (:PATH "tests/engine/support.lisp" :GIT-BLOB
   "ca131303ada021ede08046975067682ec7d88377")
  (:PATH "tests/epochs/lifecycle.lisp" :GIT-BLOB
   "6980f8ef0aec2f962d2c85c38ad5b712132ce2be")
  (:PATH "tests/epochs/support.lisp" :GIT-BLOB
   "de53c4db528218c5bb4e074d7cd26a4a38f0ecc5")
  (:PATH "tests/epochs/threads.lisp" :GIT-BLOB
   "a7e34763661de9edd8bd049c817ba961cc1d3104")
  (:PATH "tests/execution/handoff.lisp" :GIT-BLOB
   "ba702352ee63241b9ac993b0aca8f162c3deef1b")
  (:PATH "tests/execution/queue.lisp" :GIT-BLOB
   "546d4215f9f63007f632c522f0f8c1e75ac4bbeb")
  (:PATH "tests/execution/ready-recycle.lisp" :GIT-BLOB
   "1dff8707436ca52f20f62e9946621ca1037f33d2")
  (:PATH "tests/execution/ready.lisp" :GIT-BLOB
   "9f81552333f86fe0b20f2d5e8ba48b20634f5a09")
  (:PATH "tests/execution/support.lisp" :GIT-BLOB
   "b8bac07926727a644f0246f6b57d600332288310")
  (:PATH "tests/execution/threads.lisp" :GIT-BLOB
   "b1e71783b65b85e6253f733098c3153d41c4971c")
  (:PATH "tests/execution/worker.lisp" :GIT-BLOB
   "2a14573906b94b254712a1e9322058ec1081f6f8")
  (:PATH "tests/foundation/batch.lisp" :GIT-BLOB
   "00bb40ad87340ee86f5da281c09207c8da8888a6")
  (:PATH "tests/foundation/binary.lisp" :GIT-BLOB
   "ff6df200a7ace3af204b622969a387ce7a1e1504")
  (:PATH "tests/foundation/record.lisp" :GIT-BLOB
   "4294dcba9b307bddd9cc3636d7e2865f0f7030c5")
  (:PATH "tests/foundation/support.lisp" :GIT-BLOB
   "d383b1cddf929ba0340d1b74eec3ec03673eac09")
  (:PATH "tests/fulltext/admission-concurrency.lisp" :GIT-BLOB
   "fbc2b0294a9369c4812bf206f001399be2af0ff3")
  (:PATH "tests/fulltext/admission-guards.lisp" :GIT-BLOB
   "b3475774a8a7f31269ea0e1b33bb659e230f67c7")
  (:PATH "tests/fulltext/admission-lifecycle.lisp" :GIT-BLOB
   "175c3e3bd33b163bc7593066ade68eb426e8e757")
  (:PATH "tests/fulltext/admission-resources.lisp" :GIT-BLOB
   "29ac6bf4b0b392579997b79c10142b2f491a5eb7")
  (:PATH "tests/fulltext/admission-rows-support.lisp" :GIT-BLOB
   "1713cd556e5e37525af25a15b4f5b36474967d88")
  (:PATH "tests/fulltext/admission-rows.lisp" :GIT-BLOB
   "6e2d6c65c8046ad7dee030a4e95330f3ce3993dd")
  (:PATH "tests/fulltext/admission-support.lisp" :GIT-BLOB
   "1eaef196dc555b086cd53584731041bfb97cda59")
  (:PATH "tests/fulltext/admission.lisp" :GIT-BLOB
   "74ed0e49ce0c839cb5e74d854704d21cb8dbbf68")
  (:PATH "tests/fulltext/allocation-threads.lisp" :GIT-BLOB
   "870a308baeed93e1aabb6dc9a88db443592439c0")
  (:PATH "tests/fulltext/analysis-conformance.lisp" :GIT-BLOB
   "ad704e6457ad7873b3eb2feea241da5129962c8f")
  (:PATH "tests/fulltext/analysis-support.lisp" :GIT-BLOB
   "805f7e60fd3f6aa25b4c53680e5251188e57868e")
  (:PATH "tests/fulltext/analysis.lisp" :GIT-BLOB
   "4d529aef551bd365f0c12eb3dffbb7b2960fae56")
  (:PATH "tests/fulltext/codec-corruption.lisp" :GIT-BLOB
   "c62dd05be34d1f653eed8565cc0b40b950bdb97f")
  (:PATH "tests/fulltext/codec-differential.lisp" :GIT-BLOB
   "91b651930dd7f9da36fd317453686d272e0d2c40")
  (:PATH "tests/fulltext/codec-guards.lisp" :GIT-BLOB
   "9f6b8e823ae25c43b767141e0193b908ca0e763a")
  (:PATH "tests/fulltext/codec-support.lisp" :GIT-BLOB
   "890e176db757eed9e2680f5b247a12922709d4b9")
  (:PATH "tests/fulltext/codec.lisp" :GIT-BLOB
   "50b924b1c0e9127da33413f1100bf04ef2ee500d")
  (:PATH "tests/fulltext/document-differential.lisp" :GIT-BLOB
   "78466a8bc1213d0794155535eb28a990a45a38aa")
  (:PATH "tests/fulltext/document-guards.lisp" :GIT-BLOB
   "608f322bd4ac149abb9ffbb352595b5c94d3d217")
  (:PATH "tests/fulltext/document-support.lisp" :GIT-BLOB
   "57d59f345c6cbe8dba253acce7993409b5bbed94")
  (:PATH "tests/fulltext/document.lisp" :GIT-BLOB
   "ab305e31ece6bf7fd20ac5b7ea119b01c57e7c92")
  (:PATH "tests/fulltext/format-guards.lisp" :GIT-BLOB
   "9a23048572dfa5eee314221ced3425a1ea46c28a")
  (:PATH "tests/fulltext/format-support.lisp" :GIT-BLOB
   "d03bd892800d593a3550bdc709d43c357041bfab")
  (:PATH "tests/fulltext/format-threads.lisp" :GIT-BLOB
   "b8e8eb4491b59c721071396ce656eb09186f988d")
  (:PATH "tests/fulltext/format.lisp" :GIT-BLOB
   "b7cb19b82d4e50d457c603b8708693adf27785f0")
  (:PATH "tests/fulltext/index.lisp" :GIT-BLOB
   "0673c32fe456a9cb77cf4aa5cc4e071a888cccf2")
  (:PATH "tests/fulltext/minimum-v2.hex" :GIT-BLOB
   "c4db496b0e5b920665d1c80bea204f6227da1f0e")
  (:PATH "tests/fulltext/put-concurrency.lisp" :GIT-BLOB
   "613b2e5a89d505701583aa9c68e6273f4163d2e7")
  (:PATH "tests/fulltext/put-guards.lisp" :GIT-BLOB
   "6b531c1b143860a46e84d5c77da982f54fbd413b")
  (:PATH "tests/fulltext/put-lifecycle.lisp" :GIT-BLOB
   "8cba90b629299c8494194a73ef8b819f554ca557")
  (:PATH "tests/fulltext/put-physical-guards.lisp" :GIT-BLOB
   "bd293d0ef1d5596e85859cb85e41639b3a0fd70e")
  (:PATH "tests/fulltext/put-physical-native.lisp" :GIT-BLOB
   "635118c4287ab13b4b98e34d04dc307b97497827")
  (:PATH "tests/fulltext/put-physical-support.lisp" :GIT-BLOB
   "1e81cc2af12f24515debc953d4f7884b07a2e197")
  (:PATH "tests/fulltext/put-physical.lisp" :GIT-BLOB
   "f8d1fa41090aaa40c2146ec9280bff08d968fdce")
  (:PATH "tests/fulltext/put-rows.lisp" :GIT-BLOB
   "0ee39c61cdbb6742eb36d65677030d44c96ad98e")
  (:PATH "tests/fulltext/put-support.lisp" :GIT-BLOB
   "2a3c9b543587b1a9c5402a16f82cfc1c671a6160")
  (:PATH "tests/fulltext/put.lisp" :GIT-BLOB
   "83f9503ec4bd1a6610443bb8eea991e6069c6565")
  (:PATH "tests/get-active/construction.lisp" :GIT-BLOB
   "ec2831edef2e452597ce867b026eb73c84fc5214")
  (:PATH "tests/get-active/directory.lisp" :GIT-BLOB
   "48c9a60e58536170a610844e853eae6f91beeff1")
  (:PATH "tests/get-active/preflight.lisp" :GIT-BLOB
   "7f41c04257e0bab10a2ffbc091b02d660029c4df")
  (:PATH "tests/get-active/read.lisp" :GIT-BLOB
   "0ab8c2b2b639a51b0217876a896d9468f41e22de")
  (:PATH "tests/get-active/support.lisp" :GIT-BLOB
   "0eb0864894f8f8cb32221ff98c75dde5aff80c26")
  (:PATH "tests/get-directory/README.md" :GIT-BLOB
   "24543b1595fbd12972e7073680fde062337b8417")
  (:PATH "tests/get-directory/construction.lisp" :GIT-BLOB
   "537a67a6931f1c7445e68bd30683c08108bf37e7")
  (:PATH "tests/get-directory/lifetime-support.lisp" :GIT-BLOB
   "cd514970e84f8654318dcc23a6b1ef24323be8a9")
  (:PATH "tests/get-directory/lifetime.lisp" :GIT-BLOB
   "c57261d2de469318402d5bf79f5ab5d27108bb46")
  (:PATH "tests/get-directory/read.lisp" :GIT-BLOB
   "04c509eb39d9f552f4d2762630c20861e7b1c48f")
  (:PATH "tests/get-directory/series-read.lisp" :GIT-BLOB
   "b500bb83170622b6d96edbd363ebc85240064c18")
  (:PATH "tests/get-directory/series-support.lisp" :GIT-BLOB
   "ead990e110b588bb4df35ea17d3816db3b79cee5")
  (:PATH "tests/get-directory/support.lisp" :GIT-BLOB
   "a5b09ee5120bedc4e946366239dd5e6c978b27d2")
  (:PATH "tests/get-directory/threads.lisp" :GIT-BLOB
   "832073baa5d1e8aefe89ac42dc60023c96038ba3")
  (:PATH "tests/get-performance/README.md" :GIT-BLOB
   "199d6d77437b8ce90178716c4ca37ebdb85ebc2f")
  (:PATH "tests/get-performance/guards.lisp" :GIT-BLOB
   "9bbf7b2ceb817d6ecf2e7c67b0928373c2c07f70")
  (:PATH "tests/get-performance/paths.lisp" :GIT-BLOB
   "160dae42a9723e9b0e93a085864affa96a4cd6be")
  (:PATH "tests/get-performance/support.lisp" :GIT-BLOB
   "f7eac312809b34fa72dcd3b9a8b67d290cb08cd6")
  (:PATH "tests/get-performance/threads.lisp" :GIT-BLOB
   "5780e3ef9c9e34a4098ddbd72e19cebfa6a34edd")
  (:PATH "tests/get-resolver/construction.lisp" :GIT-BLOB
   "322c63ee6576304ca1ab19e28b902b680bc2acae")
  (:PATH "tests/get-resolver/read.lisp" :GIT-BLOB
   "a1788d1aab3f76b9dc29095676ec42f3a1f936a8")
  (:PATH "tests/get-resolver/sort.lisp" :GIT-BLOB
   "442ce9eef4fac8f593a9d94ed08a76b830773563")
  (:PATH "tests/get-resolver/support.lisp" :GIT-BLOB
   "11d5cf0efe8ee4f5606707cc7eca175442a50190")
  (:PATH "tests/get/lifecycle.lisp" :GIT-BLOB
   "c65090a98c47f89d42ea8e77f00d402afbb9a9bc")
  (:PATH "tests/get/segment.lisp" :GIT-BLOB
   "125d274ba50ba29a9c0d7e1d04ce8e22f7f240f2")
  (:PATH "tests/get/support.lisp" :GIT-BLOB
   "387c1101e92dce8482c3d0e27a47fa42f21e3501")
  (:PATH "tests/hash/guards.lisp" :GIT-BLOB
   "3a4454e0f55fe12ff4c84a44aa60509623621b93")
  (:PATH "tests/hash/hash64.lisp" :GIT-BLOB
   "5044b9d9d2e5872a78bfc81d9ff3c3295b242069")
  (:PATH "tests/hash/support.lisp" :GIT-BLOB
   "be3d132c4eeb9e4ee0892a98174b9e10771a38a9")
  (:PATH "tests/hash/threads.lisp" :GIT-BLOB
   "0b804901ec2c1de69c0781c08a30f8389b2d3d34")
  (:PATH "tests/index/hash-digests.lisp" :GIT-BLOB
   "bee75932d859ac1c3d02147672f9186e53d71b5b")
  (:PATH "tests/index/mode-policy.lisp" :GIT-BLOB
   "4513fb320a9f1ced973820d8a9c58ee9a0d73ea6")
  (:PATH "tests/index/mode-support.lisp" :GIT-BLOB
   "14d4c82bd54795844d14ac1d7f1b7ced320c4233")
  (:PATH "tests/index/page-chains.lisp" :GIT-BLOB
   "265a85cd6aff51dd8a5ceae50f60ff7b8d63660e")
  (:PATH "tests/index/page-corruption.lisp" :GIT-BLOB
   "880775f39ed5c6352c0ae448b7a830ea63b03a85")
  (:PATH "tests/index/page-fixtures.lisp" :GIT-BLOB
   "0ed84fd77dc21375773651e4bb42e56a2c0a5e43")
  (:PATH "tests/index/page-support.lisp" :GIT-BLOB
   "920c631d2763260aec7bcb02d3172d8be1d4b21f")
  (:PATH "tests/index/page-tests.lisp" :GIT-BLOB
   "a18f0315e5480a356504f1f541bffc1ad3484fc6")
  (:PATH "tests/index/primary-support.lisp" :GIT-BLOB
   "38c629112ce062064d66409349f76ba91b26801f")
  (:PATH "tests/index/primary-threads.lisp" :GIT-BLOB
   "289d129a4ae1690c24874714bae3812ee01bad8b")
  (:PATH "tests/index/primary.lisp" :GIT-BLOB
   "d21142f34f3687c35f39c86d962f2c8ffd52c330")
  (:PATH "tests/index/rebuild.lisp" :GIT-BLOB
   "838091c9035b5a489c12467daf3a564de1ca0746")
  (:PATH "tests/index/slot-support.lisp" :GIT-BLOB
   "384a6ac91ac56abfe7db43d587366ba6eaf369aa")
  (:PATH "tests/index/slot-threads.lisp" :GIT-BLOB
   "f7eee8b0026ee742163ab90d31a7b09263820033")
  (:PATH "tests/index/slots.lisp" :GIT-BLOB
   "5f443c496559abe79e0abace6555dc96eb6c4276")
  (:PATH "tests/io/create-relative-native.lisp" :GIT-BLOB
   "fd5e819e2197869a93259857aacfa68bfe9e9a44")
  (:PATH "tests/io/create-relative-support.lisp" :GIT-BLOB
   "8382ffb8f04b6d2fc3e4adb89f995c9c37b0e445")
  (:PATH "tests/io/create-relative.lisp" :GIT-BLOB
   "7fb4c3665ca1b8f6de2dedd2827cfc150dcddf02")
  (:PATH "tests/io/directory-lock.lisp" :GIT-BLOB
   "4cefd15616f4ac2312a669b1242929d2706eb540")
  (:PATH "tests/io/flush-failure.lisp" :GIT-BLOB
   "76a80588d99b441e8c57a97f9a10d4d9d6c7b59b")
  (:PATH "tests/io/native.lisp" :GIT-BLOB
   "bb3f9a460953d5575d7333b8b6eef6ecdb8e1e7d")
  (:PATH "tests/io/open-relative-native.lisp" :GIT-BLOB
   "cdb197bf2760de70e7ec49af76e2954a18006997")
  (:PATH "tests/io/open-relative-support.lisp" :GIT-BLOB
   "4256567b2a10423a41540298317c8ef80e6b5af0")
  (:PATH "tests/io/open-relative.lisp" :GIT-BLOB
   "4bec9451a13db1437e081bda2858d4cb8b1e5de1")
  (:PATH "tests/io/rename-native.lisp" :GIT-BLOB
   "99f79041529d20d0ea774b01e3ed82fc5a274cdd")
  (:PATH "tests/io/rename.lisp" :GIT-BLOB
   "e83443eec6187d53118795c4f6ee797112f27ea2")
  (:PATH "tests/io/support.lisp" :GIT-BLOB
   "0179a0c19bdde944f47fe83716ecc6241e37c686")
  (:PATH "tests/io/transfer-failure.lisp" :GIT-BLOB
   "c87c80fb9c82062bf4d4179d67f710ff10b4f051")
  (:PATH "tests/io/transfer.lisp" :GIT-BLOB
   "40c8f4d5e2d493db090d5d09ab024c67ca6f4037")
  (:PATH "tests/lint-fixtures/bad.lisp" :GIT-BLOB
   "d0d5fd7285428e569d3dd595a0c38de5211e10a5")
  (:PATH "tests/lint-fixtures/good.lisp" :GIT-BLOB
   "35558ab0ab2be7688e9fd55a38be44ebe9a57f37")
  (:PATH "tests/lint-fixtures/keyword-barrier.lisp" :GIT-BLOB
   "b71f5472914b386c88fe6bf079470d19a40a9b96")
  (:PATH "tests/lint-fixtures/qualified-reader.lisp" :GIT-BLOB
   "583969b51a66447b4dfffd6a8fba19e156550e8d")
  (:PATH "tests/local/native.lisp" :GIT-BLOB
   "b8891b57aa6229995b7c6ee5581d9cde650e3c93")
  (:PATH "tests/local/processes.lisp" :GIT-BLOB
   "65cad807de3003796e391c914b348fc7430cdb12")
  (:PATH "tests/local/server.lisp" :GIT-BLOB
   "ee847591e0e200b8c66769a6340666c528cd46d8")
  (:PATH "tests/local/wire.lisp" :GIT-BLOB
   "349d7df061b5871658ad3fa6a14601bd58f1fa2c")
  (:PATH "tests/mvcc/capture.lisp" :GIT-BLOB
   "3e08116a1f53e1b764a2f62d9174ff11037a8399")
  (:PATH "tests/mvcc/lifecycle.lisp" :GIT-BLOB
   "2cc481df77ba8d2353985d5a4fb94644fd0861e2")
  (:PATH "tests/mvcc/support.lisp" :GIT-BLOB
   "ca49c8db671b145088d7acfac77cc28a4777dfc2")
  (:PATH "tests/read/lifecycle.lisp" :GIT-BLOB
   "6b20bd639c91aee4c0011b26ba10487ab0f54cc0")
  (:PATH "tests/read/support.lisp" :GIT-BLOB
   "e7f982fc2737ac7c0985c4881325be2711f30bd1")
  (:PATH "tests/read/threads.lisp" :GIT-BLOB
   "b4961a7cb2455d792430a31e8a7528f4561ddc54")
  (:PATH "tests/recovery-active-checkpoint/guards.lisp" :GIT-BLOB
   "cae7d70c2a5598bb5c3e1256ef4bb8b391656f6f")
  (:PATH "tests/recovery-active-checkpoint/publication.lisp" :GIT-BLOB
   "a996bc5f82f16fe12a74d9bee5962f8d8629f53a")
  (:PATH "tests/recovery-active-checkpoint/semantics.lisp" :GIT-BLOB
   "a4b80a1a678cdc4537ee9d989f178124829e70cb")
  (:PATH "tests/recovery-active-checkpoint/support.lisp" :GIT-BLOB
   "998ab160b939c93797fc90206a9b50f2cf55e452")
  (:PATH "tests/recovery-active/publication.lisp" :GIT-BLOB
   "8a3c4ba88dd7010c65a464d231ebdab2c8c27e67")
  (:PATH "tests/recovery-active/read.lisp" :GIT-BLOB
   "63f52ee0e0ab244ed278562a5d7fbc752b7617e7")
  (:PATH "tests/recovery-active/semantics.lisp" :GIT-BLOB
   "1d3c935a1169904c900461b67adb96f4dfd96b94")
  (:PATH "tests/recovery-active/support.lisp" :GIT-BLOB
   "5ebf9d06ae855b07875aadc10e2a8ac01ba56036")
  (:PATH "tests/recovery-archive-csn/guards.lisp" :GIT-BLOB
   "a6d91274479da64fa689ca370ff495cc96ae0e51")
  (:PATH "tests/recovery-archive-csn/native.lisp" :GIT-BLOB
   "d66af858c855e39c984f1ff8534e6de3c7c7fc88")
  (:PATH "tests/recovery-archive-csn/plan.lisp" :GIT-BLOB
   "b740c77023c500208ff742e02c4d5aebcd44db70")
  (:PATH "tests/recovery-archive-csn/set.lisp" :GIT-BLOB
   "d163bf160241d2225ac3282c1d925aa65e249ab3")
  (:PATH "tests/recovery-archive-csn/support.lisp" :GIT-BLOB
   "0c458a3f6f8aa062c2cc8831834c29159e09762d")
  (:PATH "tests/recovery-archive/active.lisp" :GIT-BLOB
   "ccbaaa3294880905584ad42c0601201fa3a3dc36")
  (:PATH "tests/recovery-archive/guards.lisp" :GIT-BLOB
   "8afea2a3df30099c07badd7d9c0bcf627a5f9a9d")
  (:PATH "tests/recovery-archive/native.lisp" :GIT-BLOB
   "ae8df9ced72f9142ade184ec78bdc576e05593e1")
  (:PATH "tests/recovery-archive/query.lisp" :GIT-BLOB
   "b0a56949ec13ec7c80466ac8b3cecc79c0fc6d63")
  (:PATH "tests/recovery-archive/read.lisp" :GIT-BLOB
   "22d1042700435e2c15e3f610f9ada9c4a8d8d4ed")
  (:PATH "tests/recovery-archive/support.lisp" :GIT-BLOB
   "0cbefaed0f74c8e34e4cea9a359c58f9196f22ad")
  (:PATH "tests/recovery-closed/csn.lisp" :GIT-BLOB
   "754611c3818a0aac26b189392d4024a251439d0c")
  (:PATH "tests/recovery-closed/guards.lisp" :GIT-BLOB
   "344857641ef2206d4d5a800fbb93b834a9f13c4d")
  (:PATH "tests/recovery-closed/publication.lisp" :GIT-BLOB
   "72f179d28936100b91d1847eeb8a24c696552619")
  (:PATH "tests/recovery-closed/read.lisp" :GIT-BLOB
   "0e401337f36768cd63206cbb7b6adf91eeeeb1ef")
  (:PATH "tests/recovery-closed/semantics.lisp" :GIT-BLOB
   "a931be1523c72d49e955aa7708bec6bd3b273be0")
  (:PATH "tests/recovery-closed/support.lisp" :GIT-BLOB
   "15bafc01c04fe1763d9a6580f6ad0bbb1917f40c")
  (:PATH "tests/recovery/corruption.lisp" :GIT-BLOB
   "2f9ead22a4e3b45cb3a680aa3a32a94bfcc6d77f")
  (:PATH "tests/recovery/decisions-audit.lisp" :GIT-BLOB
   "1b79a76515d8b8c2e67c46700cd6968b40047d62")
  (:PATH "tests/recovery/decisions-radix.lisp" :GIT-BLOB
   "232312cdd4ed6b1efcedc33ddda0fd8d1d8545d7")
  (:PATH "tests/recovery/decisions-support.lisp" :GIT-BLOB
   "f67450a9d681512a4b66efe1af1bfc82180e0058")
  (:PATH "tests/recovery/decisions.lisp" :GIT-BLOB
   "28d04d8738f077bf21ac22393a4014b518a6a0f2")
  (:PATH "tests/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "e6f289d77025dce439787287abc6a4dde0ac69f5")
  (:PATH "tests/recovery/inventory-directory-native.lisp" :GIT-BLOB
   "8f89629becea88fdc74c920a59676412c3a7b976")
  (:PATH "tests/recovery/inventory-directory-support.lisp" :GIT-BLOB
   "c316b3647e7ea5391d687917fe802907f2273bb4")
  (:PATH "tests/recovery/inventory-directory.lisp" :GIT-BLOB
   "ead38feadd94f49276596d0abf989f29d13af497")
  (:PATH "tests/recovery/inventory-id.lisp" :GIT-BLOB
   "1f05c46bfc887984c476bd7673d2b2dde998c44d")
  (:PATH "tests/recovery/inventory-sources-native.lisp" :GIT-BLOB
   "86144ee3fe19ef0f2a54c9760ed193860881ced4")
  (:PATH "tests/recovery/inventory-sources-support.lisp" :GIT-BLOB
   "36b79c4091825c32ffc3aa32a146ee5121881ebc")
  (:PATH "tests/recovery/inventory-sources.lisp" :GIT-BLOB
   "3ffd5a9fb098ab4aeb091a6823fcec68d22c19aa")
  (:PATH "tests/recovery/inventory-support.lisp" :GIT-BLOB
   "06eeff2101a97f9abdec6b6f14aa621c2fec29fd")
  (:PATH "tests/recovery/inventory.lisp" :GIT-BLOB
   "0d5722e4f5ba0025d3a6fb38f0bd056a3ea0b8e9")
  (:PATH "tests/recovery/manifest-audit.lisp" :GIT-BLOB
   "9dc9667bdae700ff8ff2afc93bb385c0617eda70")
  (:PATH "tests/recovery/manifest-support.lisp" :GIT-BLOB
   "7d3b1be9964aba5894215f29b7eda3d7a14a797f")
  (:PATH "tests/recovery/manifest-transition.lisp" :GIT-BLOB
   "cdde7b60edddd974153ee670d859a94993afa367")
  (:PATH "tests/recovery/manifest.lisp" :GIT-BLOB
   "085e019e251106f6feecc7452e7b2d471a1a626f")
  (:PATH "tests/recovery/scan.lisp" :GIT-BLOB
   "1c7d71c32d58b05f7e06450680270cb55f6325dc")
  (:PATH "tests/recovery/support.lisp" :GIT-BLOB
   "f784671c59065b4363bcc5e49f06559b11e6562c")
  (:PATH "tests/runtime/adoption.lisp" :GIT-BLOB
   "8fbee7f08a25445b66895ae2e329a217070f67f4")
  (:PATH "tests/runtime/bootstrap.lisp" :GIT-BLOB
   "1398120574f95ebaec3c7431a74a35e0ced01652")
  (:PATH "tests/runtime/guards.lisp" :GIT-BLOB
   "a097cc38e13a1ef7369a2ed996d042718cf7312c")
  (:PATH "tests/runtime/native.lisp" :GIT-BLOB
   "e92ba03fb8184a6c95c44269a26a831b714974a1")
  (:PATH "tests/runtime/support.lisp" :GIT-BLOB
   "7d4dc59eab68672512aed0f4ae578436e669fe2e")
  (:PATH "tests/runtime/threads.lisp" :GIT-BLOB
   "2454593a231d5d6bb9ef4318eb06567ce3192d24")
  (:PATH "tests/scheduler/controller.lisp" :GIT-BLOB
   "8e14282e1f42f3b247a5c578d8a683ddc6147381")
  (:PATH "tests/scheduler/dispatch.lisp" :GIT-BLOB
   "6a493f0022ac8c9b6117c2a62df49fa596194c7b")
  (:PATH "tests/scheduler/lifecycle.lisp" :GIT-BLOB
   "874391809401f42a4db81fe544306165f99ceb5d")
  (:PATH "tests/scheduler/pool-begin.lisp" :GIT-BLOB
   "13a239cf97403806a73242abbd5b545440a17645")
  (:PATH "tests/scheduler/pool-chain-support.lisp" :GIT-BLOB
   "a1ea8258495b9a717e1e0ef164133f6b7140f8a5")
  (:PATH "tests/scheduler/pool-chain.lisp" :GIT-BLOB
   "86675c17ea47eff262cb03cdb41e50bcdb82b78e")
  (:PATH "tests/scheduler/pool-claim.lisp" :GIT-BLOB
   "f636ee873deb2cd5347a50c9aec4a6afa16d13c5")
  (:PATH "tests/scheduler/pool-recycle.lisp" :GIT-BLOB
   "3c779589cd7df6ae1146c2ca50b70320093bbf4a")
  (:PATH "tests/scheduler/pool-start.lisp" :GIT-BLOB
   "ec19bb409799e7956e40c34cc9264d02033cfb22")
  (:PATH "tests/scheduler/pool-step.lisp" :GIT-BLOB
   "d0ff803608990744408749722210e812f6268782")
  (:PATH "tests/scheduler/support.lisp" :GIT-BLOB
   "f2301a1adf44c33284aaa1171acd90c5828b0396")
  (:PATH "tests/series/boundaries.lisp" :GIT-BLOB
   "ca1e85473a76a5255cc591d7d239cedbd35acbe4")
  (:PATH "tests/series/controller.lisp" :GIT-BLOB
   "ef3d4671b3df48b932c1666f8b58fdca4eecbc77")
  (:PATH "tests/series/log-binding.lisp" :GIT-BLOB
   "c116a9169058ddd9e384fda5f52bb5787977e20e")
  (:PATH "tests/series/support.lisp" :GIT-BLOB
   "257c6f8cf28bdd8408a3363041d621497f4a5f67")
  (:PATH "tests/series/threads.lisp" :GIT-BLOB
   "c3eb1ce7870b81944c23efac9b8cb7f8f4888ba9")
  (:PATH "tests/series/worker-bridge.lisp" :GIT-BLOB
   "cb61feecd1f097cfc86af5de8b169d222b84f7a8")
  (:PATH "tests/series/worker-routing.lisp" :GIT-BLOB
   "59722f73f21ad9d5ce59e1b4785c025054a57cc5")
  (:PATH "tests/smoke.lisp" :GIT-BLOB
   "6bd4ab9af1f3d9eedd54822eae10b7f167aa99ed")
  (:PATH "tests/storage/compaction-scan.lisp" :GIT-BLOB
   "16e5c9e5231883844ecd7956c7f790349acd2a05")
  (:PATH "tests/storage/control-payload.lisp" :GIT-BLOB
   "72358c6f324e1c7aaab2bb2c9d03d39ccf78f664")
  (:PATH "tests/storage/log-header.lisp" :GIT-BLOB
   "b3c4c96603ee769429b847569559defda5059744")
  (:PATH "tests/storage/segment-header.lisp" :GIT-BLOB
   "7155aaf2e9c0df4f96533a0be0f6532b54f44590")
  (:PATH "tests/storage/support.lisp" :GIT-BLOB
   "6aa5df3b3cc62b552f5da890583654b82df99431")
  (:PATH "tests/vertical/method.md" :GIT-BLOB
   "19fd4bc2b408c712bf2b2f7f203b6fda9e68988e")
  (:PATH "tests/vertical/processes.lisp" :GIT-BLOB
   "059fbd2bb702e76e986b97edfbe4d3784599d583")
  (:PATH "tests/vertical/resume.lisp" :GIT-BLOB
   "6f80a0d0fec9f725beca54d06d961932bd815043")
  (:PATH "tests/vertical/scenarios.lisp" :GIT-BLOB
   "fcbc7878d56720604f0e86a916d2e42c0f28cffd")
  (:PATH "tests/vertical/support.lisp" :GIT-BLOB
   "37c2e8d1da68eb425cdd11548f8699c888afd7bf")
  (:PATH "tests/wal/builder.lisp" :GIT-BLOB
   "d62777cd09f8c30fc7246f59fd1bca8ea80c4559")
  (:PATH "tests/wal/csn-threads.lisp" :GIT-BLOB
   "25f9b134556bd4f1a842f536ddc89ba64a76892e")
  (:PATH "tests/wal/csn.lisp" :GIT-BLOB
   "da91333751d4b72259cf766e7441065b8c4387ec")
  (:PATH "tests/wal/fault.lisp" :GIT-BLOB
   "6361a87d73ce90f78438008693a7cd9d6461fe9b")
  (:PATH "tests/wal/group.lisp" :GIT-BLOB
   "04281d9ea3837ed2af0e7fa33b7e17df814982d7")
  (:PATH "tests/wal/native.lisp" :GIT-BLOB
   "077a835fb47524d97e449ae87c74461ebb374653")
  (:PATH "tests/wal/support.lisp" :GIT-BLOB
   "638262b264c64b96774ddb0a6095f4e582debe3e")
  (:PATH "tools/build.lisp" :GIT-BLOB
   "40879533738e1fc49e74941a9def5b089c551921")
  (:PATH "tools/cbor-float-write-audit.lisp" :GIT-BLOB
   "485544868eeadff247968b86c2d5da9b3b610295")
  (:PATH "tools/cbor-float-write-bench.lisp" :GIT-BLOB
   "d992c9f8cf6ff0d748fcb77f871fb77969480bca")
  (:PATH "tools/cbor-float-write-mutation.lisp" :GIT-BLOB
   "5d0d6bd46b0286f153ee9c482734c659959396e2")
  (:PATH "tools/cbor-header-bench.lisp" :GIT-BLOB
   "82b7068432790f9883a56c0b03229003d3541f90")
  (:PATH "tools/cbor-header-mutation.lisp" :GIT-BLOB
   "a47d36577af8e249c045096a5f7270cd628f0df8")
  (:PATH "tools/cbor-minimal-bench.lisp" :GIT-BLOB
   "fd85474e6bbc781a0e5df7c6df3a4891b4da29f7")
  (:PATH "tools/cbor-minimal-mutation.lisp" :GIT-BLOB
   "60b1ac184498623d1364df66e1d95f93165af159")
  (:PATH "tools/cbor-minimal-scan-bench.lisp" :GIT-BLOB
   "3cdd34a3dd5747f7fd0e513a1f2daeb7e2c2bbfb")
  (:PATH "tools/cbor-simple-write-audit.lisp" :GIT-BLOB
   "6acfcc656bfed5f8b4c59e487cffb5325d30d790")
  (:PATH "tools/cbor-simple-write-bench.lisp" :GIT-BLOB
   "07e5b0b7773f95ddae9458267b285c0ccb24dba9")
  (:PATH "tools/cbor-simple-write-mutation.lisp" :GIT-BLOB
   "ec2fe6b3235591ec5b3bb82b32046e906b045bf6")
  (:PATH "tools/cbor-string-read-driver.lisp" :GIT-BLOB
   "a6b65bd233dba2a2eec941d96a75b9db948d19f8")
  (:PATH "tools/cbor-string-write-audit.lisp" :GIT-BLOB
   "ae591bf0f2b37d0ed2ae08f16d0270568268a048")
  (:PATH "tools/cbor-string-write-bench.lisp" :GIT-BLOB
   "c4bd98e145d13deb47b7eedb0f4581a241f1d0e1")
  (:PATH "tools/cbor-string-write-mutation.lisp" :GIT-BLOB
   "ac4e1b095c88051cb9425ed023a8be8311b0108e")
  (:PATH "tools/cbor-structure-bench.lisp" :GIT-BLOB
   "a0a676c0107dee9429f27d3fdcdc78bb3d7f2957")
  (:PATH "tools/cbor-structure-mutation.lisp" :GIT-BLOB
   "e43405f5a6825f420364f112de951013d36b85ca")
  (:PATH "tools/cbor-write-bench.lisp" :GIT-BLOB
   "7ebf958bfc54c312cfd7f80146fec2117529b6f1")
  (:PATH "tools/cbor-write-mutation.lisp" :GIT-BLOB
   "a39159a8f63d995166eabec0a6f6e0836af9f799")
  (:PATH "tools/check-command-archive.lisp" :GIT-BLOB
   "4c56e6f317cc0e1a6785c4071126c6cca7dd68b7")
  (:PATH "tools/check-evidence-normalize.lisp" :GIT-BLOB
   "b15b6ab7edaacfc8d78ab0f36a0416af2e1c306d")
  (:PATH "tools/check-evidence-parallel-tests.lisp" :GIT-BLOB
   "a49a03a64a137e66c07c98f981327fc42d9cb508")
  (:PATH "tools/check-evidence-publication.lisp" :GIT-BLOB
   "458e9b82cea915be89180a02c406522f75175f75")
  (:PATH "tools/check-evidence-storage.lisp" :GIT-BLOB
   "76afc9a986beb31ae7ce37443ad3748b7052bdb4")
  (:PATH "tools/check-evidence.lisp" :GIT-BLOB
   "e3df9f52590ce2de86ad75b872c859b81bbcc518")
  (:PATH "tools/check-links.lisp" :GIT-BLOB
   "f3c9c944076b4bb1d7e4ef5360d7098ed44431d4")
  (:PATH "tools/check-trace.lisp" :GIT-BLOB
   "922737e5a8920ca16f0fae9e4b90835053b0396a")
  (:PATH "tools/ci.lisp" :GIT-BLOB "c0b6255982f4299b883992f5829baaebcd2aaa36")
  (:PATH "tools/ci/archive.lisp" :GIT-BLOB
   "d99223f0114956f620647e60b4f0a1452943185b")
  (:PATH "tools/ci/conditions-self-test.lisp" :GIT-BLOB
   "99f857163fa38683871790731b6f72448cf92ffb")
  (:PATH "tools/ci/coverage.lisp" :GIT-BLOB
   "233ae46d6ab9fab6a74046140323eecc64243174")
  (:PATH "tools/ci/data-self-test.lisp" :GIT-BLOB
   "b5d6a8f505604e3c45d228582933af38713cc01a")
  (:PATH "tools/ci/data.lisp" :GIT-BLOB
   "8cec68fa2e6e5d7e4484a53cde13964b875f9222")
  (:PATH "tools/ci/github.lisp" :GIT-BLOB
   "a2ca20ed9c586b104f59091d174028b3454d6a10")
  (:PATH "tools/ci/identity.lisp" :GIT-BLOB
   "abf3cc722957379e1408d629b81a2d1916a0788b")
  (:PATH "tools/ci/measure-self-test.lisp" :GIT-BLOB
   "18959f2608b1be4ef1b77b0a7d3b1a67735c16d4")
  (:PATH "tools/ci/measure.lisp" :GIT-BLOB
   "fb4b201a543d774c587ebbbc228df2a7d59ffc08")
  (:PATH "tools/ci/producer.lisp" :GIT-BLOB
   "a7fab0bcc8dc6a33ed37acb0d391ec1a73674493")
  (:PATH "tools/ci/publish-self-test.lisp" :GIT-BLOB
   "400b9ba4c1c3fd0e6bd158f3f89bcc58e802c595")
  (:PATH "tools/ci/publish.lisp" :GIT-BLOB
   "3cb48fb1bfa56957b74c2a6d67f83ab69a5dc6ee")
  (:PATH "tools/ci/self-test.lisp" :GIT-BLOB
   "00fd9c61039254a7a49835e3bfa84b714f3af304")
  (:PATH "tools/ci/support.lisp" :GIT-BLOB
   "b5fe7c565ed0f885b666d8dba836bec4a7ba4c65")
  (:PATH "tools/ci/test-self-test.lisp" :GIT-BLOB
   "2cd7248feeb0ff089429cee6f29ab12283665ec4")
  (:PATH "tools/ci/tests.lisp" :GIT-BLOB
   "9c81cf6aec5f89896d9e4ccdcd59ccf1d3c65c6f")
  (:PATH "tools/ci/workflow-self-test.lisp" :GIT-BLOB
   "f0278d9bc21245d6890e52011414627376bca5de")
  (:PATH "tools/collect-command-archive-tests.lisp" :GIT-BLOB
   "49da390b7e170acc9ffdafa78285f215aec75f44")
  (:PATH "tools/collect-command-archive.lisp" :GIT-BLOB
   "d2eb1bd8a62b0fd98ec023243b2a768c19988dc7")
  (:PATH "tools/compact-evidence.lisp" :GIT-BLOB
   "72a1c32b1efcb7fd89ff798a669a558ceffb0aa0")
  (:PATH "tools/compaction-bench.lisp" :GIT-BLOB
   "08ed205d82e6df9e1c044ef6ad714568bb140c0b")
  (:PATH "tools/compaction-mutation.lisp" :GIT-BLOB
   "a8d9a27713e0dfd1d98626aa43e05554285e5aa9")
  (:PATH "tools/control-checkpoint-bench.lisp" :GIT-BLOB
   "f631bbb7096359592fde0ae2b4462c2d2067d5a1")
  (:PATH "tools/control-transition-bench.lisp" :GIT-BLOB
   "40fd5a04dc62cced8e688ed30f59e0d810716a43")
  (:PATH "tools/csn-bench.lisp" :GIT-BLOB
   "6bf306166acbe72f0e57849656d4ab4e06f44c38")
  (:PATH "tools/csn-mutation.lisp" :GIT-BLOB
   "6e34a662d052b72eaf3b318365140f8d7d215851")
  (:PATH "tools/decisions-radix-mutation.lisp" :GIT-BLOB
   "1068f3f3ef7d46253c8ff83109791cd8d40a92e9")
  (:PATH "tools/decisions-sort-bench.lisp" :GIT-BLOB
   "a1bee0418d542eae3800213fc23df402ccd75a41")
  (:PATH "tools/engine-crash.lisp" :GIT-BLOB
   "04c4796c05bdcecf6d8fc83d3ee1eafcf969fed9")
  (:PATH "tools/evidence-size-audit.lisp" :GIT-BLOB
   "6c77f9642dc0fb373677dbcdca579c65cc8f4d83")
  (:PATH "tools/evidence-storage.lisp" :GIT-BLOB
   "fa2b5d36dca0837e2ed5e49b282887b2e110b2b7")
  (:PATH "tools/finish-evidence.lisp" :GIT-BLOB
   "c8ebe7bbe4c99a3c712033d0f58e97610914f87f")
  (:PATH "tools/foundation-bench.lisp" :GIT-BLOB
   "7dcbedc52483f6374b0dad9cf00230f9112f952d")
  (:PATH "tools/foundation-coverage.lisp" :GIT-BLOB
   "abd8e62e937c60e9ac68c3ccce904111388bff09")
  (:PATH "tools/foundation-mutation.lisp" :GIT-BLOB
   "f520ecdb46cc94e07d774d39cb73beed380aa867")
  (:PATH "tools/fulltext-codec-fixture.lisp" :GIT-BLOB
   "f6756e030cdde7beaab41a6b38516950f1663c9e")
  (:PATH "tools/fulltext-persistence.lisp" :GIT-BLOB
   "ab0dbf4ec2e5335721818cc03711b92d7d62111d")
  (:PATH "tools/fulltext-qualification.lisp" :GIT-BLOB
   "d649e9cafa96bcb4351bbced5de04bb10352ab85")
  (:PATH "tools/fulltext-unicode-tables.lisp" :GIT-BLOB
   "387086062f9bca26b853e243a4ce4f34f30e9653")
  (:PATH "tools/get-active-init-bench.lisp" :GIT-BLOB
   "c62f2bf8ba96c3e80cdd50ba067e4c4df3e5e957")
  (:PATH "tools/get-active-init-mutation.lisp" :GIT-BLOB
   "b2cd809d99d049757156ddf0141997e3b67903b4")
  (:PATH "tools/get-directory-bench.lisp" :GIT-BLOB
   "a6aea6c5a019aa377c7dc7c0d70a5e58b0050773")
  (:PATH "tools/get-directory-evidence.lisp" :GIT-BLOB
   "fbebdbcdb40b2e96c0098a987b16ba2fe3c9b7b5")
  (:PATH "tools/get-directory-mutation.lisp" :GIT-BLOB
   "7aa626295770df49dc1fb703137542de1c93564c")
  (:PATH "tools/get-performance-bench.lisp" :GIT-BLOB
   "be5fc283b3c06bc60548ea32c240ebf8d9ecafc2")
  (:PATH "tools/get-performance-evidence.lisp" :GIT-BLOB
   "f098cdb4cf5f0447365cf0bf255e1935d04bc53b")
  (:PATH "tools/get-performance-mutation.lisp" :GIT-BLOB
   "231cb906b55b9c92905deefc112f7baebecbd4af")
  (:PATH "tools/get-resolver-coverage.lisp" :GIT-BLOB
   "5ab21d923b68e35adbc177ecd352bb33340f0c07")
  (:PATH "tools/get-series-bench.lisp" :GIT-BLOB
   "2950d4fcb7fc93fbfc7d78c860f0ac43ed984f35")
  (:PATH "tools/get-series-capture.lisp" :GIT-BLOB
   "9c42e23d381751e8140f186f969c6c2ef8d606cf")
  (:PATH "tools/get-series-mutation.lisp" :GIT-BLOB
   "3d3e887ba8e1d90612e561dfffb3d71c486e813b")
  (:PATH "tools/index-rebuild-bench.lisp" :GIT-BLOB
   "0f6143fe0f69d972eb3723adb98cf4c1df1f7033")
  (:PATH "tools/index-rebuild-evidence.lisp" :GIT-BLOB
   "ba2c92a3dd88e2414b5500739eb5622da1d91d6b")
  (:PATH "tools/index-rebuild-mutation.lisp" :GIT-BLOB
   "8d60f445b933c82a6c6dbe98e4c9c3f7b1589340")
  (:PATH "tools/io-bench.lisp" :GIT-BLOB
   "ccb75032fce4765f0db7948cb594ef14f50be36e")
  (:PATH "tools/io-completion-mutation.lisp" :GIT-BLOB
   "7fd59fd86e2d477a6b6ee0f7a2142f8ea6b073c6")
  (:PATH "tools/io-rename-bench.lisp" :GIT-BLOB
   "988d259af126212adc2be8fb9ca9acd8755fdce0")
  (:PATH "tools/io-rename-mutation.lisp" :GIT-BLOB
   "dfc691c88e9ab940a065703a223a1c414454b0f2")
  (:PATH "tools/key-hash-bench.lisp" :GIT-BLOB
   "c86f91b92ba547d6fd0ad4f2b38710281d7c19db")
  (:PATH "tools/key-hash-evidence.lisp" :GIT-BLOB
   "7a54d7baa419f642b610d8d939b9048125e0efe6")
  (:PATH "tools/key-hash-mutation.lisp" :GIT-BLOB
   "5209188cf4f85d6f28b07e8e526ea859da91c083")
  (:PATH "tools/lint.lisp" :GIT-BLOB
   "adf3ca235874a2b950e57ea61a719c4c90e9dda8")
  (:PATH "tools/local-client.lisp" :GIT-BLOB
   "1ab2f474ad7db04a3fc8cc6dd7e84a2441498d20")
  (:PATH "tools/local-fault-server.lisp" :GIT-BLOB
   "92cd3d6164c6000c181374e3b917bbf1bb83aaa6")
  (:PATH "tools/local-server.lisp" :GIT-BLOB
   "517652d80ad2d4fbbe85be42fa110d4c902d8cf8")
  (:PATH "tools/local-tests.lisp" :GIT-BLOB
   "02aace929b7f5e2fd790c02d1557628ea17d7afc")
  (:PATH "tools/log-header-bench.lisp" :GIT-BLOB
   "acf45c9c691752a1f1516ca92d71459a3c94d5bd")
  (:PATH "tools/log-header-mutation.lisp" :GIT-BLOB
   "3c1e7eaa014e7ebf57b42c2bb83b4f448eeec31b")
  (:PATH "tools/measure-pool-begin.lisp" :GIT-BLOB
   "e3094d9f35efdaa647751f19a7acda00c36d515a")
  (:PATH "tools/measure-pool-claim.lisp" :GIT-BLOB
   "712a4a5393b69539f02cd625223918e404b331d3")
  (:PATH "tools/measure-pool-dispatch.lisp" :GIT-BLOB
   "bddb449176d3b7b6ae946e841a0ca3202e6c28ef")
  (:PATH "tools/measure-pool-lifecycle.lisp" :GIT-BLOB
   "3a229eecc3c158cec9af8fad6abd5fc2d980e2dd")
  (:PATH "tools/measure-pool-recycle.lisp" :GIT-BLOB
   "cb20f6d271889a9801106daf230ee934aaa7bf81")
  (:PATH "tools/measure-pool-start.lisp" :GIT-BLOB
   "e6be453833925b89cdc49303b99a23374f3b2689")
  (:PATH "tools/measure-pool-step.lisp" :GIT-BLOB
   "cdcb410e27475282d157b0d64a4656ea6ad069a1")
  (:PATH "tools/normalize-spike-report.lisp" :GIT-BLOB
   "e745f0c67e0abf3a9ea1bbc2981f6331ffc48e4c")
  (:PATH "tools/pool-controller-bench.lisp" :GIT-BLOB
   "cf6f31dd9c7a8d7f4e7cc1f19c4b9c5a48af6d55")
  (:PATH "tools/read-evidence.lisp" :GIT-BLOB
   "c41d27bfad39875f6c80858d451bacfcac862945")
  (:PATH "tools/reader-mutation.lisp" :GIT-BLOB
   "256252a0cdeb1d62bce34cee030093858fd2a5f8")
  (:PATH "tools/record-command.lisp" :GIT-BLOB
   "e52bad14e6bdbadae7cd005488a5ae8bac281d53")
  (:PATH "tools/recovery-active-bench.lisp" :GIT-BLOB
   "9c11d5654a6168c27c64abcc8f852673c5974515")
  (:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "f4951198a9198f32cf064534bbdc42d7bf3be9f8")
  (:PATH "tools/series-controller-bench.lisp" :GIT-BLOB
   "e1150055aeba7db590f07bb4e041094a9816fd4e")
  (:PATH "tools/series-controller-evidence.lisp" :GIT-BLOB
   "48e94f7e3432d29c29ec0ac1c75834769ba93dcd")
  (:PATH "tools/series-controller-mutation.lisp" :GIT-BLOB
   "ac124ab2fdd0d7562c0c8af8dc03153b2abde3f1")
  (:PATH "tools/snapshot-mutation.lisp" :GIT-BLOB
   "b46e9d42dd1c21e28ebbd661afe3ee05a1749fcd")
  (:PATH "tools/storage-bench.lisp" :GIT-BLOB
   "1da33e31673c8ab8458292350ac44fff2a5e96b3")
  (:PATH "tools/utf8-bench.lisp" :GIT-BLOB
   "a5edc926e662d0259712840d502a1f1a13143399")
  (:PATH "tools/utf8-mutation.lisp" :GIT-BLOB
   "27769759bb927e2055d711a6e723a69c468b0a0c")
  (:PATH "tools/vertical-crash.lisp" :GIT-BLOB
   "8f920374d5b1049f5bac1e8dfb441099575de6cd")
  (:PATH "tools/wal-bench.lisp" :GIT-BLOB
   "e6a3c8104fb0b7ebfaaff3e7966ad6d46d8a23ff")
  (:PATH "tools/wal-csn-bench.lisp" :GIT-BLOB
   "686671a5ea321554bbde0bbe6952d1d09a568f65")
  (:PATH "tools/wal-csn-mutation.lisp" :GIT-BLOB
   "b2413c756269e73eb3b08576d42f9584e311ee71")
  (:PATH "tools/worker-routing-bench.lisp" :GIT-BLOB
   "062e8dbbfb0fc912af22d037091d8b1b64f07b1e")
  (:PATH "tools/worker-series-bench.lisp" :GIT-BLOB
   "2d9b7fca164ef84543bb3c0f68c525e6813a8a8c")
  (:PATH "tools/writer-handoff-bench.lisp" :GIT-BLOB
   "7222a4a43a9be50653f8c63b1d09b37a249347c0")
  (:PATH "tools/writer-handoff-mutation.lisp" :GIT-BLOB
   "cafc0dbaedb6671672f994dfd86814d72f3307b8")
  (:PATH "tools/writer-queue-bench.lisp" :GIT-BLOB
   "6eda115b6379e6639aaff706c557f2e0c4e08b3d")
  (:PATH "tools/writer-queue-mutation.lisp" :GIT-BLOB
   "124778bd5b293d0436acf29c1bfa58480de1f701")
  (:PATH "tools/writer-ready-bench.lisp" :GIT-BLOB
   "f666bc8d68738c65c442404ffffc6d342a020c9b")
  (:PATH "tools/writer-ready-mutation.lisp" :GIT-BLOB
   "1401a183d345aedb1eb7eb07e3331180325fb07a")
  (:PATH "tools/writer-recycle-bench.lisp" :GIT-BLOB
   "e41b25ceb84621af27f22f11f7ad4ee11bd4a1b8")
  (:PATH "tools/writer-recycle-mutation.lisp" :GIT-BLOB
   "6ed4f867fd875231189f99367958300b2cecaab7")
  (:PATH "tools/writer-worker-bench.lisp" :GIT-BLOB
   "1208ddc9971179fc3fcb9300a9ba3c22fcd4a8b9")
  (:PATH "tools/writer-worker-mutation.lisp" :GIT-BLOB
   "568bccdb1229b124e43e5c1b756cf726ead6fcbc"))
 :STDOUT "ok    package ARCDOCDB presente
ok    ARCDOCDB:*VERSION* è una stringa
ok    TEST-REQ-IDX-001-HASH-ORACLE-UPSTREAM-ANCHORS
ok    TEST-REQ-IDX-001-HASH-VECTORS
ok    TEST-REQ-IDX-001-HASH-SEED-HIGH
ok    TEST-REQ-IDX-001-HASH-LENGTH
ok    TEST-REQ-IDX-001-HASH-TAIL
ok    TEST-REQ-IDX-001-HASH-BLOCKS
ok    TEST-REQ-IDX-001-HASH-EMPTY-SPANS-AT-BUFFER-EDGES
ok    TEST-REQ-IDX-001-HASH-ALL-TAILS-AT-SPAN-CEILING
ok    TEST-REQ-IDX-001-HASH-BOUNDARIES-32-8-4-THROUGH-65K
ok    TEST-REQ-IDX-001-HASH-ALL-256-SINGLE-OCTETS
ok    TEST-REQ-IDX-001-HASH-ZERO-FF-ORDERED-AND-ASYMMETRIC-LANES
ok    TEST-REQ-IDX-001-HASH-OUTSIDE-SPAN-DIFFERS-AND-ALL-BYTES-STAY-UNCHANGED
ok    TEST-REQ-IDX-001-HASH-SEED-AND-CALL-HISTORY-HAVE-NO-STATE
  XXH64 corpus: seed 6483BEEF, 256 span finiti di 0..65535 byte.
ok    TEST-REQ-IDX-001-HASH-FINITE-CORPUS-FIXED-SEED-6483BEEF
ok    TEST-REQ-IDX-001-HASH-EVERY-BYTE-IN-SELECTED-SPANS-PARTICIPATES
ok    TEST-REQ-IDX-001-HASH-NAMED-PUBLIC-CALLER-WITH-T-ARGUMENTS
ok    TEST-REQ-IDX-001-HASH-INVALID-BUFFERS-AND-NONSIMPLE-ARRAYS
ok    TEST-REQ-IDX-001-HASH-INVALID-INDEX-TYPES-AND-NEGATIVE-INDICES
ok    TEST-REQ-IDX-001-HASH-INVALID-SEEDS-IN-EACH-HALF
ok    TEST-REQ-IDX-001-HASH-VALID-INDEX-TYPES-BUT-INVALID-BUFFER-RANGE
ok    TEST-REQ-IDX-001-HASH-SPAN-65536-AND-LARGER-REJECTED-WITHOUT-MUTATION
ok    TEST-REQ-IDX-001-HASH-VALIDATION-ARGUMENTS-RANGE-SPAN-PRECEDENCE
ok    TEST-REQ-IDX-001-HASH-ABSOLUTE-INDICES-MAY-EXCEED-SPAN-LIMIT
ok    TEST-REQ-IDX-001-HASH-U32-SIGN-BITS-AND-ASYMMETRIC-WORD-ORDER
  XXH64 heap: 64 finestre seriali, 16448 chiamate misurate, atteso 0 byte.
ok    TEST-REQ-IDX-001-HASH-ZERO-HEAP-IN-SERIAL-CALL-WINDOWS
ok    TEST-REQ-IDX-001-HASH-BLOCK-RELATIONAL-GUARDS
ok    TEST-REQ-IDX-001-HASH-TAIL-RELATIONAL-GUARDS
  XXH64 thread: quattro worker privati, 1220 risultati, ready/join limitati.
ok    TEST-REQ-IDX-001-HASH-FOUR-REAL-WORKERS-WITH-PRIVATE-INPUT-AND-BOUNDED-CLEANUP
28 test XXH64 superati.
ok    TEST-REQ-AFF-004-TYPED-ERRORS-RENDERING
ok    TEST-REQ-FOR-003-OUT-OF-LINE-READERS
ok    TEST-REQ-FOR-003-LITTLE-ENDIAN
ok    TEST-REQ-FOR-003-RANGES
ok    TEST-REQ-FOR-003-CRC-KNOWN-VECTORS
ok    TEST-REQ-FOR-003-CRC-DIFFERENTIAL-INCREMENTAL
ok    TEST-REQ-FOR-003-WORD-ENCODING-INDEPENDENT-ORACLE
ok    TEST-REQ-LIM-001-WORD-ENCODING-PREFLIGHT
ok    TEST-REQ-FOR-003-INDEPENDENT-ENCODING-ORACLE
ok    TEST-REQ-LIM-001-ROUNDTRIP-VERSIONS
ok    TEST-REQ-LIM-003-KEY-BOUNDARIES
ok    TEST-REQ-LIM-001-DOCUMENT-BOUNDARIES
ok    TEST-REQ-FOR-003-EVERY-BYTE-CORRUPTION
ok    TEST-REQ-FOR-003-EVERY-TRUNCATION
ok    TEST-REQ-FOR-003-VALID-CRC-INVALID-FIELDS
ok    TEST-REQ-LIM-001-PREFLIGHT-NO-PARTIAL-WRITE
ok    TEST-REQ-AFF-002-INDEX-IDENTITY
ok    TEST-REQ-FOR-004-PREPARED-OUTCOME
ok    TEST-REQ-FOR-003-CONTROL-RECORD-SHAPES
ok    TEST-REQ-LIM-001-SEMANTIC-BOUNDARIES
ok    TEST-REQ-FOR-004-OUTCOME-PROVENANCE-FIELDS
ok    TEST-REQ-FOR-004-U64-BOTH-WORDS
ok    TEST-REQ-FOR-003-SEALED-BATCHES
ok    TEST-REQ-FOR-003-BATCH-ALL-TRUNCATIONS
ok    TEST-REQ-FOR-003-BATCH-SEAL-SEMANTIC-CORRUPTION
ok    TEST-REQ-FOR-003-BATCH-STAMP-AND-TYPE
ok    TEST-REQ-LIM-003-BATCH-BUDGETS
ok    TEST-REQ-FOR-004-BATCH-TXID-INDEPENDENT-OF-SEAL-CSN
28 test delle fondazioni superati.
ok    REQ-SEC-008-WIRE-INDEPENDENT
  Cornice full text: 3168 alterazioni singole rilevate.
ok    REQ-SEC-008-EVERY-SINGLE-BIT
ok    REQ-SEC-008-EVERY-TRUNCATION
ok    REQ-SEC-008-EMPTY-SECTIONS
ok    REQ-SEC-008-NO-SEMANTIC-PROMOTION
ok    REQ-SEC-008-META-BUDGET-EDGE
ok    REQ-SEC-008-CRC-VALID-HEADER-ERRORS
ok    REQ-SEC-008-CRC-VALID-DIRECTORY-ERRORS
ok    REQ-SEC-010-PREFLIGHT-PRESERVES-DESTINATION
ok    REQ-SEC-010-READER-INPUT-AND-BUDGET
ok    REQ-SEC-008-PARALLEL-INDEPENDENT-BUFFERS
11 test della cornice full text superati.
Unicode 18 NFC: 20171 righe, 100855 confronti.
ok    REQ-SEC-007-NORMALIZATION-CONFORMANCE
Unicode 18 Word_Break: 1944 righe, 8487 confini.
ok    REQ-SEC-007-WORD-BREAK-CONFORMANCE
Unicode 18 case fold C/F: 1606 mapping.
ok    REQ-SEC-007-FULL-CASE-FOLD-CONFORMANCE
ok    REQ-SEC-007-SCALAR-READER-EXHAUSTIVE
ok    REQ-SEC-007-PROFILE-EXAMPLES
ok    REQ-SEC-007-STATE-AND-UTF8-GUARDS
ok    REQ-SEC-010-ANALYSIS-BUDGETS
ok    REQ-SEC-004-POSITIONAL-PHRASES-AND-VERSIONS
Run posizionale: 115200 confronti con scansione indipendente.
ok    REQ-SEC-004-INDEX-DIFFERENTIAL
ok    REQ-SEC-010-INDEX-CAPACITY-AND-STATE
Cornice: 0 byte consed per 1000 scritture + verifiche.
ok    REQ-SEC-008-FRAMING-ALLOCATION
Analisi + query: 0 byte consed per 1000 operazioni.
ok    REQ-SEC-010-HOT-PATH-ALLOCATION
ok    REQ-SEC-007-ANALYSIS-CONCURRENT-READERS
13 test dell'analisi full text superati.
ok    REQ-SEC-008-CODEC-GOLDEN-INDEPENDENT
ok    REQ-SEC-008-PERSISTED-QUERY-SEMANTICS
ok    REQ-SEC-008-EMPTY-AND-MULTIPLE-FIELDS
Codec: 3744 bit e 468 troncamenti rifiutati.
ok    REQ-SEC-008-EVERY-BIT-AND-TRUNCATION
ok    REQ-SEC-008-CODEC-CRC-VALID-BODY-ERRORS
ok    REQ-SEC-008-CODEC-TERM-PROFILE-CORRUPTION
ok    REQ-SEC-008-META-AUTHORITY-AND-PROFILE
ok    REQ-SEC-010-CODEC-PREFLIGHT-PRESERVES-DESTINATION
ok    REQ-SEC-010-CODEC-SCRATCH-AND-WORK
ok    REQ-SEC-008-DESCRIPTOR-OWNS-CONFIGURATION
ok    REQ-SEC-008-CANDIDATE-CONTRACT-BEFORE-WRITE
Codec/query, ID 1: 0 byte consed per 1000 operazioni.
Codec/query, ID 18446744073709551615: 0 byte consed per 1000 operazioni.
ok    REQ-SEC-010-CODEC-HOT-ALLOCATION
Indice serializzato: 43200 confronti con scansione indipendente.
ok    REQ-SEC-008-PERSISTED-INDEX-DIFFERENTIAL
Fuzz CRC valido: 1020 rifiuti tipizzati, 4 varianti valide.
ok    REQ-SEC-008-CODEC-CRC-VALID-FUZZ
ok    REQ-SEC-008-PERSISTED-PARALLEL-READERS
15 test del codec completo full text superati.
ok    REQ-SEC-003-CBOR-NNTP-INDEPENDENT-WIRE
ok    REQ-SEC-010-DOCUMENT-BOUND-DISTINCT-AND-EMPTY
ok    REQ-SEC-007-DOCUMENT-NESTED-AND-UNICODE
ok    REQ-SEC-003-DOCUMENT-TAGGED-AND-COMPLEX-KEYS
ok    REQ-SEC-003-DOCUMENT-CONFIG-OWNED-AND-FIXED-IDS
ok    REQ-SEC-003-DOCUMENT-SELECTED-TYPES-AND-DUPLICATES
ok    REQ-SEC-003-DOCUMENT-ENTIRE-CBOR-IS-VALIDATED
ok    REQ-SEC-010-DOCUMENT-AGGREGATE-LIMITS
ok    REQ-SEC-010-DOCUMENT-WORK-NODES-AND-FILE-BUDGET
ok    REQ-SEC-010-DOCUMENT-CANCEL-AND-REUSE-AT-EVERY-PHASE
ok    REQ-SEC-010-DOCUMENT-PREFLIGHT-KEEPS-PRIOR-RESULT
ok    REQ-SEC-003-DOCUMENT-CONFIG-GUARDS
ok    REQ-SEC-003-DOCUMENT-DEPTH-AND-SIBLING-FRAMES
Documenti CBOR: 115200 confronti indipendenti su run e file, 128 bound verificati.
ok    REQ-SEC-003-DOCUMENT-INDEPENDENT-DIFFERENTIAL
ok    REQ-SEC-003-DOCUMENT-ALL-SIXTEEN-FIELDS
Preparazione CBOR, ID 1: 0 byte consed per 1000 operazioni.
Preparazione CBOR, ID 18446744073709551615: 0 byte consed per 1000 operazioni.
ok    REQ-SEC-010-DOCUMENT-HOT-ALLOCATION
ok    REQ-SEC-006-DOCUMENT-PARALLEL-WORKERS
17 test della preparazione documentale full text superati.
ok    REQ-SEC-003-RESERVATION-OWNED-NNTP-RUNS
Ledger indipendente: 256 confronti di bound su 128 operazioni.
ok    REQ-SEC-010-RESERVATION-INDEPENDENT-LEDGER
ok    REQ-SEC-003-RESERVATION-ALL-SIXTEEN-GENERATIONS
ok    REQ-SEC-003-RESERVATION-ATOMIC-CONTRACT-AND-ROW
ok    REQ-SEC-006-RESERVATION-BORROW-AND-GENERATION
ok    REQ-SEC-010-RESERVATION-PUBLIC-INPUT-GUARDS
ok    REQ-SEC-010-RESERVATION-COLD-GUARDS-AND-OWNED-CONFIG-VECTOR
ok    REQ-SEC-010-RESERVATION-LAST-INDEX-REFUSAL
ok    REQ-SEC-010-RESERVATION-FILE-BOUNDS-AND-ROTATION
ok    REQ-SEC-010-RESERVATION-CUMULATIVE-MEMORY-BUDGETS
ok    REQ-SEC-010-RESERVATION-RUN-AND-SLOT-BUDGETS
ok    REQ-SEC-006-RESERVATION-EMPTY-DOCUMENT-HOLDS-SLOT
ok    REQ-SEC-006-RESERVATION-CANCELLATION-AT-EVERY-COPY-STAGE
ok    REQ-SEC-010-RESERVATION-TRANSFER-RETAINS-HISTORICAL-COST
ok    REQ-SEC-006-RESERVATION-STALE-LEASE-AND-FOREIGN-TOKEN
ok    REQ-SEC-006-RESERVATION-LOST-SOURCE-FAIL-STOP
ok    REQ-SEC-006-RESERVATION-INTERRUPTED-ADOPTION-FAIL-STOP
ok    REQ-SEC-003-ROW-DIRECTORY-INDEPENDENT-MODEL
ok    REQ-SEC-010-ROW-DIRECTORY-CAPACITY-AND-COLD-MEMORY
ok    REQ-SEC-006-ROW-DIRECTORY-CANCEL-REUSE-AND-PRIVATE-PENDING
ok    REQ-SEC-010-ROW-DIRECTORY-REJECTIONS-WITHOUT-EFFECTS
ok    REQ-SEC-006-ROW-DIRECTORY-INTERRUPTED-INSERT
ok    REQ-SEC-006-ROW-DIRECTORY-INTERRUPTED-REMOVE
ok    REQ-SEC-006-ROW-DIRECTORY-CORRUPTION-FAIL-STOP
Riserve/copia/query, ID 1: 0 byte consed per 1000 operazioni.
Riserve/copia/query, ID 18446744073709551615: 0 byte consed per 1000 operazioni.
ok    REQ-SEC-010-RESERVATION-HOT-ALLOCATION
ok    REQ-SEC-006-RESERVATION-FOUR-INDEPENDENT-WRITERS
26 test delle riserve full text superati.
ok    REQ-SEC-003-PUT-OWNED-RECORD-INDEPENDENT-WIRE
ok    REQ-SEC-003-PUT-RECORD-NUMBER-IS-NOT-HINT-ROW
ok    REQ-WAL-005-FRAME-APPEND-RANGES-AND-CAPACITY
ok    REQ-SEC-010-PUT-CUMULATIVE-WORK-AND-MEMORY
ok    REQ-WAL-005-PUT-WRITER-DOES-NOT-SCAN-BODY
ok    REQ-WAL-005-FRAME-PREFLIGHT-NO-PARTIAL-EFFECT
ok    REQ-SEC-006-PUT-START-REJECTIONS-PRESERVE-PREVIOUS
ok    REQ-SEC-003-PUT-INVALID-DOCUMENT-NEVER-RESERVED
ok    REQ-SEC-010-PUT-RESERVATION-REFUSAL-PRESERVES-COHORT
ok    REQ-SEC-003-PUT-APPEND-PREFLIGHT-RETAINS-RESERVATION
ok    REQ-WAL-005-PUT-WORKER-ATTESTS-FRAME-BEFORE-RESERVATION
ok    REQ-WAL-005-PUT-STALE-BATCH-INCARNATION
ok    REQ-SEC-006-PUT-CANCEL-AND-REUSE-STAGES
ok    REQ-SEC-006-PUT-WRONG-LEASE-AND-GENERATION
ok    REQ-SEC-006-PUT-INTERRUPTED-APPEND-FAIL-STOP
ok    REQ-SEC-003-PUT-ALL-SIXTEEN-GENERATIONS
PUT/analisi/riserva/WAL/query, ID 1: 0 byte consed per 1000 operazioni.
PUT/analisi/riserva/WAL/query, ID 18446744073709551615: 0 byte consed per 1000 operazioni.
ok    REQ-SEC-010-PUT-HOT-ALLOCATION
ok    REQ-SEC-006-PUT-FOUR-INDEPENDENT-WORKERS
ok    REQ-SEC-004-REFERENCE-V1-V2-ORDINARY-PREPARED-BOUNDARIES
ok    REQ-SEC-004-REFERENCE-SURVIVES-REAL-BATCH-RETIREMENT
ok    REQ-WAL-005-REFERENCE-HEADER-ONLY-CRC
ok    REQ-SEC-006-REFERENCE-INTERRUPTED-CAPTURE-FAIL-STOP
ok    REQ-SEC-006-REFERENCE-FOUR-INDEPENDENT-WRITERS
ok    REQ-SEC-006-REFERENCE-REJECTIONS-PRESERVE-STATE
ok    REQ-WAL-005-REFERENCE-REJECTS-MANUAL-AND-LATE-SEALS
ok    REQ-WAL-005-REFERENCE-HEADER-CORRUPTION-FAIL-STOP
ok    REQ-SEC-004-REFERENCE-NATIVE-FILE-INDEPENDENT-RECORD
ok    REQ-SEC-004-ROW-REFERENCE-STAGES-AND-STAMPS
ok    REQ-SEC-004-ROW-REFERENCE-SURVIVES-WAL-REUSE
ok    REQ-SEC-006-ROW-REFERENCE-CANCEL-GENERIC-AND-INPUTS
ok    REQ-SEC-006-ROW-REFERENCE-INCONSISTENT-PHYSICAL-FAIL-STOP
31 test del legame PUT full text superati.
ok    TEST-REQ-AFF-004-UTF8-REFERENCE-IS-STRICT
ok    TEST-REQ-AFF-004-UTF8-EMPTY-ASCII-AND-DEFAULT-BUDGET
ok    TEST-REQ-AFF-004-UTF8-INVALID-RANGE-AND-BUFFER
ok    TEST-REQ-AFF-008-UTF8-INVALID-BUDGET
ok    TEST-REQ-AFF-008-UTF8-BYTE-BUDGET-PRECEDES-CONTENT
ok    TEST-REQ-AFF-004-UTF8-ALL-256-SINGLE-BYTE-INPUTS
  UTF-8 esaustivo: 65536 coppie, 18304 valide, 47232 rifiutate.
ok    TEST-REQ-AFF-004-UTF8-ALL-65536-TWO-BYTE-INPUTS
ok    TEST-REQ-AFF-004-UTF8-MANUAL-SCALAR-BOUNDARIES
ok    TEST-REQ-AFF-004-UTF8-NUL-BOM-NONCHARACTERS-AND-NO-NORMALIZATION
ok    TEST-REQ-AFF-004-UTF8-ILLEGAL-LEADING-OFFSET
ok    TEST-REQ-AFF-004-UTF8-TRUNCATION-BEFORE-CONTENT
ok    TEST-REQ-AFF-004-UTF8-CONTINUATION-OFFSET-AND-PRIORITY
ok    TEST-REQ-AFF-004-UTF8-SCALAR-RESTRICTIONS-AFTER-CONTINUATIONS
ok    TEST-REQ-AFF-004-UTF8-SEEDED-SCALAR-STREAM-AND-SLICES
  UTF-8 fuzz: seed 3629A11F, 4096 input di 3..8 byte, 234 validi, 3862 rifiutati.
ok    TEST-REQ-AFF-004-UTF8-DIFFERENTIAL-FUZZ-4096-INPUTS
ok    TEST-REQ-LIM-001-UTF8-EXACT-SIXTEEN-MIB-AND-OVER-BUDGET
  UTF-8: 2 worker, 128 verifiche, 83886080 byte; WALL fixture con controlli/rendezvous: worker 0 start/first/end 209810306/209815641/210071916, sink 16777216; worker 1 start/first/end 209810338/209814200/210069771, sink 16777216; overlap 259433 tick (1000000 tick/s); nessuna inferenza su tempo puro primitiva, CPU o scaling.
ok    TEST-REQ-CON-005-UTF8-TWO-PRIVATE-BUFFERS-AND-REAL-CPU-OVERLAP
17 test UTF-8 superati.
ok    TEST-REQ-AFF-004-CBOR-ALL-256-COMPLETE-LEADING-BYTES
ok    TEST-REQ-AFF-004-CBOR-ALL-256-ONE-BYTE-SPANS
ok    TEST-REQ-AFF-004-CBOR-ALL-256-EXTENDED-SIMPLE-VALUES
  CBOR BE: 65536 argomenti a 16 bit, compresi quelli non minimi.
ok    TEST-REQ-AFF-004-CBOR-ALL-65536-BIG-ENDIAN-TWO-BYTE-ARGUMENTS
ok    TEST-REQ-AFF-004-CBOR-IMMEDIATE-VALUES-WITHOUT-BODY-OR-TAG-CHILD
ok    TEST-REQ-AFF-004-CBOR-RAW-WIDTHS-PRESERVE-NONMINIMAL-ARGUMENTS
ok    TEST-REQ-AFF-004-CBOR-U64-EXTREMES-AND-ASYMMETRIC-WORDS
ok    TEST-REQ-AFF-004-CBOR-FLOATING-BITS-ZERO-SIGN-INFINITY-AND-NAN
ok    TEST-REQ-AFF-004-CBOR-INDEFINITE-AND-BREAK-ARE-CONTEXT-FREE-MARKERS
ok    TEST-REQ-AFF-004-CBOR-RESERVED-AND-ILLEGAL-INDEFINITE-PRECEDE-ARGUMENTS
ok    TEST-REQ-AFF-004-CBOR-EVERY-ARGUMENT-TRUNCATION-AND-DECLARED-END
ok    TEST-REQ-AFF-004-CBOR-SIMPLE-CHECK-FOLLOWS-COMPLETE-HEAD
ok    TEST-REQ-AFF-004-CBOR-INVALID-BUFFER-AND-RANGE-BEFORE-CONTENT
ok    TEST-REQ-AFF-004-CBOR-EMPTY-VALID-SPANS-HAVE-END-OFFSET
ok    TEST-REQ-AFF-004-CBOR-MISALIGNED-HEADS-IGNORE-TRAILING-BYTES
  CBOR fuzz: seed 8949A11F, 4096 span di 1..9 byte, 3437 validi, 659 rifiutati.
ok    TEST-REQ-AFF-004-CBOR-DIFFERENTIAL-FUZZ-4096-BOUNDED-SPANS
  CBOR header read: 2 worker, 2097152 header, 18874368 byte; WALL fixture con controlli/rendezvous: worker 0 start/first/end 210106352/210106976/210151114, sink 2401919800705024; worker 1 start/first/end 210106376/210107109/210148110, sink 2231683637051392; overlap 41734 tick (1000000 tick/s); nessuna inferenza su tempo puro primitiva, CPU o scaling.
ok    TEST-REQ-CON-005-CBOR-TWO-PRIVATE-BUFFERS-AND-REAL-CPU-OVERLAP
17 test degli header CBOR superati.
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-ALL-LEADING-BYTES-AND-SHORT-SPANS
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-MAJOR-ZERO-TO-SIX-WIDTH-THRESHOLDS
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-ALL-EXTENDED-SIMPLE-VALUES
  CBOR minimo: 65536 half e 131072 espansioni esatte, inclusi NaN e segni.
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-ALL-HALF-AND-EXACT-EXPANSIONS
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-IEEE-ORACLE-KNOWN-VALUES
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-RFC-NUMERIC-VECTORS-AND-ADJACENT-VALUES
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-FINITE-NORMAL-SUBNORMAL-BOUNDARIES
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SIGN-ZERO-INFINITY-AND-NAN-PAYLOAD
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-EVERY-TRUNCATED-HEAD-BEFORE-PREFERENCE
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SYNTAX-BEFORE-NONMINIMAL
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-INVALID-BUFFER-RANGE-AND-EMPTY-SPAN
ok    TEST-REQ-LIM-002-CBOR-MINIMAL-HEADER-ONLY-AND-MISALIGNED-SENTINELS
  CBOR minimo fuzz: seed4D494E43, 4096word32+4096word64+4096span0..9, 11223 accettati/1065 rifiutati/84 nonminimi.
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-FINITE-DIFFERENTIAL-FUZZ-SEED-4D494E43
  CBOR minimo: 2 worker, 524288 header, 4718592 byte; WALL fixture con rendezvous/controlli: worker 0 start/first/end 210394869/210394870/210417300, sink 1406013828104192; worker 1 start/first/end 210395006/210395007/210415949, sink 5628138478764032; overlap 20943 tick (1000000 tick/s); nessuna inferenza su tempo puro decoder, CPU o scaling.
ok    TEST-REQ-CON-005-CBOR-MINIMAL-TWO-PRIVATE-WORKERS-REAL-WORK-INTERVALS
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-PUBLIC-SUBNORMAL-ALIGNMENT-PAIRS
15 test delle testate CBOR minime superati.
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-RFC-DEFINITE-VECTORS
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-RFC-INDEFINITE-VECTORS
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-GENERIC-PROFILE-PERMISSIONS
  CBOR structure AST: seed 7394B21D, 256 casi generati.
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-GENERATED-AST-CORPUS
  CBOR structure lead: 512 span, 41 validi/471 rifiutati.
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-ALL-LEADS-TWO-BYTE-SPANS
  CBOR structure fuzz: seed 49CBA017, 30 validi/4066 rifiutati.
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-SEEDED-FINITE-DIFFERENTIAL
ok    TEST-REQ-AFF-008-CBOR-STRUCTURE-TRUNCATION-AT-EVERY-BOUNDARY
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-EXACT-ROOT-AND-TRAILING-PRIORITY
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-BREAK-CONTEXT-AND-TAG-PRIORITY
ok    TEST-REQ-AFF-008-CBOR-STRUCTURE-TAGS-CHARGE-PARENT-ONCE
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-CHUNKS-SAME-TYPE-AND-HEADER-FIRST
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-VALID-UNICODE-AND-CHUNK-LOCALITY
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-INVALID-UNICODE-EXACT-OFFSETS
ok    TEST-REQ-AFF-008-CBOR-STRUCTURE-PAYLOAD-WIDTH-AND-HUGE-UNSIGNED-LENGTHS
ok    TEST-REQ-AFF-008-CBOR-STRUCTURE-CONTAINER-MINIMUM-REMAINING-BYTES
ok    TEST-REQ-AFF-008-CBOR-STRUCTURE-DEPTH-100-AND-MAP-KEYS
ok    TEST-REQ-AFF-008-CBOR-STRUCTURE-NODE-BOUNDARIES-CHUNKS-AND-BREAKS
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-HEADER-ERRORS-BEFORE-NODE-BUDGET
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-INVALID-RANGE-AND-TYPE-PRIORITY
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-WORKSPACE-ALIAS-AND-PREFLIGHT-IMMUTABILITY
ok    TEST-REQ-AFF-004-CBOR-STRUCTURE-LIMIT-CONFIGURATION-AND-ORDER
ok    TEST-REQ-AFF-008-CBOR-STRUCTURE-BYTE-BUDGET-AND-EXACT-16-MIB
ok    TEST-REQ-AFF-008-CBOR-STRUCTURE-REUSE-AFTER-RUNTIME-FAILURES
  CBOR structure: 2 worker, 48 scansioni, 2359344 nodi, 5505168 byte; WALL fixture con rendezvous/controlli: worker 0 start/first/end 210514536/210520386/210619141, sink 4718784; worker 1 start/first/end 210514553/210521523/210638157, sink 3145920; overlap 104588 tick (1000000 tick/s); nessuna inferenza su tempo puro scanner, CPU o scaling.
ok    TEST-REQ-CON-005-CBOR-STRUCTURE-TWO-PRIVATE-WORKSPACES-REAL-CPU-OVERLAP
24 test della struttura CBOR superati.
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-ALL-MAJOR-TYPES-AND-GENERIC-PERMISSIONS
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-INTEGER-AND-TAG-WIDTH-THRESHOLDS
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-STRING-AND-CONTAINER-WIDTH-THRESHOLDS
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-NONMINIMAL-WIDTHS-AT-EVERY-MAJOR
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-FLOATS-IN-ROOT-KEYS-VALUES-AND-TAGS
  CBOR struttura minima: 768 casi lead, 84 accettati/684 rifiutati.
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-ALL-LEADING-BYTES-COLD-REFERENCE
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-HEADER-SYNTAX-BEFORE-LOCAL-PREFERENCE
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-PREFERENCE-BEFORE-BUDGETS-AND-PAYLOAD
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-NESTED-PREFERENCE-NOT-ONLY-ROOT
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-OPAQUE-BYTES-AND-CONTROL-TEXT-ARE-NOT-HEADERS
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-UTF8-ABSOLUTE-OFFSETS-AND-WHOLE-PAYLOAD
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-COMPLETED-ROOT-PRECEDES-TRAILING-CONTENT
ok    TEST-REQ-AFF-008-CBOR-MINIMAL-SCAN-TAGS-COUNT-ONCE-IN-PARENT-AND-NODE-BOUNDS
ok    TEST-REQ-LIM-002-CBOR-MINIMAL-SCAN-DEPTH-100-101-AND-MAP-KEYS
ok    TEST-REQ-AFF-008-CBOR-MINIMAL-SCAN-HUGE-LENGTHS-AND-PARENT-ARITY-PRIORITY
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-INVALID-INPUT-PRIORITY-AND-COLD-IMMUTABILITY
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-WORKSPACE-ALIAS-AND-LIMIT-ORDER
ok    TEST-REQ-LIM-001-CBOR-MINIMAL-SCAN-EXACT-SIXTEEN-MIB-AND-OVER-BUDGET
ok    TEST-REQ-AFF-008-CBOR-MINIMAL-SCAN-RESET-AFTER-ERRORS-AND-ALTERNATING-MODES
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-MISALIGNMENT-DECLARED-SPAN-AND-TRUNCATIONS
  CBOR struttura minima: 512 AST e fuzz4096 seed53434d31, 41 validi/4055 rifiutati.
ok    TEST-REQ-AFF-004-CBOR-MINIMAL-SCAN-SEEDED-ASTS-AND-FINITE-DIFFERENTIAL-FUZZ
  CBOR minimal scan: 2 worker, 48 scansioni, 2359344 nodi, 11796624 byte; WALL fixture con rendezvous/controlli: worker 0 start/first/end 211038180/211045684/211176453, sink 4718784; worker 1 start/first/end 211043591/211051484/211221969, sink 9437376; overlap 132862 tick (1000000 tick/s); nessuna inferenza su tempo puro scanner, CPU o scaling.
ok    TEST-REQ-CON-005-CBOR-MINIMAL-SCAN-TWO-PRIVATE-WORKSPACES-REAL-TIME-OVERLAP
22 test della struttura CBOR minima superati.
ok    TEST-REQ-CBR-001-CBOR-WRITE-LITERAL-VECTORS-ALL-SEVEN-MAJOR-TYPES
ok    TEST-REQ-CBR-001-CBOR-WRITE-DIRECT-ARGUMENTS-ZERO-THROUGH-TWENTY-THREE
ok    TEST-REQ-CBR-001-CBOR-WRITE-ADJACENT-WIDTH-BOUNDARIES-AND-SPLIT-U64
  CBOR write: 65536 argomenti u16 x 7 major, 458752 confronti aritmetici freddi.
ok    TEST-REQ-CBR-001-CBOR-WRITE-ALL-U16-ARGUMENTS-FOR-EACH-MAJOR
ok    TEST-REQ-CBR-001-CBOR-WRITE-EVERY-INSUFFICIENT-CAPACITY-BEFORE-ANY-BYTE
ok    TEST-REQ-CBR-001-CBOR-WRITE-INVALID-RANGES-DOMINATE-ALL-OTHER-ERRORS
ok    TEST-REQ-CBR-001-CBOR-WRITE-REJECTS-NON-SIMPLE-OCTET-DESTINATIONS
ok    TEST-REQ-CBR-001-CBOR-WRITE-MAJOR-PRECEDES-HIGH-LOW-AND-CAPACITY
ok    TEST-REQ-CBR-001-CBOR-WRITE-HIGH-PRECEDES-LOW-AND-CAPACITY
ok    TEST-REQ-CBR-001-CBOR-WRITE-LOW-PRECEDES-CAPACITY
ok    TEST-REQ-CBR-001-CBOR-WRITE-EMPTY-VALID-SPANS-ARE-CAPACITY-ERRORS
ok    TEST-REQ-CBR-001-CBOR-WRITE-EXACT-CAPACITY-MISALIGNMENT-AND-EXTRA-SPAN
ok    TEST-REQ-CBR-001-CBOR-WRITE-HEADER-HAS-NO-DOCUMENT-OR-PAYLOAD-BUDGET
ok    TEST-REQ-CBR-001-CBOR-WRITE-REUSE-AND-CONSECUTIVE-HEADERS
  CBOR write fuzz: seed57524342, 4096 casi; dimensioni1/2/3/5/9 = 560/465/511/512/2048.
ok    TEST-REQ-CBR-001-CBOR-WRITE-DIFFERENTIAL-FUZZ-SEED-57524342
  CBOR header write: 2 worker, 229376 header; WALL fixture con controlli/rendezvous dopo il primo giro completo: worker 0 start/first/end 211416357/211416358/211425294, sink 15466496; worker 1 start/first/end 211416433/211416434/211428499, sink 17006592; overlap 8861 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
ok    TEST-REQ-CBR-001-CBOR-WRITE-TWO-EXCLUSIVE-DESTINATIONS-REAL-TIME-OVERLAP
ok    TEST-REQ-CBR-001-CBOR-WRITE-MINIMAL-READER-ROUNDTRIP-SUPPLEMENT
17 test della scrittura degli header CBOR minimi superati.
ok    TEST-REQ-CBR-002-STRING-WRITE-LITERAL-HEADERS-AND-BYTE-PAYLOADS
ok    TEST-REQ-CBR-002-STRING-WRITE-MAJOR-TWO-PRESERVES-ALL-OCTETS
ok    TEST-REQ-CBR-002-STRING-WRITE-TEXT-NUL-BOM-NONCHARACTERS-AND-NO-NORMALIZATION
ok    TEST-REQ-CBR-002-STRING-WRITE-WIDTH-BOUNDARIES-AND-ADJACENT-LENGTHS
  CBOR string write: lunghezze0..4096 x MT2/3, 8194 confronti freddi.
ok    TEST-REQ-CBR-002-STRING-WRITE-ALL-LENGTHS-ZERO-THROUGH-4096
ok    TEST-REQ-CBR-002-STRING-WRITE-EVERY-SHORT-CAPACITY-WITH-PHYSICAL-SUFFIX
ok    TEST-REQ-CBR-002-STRING-WRITE-DESTINATION-RANGE-IS-FIRST
ok    TEST-REQ-CBR-002-STRING-WRITE-INVALID-DESTINATION-AND-SOURCE-SHAPES
ok    TEST-REQ-CBR-002-STRING-WRITE-MAJOR-BEFORE-SOURCE-BUDGET-AND-CAPACITY
ok    TEST-REQ-CBR-002-STRING-WRITE-SOURCE-RANGE-BEFORE-BUDGET-AND-CAPACITY
ok    TEST-REQ-CBR-002-STRING-WRITE-BUDGET-ARGUMENT-BEFORE-RESOURCE-AND-UTF8
ok    TEST-REQ-CBR-002-STRING-WRITE-BUDGET-INCLUDES-HEADER-AND-EMPTY-ITEM
ok    TEST-REQ-CBR-002-STRING-WRITE-MAXIMUM-ITEM-AND-ONE-BYTE-OVER-LIMIT
ok    TEST-REQ-CBR-002-STRING-WRITE-SAME-ARRAY-DISJOINT-TOUCHING-AND-EMPTY
ok    TEST-REQ-CBR-002-STRING-WRITE-OVERLAP-INCLUDES-HEADER-AND-NOT-EXTRA-SPAN
ok    TEST-REQ-CBR-002-STRING-WRITE-UTF8-MALFORMED-MANUAL-SOURCE-OFFSETS
ok    TEST-REQ-CBR-002-STRING-WRITE-BUDGET-CAPACITY-OVERLAP-BEFORE-UTF8
ok    TEST-REQ-CBR-002-STRING-WRITE-REUSE-AFTER-ERRORS-AND-CONCATENATION
  CBOR string write fuzz: seed53574342, 2048 casi, 1546 accettati/502 UTF-8 rifiutati.
ok    TEST-REQ-CBR-002-STRING-WRITE-DIFFERENTIAL-FUZZ-SEED-53574342
ok    TEST-REQ-CBR-002-STRING-WRITE-MINIMAL-SCAN-SUPPLEMENT-AFTER-COLD-BYTE-CHECK
  CBOR string write: onda 0, 2 worker riusati, 16384 item; WALL fixture con rendezvous/controlli: worker 0 start/first/end 213811267/213811280/213858810, sink 9707520; worker 1 start/first/end 213811288/213811308/213922481, sink 9969664; overlap 47522 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
  CBOR string write: onda 1, 2 worker riusati, 16384 item; WALL fixture con rendezvous/controlli: worker 0 start/first/end 213858822/213858826/213966021, sink 9707520; worker 1 start/first/end 213922488/213922499/214041034, sink 9969664; overlap 43533 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
ok    TEST-REQ-CBR-002-STRING-WRITE-TWO-REUSED-WORKERS-SHARED-IMMUTABLE-SOURCE
21 test della scrittura delle stringhe CBOR minime superati.
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-LITERAL-VECTORS
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-ALL-248-CODES-OFFSETS-AND-RESIDUALS
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-EVERY-INSUFFICIENT-CAPACITY-AND-PHYSICAL-SUFFIX
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-ALL-EIGHT-RESERVED-BEFORE-CAPACITY
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-INVALID-VALUE-TYPES-AND-BOUNDS
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-INVALID-RANGES-DOMINATE-VALUE-AND-CAPACITY
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-NON-SIMPLE-DESTINATIONS
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-DISPLACED-VIEW-AND-WHOLE-BACKING-UNCHANGED
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-EMPTY-SPANS-AND-ZERO-LENGTH-ARRAY
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-START-ZERO-AND-EXACT-PHYSICAL-END
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-REUSE-AFTER-ERRORS-AND-SUCCESS
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-CONCATENATION-OF-ALL-CODES
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-EXACT-SINGLE-RESULT-FOR-ALL-CODES
  CBOR simple write: fuzz seed 53494D43, 2048 casi: 768 successi, 512 valori, 256 capacita, 512 destinazioni/range rifiutati.
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-FIXED-SEED-2048-FUZZ
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-READER-AND-SCANNER-AFTER-COLD-BYTES
  CBOR simple write: onda 0, 2 worker riusati, 16384 item; WALL fixture con rendezvous/controlli: worker 0 start/first/end 214059656/214059669/214065027, sink 3804160; worker 1 start/first/end 214059678/214059680/214063815, sink 3836928; overlap 4137 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
  CBOR simple write: onda 1, 2 worker riusati, 16384 item; WALL fixture con rendezvous/controlli: worker 0 start/first/end 214065035/214065035/214067593, sink 3804160; worker 1 start/first/end 214063823/214063824/214067699, sink 3836928; overlap 2558 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
ok    TEST-REQ-CBR-003-SIMPLE-WRITE-TWO-REUSED-WORKERS-IMMUTABLE-PLANS
16 test della scrittura dei valori semplici CBOR superati.
ok    TEST-REQ-CBR-004-FLOAT-WRITE-ORACLE-KNOWN-RATIONALS-AND-NAN-PADDING
ok    TEST-REQ-CBR-004-FLOAT-WRITE-LITERAL-ZERO-INFINITY-FINITE-AND-NAN-VECTORS
  CBOR float write: 65536 half, 131072 espansioni; 196608 successi e 196608 capacita insufficienti, otto offset e tre configurazioni ruotati.
ok    TEST-REQ-CBR-004-FLOAT-WRITE-ALL-65536-HALF-AND-EXACT-EXPANSIONS
ok    TEST-REQ-CBR-004-FLOAT-WRITE-FINITE-NORMAL-SUBNORMAL-BOUNDARIES-AND-ADJACENCIES
ok    TEST-REQ-CBR-004-FLOAT-WRITE-BINARY64-SUBNORMAL-ALIGNMENT-ACROSS-WORDS
ok    TEST-REQ-CBR-004-FLOAT-WRITE-NAN-SIGNALING-QUIET-PAYLOAD-ALL-ALIGNMENTS
ok    TEST-REQ-CBR-004-FLOAT-WRITE-INVALID-AI-TYPES-AND-ALL-OCTET-VALUES
ok    TEST-REQ-CBR-004-FLOAT-WRITE-INVALID-HIGH-AND-LOW-TYPES-AND-U32-BOUNDS
ok    TEST-REQ-CBR-004-FLOAT-WRITE-INCOHERENT-WIDTH-WORDS-BEFORE-CAPACITY
ok    TEST-REQ-CBR-004-FLOAT-WRITE-PREFLIGHT-PRECEDENCE-CHAIN
ok    TEST-REQ-CBR-004-FLOAT-WRITE-INVALID-RANGES-BEFORE-ALL-VALUE-ERRORS
ok    TEST-REQ-CBR-004-FLOAT-WRITE-NON-SIMPLE-DESTINATIONS-AND-WHOLE-DISPLACED-BACKING
ok    TEST-REQ-CBR-004-FLOAT-WRITE-EMPTY-SPAN-AND-ZERO-LENGTH-DESTINATION
ok    TEST-REQ-CBR-004-FLOAT-WRITE-REUSE-AFTER-ERRORS-AND-SHORTER-SUCCESS
ok    TEST-REQ-CBR-004-FLOAT-WRITE-CONCATENATION-OF-REDUCED-AND-RETAINED-FORMS
  CBOR float write: fuzz seed464C5434, 2048 casi: 768 successi, 256 capacita, 128 AI, 128 HIGH, 128 LOW, 256 parole, 384 range/destinazioni rifiutati.
ok    TEST-REQ-CBR-004-FLOAT-WRITE-FIXED-SEED-2048-FUZZ
ok    TEST-REQ-CBR-004-FLOAT-WRITE-READER-AND-SCANNER-ONLY-AFTER-COLD-COMPARISON
  CBOR float write: onda 0, 2 worker riusati, 16384 item; WALL fixture con rendezvous/controlli: worker 0 start/first/end 214394289/214394295/214397398, sink 2115584; worker 1 start/first/end 214394369/214394371/214397360, sink 2148352; overlap 2991 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
  CBOR float write: onda 1, 2 worker riusati, 16384 item; WALL fixture con rendezvous/controlli: worker 0 start/first/end 214397403/214397403/214400451, sink 2115584; worker 1 start/first/end 214397370/214397370/214400413, sink 2148352; overlap 3010 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
ok    TEST-REQ-CBR-004-FLOAT-WRITE-TWO-REUSED-WORKERS-IMMUTABLE-PLANS
18 test della scrittura dei float CBOR superati.
ok    TEST-REQ-CBR-005-ARRAY-EMPTY-SCALAR-AND-FIVE-LITERAL-CHILDREN
ok    TEST-REQ-CBR-005-ARRAY-COUNT-WIDTH-BOUNDARIES-AND-MINIMAL-HEADER
ok    TEST-REQ-CBR-005-ARRAY-NESTED-TAG-MAP-TEXT-AND-RAW-FLOAT-PREFERENCE
ok    TEST-REQ-CBR-005-ARRAY-CONCATENATION-NEXT-AND-REUSED-SPACE
ok    TEST-REQ-CBR-005-ARRAY-DESTINATION-TYPE-AND-RANGE-PRECEDES-EVERYTHING
ok    TEST-REQ-CBR-005-ARRAY-SOURCE-TYPE-RANGE-AND-BACKING-ARRAY-INTACT
ok    TEST-REQ-CBR-005-ARRAY-TABLE-TYPE-AND-COUNT-DOMAINS
ok    TEST-REQ-CBR-005-ARRAY-WORKSPACE-TYPE-AND-ALL-SCRATCH-ALIASES-EVEN-EMPTY
ok    TEST-REQ-CBR-005-ARRAY-CONFIGURED-LIMITS-AND-EMPTY-ROOT-MINIMUM
ok    TEST-REQ-CBR-005-ARRAY-STRICT-ENTRY-ORDER-BOUNDS-LAST-AND-UNREAD-TAIL
ok    TEST-REQ-CBR-005-ARRAY-ALL-PREFLIGHT-PHASE-PRECEDENCES
ok    TEST-REQ-CBR-005-ARRAY-OVERLAP-ENTIRE-FOOTPRINT-TOUCHING-AND-EMPTY
ok    TEST-REQ-CBR-005-ARRAY-FULL-BYTE-BUDGET-EXACT-16MIB-AND-ONE-OVER
ok    TEST-REQ-CBR-005-ARRAY-ROOT-TAG-NODE-ACCOUNTING-AND-EXHAUSTED-RESIDUE
ok    TEST-REQ-CBR-005-ARRAY-ROOT-DEPTH-SCALARS-TAGS-AND-99-100-CHILD-CONTAINERS
ok    TEST-REQ-CBR-005-ARRAY-CHILD-ERRORS-ABSOLUTE-OFFSETS-AND-LEFT-TO-RIGHT
ok    TEST-REQ-CBR-005-ARRAY-REUSE-AFTER-PARSER-AND-PREFLIGHT-ERRORS
ok    TEST-REQ-CBR-005-ARRAY-SCRATCH-LAST-CHILD-AND-ZERO-COUNT-NO-RESET
  CBOR array fuzz: seed41525235, 1024 casi, 512 successi e 64 ciascuno capacita/byte/entry/nodi/profondita/parse/source-range/count.
ok    TEST-REQ-CBR-005-ARRAY-FIXED-SEED-1024-FUZZ-AND-FROZEN-CLASS-COUNTS
  CBOR array: onda 0, 2 worker riusati, 4096 composizioni; WALL fixture con rendezvous/controlli: worker 0 start/first/end 214845409/214845419/214847888, sink 52178944; worker 1 start/first/end 214845538/214845545/214848271, sink 75218944; overlap 2350 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
  CBOR array: onda 1, 2 worker riusati, 4096 composizioni; WALL fixture con rendezvous/controlli: worker 0 start/first/end 214847891/214847894/214850582, sink 52178944; worker 1 start/first/end 214848277/214848280/214850983, sink 75218944; overlap 2305 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
ok    TEST-REQ-CBR-005-ARRAY-TWO-REUSED-WORKERS-PRIVATE-SCRATCH-AND-READONLY-INPUTS
20 test della composizione degli array CBOR superati.
ok    TEST-REQ-CBR-006-MAP-EMPTY-SCALAR-PAIR-AND-TWO-LITERAL-PAIRS
ok    TEST-REQ-CBR-006-MAP-PAIR-COUNT-WIDTH-BOUNDARIES-AND-MINIMAL-HEADER
ok    TEST-REQ-CBR-006-MAP-NESTED-UTF8-FLOATS-OPAQUE-BYTES-AND-PRESERVED-PAIR-ORDER
ok    TEST-REQ-CBR-006-MAP-CONCATENATION-NEXT-AND-REUSED-SPACE
ok    TEST-REQ-CBR-006-MAP-DESTINATION-TYPE-AND-RANGE-PRECEDES-EVERYTHING
ok    TEST-REQ-CBR-006-MAP-SOURCE-TYPE-RANGE-AND-BACKING-ARRAY-INTACT
ok    TEST-REQ-CBR-006-MAP-TABLE-TYPE-COUNT-DOMAINS-AND-HALF-LENGTH-BEFORE-MULTIPLICATION
ok    TEST-REQ-CBR-006-MAP-WORKSPACE-TYPE-AND-ALL-SCRATCH-ALIASES-EVEN-EMPTY
ok    TEST-REQ-CBR-006-MAP-CONFIGURED-LIMITS-AND-EMPTY-ROOT-MINIMUM
ok    TEST-REQ-CBR-006-MAP-STRICT-ACTIVE-ENDS-LAST-AND-UNREAD-EVEN-OR-ODD-TAIL
ok    TEST-REQ-CBR-006-MAP-ALL-PREFLIGHT-PHASE-PRECEDENCES
ok    TEST-REQ-CBR-006-MAP-OVERLAP-ENTIRE-FOOTPRINT-TOUCHING-AND-EMPTY
ok    TEST-REQ-CBR-006-MAP-FULL-BYTE-BUDGET-KEY-PLUS-VALUE-EXACT-16MIB-AND-OVER
ok    TEST-REQ-CBR-006-MAP-ROOT-KEY-VALUE-TAG-NODES-AND-ZERO-RESIDUE-BEFORE-RESET
ok    TEST-REQ-CBR-006-MAP-ROOT-DEPTH-SCALARS-TAGS-AND-99-100-CHILD-CONTAINERS
ok    TEST-REQ-CBR-006-MAP-KEY-AND-VALUE-PARSER-ERRORS-ABSOLUTE-AND-LEFT-TO-RIGHT
ok    TEST-REQ-CBR-006-MAP-REUSE-AFTER-VALUE-PARSER-AND-PREFLIGHT-ERRORS
ok    TEST-REQ-CBR-006-MAP-SCRATCH-LAST-VALUE-AND-ZERO-PAIRS-NO-RESET
  CBOR map fuzz: seed4D415035, 1024 casi, 512 successi e 64 ciascuno capacita/byte/entry/nodi/profondita/parse/source-range/count.
ok    TEST-REQ-CBR-006-MAP-FIXED-SEED-1024-FUZZ-AND-FROZEN-CLASS-COUNTS
  CBOR map: onda 0, 2 worker riusati, 4096 composizioni; WALL fixture con rendezvous/controlli: worker 0 start/first/end 215232772/215232835/215237776, sink 54677504; worker 1 start/first/end 215232815/215232821/215240306, sink 77537280; overlap 4961 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
  CBOR map: onda 1, 2 worker riusati, 4096 composizioni; WALL fixture con rendezvous/controlli: worker 0 start/first/end 215237788/215237798/215245803, sink 54677504; worker 1 start/first/end 215240312/215240320/215245027, sink 77537280; overlap 4715 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
ok    TEST-REQ-CBR-006-MAP-TWO-REUSED-WORKERS-PRIVATE-SCRATCH-AND-READONLY-INPUTS
20 test della composizione delle mappe CBOR superati.
ok    TEST-REQ-CBR-007-TAG-U32-WORD-WIDTH-BOUNDARIES-AND-ALL-WIRE-SENTINELS
ok    TEST-REQ-CBR-007-TAG-OPAQUE-SCALARS-UTF8-FLOATS-CONTAINERS-AND-PAIR-ORDER
ok    TEST-REQ-CBR-007-TAG-CONCATENATION-NEXT-AND-EXACT-RETURN-ARITY
ok    TEST-REQ-CBR-007-TAG-DESTINATION-TYPE-AND-RANGE-PRECEDES-EVERYTHING
ok    TEST-REQ-CBR-007-TAG-SOURCE-TYPE-RANGE-EMPTY-AND-BACKING-ARRAY-INTACT
ok    TEST-REQ-CBR-007-TAG-HIGH-THEN-LOW-DOMAIN-PRECEDENCE-WITHOUT-U64
ok    TEST-REQ-CBR-007-TAG-WORKSPACE-TYPE-AND-BOTH-KINDS-ALIASES
ok    TEST-REQ-CBR-007-TAG-CONFIGURED-LIMITS-AND-ROOT-TWO-NODE-MINIMUM
ok    TEST-REQ-CBR-007-TAG-ALL-PREFLIGHT-PHASE-PRECEDENCES
ok    TEST-REQ-CBR-007-TAG-CAPACITY-ACTIVE-END-AND-COMPLETE-BYTE-BUDGET
ok    TEST-REQ-CBR-007-TAG-OVERLAP-INCLUDING-ONLY-HEADER-AND-TOUCHING-BOUNDARIES
ok    TEST-REQ-CBR-007-TAG-FULL-16MIB-WITH-ONE-AND-NINE-BYTE-HEADER-AND-OVER
ok    TEST-REQ-CBR-007-TAG-ROOT-AND-CONTENT-NODE-RESIDUE-LONG-TAG-CHAINS-NO-FRAME
ok    TEST-REQ-CBR-007-TAG-DEPTH-UNCHANGED-ZERO-SCALARS-AND-100-101-CONTAINERS
ok    TEST-REQ-CBR-007-TAG-PARSER-FAILURES-ABSOLUTE-OFFSET-AND-COMPLETE-SINGLE-ITEM
ok    TEST-REQ-CBR-007-TAG-EVERY-TRUNCATION-NONZERO-SOURCE-START-AND-EXACT-END
ok    TEST-REQ-CBR-007-TAG-SCRATCH-REUSE-AFTER-PARSER-AND-PREFLIGHT-ERRORS
ok    TEST-REQ-CBR-007-TAG-SCRATCH-CONTENT-ONLY-STATISTICS-AFTER-SUCCESS
  CBOR tag fuzz: seed54414737, 1024 casi, 512 successi e 64 ciascuno capacita/byte/high/nodi/profondita/parse/source-range/empty.
ok    TEST-REQ-CBR-007-TAG-FIXED-SEED-1024-FUZZ-AND-FROZEN-CLASS-COUNTS
  CBOR tag: onda 0, 2 worker riusati, 4096 composizioni; WALL fixture con rendezvous/controlli: worker 0 start/first/end 215947951/215947957/215949685, sink 66766848; worker 1 start/first/end 215947965/215947966/215951759, sink 97310720; overlap 1720 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
  CBOR tag: onda 1, 2 worker riusati, 4096 composizioni; WALL fixture con rendezvous/controlli: worker 0 start/first/end 215949687/215949688/215953982, sink 66766848; worker 1 start/first/end 215951766/215951768/215956943, sink 97310720; overlap 2216 tick (1000000 tick/s); nessuna inferenza su tempo puro encoder, CPU o scaling.
ok    TEST-REQ-CBR-007-TAG-TWO-REUSED-WORKERS-PRIVATE-SCRATCH-AND-READONLY-SOURCE
20 test della composizione dei tag CBOR superati.
ok    TEST-REQ-CBR-008-ITEM-LITERAL-ALL-MAJORS-AND-UNREAD-POISON-TAIL
ok    TEST-REQ-CBR-008-ITEM-INTEGER-TAG-AND-STRING-WIDTH-BOUNDARIES
ok    TEST-REQ-CBR-008-ITEM-CONCATENATED-FRONTIERS-AND-EXACT-SCANNERS-STILL-TRAILING
ok    TEST-REQ-CBR-008-ITEM-AUTHORIZED-END-PHYSICAL-SENTINELS-AND-NONZERO-START
ok    TEST-REQ-CBR-008-ITEM-BUFFER-TYPE-RANGE-AND-WHOLE-BACKING-ARRAY-PRESERVATION
ok    TEST-REQ-CBR-008-ITEM-WORKSPACE-TYPE-ALIAS-AND-PREFLIGHT-BEFORE-RESET
ok    TEST-REQ-CBR-008-ITEM-CONFIGURED-LIMITS-AND-ALL-PREFLIGHT-PRECEDENCES
ok    TEST-REQ-CBR-008-ITEM-BYTE-BUDGET-INCLUDES-ENTIRE-WINDOW-AND-UNREAD-TAIL
ok    TEST-REQ-CBR-008-ITEM-ROOT-AND-TAG-CHAIN-NODE-BUDGET-WITHOUT-TAIL-NODES
ok    TEST-REQ-CBR-008-ITEM-DEPTH-ZERO-AND-100-101-WITHOUT-TAIL-DEPTH
ok    TEST-REQ-CBR-008-ITEM-MALFORMED-FIRST-ITEM-ABSOLUTE-ERRORS-AND-MINIMALITY
ok    TEST-REQ-CBR-008-ITEM-EVERY-TRUNCATION-IS-BOUNDED-BY-AUTHORIZED-END
ok    TEST-REQ-CBR-008-ITEM-HEADER-PREFERENCE-BEFORE-NODES-DEPTH-AND-PAYLOAD
ok    TEST-REQ-CBR-008-ITEM-SCRATCH-REUSE-AND-CONTENT-STATISTICS-WITHOUT-TAIL
ok    TEST-REQ-CBR-008-ITEM-FULL-16MIB-WINDOW-TAIL-AND-COMPLETE-PAYLOAD-BOUNDARY
  CBOR item fuzz: seed49544538, 1024 casi, 512 successi e 64 ciascuno byte/nodi/depth/nonminimal/range/workspace/byte-limit/truncated.
ok    TEST-REQ-CBR-008-ITEM-FIXED-SEED-1024-FUZZ-AND-FROZEN-CLASS-COUNTS
  CBOR item: onda 0, 2 worker riusati, 4096 letture; WALL fixture con rendezvous/controlli: worker 0 start/first/end 216071097/216071124/216074365, sink 74129408; worker 1 start/first/end 216071111/216071124/216072870, sink 74129408; overlap 1759 tick (1000000 tick/s); nessuna inferenza su tempo puro decoder, CPU o scaling.
  CBOR item: onda 1, 2 worker riusati, 4096 letture; WALL fixture con rendezvous/controlli: worker 0 start/first/end 216074375/216074377/216077251, sink 74129408; worker 1 start/first/end 216072877/216072879/216076191, sink 74129408; overlap 1816 tick (1000000 tick/s); nessuna inferenza su tempo puro decoder, CPU o scaling.
ok    TEST-REQ-CBR-008-ITEM-TWO-REUSED-WORKERS-PRIVATE-SCRATCH-AND-READONLY-BUFFER
17 test della lettura del primo item CBOR minimo superati.
ok    TEST-REQ-CBR-009-STRING-LITERAL-EMPTY-UTF8-AND-UNREAD-TAILS
ok    TEST-REQ-CBR-009-STRING-LENGTH-WIDTH-BOUNDARIES-AND-PAYLOAD-OFFSET
ok    TEST-REQ-CBR-009-STRING-RAW-BYTES-NEVER-VALIDATED-AS-UTF8
ok    TEST-REQ-CBR-009-STRING-CONCATENATION-AND-ZERO-LENGTH-PAYLOAD-FRONTIERS
ok    TEST-REQ-CBR-009-STRING-BUFFER-TYPE-RANGE-AND-BACKING-ARRAY-PRESERVED
ok    TEST-REQ-CBR-009-STRING-BYTE-LIMIT-DOMAIN-AND-PREFLIGHT-PRECEDENCES
ok    TEST-REQ-CBR-009-STRING-BUDGET-COVERS-WHOLE-WINDOW-AND-EMPTY-SPAN
ok    TEST-REQ-CBR-009-STRING-TYPE-PRECEDES-FIT-FOR-EVERY-OTHER-MAJOR
ok    TEST-REQ-CBR-009-STRING-HEADER-SYNTAX-AND-MINIMALITY-PRECEDE-TYPE
ok    TEST-REQ-CBR-009-STRING-NONMINIMAL-LENGTHS-BEFORE-FIT-OR-UTF8
ok    TEST-REQ-CBR-009-STRING-U64-LENGTH-AND-LOW-WORD-FIT-BEFORE-PAYLOAD
ok    TEST-REQ-CBR-009-STRING-EVERY-HEADER-AND-PAYLOAD-TRUNCATION-AT-AUTHORIZED-END
ok    TEST-REQ-CBR-009-STRING-UTF8-REASONS-AND-ABSOLUTE-PAYLOAD-OFFSETS
ok    TEST-REQ-CBR-009-STRING-FIT-BEFORE-UTF8-AND-VALIDATION-STOPS-AT-PAYLOAD-END
ok    TEST-REQ-CBR-009-STRING-FULL-16MIB-WINDOW-PAYLOAD-AND-ONE-BYTE-OVER
  CBOR string read fuzz: seed53545239, 1024 casi, 512 successi e 64 ciascuno byte/type/nonminimal/truncated/utf8/range/byte-limit/empty.
ok    TEST-REQ-CBR-009-STRING-FIXED-SEED-1024-FUZZ-AND-FROZEN-CLASSES
  CBOR string read: onda 0, 2 worker riusati, 4096 letture; WALL fixture con rendezvous/controlli: worker 0 start/first/end 216461054/216461115/216461854, sink 84649984; worker 1 start/first/end 216461193/216461198/216463084, sink 85010432; overlap 661 tick (1000000 tick/s); nessuna inferenza su tempo puro decoder, CPU o scaling.
  CBOR string read: onda 1, 2 worker riusati, 4096 letture; WALL fixture con rendezvous/controlli: worker 0 start/first/end 216461858/216461858/216464779, sink 84649984; worker 1 start/first/end 216463096/216463097/216465052, sink 85010432; overlap 1683 tick (1000000 tick/s); nessuna inferenza su tempo puro decoder, CPU o scaling.
ok    TEST-REQ-CBR-009-STRING-TWO-REUSED-WORKERS-SHARE-BUFFER-WITH-DISTINCT-RAW-AND-TEXT-WINDOWS
17 test della lettura delle stringhe CBOR minime superati.
ok    TEST-REQ-MVC-008-CSN-DEFAULT-CAPACITY-AND-VALID-BOUNDARIES
ok    TEST-REQ-AFF-008-CSN-INVALID-CONFIGURATION-EACH-FIELD
ok    TEST-REQ-MVC-008-CSN-RECOVERY-BASE-AND-FIRST-SUCCESSOR
ok    TEST-REQ-MVC-008-CSN-FULL-REFUSAL-CREDIT-AND-EVERY-SLOT-REUSED
ok    TEST-REQ-MVC-008-CSN-REVERSE-COMPLETION-AND-INTERIOR-GAP
ok    TEST-REQ-MVC-008-CSN-ADR0046-MODULO-RING-COUNTEREXAMPLE
ok    TEST-REQ-MVC-008-CSN-CARRY-U32-AND-HORIZON-BORROW
ok    TEST-REQ-MVC-008-CSN-CROSSES-SBCL-FIXNUM-BOUNDARY
ok    TEST-REQ-AFF-008-CSN-LAST-U64-AND-EXHAUSTION-DOES-NOT-WRAP
ok    TEST-REQ-AFF-004-CSN-INVALID-TOKEN-SHAPES-AND-ZERO
ok    TEST-REQ-AFF-004-CSN-EXACT-SLOT-HIGH-LOW-AND-REGISTRY-BINDING
ok    TEST-REQ-AFF-004-CSN-DOUBLE-RESOLUTION-AND-STALE-REUSED-SLOT
  CSN: K=2, 6 commit, 850 prefissi, 243 storie complete.
  CSN: K=3, 6 commit, 7310 prefissi, 2403 storie complete.
ok    TEST-REQ-MVC-008-CSN-EXHAUSTIVE-CAPACITY-2-3-THROUGH-SIX-COMMITS
  CSN seed #x46C5A71B: 2993 presi, 2987 risolti, 2085 pieni, 964 letture, 971 stale.
ok    TEST-REQ-MVC-008-CSN-DETERMINISTIC-TEN-THOUSAND-ACTIONS
ok    TEST-REQ-AFF-004-CSN-PRIVATE-FI-SHAPE-BEFORE-PUBLIC-MUTATION
ok    TEST-REQ-AFF-004-CSN-PRIVATE-FI-FRONTIERS-BEFORE-PUBLIC-MUTATION
ok    TEST-REQ-AFF-004-CSN-PRIVATE-FI-LIVE-COUNT-TOKEN-AND-RESIDUAL-SCAN
ok    TEST-REQ-CON-004-CSN-GUARD-MACRO-SINGLE-EVALUATION-VALUES-AND-CLEANUP
ok    TEST-REQ-CON-004-CSN-HELD-WORKER-GUARD-BUSY-AND-INDEPENDENT-REGISTRY
  CSN: 4 worker x 1000 assegnazioni, 4 busy, 2 full, slot #(1333 350 2317), H convergente.
ok    TEST-REQ-MVC-008-CSN-FOUR-REAL-WORKERS-ONE-THOUSAND-ASSIGNMENTS-EACH
20 test del registro CSN superati.
ok    TEST-REQ-AFF-008-SNAPSHOT-CONFIGURATION-BOUNDARIES
ok    TEST-REQ-AFF-008-SNAPSHOT-CONFIGURATION-TYPED-RANGE-REFUSALS
ok    TEST-REQ-MVC-005-SNAPSHOT-EMPTY-ARCHIVE-CSN-ZERO
ok    TEST-REQ-MVC-005-SNAPSHOT-CANONICAL-OUT-OF-ORDER-ACTIVATION
ok    TEST-REQ-MVC-005-SNAPSHOT-CARRY-U32-AND-BOXED-CSN
ok    TEST-REQ-MVC-007-SNAPSHOT-MAXIMUM-CSN-IS-NOT-ABSENCE
ok    TEST-REQ-MVC-007-SNAPSHOT-SAME-CSN-DISTINCT-GENERATIONS
ok    TEST-REQ-MVC-003-SNAPSHOT-MULTIPIN-RETENTION-BOUNDARIES
ok    TEST-REQ-MVC-007-SNAPSHOT-CONSERVATIVE-THRESHOLD-UNTIL-RECALCULATION
ok    TEST-REQ-AFF-008-SNAPSHOT-CAPACITY-REFUSES-BEFORE-MUTATION
ok    TEST-REQ-MVC-007-SNAPSHOT-PINNED-CONTEXT-REFUSES-BEFORE-MUTATION
ok    TEST-REQ-AFF-008-SNAPSHOT-DEADLINE-OVERFLOW-AND-EXACT-U64-BOUNDARY
ok    TEST-REQ-AFF-008-SNAPSHOT-PRIVATE-FI-GENERATION-EXHAUSTION
ok    TEST-REQ-MVC-004-SNAPSHOT-ACTIVE-READER-DEADLINE-BEFORE-EXACT-AFTER
ok    TEST-REQ-MVC-004-SNAPSHOT-ACTIVE-ACTIVATION-EXPIRY-REMOVES-PIN
ok    TEST-REQ-MVC-004-SNAPSHOT-WAIT-DEADLINE-BEFORE-EXACT-AFTER
ok    TEST-REQ-MVC-004-SNAPSHOT-LIFETIME-INCLUDES-INITIAL-WAIT
ok    TEST-REQ-AFF-008-SNAPSHOT-TIMER-BUDGET-REFUSALS-AND-EMPTY-SWEEP
ok    TEST-REQ-AFF-008-SNAPSHOT-TIMER-CIRCULAR-FAIRNESS-AND-MIXED-DEADLINES
ok    TEST-REQ-MVC-004-SNAPSHOT-TIMER-DISTINGUISHES-WAIT-AND-AGE
ok    TEST-REQ-MVC-007-SNAPSHOT-TERMINATION-IDEMPOTENT-ACTIVE-AND-WAITING
ok    TEST-REQ-MVC-007-SNAPSHOT-STALE-GENERATION-AFTER-CONTEXT-REUSE
ok    TEST-REQ-MVC-007-SNAPSHOT-STALE-CONTEXT-AFTER-SLOT-REUSE
ok    TEST-REQ-MVC-005-SNAPSHOT-PRIVATE-BUFFER-RANGE-AND-UNBOUND-IDENTITY
ok    TEST-REQ-AFF-004-SNAPSHOT-TERMINAL-INVALIDATION-PRESERVES-PINS
ok    TEST-REQ-AFF-004-SNAPSHOT-PRIVATE-FI-READER-CSN-STATE-AND-RANGE
ok    TEST-REQ-AFF-004-SNAPSHOT-PRIVATE-FI-COUNTER-GUARDS
ok    TEST-REQ-AFF-004-SNAPSHOT-PRIVATE-FI-RECALCULATION-INVARIANTS
ok    TEST-REQ-MVC-007-SNAPSHOT-ANNOUNCEMENT-BEFORE-CAPTURE
ok    TEST-REQ-MVC-007-SNAPSHOT-HORIZON-REGRESSION
ok    TEST-REQ-MVC-007-SNAPSHOT-CAPTURED-CSN-BELOW-HORIZON
ok    TEST-REQ-MVC-007-SNAPSHOT-BUSY-ROLLBACK-WITHOUT-PIN
ok    TEST-REQ-MVC-007-SNAPSHOT-BUSY-ROLLBACK-WITH-PIN
ok    TEST-REQ-MVC-007-SNAPSHOT-OTHER-RESOURCE-FAIL-STOP
ok    TEST-REQ-MVC-007-SNAPSHOT-CANONICAL-CONDITION-IDENTITY
ok    TEST-REQ-MVC-007-SNAPSHOT-THROW-AFTER-ANNOUNCEMENT
ok    TEST-REQ-MVC-007-SNAPSHOT-FAULT-BEFORE-PUBLISH
ok    TEST-REQ-MVC-007-SNAPSHOT-FAULT-DURING-PUBLISH
ok    TEST-REQ-MVC-007-SNAPSHOT-FAULT-AFTER-PUBLISH
ok    TEST-REQ-MVC-007-SNAPSHOT-READY-EQUALITY-AND-PUBLISHED-IDENTITY
ok    TEST-REQ-CON-004-SNAPSHOT-HELD-MUTEX-READER-AND-OTHER-ARCHIVE
ok    TEST-REQ-CON-004-SNAPSHOT-RECURSIVE-GUARD-AND-NIL-BODY
ok    TEST-REQ-CON-004-SNAPSHOT-READER-WITH-CSN-MUTEX-HELD
43 test snapshot/CSN superati.
ok    TEST-REQ-AFF-008-EBR-VALID-CAPACITIES-AND-INITIAL-STATE
ok    TEST-REQ-AFF-008-EBR-WORKER-CAPACITY-REFUSALS
ok    TEST-REQ-AFF-008-EBR-RETIREMENT-CAPACITY-REFUSALS
ok    TEST-REQ-CMP-005-EBR-CANONICAL-CONTEXT-AND-WORKER-RANGE
ok    TEST-REQ-CMP-005-EBR-ENTER-EXIT
ok    TEST-REQ-CMP-005-EBR-NESTED-ENTRY-PRESERVES-PIN
ok    TEST-REQ-CMP-005-EBR-INACTIVE-EXIT-REFUSED
ok    TEST-REQ-CMP-005-EBR-INDEPENDENT-READERS
ok    TEST-REQ-CMP-005-EBR-OWNER-NONLOCAL-CLEANUP
ok    TEST-REQ-CMP-007-EBR-RESERVATION-RESOURCE-AND-CREDITS
ok    TEST-REQ-CMP-007-EBR-NULL-RESOURCE-PRESERVES-STATE
ok    TEST-REQ-CMP-007-EBR-DUPLICATE-RESOURCE-PRESERVES-STATE
ok    TEST-REQ-AFF-008-EBR-FULL-CAPACITY-PRESERVES-STATE
ok    TEST-REQ-CMP-007-EBR-CANCEL-IS-IDEMPOTENT
ok    TEST-REQ-CMP-007-EBR-PUBLISH-ADVANCES-ONCE
ok    TEST-REQ-CMP-007-EBR-PUBLISHED-RETIREMENT-CANNOT-CANCEL
ok    TEST-REQ-CMP-007-EBR-INVALID-TICKET-STATE-OPERATIONS
ok    TEST-REQ-CMP-007-EBR-STRICT-RECLAIM-THRESHOLD
ok    TEST-REQ-CMP-007-EBR-TWO-OLD-READERS-BLOCK-RECLAIM
ok    TEST-REQ-CMP-007-EBR-NEW-READER-DOES-NOT-BLOCK-OLD-RETIREMENT
ok    TEST-REQ-CMP-007-EBR-THRESHOLD-IS-MONOTONE
ok    TEST-REQ-CMP-007-EBR-RESOURCE-UNTIL-COMPLETION
ok    TEST-REQ-CMP-007-EBR-COMPLETION-IS-IDEMPOTENT
ok    TEST-REQ-CMP-007-EBR-STALE-GENERATION-PRESERVES-REUSE
ok    TEST-REQ-CMP-007-EBR-ZERO-AND-WRONG-GENERATION-PRESERVE-STATE
ok    TEST-REQ-AFF-008-EBR-GENERATION-MAXIMUM-WITHOUT-WRAP
ok    TEST-REQ-AFF-008-EBR-EPOCH-CREDIT-BEFORE-PUBLICATION
ok    TEST-REQ-AFF-008-EBR-CANCEL-RESTORES-EPOCH-CREDIT
ok    TEST-REQ-AFF-004-EBR-METADATA-INCOHERENCE-FAULTS
ok    TEST-REQ-AFF-004-EBR-COUNTER-INCOHERENCE-FAULTS
ok    TEST-REQ-AFF-004-EBR-FUTURE-READER-FAULTS
ok    TEST-REQ-AFF-004-EBR-READER-CLEANUP-AFTER-FAULT
ok    TEST-REQ-CMP-007-EBR-CLAIM-IS-EXCLUSIVE
ok    TEST-REQ-CMP-005-EBR-READER-FINISHES-WITH-MAINTENANCE-MUTEX-HELD
34 test epoche/reclaim superati.
ok    TEST-REQ-MVC-005-READ-CURRENT-BUFFER-UNTOUCHED
ok    TEST-REQ-MVC-005-READ-SNAPSHOT-CSN-ZERO-CARRY-BOXED
ok    TEST-REQ-MVC-004-READ-COMPLETION-KEEPS-SNAPSHOT
ok    TEST-REQ-MVC-004-READ-WAITING-REFUSAL-CLEANS-EPOCH
ok    TEST-REQ-MVC-004-READ-ENDED-BEGIN-CLEANS-EPOCH
ok    TEST-REQ-CON-004-READ-CURRENT-GENERATION-BEFORE-PIN
ok    TEST-REQ-CON-004-READ-SNAPSHOT-ZERO-GENERATION-BEFORE-PIN
ok    TEST-REQ-CON-004-READ-FOREIGN-SNAPSHOT-BEFORE-PIN
ok    TEST-REQ-CON-004-READ-ALREADY-ACTIVE-READER-REFUSAL
ok    TEST-REQ-CON-004-READ-NESTED-KEEPS-EXISTING-PIN
ok    TEST-REQ-MVC-005-READ-INACTIVE-BUFFER-REFUSAL
ok    TEST-REQ-MVC-005-READ-RESULT-RANGE-PRESERVES-BUFFER
ok    TEST-REQ-MVC-004-READ-FINAL-SNAPSHOT-CHECK
ok    TEST-REQ-CMP-007-READ-LOGICAL-EXPIRY-KEEPS-LIVE-EPOCH
ok    TEST-REQ-CON-004-READ-CLOCK-REGRESSION-RELEASES-PIN
ok    TEST-REQ-CMP-007-READ-ABANDON-RELEASES-PIN
ok    TEST-REQ-AFF-004-READ-IDLE-RESIDUAL-GENERATION
ok    TEST-REQ-AFF-004-READ-IDLE-RESIDUAL-CSN
ok    TEST-REQ-AFF-004-READ-IDLE-RESIDUAL-START
ok    TEST-REQ-AFF-004-READ-IDLE-RESIDUAL-CONFIRMED
ok    TEST-REQ-AFF-004-READ-IDLE-RESIDUAL-SNAPSHOT
ok    TEST-REQ-AFF-004-READ-ACTIVE-CURRENT-GENERATION
ok    TEST-REQ-AFF-004-READ-ACTIVE-CURRENT-CSN
ok    TEST-REQ-AFF-004-READ-ACTIVE-SNAPSHOT-ZERO-GENERATION
ok    TEST-REQ-AFF-004-READ-ACTIVE-FOREIGN-BINDING
ok    TEST-REQ-AFF-004-READ-MISSING-EPOCH-FAULT
ok    TEST-REQ-AFF-004-READ-FAULTED-CONTEXT-STAYS-FAULTED
ok    TEST-REQ-AFF-004-READ-FINAL-CSN-CHANGED-FAULT
ok    TEST-REQ-CMP-007-READ-EXTERNAL-ERROR-THROW-CLEANUP
ok    TEST-REQ-CON-004-READ-TWO-WORKER-MIGRATION
30 test dei compiti di lettura superati.
ok    TEST-REQ-AFF-008-GET-EXACT-PAYLOAD-BUDGET
ok    TEST-REQ-AFF-008-GET-DEFAULT-PAYLOAD-BUDGET
ok    TEST-REQ-AFF-008-GET-BUDGET-REFUSED-BEFORE-WORKER-LOOKUP
ok    TEST-REQ-AFF-008-GET-INVALID-WORKER-CONFIGURATION
ok    TEST-REQ-FOR-001-GET-VIEW-IDENTITY-LENGTH
ok    TEST-REQ-FOR-001-GET-VIEW-COPIES-IDENTITY
ok    TEST-REQ-CON-004-GET-SECOND-VIEW-SAME-CANONICAL-ARCHIVE
ok    TEST-REQ-CON-004-GET-EQUAL-REGISTERS-DISTINCT-ARCHIVE-REFUSED
ok    TEST-REQ-CON-004-GET-FOREIGN-ARCHIVE-REFUSED
ok    TEST-REQ-LIM-003-GET-KEY-LENGTH-BOUNDARIES
ok    TEST-REQ-CON-004-GET-PRIVATE-KEY-ALIAS-REFUSED
ok    TEST-REQ-IDX-001-GET-UNCONFIGURED-HASH-RELEASES-EPOCH
ok    TEST-REQ-CON-004-GET-NESTED-START-PRESERVES-EXISTING-PIN
ok    TEST-REQ-CON-004-GET-PREMATURE-FINISH-PRESERVES-EXISTING-PIN
ok    TEST-REQ-CMP-007-GET-ABANDON-IS-IDEMPOTENT-AND-REUSABLE
ok    TEST-REQ-AFF-004-GET-FI-FAULTED-CONTEXT-IS-TERMINAL
ok    TEST-REQ-AFF-004-GET-FI-IDLE-RESIDUE-FAULTS
ok    TEST-REQ-MVC-005-GET-CURRENT-MISS-AUTHORIZES-ABSENCE
ok    TEST-REQ-MVC-001-GET-SNAPSHOT-MISS-REQUIRES-HISTORY
ok    TEST-REQ-MVC-001-GET-SNAPSHOT-CANDIDATE-OLDER-THAN-LIMIT
ok    TEST-REQ-MVC-001-GET-SNAPSHOT-CANDIDATE-EQUAL-TO-LIMIT
ok    TEST-REQ-MVC-001-GET-SNAPSHOT-NEWER-CANDIDATE-REQUIRES-HISTORY
ok    TEST-REQ-MVC-005-GET-CURRENT-HIGH-CSN-REMAINS-CANDIDATE
ok    TEST-REQ-MVC-004-GET-COPY-IS-PRIVATE-UNTIL-FINAL-CONFIRMATION
ok    TEST-REQ-IDX-001-GET-CANDIDATE-COPY-HAS-INDEPENDENT-STORAGE
ok    TEST-REQ-CON-004-GET-CANDIDATE-ALIAS-PRESERVES-EXISTING-PIN
ok    TEST-REQ-AFF-008-GET-OUTPUT-RANGE-ERROR-RELEASES-EPOCH
ok    TEST-REQ-CON-004-GET-OUTPUT-ALIAS-ERROR-RELEASES-EPOCH
ok    TEST-REQ-MVC-004-GET-FINAL-EXPIRY-AFTER-VALUE-COPY
ok    TEST-REQ-MVC-004-GET-FINAL-TERMINATION-AFTER-VALUE-COPY
ok    TEST-REQ-CON-004-GET-CLOCK-REGRESSION-AFTER-VALUE-COPY
ok    TEST-REQ-AFF-004-GET-FI-EMPTY-VALUE-RANGE-FAULTS
ok    TEST-REQ-AFF-004-GET-FI-VALUE-OVERFLOW-FAULTS
ok    TEST-REQ-AFF-003-GET-EXTERNAL-ERROR-AFTER-COPY-CLEANS-OWNER
ok    TEST-REQ-AFF-003-GET-EXTERNAL-THROW-AFTER-COPY-CLEANS-OWNER
ok    TEST-GET-D04-NATIVE-READONLY-HEADER-AND-KNOWN-PUT
ok    TEST-GET-D08-MISS-INSERT-THEN-HIT-WITHOUT-RECORD-IO
ok    TEST-GET-D08-CACHE-DISABLED-STILL-LOADS-KNOWN-VALUE
ok    TEST-GET-D05-CACHE-MISS-PROBE-KEEPS-CANDIDATE-AND-DOES-NO-IO
ok    TEST-GET-D05-PREPARED-PROBE-REQUIRES-PROOF-WITHOUT-IO
ok    TEST-GET-D05-SMALL-PROBE-PRECEDES-PROOF-AND-CACHE
ok    TEST-GET-D05-SMALL-LOAD-DOES-NO-PROOF-OR-RECORD-IO
ok    TEST-GET-D07-PREPARED-REAL-OUTCOME-BEFORE-PUT
ok    TEST-GET-D08-PREPARED-CACHE-HIT-STILL-READS-AUTHORITATIVE-PROOF
ok    TEST-GET-D04-HEADER-REJECTS-OTHER-SEGMENT-IDENTITY
ok    TEST-GET-D04-HEADER-REJECTS-OTHER-SERIE-IDENTITY
ok    TEST-GET-D04-CORRUPT-REAL-HEADER-CANNOT-CREATE-CAPABILITY
ok    TEST-GET-D04-TARGET-OWNER-REFUSAL-RELEASES-EPOCH
ok    TEST-GET-D04-TARGET-SEGMENT-ID-DISAGREES-WITH-INDEX-LOCATION
ok    TEST-GET-D04-HIGH-SEGMENT-WORD-IS-NOT-TRUNCATED-TO-LOCATION
ok    TEST-GET-D04-COMMITTED-PREFIX-ONE-BYTE-SHORT-FOR-PUT
ok    TEST-GET-D04-RECORD-LOCATION-BEFORE-HEADER-IS-REFUSED
ok    TEST-GET-D04-INDEX-SIZE-WITH-NO-VALUE-IS-NOT-A-GET-SOURCE
ok    TEST-GET-D04-INVALID-STORAGE-FLAGS-REJECTED-BEFORE-IO
ok    TEST-GET-D04-PERMITTED-FLAG-MUST-MATCH-PERSISTENT-PUT
ok    TEST-GET-D04-V1-HEADER-SELECTS-V1-RECORD-VERIFIER
ok    TEST-GET-D04-V1-KEY-LIMIT-REFUSES-V2-SIZED-INDEX-KEY
ok    TEST-GET-D04-COMPACTED-ORIGIN-CANNOT-AUTHORIZE-PREPARED-PUT
ok    TEST-GET-D06-PREPARED-PROOF-IS-MANDATORY
ok    TEST-GET-D06-PLAIN-PUT-REJECTS-UNEXPECTED-PROOF-OFFSET
ok    TEST-GET-D06-OUTCOME-MUST-NOT-OVERLAP-PUT
ok    TEST-GET-D06-OUTCOME-BEFORE-HEADER-IS-REFUSED
ok    TEST-GET-D06-OUTCOME-ONE-BYTE-BEYOND-COMMITTED-PREFIX
ok    TEST-GET-D07-OUTCOME-HEADER-AND-BODY-CRCS-CHECKED-BEFORE-PUT
ok    TEST-GET-D07-OUTCOME-CSN-MUST-MATCH-COMMITTED-INDEX
ok    TEST-GET-D07-VALID-CRC-OTHER-RECORD-TYPE-IS-NOT-OUTCOME
ok    TEST-GET-D07-OUTCOME-TXID-MUST-MATCH-PREPARED-PUT
ok    TEST-GET-D07-PERSISTENT-PUT-BODY-CORRUPTION-IS-NOT-A-CACHE-MISS
ok    TEST-GET-D07-PLAIN-PUT-CSN-DISAGREES-WITH-INDEX
ok    TEST-GET-D08-FI-CORRUPT-CACHE-COPY-FALLS-BACK-TO-INTACT-NATIVE-PUT
70 test GET superati.
ok    TEST-REQ-AFF-002-PERFORMANCE-FILE-V1-VALUE16
ok    TEST-REQ-AFF-002-PERFORMANCE-FILE-V1-VALUE256
ok    TEST-REQ-AFF-002-PERFORMANCE-FILE-V1-VALUE4096
ok    TEST-REQ-AFF-002-PERFORMANCE-FILE-V2-VALUE16
ok    TEST-REQ-AFF-002-PERFORMANCE-FILE-V2-VALUE256
ok    TEST-REQ-AFF-002-PERFORMANCE-FILE-V2-VALUE4096
ok    TEST-REQ-CCH-002-PERFORMANCE-CACHE-HIT-V1
ok    TEST-REQ-CCH-002-PERFORMANCE-CACHE-HIT-V2
ok    TEST-REQ-IDX-001-PERFORMANCE-ABSENT
ok    TEST-REQ-MVC-005-PERFORMANCE-SNAPSHOT-BOXED-LATE
ok    TEST-REQ-MVC-004-PERFORMANCE-SNAPSHOT-FINAL-AUTHORIZATION
ok    TEST-REQ-AFF-002-PERFORMANCE-OUTPUT-COPY
ok    TEST-REQ-AFF-002-PERFORMANCE-PREFIX-BOUNDARY
ok    TEST-REQ-AFF-002-PERFORMANCE-MAX-U64-VERIFICATION
ok    TEST-REQ-CCH-004-PERFORMANCE-CACHE-CRC-FALLBACK
ok    TEST-REQ-AFF-002-PERFORMANCE-PERSISTENT-CRC-GUARD
ok    TEST-REQ-CMP-007-PERFORMANCE-CLEANUP
ok    TEST-REQ-CCH-004-PERFORMANCE-CACHE-REPAIR-HIT
ok    TEST-REQ-CON-004-PERFORMANCE-SHARED-READERS4
19 test del contratto GET per benchmark superati.
ok    TEST-REQ-CCH-004-CACHE-EMPTY-AND-PUBLISHED
ok    TEST-REQ-CCH-004-CACHE-ODD-SEQUENCE-IS-UNREADABLE
ok    TEST-REQ-CCH-004-CACHE-SEQUENCE-LIMIT-IS-UNREADABLE
ok    TEST-REQ-CCH-004-CACHE-DISABLED-IS-TERMINAL
ok    TEST-REQ-CCH-004-CACHE-LAST-CREDIT-THEN-DISABLED
ok    TEST-REQ-CCH-004-CACHE-ODD-SLOTS-ARE-QUARANTINED
ok    TEST-REQ-CCH-004-CACHE-CORRUPT-COPY-IS-REJECTED
ok    TEST-REQ-CCH-004-CACHE-CORRUPT-INPUT-PRECEDES-PUBLICATION
  Cache v1/16 byte: 4 worker, 32 record/8 vie; fase libera: tentativi 2048, inserted/present/busy/unavailable 1721/235/92/0, hit/miss 2455/1641, espulsioni 1721, scan non riletti espulsi 2; controllo del worker zero: 1 INSERTED, 1 HIT e 1 espulsione prima del rilascio comune. Rendezvous dopo un campione per worker; nessuna copertura delle finestre interne o misura di scaling.
ok    TEST-REQ-CCH-004-CACHE-V1-FOUR-WORKERS-SMALL-RECORDS
  Cache v2/16 byte: 4 worker, 32 record/8 vie; fase libera: tentativi 2048, inserted/present/busy/unavailable 1945/54/49/0, hit/miss 2572/1524, espulsioni 1945, scan non riletti espulsi 3; controllo del worker zero: 1 INSERTED, 1 HIT e 1 espulsione prima del rilascio comune. Rendezvous dopo un campione per worker; nessuna copertura delle finestre interne o misura di scaling.
ok    TEST-REQ-CCH-004-CACHE-V2-FOUR-WORKERS-SMALL-RECORDS
  Cache v1/4096 byte: 4 worker, 32 record/8 vie; fase libera: tentativi 2048, inserted/present/busy/unavailable 1718/317/13/0, hit/miss 2401/1695, espulsioni 1718, scan non riletti espulsi 1; controllo del worker zero: 1 INSERTED, 1 HIT e 1 espulsione prima del rilascio comune. Rendezvous dopo un campione per worker; nessuna copertura delle finestre interne o misura di scaling.
ok    TEST-REQ-CCH-004-CACHE-V1-FOUR-WORKERS-MULTI-KIB-RECORDS
  Cache v2/4096 byte: 4 worker, 32 record/8 vie; fase libera: tentativi 2048, inserted/present/busy/unavailable 1655/385/8/0, hit/miss 2471/1625, espulsioni 1655, scan non riletti espulsi 1; controllo del worker zero: 1 INSERTED, 1 HIT e 1 espulsione prima del rilascio comune. Rendezvous dopo un campione per worker; nessuna copertura delle finestre interne o misura di scaling.
ok    TEST-REQ-CCH-004-CACHE-V2-FOUR-WORKERS-MULTI-KIB-RECORDS
  Cache v1: mutex detenuto da altro worker, BUSY completato prima del rilascio; stesso worker poi INSERTED e HIT verificato.
ok    TEST-REQ-CCH-004-CACHE-V1-OTHER-THREAD-HELD-STRIPE-IS-NONBLOCKING
  Cache v2: mutex detenuto da altro worker, BUSY completato prima del rilascio; stesso worker poi INSERTED e HIT verificato.
ok    TEST-REQ-CCH-004-CACHE-V2-OTHER-THREAD-HELD-STRIPE-IS-NONBLOCKING
14 test della pubblicazione cache superati.
ok    TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START
ok    TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N
ok    TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT
ok    TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS
ok    TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED
ok    TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER
ok    TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER
ok    TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME
ok    TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17
ok    TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID
ok    TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT
ok    TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK
ok    TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT
ok    TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL
ok    TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP
ok    TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS
ok    TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH
ok    TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS
ok    TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE
ok    TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ
ok    TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS
ok    TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION
ok    TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY
ok    TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN
ok    TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION
ok    TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY
ok    TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER
ok    TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO
ok    TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER
ok    TEST-REQ-WAL-006-SERIES-GET-EMPTY-ACTIVE-INITIALIZATION-NATIVE-V1-V2
ok    TEST-REQ-WAL-006-SERIES-GET-INITIAL-CONTROLLER-ROOT-AND-NIL-REFUSAL
ok    TEST-REQ-IDX-001-SERIES-GET-EMPTY-ACTIVE-CLOSED-BEFORE-FIRST-BATCH-NATIVE-V1-V2
ok    TEST-REQ-AFF-004-SERIES-GET-EMPTY-ACTIVE-CANDIDATE-FAULTED-NATIVE-V1-V2
ok    TEST-REQ-WAL-006-SERIES-GET-EMPTY-ACTIVE-FIRST-BATCH-PUBLISH-AND-REUSE-NATIVE-V1-V2
ok    TEST-REQ-WAL-006-SERIES-GET-EMPTY-ACTIVE-REPEATED-INITIALIZATION-REFUSED
ok    TEST-REQ-WAL-006-SERIES-GET-EMPTY-ACTIVE-FOREIGN-OWNER-BEFORE-INITIALIZATION
ok    TEST-REQ-WAL-006-SERIES-GET-EMPTY-ACTIVE-DUPLICATE-BEFORE-INITIALIZATION
ok    TEST-REQ-CON-002-SERIES-GET-EMPTY-ACTIVE-LEASE-BEFORE-CHECKS
ok    TEST-REQ-WAL-006-SERIES-GET-EMPTY-ACTIVE-FILE-FRONTIER-REFUSED
ok    TEST-REQ-CMP-007-SERIES-GET-EMPTY-ACTIVE-FIXTURE-CLEANUP-NATIVE-V1-V2
ok    TEST-REQ-WAL-006-SERIES-GET-EMPTY-ACTIVE-CLOSED-CAPABILITIES-REFUSED
ok    TEST-REQ-IDX-001-SERIES-GET-CONTENT-ROUNDTRIP
ok    TEST-REQ-IDX-001-SERIES-GET-CLOSED-CONTROLLER-NATIVE-V1-V2
ok    TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED
ok    TEST-REQ-CCH-002-SERIES-GET-FIVE-OUTCOMES-COLD-AND-HOT
ok    TEST-REQ-CCH-004-SERIES-GET-CACHE-CORRUPTION-NATIVE-FALLBACK
ok    TEST-REQ-CMP-007-SERIES-GET-WRONG-OWNER-CLEANUP
ok    TEST-REQ-AFF-004-SERIES-GET-NIL-AND-CORRUPT-ROOT-FAULTED
ok    TEST-REQ-AFF-004-SERIES-GET-CORRUPT-ACTIVE-CONTENT-FAULTED
ok    TEST-REQ-AFF-004-SERIES-GET-SOURCE-CONTROLLER-MISMATCH-TYPED-FAULTED
ok    TEST-REQ-IDX-001-SERIES-GET-MISSING-CLOSED-ID-FAULTED
ok    TEST-REQ-CON-004-SERIES-GET-WRONG-STATE-NO-PIN-STEAL
ok    TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION
ok    TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE
ok    TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-EXCLUDES-LATER-PUBLICATION
ok    TEST-REQ-WAL-005-SERIES-GET-WRITER-FOREIGN-OWNER-BEFORE-ADOPTION
ok    TEST-REQ-WAL-005-SERIES-GET-WRITER-DUPLICATE-ACTIVE-BEFORE-ADOPTION
ok    TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED
ok    TEST-REQ-AFF-004-SERIES-GET-ACTIVE-OWNER-AND-ID-GUARDS
ok    TEST-REQ-IDX-001-SERIES-GET-CONTAINS-EMPTY-AND-ID-EXTREMES
ok    TEST-REQ-IDX-001-SERIES-GET-CONTAINS-65536-GEOMETRY-SEARCH17
ok    TEST-REQ-CON-004-SERIES-GET-BUFFER-REQUIRED-FIVE-OUTCOMES-AND-RESTART
ok    TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-READER-FAULTED
ok    TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-WRITER-ARCHIVE-FAULTED
ok    TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-ADAPTERS-NATIVE
ok    TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-INVALID-ROOT-FAULTED
ok    TEST-REQ-CMP-007-SERIES-GET-ACTIVE-OWNER-BEFORE-FAULTED-CONTROLLER
ok    TEST-REQ-WAL-006-SERIES-GET-ACTIVE-UNEXPECTED-PROOF-FAULTED
ok    TEST-REQ-CMP-007-SERIES-GET-OLD-CANDIDATE-NEW-ACTIVE-SUPERSET-NATIVE-V1-V2
ok    TEST-REQ-CMP-007-SERIES-GET-NATIVE-SOURCE-PINNED-THROUGH-COPY-AND-RECLAIM
ok    TEST-REQ-CMP-007-SERIES-GET-NATIVE-HOOK-CONDITION-RELEASES-PIN-BEFORE-RECLAIM
ok    TEST-REQ-CMP-007-SERIES-GET-NATIVE-HOOK-NONLOCAL-EXIT-RELEASES-PIN-BEFORE-RECLAIM
72 test directory GET superati.
ok    TEST-REQ-FOR-004-RESOLVER-RADIX-ALL-EIGHT-OCTETS
ok    TEST-REQ-FOR-004-RESOLVER-RADIX-ZERO-AND-SINGLE-PROOF
ok    TEST-REQ-FOR-004-RESOLVER-RADIX-U64-ORDER-AND-STABLE-DUPLICATES
ok    TEST-REQ-FOR-004-RESOLVER-LOOKUP-FIRST-DUPLICATE-AND-U64-BORDERS
ok    TEST-REQ-FOR-004-RESOLVER-DUPLICATE-CSN-EACH-WORD-CONFLICTS
ok    TEST-REQ-FOR-004-RESOLVER-ORDER-HIGH-LOW-AND-PHYSICAL-OFFSET
ok    TEST-REQ-FOR-004-RESOLVER-PROOF-SHAPE-BEFORE-SORT-OR-SEARCH
ok    TEST-REQ-FOR-004-RESOLVER-RADIX-PREFLIGHT-NO-PARTIAL-EFFECTS
ok    TEST-REQ-FOR-004-RESOLVER-NATIVE-V1-V2-MULTIPLE-BATCHES-AND-PUTS
ok    TEST-REQ-AFF-008-RESOLVER-PAYLOAD-ZERO-OUTCOMES-EXACT-ONE-SHORT
ok    TEST-REQ-AFF-008-RESOLVER-PAYLOAD-ONE-OUTCOME-EXACT-ONE-SHORT
ok    TEST-REQ-AFF-008-RESOLVER-PAYLOAD-TWO-OUTCOMES-RADIX-EXACT-ONE-SHORT
ok    TEST-REQ-AFF-008-RESOLVER-EMPTY-PREFIX-ZERO-PAYLOAD
ok    TEST-REQ-FOR-004-RESOLVER-UNRESOLVED-PREPARED-NOT-INVENTED-COMMIT
ok    TEST-REQ-FOR-004-RESOLVER-OUTCOME-BEFORE-PUT-IS-CORRUPTION
ok    TEST-REQ-FOR-004-RESOLVER-CONFLICTING-OUTCOME-LOW-WORD
ok    TEST-REQ-FOR-004-RESOLVER-CONFLICTING-OUTCOME-HIGH-WORD
ok    TEST-REQ-CON-004-RESOLVER-SOURCE-BUFFER-REUSE-DOES-NOT-ALTER-MAP
ok    TEST-REQ-AFF-008-RESOLVER-SOURCE-BUDGET-BEFORE-IO
ok    TEST-REQ-AFF-008-RESOLVER-RECORD-AND-BATCH-BUDGETS
ok    TEST-REQ-STO-006-RESOLVER-ONE-FD-AUTHORITATIVE-PREFIX-PRESERVES-TAIL
ok    TEST-REQ-FOR-004-RESOLVER-MULTIPLE-PREPARED-TXID-AND-CSN-U64
ok    TEST-REQ-FOR-004-RESOLVER-TXID-HIGH-LOW-BOUNDARIES
ok    TEST-REQ-FOR-004-RESOLVER-IDENTICAL-DUPLICATES-SELECT-FIRST-PHYSICAL-PROOF
ok    TEST-REQ-FOR-004-RESOLVER-MIXED-ORDINARY-PREPARED-FLAGS
ok    TEST-REQ-CCH-002-RESOLVER-PREPARED-COLD-READ-PROOF-BEFORE-PUT-SAME-FD
ok    TEST-REQ-CCH-002-RESOLVER-PREPARED-CACHE-HIT-STILL-REREADS-OWN-PROOF
ok    TEST-REQ-CCH-002-RESOLVER-ORDINARY-CACHE-HIT-REQUIRES-NO-PROOF-OR-IO
ok    TEST-REQ-FOR-004-RESOLVER-UNRESOLVED-PREPARED-CANNOT-AUTHORIZE-RESPONSE
ok    TEST-REQ-FOR-004-RESOLVER-CANDIDATE-CSN-LOW-WORD-MISMATCH
ok    TEST-REQ-FOR-004-RESOLVER-CANDIDATE-CSN-HIGH-WORD-MISMATCH
ok    TEST-REQ-CMP-007-RESOLVER-FOREIGN-CANONICAL-OWNER-CLEANS-PIN
ok    TEST-REQ-CON-004-RESOLVER-PRECONDITIONS-PRESERVE-EXISTING-PIN
ok    TEST-REQ-CON-004-RESOLVER-SMALL-BUFFER-PRECEDES-PREPARED-PROOF-IO
ok    TEST-REQ-FOR-004-RESOLVER-WARM-CACHE-CANNOT-HIDE-PROOF-HEADER-CRC
ok    TEST-REQ-FOR-004-RESOLVER-WARM-CACHE-CANNOT-HIDE-PROOF-CSN-LOW
ok    TEST-REQ-FOR-004-RESOLVER-WARM-CACHE-CANNOT-HIDE-PROOF-CSN-HIGH
ok    TEST-REQ-FOR-004-RESOLVER-WARM-CACHE-CANNOT-HIDE-PROOF-TXID-LOW
ok    TEST-REQ-FOR-004-RESOLVER-WARM-CACHE-CANNOT-HIDE-PROOF-TXID-HIGH
ok    TEST-REQ-FOR-004-RESOLVER-LATER-IDENTICAL-PROOF-CANNOT-RESCUE-CORRUPT-FIRST
ok    TEST-REQ-CON-004-RESOLVER-THROW-DURING-PROOF-RELEASES-PIN
ok    TEST-REQ-MVC-004-RESOLVER-SNAPSHOT-EXPIRES-AFTER-PRIVATE-PREPARED-COPY
42 test resolver GET superati.
ok    TEST-REQ-FOR-001-ACTIVE-SOURCE-CONFIGURATION-IDENTITY-AND-FD
ok    TEST-REQ-FOR-003-ACTIVE-NATIVE-V1-V2-PUT-AND-TOMBSTONE
ok    TEST-REQ-IDX-001-ACTIVE-TOMBSTONE-PAGE-ZERO-PUTS
ok    TEST-REQ-WAL-005-ACTIVE-PREFLIGHT-IMMUTABLE-NO-CSN-OR-IO
ok    TEST-REQ-AFF-008-ACTIVE-FIRST-PAYLOAD-EXACT-ONE-SHORT
ok    TEST-REQ-AFF-008-ACTIVE-SECOND-PAYLOAD-PEAK-EXACT-ONE-SHORT
ok    TEST-REQ-AFF-008-ACTIVE-PAGE-BUDGET-EXACT-REFUSES-NEXT
ok    TEST-REQ-AFF-008-ACTIVE-PUT-BUDGET-EXACT-REFUSES-NEXT
ok    TEST-REQ-AFF-008-ACTIVE-RECORD-BYTE-BUDGETS-EXACT-ONE-SHORT
ok    TEST-REQ-FOR-004-ACTIVE-PREPARED-OUTCOME-REFUSED-BEFORE-CSN
ok    TEST-REQ-CON-004-ACTIVE-ROOTS-PERSIST-AFTER-PUBLIC-BATCH-REUSE
ok    TEST-REQ-AFF-001-ACTIVE-SEALED-CRC-FAULTS-ARCHIVE-PRESERVES-CAUSE
ok    TEST-REQ-WAL-005-ACTIVE-PREFLIGHT-BATCH-FILE-ID
ok    TEST-REQ-WAL-005-ACTIVE-PREFLIGHT-BATCH-VERSION
ok    TEST-REQ-WAL-005-ACTIVE-PREFLIGHT-EMPTY-OPEN
ok    TEST-REQ-WAL-005-ACTIVE-PREFLIGHT-OPEN-TOKEN-BOUND
ok    TEST-REQ-WAL-005-ACTIVE-PREFLIGHT-SEALED-REFUSED-WITH-TOKEN-PRESERVED
ok    TEST-REQ-WAL-005-ACTIVE-PREFLIGHT-PREVIOUS-ORDER
ok    TEST-REQ-AFF-008-ACTIVE-PREFLIGHT-RING-FULL
ok    TEST-REQ-AFF-008-ACTIVE-PREFLIGHT-EVENT-GENERATION-BOUND
ok    TEST-REQ-WAL-005-ACTIVE-PREFLIGHT-CONTIGUOUS-OFFSET
ok    TEST-REQ-AFF-008-ACTIVE-PREFLIGHT-SEGMENT-SPACE
ok    TEST-REQ-AFF-008-ACTIVE-PREFLIGHT-RECORD-BOUNDARY
ok    TEST-REQ-AFF-008-ACTIVE-PREFLIGHT-SEAL-BYTE-BOUNDARY
ok    TEST-REQ-AFF-001-ACTIVE-PREFLIGHT-HEADER-CORRUPTION-FAULTS-ARCHIVE
ok    TEST-REQ-AFF-001-ACTIVE-PREFLIGHT-OPEN-COUNT-FAULTS-ARCHIVE
ok    TEST-REQ-IDX-001-ACTIVE-DIRECTORY-NIBBLE-TRANSITIONS-PERSISTENT
ok    TEST-REQ-IDX-001-ACTIVE-DIRECTORY-65536-FINAL-CONVERGENCE
ok    TEST-REQ-IDX-001-ACTIVE-DIRECTORY-MALFORMED-LOCAL-GUARDS
ok    TEST-REQ-IDX-001-ACTIVE-DIRECTORY-OCCUPIED-APPEND-PRESERVES-GRAPH
ok    TEST-REQ-FOR-003-ACTIVE-NATIVE-V1-V2-CSN-U64-AND-ORDINARY-FLAGS
ok    TEST-REQ-CCH-002-ACTIVE-COLD-READ-AND-WARM-PROBE-AND-READ
ok    TEST-REQ-WAL-006-ACTIVE-DURABLE-PLANNED-ROOT-CANNOT-AUTHORIZE-VALUE
ok    TEST-REQ-WAL-006-ACTIVE-OLD-PUT-USES-OWN-PAGE-END
ok    TEST-REQ-IDX-001-ACTIVE-HEADER-SEAL-TOMBSTONE-FRONTIER-AND-MISSING-ROW-FAULT
ok    TEST-REQ-IDX-001-ACTIVE-CANDIDATE-CSN-LOW-AND-HIGH-WORD-MISMATCH
ok    TEST-REQ-IDX-001-ACTIVE-CANDIDATE-WIRE-SIZE-AND-RESERVED-HIGH-WORD
ok    TEST-REQ-CMP-007-ACTIVE-FOREIGN-SOURCE-OWNER-CLEANS-BEFORE-OUTER-UNWIND
ok    TEST-REQ-CMP-007-ACTIVE-CLOSED-READONLY-FD-IS-TERMINAL-SOURCE-FAULT
ok    TEST-REQ-CON-004-ACTIVE-THROW-AT-NATIVE-PREAD-CLEANS-WITHOUT-AUTHORIZING
ok    TEST-REQ-CON-004-ACTIVE-SMALL-BUFFER-RESTARTS-AND-REACQUIRES-NEW-ROOT
ok    TEST-REQ-MVC-004-ACTIVE-SNAPSHOT-EXPIRES-AFTER-PRIVATE-COPY
42 test GET ACTIVE superati.
ok    TEST-REQ-AFF-008-WRITER-CONFIGURATION
ok    TEST-REQ-AFF-008-WRITER-DEFAULTS-AND-CONFIGURATION-BOUNDARIES
ok    TEST-REQ-CON-001-WRITER-FIFO-RING-WRAP-AND-NIL
ok    TEST-REQ-AFF-008-WRITER-FULL-REFUSAL-RETAINS-PAYLOAD
ok    TEST-REQ-CON-004-WRITER-GUARD-BUSY-DOES-NOT-MUTATE
ok    TEST-REQ-CON-001-WRITER-TARGET-SUBRANGE-AND-EMPTY
ok    TEST-REQ-AFF-004-WRITER-INVALID-TARGET-PREFLIGHT
ok    TEST-REQ-AFF-004-WRITER-PRIVATE-RING-ALIAS-REFUSED
ok    TEST-REQ-CON-001-WRITER-LEASE-LIFECYCLE
ok    TEST-REQ-CON-001-WRITER-STALE-LEASE-SAME-THREAD
ok    TEST-REQ-AFF-008-WRITER-QUANTUM-IS-CUMULATIVE-PER-LEASE
ok    TEST-REQ-AFF-008-WRITER-GENERATION-DOES-NOT-WRAP
ok    TEST-REQ-CON-001-WRITER-SEEDED-LIST-ORACLE
ok    TEST-REQ-CON-001-WRITER-FOREIGN-THREAD-CANNOT-USE-LEASE
ok    TEST-REQ-CON-001-WRITER-CAS-HAS-ONE-OWNER
  Due Serie: 128 CRC, 1048576 byte; WALL fixture con controlli/rendezvous fuori dalle lease: worker 0 start/first/end 219508690/219509163/219541610, sink 596103808; worker 1 start/first/end 219508659/219509643/219541301, sink 1698207232; overlap 32611 tick (1000000 tick/s); nessuna inferenza su tempo puro calcolo, CPU o scaling.
ok    TEST-REQ-CON-003-INDEPENDENT-SERIES-PROGRESS-AND-CPU-OVERLAP
  wave 0: 144 messaggi, 3 producer, 2 consumer, 5 worker riusati, drain aperto.
  wave 1: 144 messaggi, 3 producer, 2 consumer, 5 worker riusati, drain aperto.
  wave 2: 144 messaggi, 3 producer, 2 consumer, 5 worker riusati, drain aperto.
ok    TEST-REQ-CON-001-WRITER-REAL-PRODUCERS-CONSUMERS-AND-WORKER-REUSE
ok    TEST-REQ-AFF-008-HANDOFF-CONFIGURATION-AND-LIMITS
ok    TEST-REQ-CON-005-HANDOFF-SINGLE-OBLIGATION-AND-DUPLICATE-BEGIN
ok    TEST-REQ-CON-005-HANDOFF-ENQUEUE-BEFORE-AND-AFTER-EMPTY-RELEASE
ok    TEST-REQ-CON-004-HANDOFF-CUMULATIVE-QUANTUM-AND-SUCCESSIVE-SLICES
ok    TEST-REQ-AFF-008-HANDOFF-FULL-READY-AND-RUNNING-RETAIN-STATE
ok    TEST-REQ-CON-004-HANDOFF-BUSY-IDLE-AND-READY-PRESERVE-STATE
ok    TEST-REQ-CON-005-HANDOFF-BUSY-RELEASE-RETAINS-LEASE-FOR-RETRY
ok    TEST-REQ-CON-005-HANDOFF-EARLY-RELEASE-CONSERVES-ENTIRE-BACKLOG
ok    TEST-REQ-AFF-004-HANDOFF-LEASE-VALIDATION-AND-STALE-GENERATION
ok    TEST-REQ-AFF-004-HANDOFF-TARGET-PREFLIGHT-AND-PRIVATE-ALIAS
ok    TEST-REQ-AFF-008-HANDOFF-GENERATION-EXHAUSTION-PRESERVES-READY
ok    TEST-REQ-AFF-004-HANDOFF-REJECTS-INCONSISTENT-SCHEDULING-STATES
ok    TEST-REQ-AFF-004-HANDOFF-HELPERS-REQUIRE-CURRENT-THREAD-GUARD
ok    TEST-REQ-CON-001-HANDOFF-SEEDED-LIST-AND-SCHEDULING-ORACLE
ok    TEST-REQ-CON-001-HANDOFF-FOREIGN-THREAD-CANNOT-USE-LEASE
ok    TEST-REQ-CON-002-HANDOFF-TRANSFERS-SUCCESSIVE-SLICES-BETWEEN-REUSED-THREADS
  Handoff: 4 thread riusati, 6 ondate, 36 messaggi, 2 Serie indipendenti.
ok    TEST-REQ-CON-003-HANDOFF-REUSES-FOUR-WORKERS-ACROSS-INDEPENDENT-SERIES-WAVES
ok    TEST-REQ-AFF-008-READY-CONFIGURATION-AND-LIMITS
ok    TEST-REQ-AFF-004-READY-SHARD-AND-WRITER-PREFLIGHT
ok    TEST-REQ-CON-001-READY-PER-SHARD-FIFO-WRAP-AND-PRIVATE-OPAQUE-RING
ok    TEST-REQ-CON-004-READY-CURSOR-ROTATES-FIRST-CHOICE-AND-EMPTY-SCAN
ok    TEST-REQ-CON-001-READY-SEEDED-INDEPENDENT-LISTS-AND-CURSORS
ok    TEST-REQ-CON-005-READY-FULL-PRESERVES-SCHEDULING-OBLIGATION
ok    TEST-REQ-CON-005-READY-DEQUEUED-REFERENCE-SURVIVES-BEGIN-BUSY
ok    TEST-REQ-CON-004-READY-SKIPS-BUSY-HOME-AND-PRESERVES-LOCAL-RING
ok    TEST-REQ-CON-004-READY-BUSY-OBSERVATIONS-AND-SCAN-ORDER-ORACLE
ok    TEST-REQ-CON-005-READY-BUSY-PUBLICATION-RETAINS-OBLIGATION-AND-PAYLOAD
ok    TEST-REQ-AFF-004-READY-REJECTS-INVALID-PRIVATE-RING-SHAPES
ok    TEST-REQ-AFF-004-READY-REJECTS-INVALID-PRIVATE-PARTITION-ARRAYS
ok    TEST-REQ-AFF-004-READY-REJECTS-INCONSISTENT-OCCUPIED-AND-FREE-SLOTS
ok    TEST-REQ-AFF-004-READY-HELPERS-REJECT-MISSING-AND-FOREIGN-GUARD
ok    TEST-REQ-CON-005-READY-HANDOFF-BEFORE-AFTER-RELEASE-AND-NEXT-WAVE
  Ready: 4 thread riusati, 6 ondate, 36 payload, shard fermata e stealing.
ok    TEST-REQ-CON-003-READY-REUSED-WORKERS-LIVE-PRODUCERS-AND-INDEPENDENT-SHARDS
  Ready: 2 consumer riusati, 8 ondate, un riferimento estratto per ondata.
ok    TEST-REQ-CON-002-READY-COMPETING-CONSUMERS-TAKE-ONE-REFERENCE-PER-WAVE
ok    TEST-REQ-CON-001-RECYCLE-ROOM-PUBLISHES-AND-PRESERVES-FIFO
ok    TEST-REQ-CON-005-RECYCLE-CAPACITY-ONE-TRANSFERS-OLD-AND-KEEPS-NEW
ok    TEST-REQ-CON-001-RECYCLE-FULL-WRAP-PRESERVES-INDEPENDENT-LIST-ORDER
ok    TEST-REQ-CON-001-RECYCLE-SEEDED-OBLIGATIONS-AND-PAYLOADS-EXACTLY-ONCE
ok    TEST-REQ-CON-005-RECYCLE-ALL-CONSUMERS-RESCHEDULE-AFTER-PRODUCER-REFILLS-FULL
ok    TEST-REQ-CON-005-RECYCLE-BUSY-RETAINS-OBLIGATION-AND-BOTH-RING-SHAPES
ok    TEST-REQ-AFF-004-RECYCLE-SHARD-WRITER-PREFLIGHT-BEFORE-HELD-GUARD
ok    TEST-REQ-AFF-004-RECYCLE-PRIVATE-RING-AND-PARTITION-SHAPES-PRE-MUTATION
ok    TEST-REQ-AFF-004-RECYCLE-MALFORMED-FULL-HEAD-AND-FREE-TAIL-PRE-MUTATION
ok    TEST-REQ-AFF-004-RECYCLE-HELPER-REJECTS-MISSING-AND-FOREIGN-GUARD
ok    TEST-REQ-CON-001-RECYCLE-PRIVATE-OPAQUE-DUPLICATE-IS-OUTSIDE-HANDOFF-PROTOCOL
ok    TEST-REQ-CON-005-RECYCLE-HANDOFF-BEFORE-RELEASE-AND-NEW-WAVE-WITHOUT-CLEANUP
ok    TEST-REQ-CON-005-RECYCLE-RETURNED-OBLIGATION-SURVIVES-BEGIN-BUSY
  Recycle: 3 thread riusati, 8 ondate, 48 payload, ready FULL e busy bounded.
ok    TEST-REQ-CON-002-RECYCLE-TWO-COMPETING-CONSUMERS-AND-LIVE-PRODUCER-REUSED
ok    TEST-REQ-CON-003-RECYCLE-OTHER-SHARD-PROGRESSES-WHILE-FIRST-GUARD-IS-HELD
ok    TEST-REQ-CON-004-WORKER-FACTORY-PREFLIGHT-AND-EMPTY-CURSOR-ROTATION
ok    TEST-REQ-CON-001-WORKER-CLAIM-BATCH-ACK-AND-IDLE-RELEASE
ok    TEST-REQ-CON-005-WORKER-QUANTUM-YIELD-RESCHEDULE-AND-MONOTONE-TOKENS
ok    TEST-REQ-CON-005-WORKER-BATCH-DEBT-BLOCKS-MORE-POP-FINISH-AND-TRANSFER
ok    TEST-REQ-AFF-004-WORKER-CURRENT-TOKEN-REQUIRED-AND-STALE-ACK-KEEPS-DEBT
ok    TEST-REQ-AFF-004-WORKER-BUFFER-RANGE-AND-PRIVATE-ALIAS-PREFLIGHT
ok    TEST-REQ-CON-005-WORKER-BEGIN-BUSY-RETAINS-CLAIMED-REFERENCE
ok    TEST-REQ-CON-005-WORKER-POP-BUSY-RETAINS-LEASE-BUFFER-AND-GENERATION
ok    TEST-REQ-CON-005-WORKER-END-BUSY-IS-FINISHING-AND-BLOCKS-NEW-POP
ok    TEST-REQ-CON-004-WORKER-SCANNED-HOME-AND-FULL-RECYCLE-RETAINED-ON-BUSY
ok    TEST-REQ-CON-005-WORKER-TWO-CONTEXTS-FULL-REFILL-PRESERVES-ALL-OBLIGATIONS
ok    TEST-REQ-CON-005-WORKER-EMPTY-OBSERVATION-AND-NEW-WAVE-AFTER-IDLE
ok    TEST-REQ-CON-002-WORKER-FOREIGN-THREAD-REFUSES-ALL-SIX-PHASES
ok    TEST-REQ-AFF-008-WORKER-LOCAL-GENERATION-LIMIT-CAN-CEDE-INTO-FRESH-CONTEXT
ok    TEST-REQ-CON-002-WORKER-CEDE-ADOPT-VALIDATES-HOME-AND-SINGLE-CALLER-OBLIGATION
ok    TEST-REQ-CON-001-WORKER-SEEDED-INDEPENDENT-OBLIGATIONS-PAYLOADS-AND-BATCH-DEBT
ok    TEST-REQ-AFF-004-WORKER-PRIVATE-SHAPES-AND-PENDING-COUNT-INVARIANTS
ok    TEST-REQ-AFF-004-WORKER-PRIVATE-INDEX-CORRUPTION-POISONS-BEFORE-ADOPT
ok    TEST-REQ-AFF-008-WORKER-BOUNDARY-EXPANSION-VALUES-ONCE-AND-ERROR-IDENTITY
ok    TEST-REQ-AFF-008-WORKER-STALE-NOT-READY-REFERENCE-CANNOT-STEAL-NEW-WAVE
ok    TEST-REQ-AFF-008-WORKER-GENERATION-OVERFLOW-PRECEDES-EMPTY-AND-YIELD-POP
  Worker: 4 thread riusati, 6 ondate, 36 payload CRC, contesti owner-only.
ok    TEST-REQ-CON-003-WORKER-REUSED-OWNER-CONTEXTS-LIVE-PRODUCERS-AND-INDEPENDENT-SHARDS
  Worker: 2 consumer owner riusati, 8 ondate, un solo obbligo per ondata.
ok    TEST-REQ-CON-002-WORKER-COMPETING-OWNER-CONTEXTS-CLAIM-ONE-OBLIGATION-PER-WAVE
89 test delle code writer superati.
ok    TEST-REQ-THR-001-POOL-CONSTRUCTION-DEFAULTS-AND-VALID-BOUNDS
ok    TEST-REQ-AFF-008-POOL-PRIVATE-CONSTRUCTION-DEFAULTS-AND-EXPLICIT-STATE
ok    TEST-REQ-AFF-008-POOL-GENERATED-EQUALITY-COMPARES-EACH-BOUNDED-SIGNAL
ok    TEST-REQ-AFF-008-POOL-DECLARED-INTEGER-DOMAINS-AND-DIRECTION-MEMBERS
ok    TEST-REQ-AFF-008-POOL-INVALID-CONFIGURATION-HAS-TYPED-REASONS
ok    TEST-REQ-THR-001-POOL-FIRST-SAMPLE-SEEDS-EXACT-FIXED-POINT-SIGNALS
ok    TEST-REQ-AFF-013-POOL-EWMA-INDEPENDENT-ORACLE-AND-NEGATIVE-ROUNDING
ok    TEST-REQ-AFF-008-POOL-INVALID-SAMPLES-PRESERVE-ENTIRE-PUBLIC-STATE
ok    TEST-REQ-AFF-008-POOL-SAMPLE-UPPER-BOUNDS-AND-CLOCK-EXHAUSTION
ok    TEST-REQ-THR-001-POOL-ADDITIVE-GROWTH-NEEDS-COMPLETE-DWELL
ok    TEST-REQ-THR-001-POOL-MULTIPLICATIVE-DECREASE-FLOORS-AND-CLAMPS
ok    TEST-REQ-THR-001-POOL-HYSTERESIS-THRESHOLDS-ARE-INCLUSIVE-AS-SPECIFIED
ok    TEST-REQ-THR-001-POOL-CONFIGURABLE-QUEUE-THRESHOLD-AND-CUSTOM-PERIOD
ok    TEST-REQ-THR-001-POOL-BOUNDS-DO-NOT-EMIT-ZERO-CHANGE-COMMANDS
ok    TEST-REQ-THR-001-POOL-HOLD-REGION-BREAKS-CONTINUOUS-DWELL
ok    TEST-REQ-THR-001-POOL-DIRECTION-CHANGE-RESTARTS-DWELL
ok    TEST-REQ-THR-001-POOL-LONG-GAP-RESETS-EWMA-AND-DWELL
ok    TEST-REQ-THR-001-POOL-GAP-EXACTLY-TWO-PERIODS-KEEPS-EXISTING-DWELL
ok    TEST-REQ-THR-001-POOL-PENDING-TARGET-IS-RETAINED-AND-SENSORS-ADVANCE
ok    TEST-REQ-THR-001-POOL-FIRST-PENDING-SAMPLE-AND-COMPLETED-COMMAND-DWELL
ok    TEST-REQ-CON-005-POOL-CROSS-THREAD-ACCESS-REJECTED-WITHOUT-OWNER-MUTATION
ok    TEST-REQ-AFF-008-POOL-PRIVATE-BOUND-AND-CLOCK-FAULTS-ARE-DETECTED
ok    TEST-REQ-CON-005-POOL-INDEPENDENT-CONTROLLERS-HAVE-DETERMINISTIC-PARALLEL-TRACES
ok    TEST-REQ-CON-005-POOL-PORT-OWNER-AND-REGISTRY-COORDINATOR-ARE-DISTINCT
ok    TEST-REQ-THR-001-POOL-ACTIVATION-RETIREMENT-AWAIT-REAL-WORKER-ACKS
ok    TEST-REQ-AFF-008-POOL-REGISTRY-COPIES-CALLER-VECTOR-AND-BINDS-ONCE
ok    TEST-REQ-AFF-008-POOL-REGISTRY-INVALID-SHAPE-DOES-NOT-BIND-ANY-PORT
ok    TEST-REQ-CON-001-POOL-RETIREMENT-PRESERVES-CLAIM-LEASE-BATCH-AND-FINISHING
ok    TEST-REQ-CON-002-POOL-RESCHEDULE-OBLIGATION-BLOCKS-RETIREMENT-UNTIL-TRANSFER
ok    TEST-REQ-CON-004-POOL-FAULTED-WORKER-RETAINS-COMMAND-REFERENCE-AND-DIAGNOSTIC
ok    TEST-REQ-AFF-008-POOL-PORT-STARTUP-VALIDATES-FLAGS-COORDINATOR-AND-IDLE-DEBTS
ok    TEST-REQ-AFF-008-POOL-STARTUP-REJECTS-COORDINATOR-AND-REUSED-WORKER-OWNER
ok    TEST-REQ-AFF-008-POOL-STARTUP-REJECTS-NONZERO-OR-PENDING-GENERATION-BEFORE-BINDING
ok    TEST-REQ-AFF-008-POOL-INVALID-SAMPLES-DO-NOT-MUTATE-CONTROLLER-OR-PORTS
ok    TEST-REQ-AFF-008-POOL-GENERATION-EXHAUSTION-PRECEDES-EVERY-CONTROLLER-AND-PORT-WRITE
ok    TEST-REQ-AFF-008-POOL-WORD-PROTOCOL-FAULTS-REFUSE-READER-COORDINATOR-AND-WORKER
ok    TEST-REQ-AFF-008-POOL-IDLE-DEBT-REFUSES-ACK-WITHOUT-POISONING-OR-RESET
ok    TEST-REQ-AFF-008-POOL-PRIVATE-REGISTRY-TARGET-CAPACITY-PREFIX-AND-COUNT-INVARIANTS
ok    TEST-REQ-AFF-008-POOL-CAS-CONFLICT-CANNOT-REPORT-REQUEST-OR-ACK-SUCCESS
ok    TEST-REQ-AFF-008-POOL-GENERATED-PORT-EQUALITY-COMPARES-REQUEST-ACK-AND-BINDING
ok    TEST-REQ-CON-005-POOL-TWO-RETIREMENT-ACKS-CAN-ARRIVE-WITH-A-PREFIX-HOLE
ok    TEST-REQ-CON-005-POOL-INACTIVE-CLAIM-KEEPS-REAL-READY-OBLIGATION-AND-CURSOR
ok    TEST-REQ-THR-001-POOL-REAL-GROW-ACKNOWLEDGES-BEFORE-TAKING-READY-WRITER
ok    TEST-REQ-THR-001-POOL-REAL-SHRINK-RETIRES-BEFORE-REMOVING-READY-WRITER
ok    TEST-REQ-CON-005-POOL-FOREIGN-OWNER-REJECTION-PRECEDES-PHASE-AND-WORD-CHECKS
ok    TEST-REQ-CON-004-POOL-EVERY-NONIDLE-PHASE-REFUSES-BEFORE-INACTIVE-OR-DEBT-VALIDATION
ok    TEST-REQ-AFF-008-POOL-IDLE-INCONSISTENCY-REFUSES-RETIREMENT-ACK-AND-C1-POISONING
ok    TEST-REQ-AFF-008-POOL-CORRUPT-WORD-PROTOCOL-PRESERVES-READY-AND-LOCAL-WORKER
ok    TEST-REQ-AFF-008-POOL-RETIREMENT-ACK-CAS-CONFLICT-CANNOT-TAKE-A-READY-WRITER
ok    TEST-REQ-CON-005-POOL-ACTIVE-EMPTY-AND-BUSY-PRESERVE-C1-CURSOR-ROTATION
ok    TEST-REQ-THR-001-POOL-RETIRE-AFTER-ACTIVE-SAMPLE-PERMITS-ONE-LAST-COMPLETE-TASK
ok    TEST-REQ-CON-002-POOL-PENDING-RETIRE-WAITS-FOR-BRIDGE-BATCH-AND-EXPLICIT-HANDOFF
ok    TEST-REQ-CON-002-POOL-FULL-RECYCLE-KEEPS-CLAIMED-AND-ROUTES-NEW-WRITER-BEFORE-RETIRE
ok    TEST-REQ-AFF-008-POOL-DISPATCH-FACTORY-TYPE-AND-CONTEXT-BINDING-REFUSE-WITHOUT-EFFECTS
ok    TEST-REQ-CON-005-POOL-DISPATCH-FACTORY-REQUIRES-COMPLETE-IDLE-BEFORE-CONSTRUCTION
ok    TEST-REQ-CON-005-POOL-DISPATCH-FOREIGN-OWNER-PRECEDES-TABLE-PHASE-AND-POOL-CHECKS
ok    TEST-REQ-CON-005-POOL-DISPATCH-INACTIVE-EMPTY-BUSY-NEVER-ENTER-ROUTING
ok    TEST-REQ-CON-002-POOL-DISPATCH-ROUTES-TWO-REAL-WRITERS-WITHOUT-IMPLICIT-BEGIN
ok    TEST-REQ-CON-002-POOL-DISPATCH-EXISTING-CLAIMED-ROUTES-WITHOUT-READING-CORRUPT-POOL-WORDS
ok    TEST-REQ-CON-002-POOL-DISPATCH-PENDING-RETIRE-DRAINS-EXISTING-CLAIMED-BEFORE-ACK
ok    TEST-REQ-CON-002-POOL-DISPATCH-FULL-RECYCLE-ROUTES-NEW-CLAIMED-WHILE-RETIRE-PENDING
ok    TEST-REQ-CON-004-POOL-DISPATCH-ALL-DISALLOWED-PHASES-PRESERVE-FIRST-FAULT-AND-DEBTS
ok    TEST-REQ-AFF-008-POOL-DISPATCH-ROUTING-FAULT-RETAINS-ACTIVATION-ACK-AND-ACQUIRED-OBLIGATION
ok    TEST-REQ-AFF-008-POOL-DISPATCH-CORRUPT-TABLE-BINDING-REFUSES-BEFORE-CLAIM-OR-ROUTING
ok    TEST-REQ-AFF-008-POOL-DISPATCH-CORRUPT-LINK-FAULTS-AFTER-CLAIM-WITHOUT-BEGIN-OR-ROLLBACK
ok    TEST-REQ-AFF-008-POOL-DISPATCH-CONTRADICTORY-GATE-OUTPUT-REFUSES-BEFORE-ROUTING
ok    TEST-REQ-CON-002-POOL-DISPATCH-WRITER-BUSY-BEGIN-KEEPS-CLAIMED-FOR-EXPLICIT-RETRY
ok    TEST-REQ-CON-002-POOL-RECYCLE-ROOM-PUBLISHES-ONCE-WITHOUT-SECOND-CLAIM-OR-ROUTING
ok    TEST-REQ-CON-002-POOL-RECYCLE-FULL-ROUTES-NEW-WRITER-WITHOUT-BEGIN-OR-CURSOR-CHANGE
ok    TEST-REQ-CON-004-POOL-RECYCLE-READY-BUSY-PRESERVES-COMPLETE-OBLIGATION-AND-RING
ok    TEST-REQ-CON-005-POOL-RECYCLE-SIX-DISALLOWED-PHASES-PRESERVE-DEBTS-AND-FIRST-FAULT
ok    TEST-REQ-CON-002-POOL-RECYCLE-EXISTING-OBLIGATION-IGNORES-INACTIVE-AND-CORRUPT-WORDS
ok    TEST-REQ-CON-002-POOL-RECYCLE-ROOM-DOES-NOT-ACKNOWLEDGE-PENDING-RETIRE
ok    TEST-REQ-AFF-008-POOL-RECYCLE-BINDING-REFUSES-BEFORE-TRANSFER
ok    TEST-REQ-CON-005-POOL-RECYCLE-FOREIGN-OWNER-PRECEDES-BINDING-AND-POOL-DATA
ok    TEST-REQ-AFF-008-POOL-RECYCLE-ROUTING-FAULT-KEEPS-COMPLETED-FULL-TRANSFER
ok    TEST-REQ-AFF-008-POOL-RECYCLE-CONTRADICTORY-OUTPUT-REFUSES-BEFORE-ROUTING-WITHOUT-C3-FAULT
ok    TEST-REQ-AFF-008-POOL-RECYCLE-INVALID-DISPATCHER-TYPE-HAS-NO-EFFECTS
ok    TEST-REQ-CON-004-POOL-RECYCLE-READY-INVARIANT-PRESERVES-ORIGINAL-C1-FAULT
ok    TEST-REQ-CON-004-POOL-RECYCLE-UNKNOWN-STATUS-REFUSES-AT-RUNTIME-WITHOUT-EFFECTS
ok    TEST-REQ-CON-002-POOL-BEGIN-REAL-ACTIVE-FORWARDS-FOUR-VALUES-WITHOUT-POP
ok    TEST-REQ-CON-002-POOL-BEGIN-FULL-RECYCLE-STARTS-CURRENT-B-INSTEAD-OF-PREVIOUS-A
ok    TEST-REQ-CON-002-POOL-BEGIN-EXISTING-CLAIM-IGNORES-INACTIVE-CORRUPT-AND-RETIRE-WORDS
ok    TEST-REQ-CON-005-POOL-BEGIN-REAL-WRITER-BUSY-KEEPS-CLAIMED-AND-BOTH-GENERATIONS
ok    TEST-REQ-CON-005-POOL-BEGIN-REAL-SERIE-BUSY-RETURNS-CLOSING-WITH-EXPLICIT-CLOSE
ok    TEST-REQ-AFF-008-POOL-BEGIN-SERIE-GENERATION-LIMIT-RETURNS-TOKEN-AND-EXPLICIT-CLOSE
ok    TEST-REQ-AFF-008-POOL-BEGIN-LOCAL-GENERATION-LIMIT-PRECEDES-WRITER-AND-SERIE-ACQUIRE
ok    TEST-REQ-AFF-008-POOL-BEGIN-BINDING-PRECEDES-ROUTING-AND-ANY-ACQUISITION
ok    TEST-REQ-CON-005-POOL-BEGIN-REAL-FOREIGN-OWNER-PRECEDES-BINDING-AND-ACQUISITIONS
ok    TEST-REQ-CON-005-POOL-BEGIN-SIX-WRONG-PHASES-PRESERVE-CAPACITIES-AND-PRIOR-FAULT
ok    TEST-REQ-AFF-008-POOL-BEGIN-ROUTING-FAULT-PRECEDES-BEGIN-AND-PRESERVES-ORIGINAL-CONDITION
ok    TEST-REQ-AFF-008-POOL-BEGIN-REAL-WRITER-NOT-READY-PROPAGATES-C1-FAULT-EQ
ok    TEST-REQ-AFF-008-POOL-BEGIN-UNEXPECTED-SERIE-ACQUIRE-KEEPS-C1-CAPACITY-AND-CONDITION-EQ
ok    TEST-REQ-AFF-008-POOL-BEGIN-INVALID-DISPATCHER-TYPE-PRESERVES-FIXTURE
ok    TEST-REQ-CON-002-POOL-STEP-IDLE-ACTIVATES-BEFORE-CLAIM-AND-FORWARDS-ORIGINAL-CURSOR
ok    TEST-REQ-CON-005-POOL-STEP-IDLE-EMPTY-ROTATES-ONCE-WITHOUT-IMPLICIT-SECOND-ATTEMPT
ok    TEST-REQ-CON-005-POOL-STEP-IDLE-REAL-READY-BUSY-FORWARDS-STATUS-WITHOUT-RETRY
ok    TEST-REQ-CON-005-POOL-STEP-IDLE-INACTIVE-KEEPS-READY-AND-CURSOR-WITHOUT-SCAN
ok    TEST-REQ-CON-005-POOL-STEP-IDLE-PENDING-RETIRE-ACKNOWLEDGES-BEFORE-READY-ACCESS
ok    TEST-REQ-CON-002-POOL-STEP-CURRENT-IGNORES-INACTIVE-CORRUPT-AND-RETIRE-WORDS
ok    TEST-REQ-CON-002-POOL-STEP-ROOM-PUBLISHES-AND-RETURNS-WITHOUT-FALL-THROUGH-OR-ACK
ok    TEST-REQ-CON-002-POOL-STEP-FULL-ROUTES-B-ONCE-AND-NEXT-STEP-IS-CURRENT
ok    TEST-REQ-CON-004-POOL-STEP-RESCHEDULE-READY-BUSY-PRESERVES-OBLIGATION-WITHOUT-RETRY
ok    TEST-REQ-CON-004-POOL-STEP-RUNNING-BATCH-FINISHING-AND-FAULTED-REFUSE-BEFORE-DELEGATION
ok    TEST-REQ-AFF-008-POOL-STEP-BINDING-PRECEDES-PHASE-AND-ANY-OPERATIONAL-ENTRY
ok    TEST-REQ-CON-005-POOL-STEP-FOREIGN-OWNER-PRECEDES-BINDING-PHASE-AND-POOL-WORDS
ok    TEST-REQ-AFF-008-POOL-STEP-FULL-ROUTING-FAULT-KEEPS-TRANSFER-AND-FIRST-CONDITION-EQ
ok    TEST-REQ-AFF-008-POOL-STEP-CLAIM-ROUTING-FAULT-KEEPS-SUCCESSFUL-ACTIVATION-ACK
ok    TEST-REQ-CON-004-POOL-STEP-GETTER-FI-OUTSIDE-TYPE-REFUSES-BEFORE-DELEGATION
ok    TEST-REQ-AFF-008-POOL-STEP-INVALID-DISPATCHER-TYPE-KEEPS-FIXTURE
  pool-chain: A :RUNNING, B 32 quantum conclusi prima della release A.
  pool-chain: A :BATCH, B 32 quantum conclusi prima della release A.
ok    TEST-REQ-CON-002-POOL-CHAIN-OTHER-SERIES-COMPLETES-BEFORE-HELD-LEASE-AND-BATCH-RELEASE
  pool-chain: capacity 1, home 0, FULL, ritiro e handoff conclusi.
  pool-chain: capacity 1, home 2, FULL, ritiro e handoff conclusi.
  pool-chain: capacity 2, home 0, ROOM, ritiro e handoff conclusi.
  pool-chain: capacity 2, home 2, ROOM, ritiro e handoff conclusi.
ok    TEST-REQ-THR-001-POOL-CHAIN-FULL-ROOM-RETIREMENT-AND-CROSS-WORKER-READY-HANDOFF
ok    TEST-REQ-CON-002-POOL-START-ACTIVATION-CLAIM-AND-ONE-BEGIN-WITH-ORIGINAL-METADATA
ok    TEST-REQ-CON-005-POOL-START-EMPTY-BUSY-INACTIVE-NEVER-ROUTE-OR-BEGIN
ok    TEST-REQ-CON-002-POOL-START-CURRENT-PRIORITIZES-OBLIGATION-OVER-INACTIVE-OR-RETIREMENT
ok    TEST-REQ-CON-002-POOL-START-FULL-BEGINS-NEW-WRITER-AND-PRESERVES-PENDING-RETIREMENT
ok    TEST-REQ-CON-002-POOL-START-ROOM-STOPS-AFTER-PUBLICATION-WITHOUT-SECOND-CLAIM-OR-ACK
ok    TEST-REQ-CON-004-POOL-START-WRITER-BUSY-PRESERVES-CLAIMED-AND-CONSUMES-NO-TOKEN
ok    TEST-REQ-CON-004-POOL-START-WRITER-BUSY-AFTER-CLAIM-KEEPS-TRANSFER-AND-ACTIVATION-ACK
ok    TEST-REQ-AFF-008-POOL-START-ROUTING-FAULT-AFTER-CLAIM-NEVER-BEGINS-OR-ROLLS-BACK-ACK
ok    TEST-REQ-CON-004-POOL-START-READY-BUSY-KEEPS-RESCHEDULE-AND-RING
ok    TEST-REQ-AFF-008-POOL-START-SERIE-BUSY-OR-GENERATION-EXHAUSTED-RETURNS-LIVE-CLOSING-TOKEN
ok    TEST-REQ-AFF-008-POOL-START-LOCAL-GENERATION-LIMIT-BEFORE-EITHER-LEASE
ok    TEST-REQ-CON-005-POOL-START-ACTIVE-BATCH-FINISHING-AND-FAULTED-REFUSE-WITHOUT-EFFECTS
ok    TEST-REQ-AFF-008-POOL-START-BINDING-BEFORE-SELECTION-OR-ACQUISITION
ok    TEST-REQ-CON-005-POOL-START-REAL-FOREIGN-OWNER-REFUSES-BEFORE-ROUTING
ok    TEST-REQ-AFF-008-POOL-START-DEFENSIVE-STATUS-AND-LINK-PAIRS-ARE-OPERATIONAL
ok    TEST-REQ-AFF-008-POOL-START-UNEXPECTED-ACQUIRE-KEEPS-FIRST-C1-CAUSE-AND-WRITER-LEASE
ok    TEST-REQ-AFF-008-POOL-START-INVALID-DISPATCHER-IS-TYPED-AND-DOES-NOT-TOUCH-FIXTURE
129 test del controllore pool superati.
ok    TEST-REQ-FOR-002-SEGMENT-HEADER-INDEPENDENT-ORACLE
ok    TEST-REQ-FOR-001-SEGMENT-HEADER-ALL-TRUNCATIONS-AND-BIT-FLIPS
ok    TEST-REQ-FOR-002-SEGMENT-HEADER-CRC-VALID-INVALID-FIELDS
ok    TEST-REQ-AFF-002-SEGMENT-HEADER-IDENTITY
ok    TEST-REQ-FOR-002-SEGMENT-HEADER-PREFLIGHT-PRESERVES-BUFFER
ok    TEST-REQ-FOR-002-LOG-HEADER-INDEPENDENT-ORACLE
ok    TEST-REQ-FOR-002-LOG-HEADER-DEFAULT-VERSION-IS-TWO
ok    TEST-REQ-FOR-001-LOG-HEADER-ALL-TRUNCATIONS
ok    TEST-REQ-FOR-001-LOG-HEADER-ALL-BIT-FLIPS
ok    TEST-REQ-FOR-002-LOG-HEADER-EVERY-RESERVED-BYTE
ok    TEST-REQ-FOR-002-LOG-HEADER-EVERY-IDENTITY-BYTE
ok    TEST-REQ-FOR-002-LOG-HEADER-CRC-VALID-WRONG-MAGIC
ok    TEST-REQ-FOR-002-LOG-HEADER-UNKNOWN-VERSION-WITH-VALID-CRC
ok    TEST-REQ-FOR-001-LOG-HEADER-CRC-BEFORE-UNKNOWN-VERSION
ok    TEST-REQ-FOR-002-LOG-HEADER-ENCODER-PREFLIGHT-PRESERVES-BUFFER
ok    TEST-REQ-FOR-002-LOG-HEADER-READER-PREFLIGHT
ok    TEST-REQ-FOR-002-COMPACTION-EMPTY-HEADERS
ok    TEST-REQ-CMP-009-COMPACTION-RESOLVED-RECORDS-AND-COUNTS
ok    TEST-REQ-FOR-002-COMPACTION-VERSION-FROM-FILE
ok    TEST-REQ-FOR-003-COMPACTION-EVERY-CONTENT-TRUNCATION
ok    TEST-REQ-FOR-001-COMPACTION-EVERY-BIT-CORRUPTION
ok    TEST-REQ-FOR-002-COMPACTION-AUTHORITATIVE-IDENTITIES
ok    TEST-REQ-FOR-002-COMPACTION-HEADER-FIELDS-AND-VERSION
ok    TEST-REQ-CMP-009-COMPACTION-REJECTS-WRITER-ORIGIN
ok    TEST-REQ-CMP-009-COMPACTION-REJECTS-PREPARED-RECORDS
ok    TEST-REQ-CMP-009-COMPACTION-REJECTS-CONTROL-RECORDS
ok    TEST-REQ-FOR-003-COMPACTION-CRC-VALID-INVALID-TYPE-AND-FLAGS
ok    TEST-REQ-FOR-003-COMPACTION-CRC-VALID-INCONSISTENT-LENGTHS
ok    TEST-REQ-FOR-001-COMPACTION-IGNORES-PHYSICAL-TAIL
ok    TEST-REQ-AFF-008-COMPACTION-EXACT-AND-EXHAUSTED-BUDGETS
ok    TEST-REQ-AFF-008-COMPACTION-INVALID-ARGUMENTS
ok    TEST-REQ-FOR-003-EDIT-ENCODING-LAYOUT
ok    TEST-REQ-FOR-003-EDIT-TRUNCATION-COUNTS-AND-LENGTHS
ok    TEST-REQ-AFF-008-EDIT-BUDGET-BOUNDARIES
ok    TEST-REQ-TXM-001-DECISION-ENCODING-LAYOUT
ok    TEST-REQ-TXM-001-DECISION-TRUNCATION-AND-BUDGETS
ok    TEST-REQ-FOR-003-CONTROL-RECORD-BOTH-VERSIONS
ok    TEST-REQ-FOR-003-CONTROL-RECORD-INTEGRITY-BEFORE-COUNTS
ok    TEST-REQ-AFF-008-ENCODER-PREFLIGHT-NO-PARTIAL-WRITE
ok    TEST-REQ-AFF-008-EDIT-CUMULATIVE-BUDGET-AND-CORRUPT-HUGE-COUNTS
ok    TEST-REQ-AFF-008-ENCODER-OVERFLOW-AND-UNUSED-SECTIONS
ok    TEST-REQ-FOR-003-DECISION-RECORD-ALL-TRUNCATIONS-AND-BIT-FLIPS
ok    TEST-REQ-AFF-008-BYTE-BUDGET-BEFORE-CRC-SCAN
ok    TEST-REQ-AFF-008-INTERNAL-RANGE-GUARDS
44 test dei metadati storage superati.
ok    TEST-REQ-AFF-001-SHORT-APPEND-AND-GROUP-FLUSH
ok    TEST-REQ-STO-003-SHORT-PREAD-POSITIONAL-NO-STATE-WRITE
ok    TEST-REQ-AFF-001-WRITE-ERRORS-NEVER-RETRY
ok    TEST-REQ-AFF-001-FLUSH-ERROR-PRESERVES-DURABLE-FRONTIER
ok    TEST-REQ-AFF-002-READ-ERRORS-NO-RETRY-NO-SHARED-MUTATION
ok    TEST-REQ-AFF-008-INVALID-PROGRESS-AND-EOF
ok    TEST-REQ-AFF-008-PREFLIGHT-BUDGET-AND-ZERO-LENGTH
ok    TEST-REQ-AFF-001-CLOSE-ONCE-EVEN-EINTR
ok    TEST-REQ-AFF-001-DIRECTORY-FLUSH-DISPATCH-AND-INVALID-RETURN
ok    TEST-REQ-STO-003-OPEN-PREFLIGHT-AND-ERRORS
ok    TEST-REQ-AFF-001-DIRECTORY-FAILURE-AND-EMPTY-FILE-FLUSH
ok    TEST-REQ-AFF-001-INVALID-CLOSE-RESULT-AND-CLOSED-READER
ok    TEST-REQ-AFF-004-INVALID-PRIVATE-DESCRIPTOR-BEFORE-SYSCALL
ok    TEST-REQ-STO-003-NATIVE-APPEND-FLUSH-AND-CHECKED-RECORD
ok    TEST-REQ-STO-003-NATIVE-NO-FOLLOW-FILE-KINDS-AND-CLOEXEC
ok    TEST-REQ-STO-003-CONCURRENT-PREAD-DISTINCT-BUFFERS
ok    TEST-REQ-FOR-003-NATIVE-TWO-SEALED-BATCHES-ONE-FLUSH
ok    TEST-REQ-AFF-004-NATIVE-ERRNO-AND-CLEANUP-PROVENANCE
ok    TEST-REQ-REC-001-IO-RENAME-MINIMUM-SOURCE-NAME
ok    TEST-REQ-REC-001-IO-RENAME-MINIMUM-DESTINATION-NAME
ok    TEST-REQ-REC-001-IO-RENAME-MAXIMUM-SOURCE-NAME
ok    TEST-REQ-REC-001-IO-RENAME-MAXIMUM-DESTINATION-NAME
ok    TEST-REQ-REC-001-IO-RENAME-BOTH-NAME-BOUNDARIES
ok    TEST-REQ-REC-001-IO-RENAME-ALL-PERMITTED-ASCII
ok    TEST-REQ-REC-001-IO-RENAME-NAMES-WITH-DOTS-AND-BACKSLASH
ok    TEST-REQ-REC-001-IO-RENAME-CASE-SENSITIVE-NAMES
ok    TEST-REQ-REC-001-IO-RENAME-STRING-FILL-POINTER
ok    TEST-REQ-REC-001-IO-RENAME-ADJUSTABLE-STRINGS-NORMALIZED
ok    TEST-REQ-REC-001-IO-RENAME-DISPLACED-STRINGS-NORMALIZED
ok    TEST-REQ-REC-001-IO-RENAME-DISPLACED-ADJUSTABLE-FILL-POINTER-NORMALIZED
ok    TEST-REQ-REC-001-IO-RENAME-PRIVATE-COPIES-BEFORE-CALLBACK-EFFECT
ok    TEST-REQ-AFF-004-IO-RENAME-NON-STRING-NAMES
ok    TEST-REQ-REC-001-IO-RENAME-EMPTY-NAME
ok    TEST-REQ-REC-001-IO-RENAME-NAME-OVER-MAXIMUM
ok    TEST-REQ-REC-001-IO-RENAME-NUL-NAME
ok    TEST-REQ-REC-001-IO-RENAME-SLASH-NAME
ok    TEST-REQ-REC-001-IO-RENAME-DOT-NAME
ok    TEST-REQ-REC-001-IO-RENAME-DOTDOT-NAME
ok    TEST-REQ-REC-001-IO-RENAME-NON-ASCII-NAME
ok    TEST-REQ-REC-001-IO-RENAME-FORBIDDEN-LAST-CHARACTER-AT-MAXIMUM-LENGTH
ok    TEST-REQ-REC-001-IO-RENAME-SAME-NAME-SAME-STRING
ok    TEST-REQ-REC-001-IO-RENAME-SAME-NAME-DISTINCT-STRINGS
ok    TEST-REQ-AFF-004-IO-RENAME-INPUT-CAPABILITY
ok    TEST-REQ-AFF-004-IO-RENAME-APPEND-CAPABILITY
ok    TEST-REQ-AFF-004-IO-RENAME-CLOSED-DIRECTORY
ok    TEST-REQ-AFF-004-IO-RENAME-FAULTED-DIRECTORY
ok    TEST-REQ-AFF-004-IO-RENAME-INVALID-PRIVATE-DESCRIPTOR
ok    TEST-REQ-AFF-004-IO-RENAME-BACKEND-KEYWORD-OMITTED
ok    TEST-REQ-AFF-004-IO-RENAME-BACKEND-CALLBACK-NIL
ok    TEST-REQ-REC-001-IO-RENAME-BACKEND-CALLBACK-PRESENT-SINGLE-CALL
ok    TEST-REQ-REC-001-IO-RENAME-DIRECTORY-DESCRIPTOR-BOUNDARIES
ok    TEST-REQ-AFF-001-IO-RENAME-FLUSH-IS-SEPARATE
ok    TEST-REQ-AFF-001-IO-RENAME-ENOENT-NO-RETRY-OR-CLOSE
ok    TEST-REQ-AFF-001-IO-RENAME-EIO-NO-RETRY-OR-CLOSE
ok    TEST-REQ-AFF-001-IO-RENAME-EINTR-NO-RETRY-OR-CLOSE
ok    TEST-REQ-AFF-001-IO-RENAME-NIL-RESULT-FAULTS
ok    TEST-REQ-AFF-001-IO-RENAME-POSITIVE-RESULT-FAULTS
ok    TEST-REQ-AFF-001-IO-RENAME-NEGATIVE-RESULT-FAULTS
ok    TEST-REQ-AFF-001-IO-RENAME-NON-INTEGER-ZERO-RESULT-FAULTS
ok    TEST-REQ-AFF-001-IO-RENAME-CALLBACK-CLOSE-THEN-RETURN-ONE-KEEPS-CLOSED
ok    TEST-REQ-AFF-001-IO-RENAME-CALLBACK-CLOSE-THEN-EIO-KEEPS-CLOSED
ok    TEST-REQ-AFF-001-IO-RENAME-CALLBACK-CLOSE-THEN-ZERO-KEEPS-CLOSED
ok    TEST-REQ-AFF-004-IO-RENAME-ORIGINAL-TYPED-CONDITION-PRESERVED
ok    TEST-REQ-AFF-004-IO-RENAME-ORIGINAL-FOREIGN-CONDITION-PRESERVED
ok    TEST-REQ-AFF-001-IO-RENAME-CONDITION-DURING-CALLBACK-RETURN
ok    TEST-REQ-AFF-001-IO-RENAME-SYSCALL-ERROR-DURING-CALLBACK-RETURN
ok    TEST-REQ-AFF-001-IO-RENAME-NONLOCAL-EXIT-CLEANUP-FAULTS-BEFORE-CALLER-CLEANUP
ok    TEST-REQ-AFF-001-IO-RENAME-HANDLER-NONLOCAL-EXIT-CLEANUP-FAULTS
ok    TEST-REQ-AFF-001-IO-RENAME-LOCAL-INTERRUPT-PROBE-CLEANUP-BOUNDARIES
ok    TEST-REQ-AFF-001-IO-RENAME-LOCAL-INTERRUPT-PROBE-FAILURE-SIGNAL
ok    TEST-REQ-AFF-004-IO-RENAME-RESULT-HANDLER-CONDITION-PRESERVED
ok    TEST-REQ-REC-001-IO-RENAME-POSTCHECKER-NIL-SUCCESS
ok    TEST-REQ-AFF-001-IO-RENAME-POSTCHECKER-NON-NIL-RESULT-FAULTS
ok    TEST-REQ-AFF-001-IO-RENAME-POSTCHECKER-INCOMPLETE-EXIT-FAULTS
ok    TEST-REQ-REC-001-IO-RENAME-NATIVE-REPLACEMENT-KEEPS-OLD-INODE-AND-APPEND
ok    TEST-REQ-REC-001-IO-RENAME-NATIVE-FSYNC-DIRECTORY-IS-EXPLICIT
ok    TEST-REQ-REC-001-IO-RENAME-NATIVE-PARENT-MOVE-KEEPS-FD-NAMESPACE-AND-CWD
ok    TEST-REQ-AFF-004-IO-RENAME-NATIVE-MISSING-SOURCE-PRESERVES-TARGET-AND-FAULTS
ok    TEST-REQ-AFF-008-IO-RENAME-NATIVE-INVALID-NAMES-PRECEDE-SYSCALL
ok    TEST-REQ-AFF-008-IO-RENAME-NATIVE-NAME-LENGTH-BOUNDARIES
ok    TEST-REQ-AFF-008-IO-RENAME-NATIVE-ADJUSTABLE-DISPLACED-FILLPOINTER-NAMES
ok    TEST-REQ-CON-004-IO-RENAME-NATIVE-FOUR-INDEPENDENT-WORKERS-BOUNDED-ROUNDS
ok    TEST-REQ-REC-001-IO-RENAME-NATIVE-VERIFIED-DISTINCT-INODES-AND-SEPARATE-FSYNC
ok    TEST-REQ-AFF-008-IO-RENAME-NATIVE-VERIFIED-FD-NAME-MISMATCHES-BEFORE-RENAME
ok    TEST-REQ-AFF-008-IO-RENAME-NATIVE-VERIFIED-HARDLINK-ALIAS-BEFORE-RENAME
ok    TEST-REQ-AFF-004-IO-RENAME-NATIVE-VERIFIED-EXIT-AFTER-EFFECT-FAULTS-WITHOUT-ROLLBACK
ok    TEST-REQ-AFF-001-FLUSH-GUARD-SUCCESS
ok    TEST-REQ-AFF-004-FLUSH-GUARD-ORIGINAL-CONDITION
ok    TEST-REQ-AFF-004-FLUSH-GUARD-NONLOCAL-EXIT
ok    TEST-REQ-AFF-008-FLUSH-GUARD-INVALID-RESULTS
ok    TEST-REQ-AFF-001-FLUSH-GUARD-ERRNO-NO-RETRY
ok    TEST-REQ-AFF-004-FLUSH-GUARD-CLOSE-SUCCESS-REJECTED
ok    TEST-REQ-AFF-004-FLUSH-GUARD-CLOSE-ERRNO-PRESERVED
ok    TEST-REQ-AFF-004-FLUSH-GUARD-CLOSE-INVALID-RESULT-PRESERVED
ok    TEST-REQ-AFF-004-FLUSH-GUARD-CLOSE-ORIGINAL-CONDITION
ok    TEST-REQ-AFF-008-FLUSH-GUARD-WRITTEN-MUTATED
ok    TEST-REQ-AFF-008-FLUSH-GUARD-PREFLIGHT-CLOSED
ok    TEST-REQ-AFF-008-FLUSH-GUARD-PREFLIGHT-INPUT
ok    TEST-REQ-AFF-004-TRANSFER-GUARD-ORIGINAL-WRITE-CONDITION
ok    TEST-REQ-AFF-004-TRANSFER-GUARD-NONLOCAL-WRITE
ok    TEST-REQ-AFF-004-TRANSFER-GUARD-CLOSED-WRITE-PROGRESS
ok    TEST-REQ-AFF-004-TRANSFER-GUARD-CLOSED-WRITE-ERRNO
ok    TEST-REQ-AFF-004-TRANSFER-GUARD-CLOSED-WRITE-INVALID-RESULT
ok    TEST-REQ-AFF-004-TRANSFER-GUARD-CLOSED-WRITE-ORIGINAL-CONDITION
ok    TEST-REQ-AFF-008-TRANSFER-GUARD-WRITTEN-MUTATED
ok    TEST-REQ-AFF-004-TRANSFER-GUARD-CLOSED-READ-PROGRESS
ok    TEST-REQ-AFF-004-TRANSFER-GUARD-NONLOCAL-READ-REMAINS-READONLY
ok    TEST-REQ-AFF-001-IO-OPEN-RELATIVE-OWNED-INPUT-EOF-AND-EXACT-IDENTITIES
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-ZERO-AND-INDEX-EOF-BOUNDARIES
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-ALL-CALLBACKS-REQUIRED-NO-LEGACY-FALLBACK
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-INVALID-BUDGETS-BEFORE-CALLBACK
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-ASCII-NAME-BOUNDS-AND-PRIVATE-COPY
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-PARENT-MODE-AND-LIFECYCLE-PREFLIGHT
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-INVALID-CHILD-FD-AND-PARENT-ALIAS-NOT-CLOSED
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-METADATA-SHAPE-AND-SIZE-BUDGET
ok    TEST-REQ-FOR-001-IO-OPEN-RELATIVE-ENTRY-IDENTITY-MISMATCH-AND-INVALID-RESULT
ok    TEST-REQ-AFF-001-IO-OPEN-RELATIVE-PARENT-CLOSED-IN-EACH-CALLBACK
ok    TEST-REQ-AFF-001-IO-OPEN-RELATIVE-CALLBACK-CONDITIONS-AND-SYSCALL-PROVENANCE
ok    TEST-REQ-AFF-004-IO-OPEN-RELATIVE-CLEANUP-FAILURE-KEEPS-PRIMARY-FIELDS-NO-RETRY
ok    TEST-REQ-AFF-004-IO-OPEN-RELATIVE-NONLOCAL-EXIT-CLEANS-CHILD-BEFORE-CALLER
ok    TEST-REQ-AFF-001-IO-OPEN-RELATIVE-NATIVE-READ-EOF-FLAGS-AND-PRESERVED-WRITER
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-NATIVE-EMPTY-FILE-ZERO-BUDGET
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-NATIVE-SPARSE-U64-EOF-EXACT-AND-ONE-UNDER
ok    TEST-REQ-AFF-008-IO-OPEN-RELATIVE-NATIVE-NO-FOLLOW-FILE-KINDS-AND-MISSING
ok    TEST-REQ-AFF-001-IO-OPEN-RELATIVE-NATIVE-PARENT-MOVE-IGNORES-REPLACEMENT-DECOY
ok    TEST-REQ-AFF-001-IO-OPEN-RELATIVE-NATIVE-REPEAT-CLOSE-OWNS-ONLY-CHILD
ok    TEST-REQ-AFF-001-IO-CREATE-RELATIVE-OWNED-APPEND-FD-ZERO-AND-EXACT-IDENTITIES
ok    TEST-REQ-AFF-008-IO-CREATE-RELATIVE-POSITIVE-BUDGET-BOUNDS-BEFORE-CALLBACK
ok    TEST-REQ-AFF-008-IO-CREATE-RELATIVE-ALL-CALLBACKS-REQUIRED-NO-LEGACY-FALLBACK
ok    TEST-REQ-AFF-008-IO-CREATE-RELATIVE-TMP-LEAF-BOUNDS-AND-PRIVATE-COPY
ok    TEST-REQ-AFF-008-IO-CREATE-RELATIVE-PARENT-MODE-AND-LIFECYCLE-PREFLIGHT
ok    TEST-REQ-AFF-008-IO-CREATE-RELATIVE-INVALID-CHILD-FD-AND-PARENT-ALIAS-NOT-CLOSED
ok    TEST-REQ-AFF-008-IO-CREATE-RELATIVE-METADATA-SHAPE-EMPTY-AND-SIZE-BUDGET
ok    TEST-REQ-FOR-001-IO-CREATE-RELATIVE-ENTRY-IDENTITY-MISMATCH-AND-INVALID-RESULT
ok    TEST-REQ-AFF-001-IO-CREATE-RELATIVE-PARENT-CLOSED-IN-EACH-CALLBACK
ok    TEST-REQ-AFF-001-IO-CREATE-RELATIVE-CALLBACK-CONDITIONS-PRESERVE-PRIMARY
ok    TEST-REQ-AFF-001-IO-CREATE-RELATIVE-SYSCALL-PROVENANCE-AT-EACH-STAGE
ok    TEST-REQ-AFF-004-IO-CREATE-RELATIVE-CLEANUP-FAILURE-KEEPS-PRIMARY-FIELDS-NO-RETRY
ok    TEST-REQ-AFF-004-IO-CREATE-RELATIVE-NONLOCAL-EXIT-CLEANS-CHILD-BEFORE-CALLER
ok    TEST-REQ-AFF-001-IO-CREATE-RELATIVE-NATIVE-APPEND-FLAGS-PERMISSIONS-AND-READONLY-IDENTITY
ok    TEST-REQ-AFF-008-IO-CREATE-RELATIVE-NATIVE-COLLISIONS-PRESERVE-FILE-FIFO-DIRECTORY-AND-SYMLINK
ok    TEST-REQ-AFF-001-IO-CREATE-RELATIVE-NATIVE-PARENT-MOVE-IGNORES-REPLACEMENT-DECOY
ok    TEST-REQ-AFF-001-IO-CREATE-RELATIVE-NATIVE-REPEATED-CLOSE-AND-DESCRIPTOR-REUSE
ok    TEST-REQ-AFF-004-IO-CREATE-RELATIVE-NATIVE-POSTCREATE-VALIDATION-FAILURE-KEEPS-ORPHAN
ok    TEST-REQ-AFF-001-IO-DIRECTORY-LOCK-SUCCESS-EXACT-FD-AND-CLOSE-ONCE
ok    TEST-REQ-AFF-001-IO-DIRECTORY-LOCK-BUSY-PRESERVES-PARENT-NO-RETRY
ok    TEST-REQ-AFF-004-IO-DIRECTORY-LOCK-ERRNO-PROVENANCE-WITHOUT-RETRY
ok    TEST-REQ-AFF-004-IO-DIRECTORY-LOCK-REJECTS-EVERY-NONZERO-OR-NONINTEGER-RESULT
ok    TEST-REQ-AFF-008-IO-DIRECTORY-LOCK-MISSING-CALLBACK-NO-NATIVE-FALLBACK
ok    TEST-REQ-AFF-008-IO-DIRECTORY-LOCK-WRONG-MODE-BEFORE-CALLBACK-OR-SUPPORT-CHECK
ok    TEST-REQ-AFF-001-IO-DIRECTORY-LOCK-CLOSED-OR-FAULTED-BEFORE-CALLBACK
ok    TEST-REQ-AFF-008-IO-DIRECTORY-LOCK-INVALID-FD-BEFORE-CALLBACK
ok    TEST-REQ-AFF-001-IO-DIRECTORY-LOCK-CALLBACK-INVALIDATES-PARENT-NO-SUCCESS
ok    TEST-REQ-AFF-004-IO-DIRECTORY-LOCK-PRESERVES-TYPED-CALLBACK-CONDITION
ok    TEST-REQ-AFF-001-IO-DIRECTORY-LOCK-NATIVE-TWO-OPENS-BUSY-CLOSE-REACQUIRE
155 test I/O superati.
ok    TEST-REQ-FOR-001-CONTROL-CANONICAL-ACTIVE-AND-CHECKPOINT-V1-V2
ok    TEST-REQ-REC-001-CONTROL-MANIFEST-COMPLETE-STATE
ok    TEST-REQ-AFF-008-CONTROL-BUILDER-COPIES-CALLER-PAYLOAD
ok    TEST-REQ-REC-001-CONTROL-PREPARE-CHUNKS-ORDER-AND-SHORT-LAST-BLOCK
ok    TEST-REQ-AFF-008-CONTROL-PREPARE-ONE-BYTE-AND-OVERSIZED-CHUNKS
ok    TEST-REQ-AFF-001-CONTROL-PREPARE-POSITIVE-SHORT-IO
ok    TEST-REQ-REC-001-CONTROL-PUBLICATION-SUCCESS-ACCESSORS-AND-RETRY
ok    TEST-REQ-AFF-008-CONTROL-BUILDER-PAYLOAD-AND-BUDGET-PREFLIGHT
ok    TEST-REQ-REC-001-CONTROL-BUILDER-REJECTS-OTHER-ACTIVE
ok    TEST-REQ-AFF-008-CONTROL-BUILDER-MANIFEST-CUMULATIVE-BUDGETS
ok    TEST-REQ-AFF-008-CONTROL-PREPARE-ZERO-CHUNK
ok    TEST-REQ-AFF-008-CONTROL-PREPARE-SHORT-SCRATCH
ok    TEST-REQ-AFF-008-CONTROL-PREPARE-THREE-SCRATCH-ALIASES
ok    TEST-REQ-AFF-008-CONTROL-PREPARE-READ-TRANSFER-BUDGET
ok    TEST-REQ-AFF-008-CONTROL-PREPARE-WRITE-TRANSFER-AND-TOTAL-BUDGETS
ok    TEST-REQ-AFF-008-CONTROL-PREPARE-STARTED-APPEND
ok    TEST-REQ-REC-001-CONTROL-PREPARE-REJECTS-PHYSICAL-ACTIVE-ALIAS
ok    TEST-REQ-AFF-008-CONTROL-PREPARE-BACKEND-MISMATCH
ok    TEST-REQ-AFF-002-CONTROL-PREPARE-READBACK-FIRST-MIDDLE-LAST-AND-BOUNDARY
ok    TEST-REQ-AFF-001-CONTROL-PREPARE-FILE-FLUSH-FAILURE
ok    TEST-REQ-AFF-001-CONTROL-PREPARE-WRITER-TYPED-ERROR-AFTER-BYTE
ok    TEST-REQ-AFF-001-CONTROL-PREPARE-WRITER-NONLOCAL-AFTER-BYTE
ok    TEST-REQ-AFF-008-CONTROL-PUBLICATION-MISSING-ENTRY-AND-RENAME-CALLBACKS
ok    TEST-REQ-AFF-008-CONTROL-REPLACEMENT-PREFLIGHT-MISSING-IDENTITY
ok    TEST-REQ-AFF-008-CONTROL-PUBLICATION-PREVIOUS-MODE-AND-BACKEND
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-CLOSED-CAPABILITIES
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-LOG-HEALTH-PREFLIGHT
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-CHECKPOINT-WRITTEN-AND-DURABLE-FRONTIERS
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-ACTIVE-WRITTEN-AND-DURABLE-FRONTIERS
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-REAL-ACTIVE-ADVANCE-BEFORE-CLAIM
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-ORIGINAL-ERROR-AT-EACH-FD-IDENTITY
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-ORIGINAL-ERROR-AT-EACH-ENTRY-IDENTITY
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-ERRNO-OPERATION-AND-NO-RETRY
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-INVALID-FD-IDENTITY-COMPONENTS
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-INVALID-ENTRY-IDENTITY-COMPONENTS
ok    TEST-REQ-REC-001-CONTROL-PUBLICATION-ENTRY-DEVICE-OR-INODE-MISMATCH-AT-EACH-STEP
ok    TEST-REQ-REC-001-CONTROL-PUBLICATION-SOURCE-TARGET-PHYSICAL-ALIAS
ok    TEST-REQ-REC-001-CONTROL-PUBLICATION-IDENTITIES-DISTINCT-IN-EITHER-COMPONENT
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-RENAME-NONZERO-OR-INVALID-RESULT
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-RENAME-ORIGINAL-TYPED-AND-FOREIGN-ERRORS
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-NONLOCAL-IDENTITY-ENTRY-AND-RENAME
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-DIRECTORY-FLUSH-NONZERO
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-DIRECTORY-FLUSH-ORIGINAL-TYPED-ERROR
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-DIRECTORY-FLUSH-NONLOCAL
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-DIRECTORY-CALLBACK-CLOSES-AND-RETURNS-ZERO
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-RENAME-CALLBACK-CLOSES-AND-RETURNS-ZERO
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-DIRECTORY-CLOSE-THEN-ORIGINAL-ERROR
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-CALLBACK-ADVANCES-ACTIVE-POSTCONDITION
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-CALLBACK-ADVANCES-CHECKPOINT-POSTCONDITION
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-CALLBACK-CLOSES-PREVIOUS-POSTCONDITION
ok    TEST-REQ-AFF-004-CONTROL-PUBLICATION-UNCAUGHT-REENTRANCY-PRESERVES-ORIGINAL
ok    TEST-REQ-REC-001-CONTROL-PUBLICATION-HANDLED-REENTRANCY-WINNER-PRESERVED
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-DIRECTORY-FRONTIER-MUTATED-IN-CALLBACK
ok    TEST-REQ-AFF-001-CONTROL-PUBLICATION-CLOSED-CHECKPOINT-AFTER-FLUSH
ok    TEST-REQ-REC-001-CONTROL-PUBLICATION-MISSING-SOURCE-OR-TARGET-ENTRY
ok    TEST-REQ-AFF-004-CONTROL-PREPARE-DIRECTORY-FLUSH-ORIGINAL-ERROR
ok    TEST-REQ-AFF-001-CONTROL-PREPARE-DIRECTORY-FLUSH-NONLOCAL
ok    TEST-REQ-AFF-001-CONTROL-PREPARE-WRITER-CLOSE-STOPS-SHORT-IO
ok    TEST-REQ-REC-001-CONTROL-PUBLICATION-CAS-LOSER-DOES-NOT-FAULT-WINNER
ok    TEST-REQ-AFF-001-CONTROL-PREPARE-WRITER-ERROR-PRESERVES-KNOWN-SHORT-PROGRESS
ok    TEST-REQ-AFF-004-CONTROL-PREPARE-ORIGINAL-ERROR-AT-EACH-IDENTITY
ok    TEST-REQ-AFF-004-CONTROL-ACTIVE-PREPARATION-ORIGINAL-ERROR-AT-EACH-IDENTITY
ok    TEST-REQ-REC-001-CONTROL-NATIVE-SUCCESS-V1-REAL-RECOVERY
ok    TEST-REQ-REC-001-CONTROL-NATIVE-SUCCESS-V2-REAL-RECOVERY
ok    TEST-REQ-REC-001-CONTROL-NATIVE-MOVED-PARENT-FD-ANCHORED-V1-V2
ok    TEST-REQ-AFF-008-CONTROL-NATIVE-SOURCE-SYMLINK-REJECTED-BEFORE-EFFECTS
ok    TEST-REQ-AFF-008-CONTROL-NATIVE-TARGET-SYMLINK-REJECTED-BEFORE-EFFECTS
ok    TEST-REQ-AFF-008-CONTROL-NATIVE-SOURCE-NAME-MISMATCH-IDENTICAL-BYTES
ok    TEST-REQ-AFF-008-CONTROL-NATIVE-WRONG-PREVIOUS-OTHER-INODE-IDENTICAL-BYTES
ok    TEST-REQ-AFF-008-CONTROL-NATIVE-HARDLINK-ALIAS-REJECTED-BEFORE-EFFECTS
ok    TEST-REQ-AFF-008-CONTROL-NATIVE-BACKEND-MISMATCH-PREFLIGHT-KEEPS-PREPARED
ok    TEST-REQ-AFF-004-CONTROL-NATIVE-FSYNC-FAILURE-AFTER-RENAME-NO-WRAPPER-READABLE-FILE
ok    TEST-REQ-CON-004-CONTROL-NATIVE-FOUR-WORKERS-FOUR-ROUNDS-V1-V2
ok    TEST-REQ-AFF-008-CONTROL-NATIVE-TIMEOUT-IS-TYPED-SEPARATE-FROM-ASSERT
ok    TEST-REQ-FOR-001-CONTROL-RECOVERY-BITWISE-FIXTURE-ORACLE
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-V1-PUBLIC-DEFAULTS
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-V2-PUBLIC-DEFAULTS
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-CHUNKS-SHORTREADS-ALL-OFFSETS
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-OWNED-MANIFEST-SCRATCH-REUSED
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-CRV-D01-ZERO-CHUNK
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-CRV-D01-SIZE-BELOW-HEADER
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-CRV-D01-BUDGET-BELOW-HEADER
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-CRV-D01-EXACT-HEADER-NO-SNAPSHOT
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-ALIAS-BEFORE-BUFFER-RANGE
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-SHORT-SCRATCH-NO-EFFECTS
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-TRANSFER-BUDGET-MIN-SIZE-CHUNK
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-WRONG-CAPABILITY-MODE
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-CLOSED-INPUT-PREFLIGHT
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-INVALID-SCANNER-BUDGETS-BEFORE-READ
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-OUT-OF-TYPE-BUDGETS-BEFORE-READ
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-EXACT-BYTE-BUDGET-AND-EXHAUSTION
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-BATCH-BUDGET-NOT-CONVERTED-TO-TAIL
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-RECORD-BUDGET-EXACT-AND-EXHAUSTED
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-EDIT-BUDGET-EXACT-AND-EXHAUSTED
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-SEGMENT-OCCURRENCES-BEFORE-COALESCENCE
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-OUTCOME-OCCURRENCES-BEFORE-COALESCENCE
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-PER-EDIT-CLOSED-REMOVED-BUDGETS
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-ZERO-OUTCOMES-VALID-ZERO-SEGMENTS-EXHAUSTED
ok    TEST-REQ-AFF-009-CONTROL-RECOVERY-DURABLE-WITNESS-BEYOND-FIRST-BAD-RECORD
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-GENUINE-TAIL-EVERY-CUT-AFTER-VALID-PREFIX
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-SEALED-SEMANTIC-ERRORS-NEVER-TAIL
ok    TEST-REQ-FOR-001-CONTROL-RECOVERY-HEADER-CRC-AND-VALIDATION-ORDER
ok    TEST-REQ-FOR-002-CONTROL-RECOVERY-INVALID-MAGIC-VALID-CRC
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-EVERY-UUID-BYTE-VALID-CRC
ok    TEST-REQ-FOR-002-CONTROL-RECOVERY-EVERY-RESERVED-BYTE-VALID-CRC
ok    TEST-REQ-FOR-002-CONTROL-RECOVERY-UNSUPPORTED-HEADER-FORMAT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-PHYSICAL-EOF-EVERY-SHORTREAD-CUT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-ORIGINAL-IO-CONDITION-OPEN-AND-CLOSED
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-ORIGINAL-FOREIGN-CONDITION-OPEN-AND-CLOSED
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-NONLOCAL-VALUES-OPEN-AND-CLOSED
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-SYSCALL-ERROR-PROGRESS-NO-RETRY
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-INVALID-READER-PROGRESS
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-CLOSE-DURING-READ-NO-RESULT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-CRV-D02-PREFIX-BEFORE-HEADER-OUTSIDE-CONTRACT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-CRV-D02-PREFIX-BEYOND-EOF-OUTSIDE-CONTRACT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-CRV-D02-COMPLETE-BEFORE-EOF-OUTSIDE-CONTRACT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-CRV-D02-TAIL-AT-EOF-OUTSIDE-CONTRACT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-PREFLIGHT-RETURN-OUTSIDE-CONTRACT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-READ-RETURN-OUTSIDE-CONTRACT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-HEADER-RETURN-OUTSIDE-CONTRACT
ok    TEST-REQ-AFF-002-CONTROL-RECOVERY-CLOSE-AFTER-REPLAY-OUTSIDE-CONTRACT
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-PUBLICATION-SUCCESS-V1-REAL-INODES-FRONTIERS
ok    TEST-REQ-REC-001-CONTROL-RECOVERY-PUBLICATION-SUCCESS-V2-REAL-INODES-FRONTIERS
ok    TEST-REQ-AFF-001-CONTROL-RECOVERY-PUBLICATION-READONLY-CAPABILITY-EXACT-NO-APPEND-SUBSTITUTION
ok    TEST-REQ-AFF-018-CONTROL-RECOVERY-PUBLICATION-SAME-UUID-DIFFERENT-VIEW-PRECLAIM-VALID-RETRY
ok    TEST-REQ-AFF-018-CONTROL-RECOVERY-PUBLICATION-DIFFERENT-UUID-VIEW-PRECLAIM-VALID-RETRY
ok    TEST-REQ-AFF-018-CONTROL-RECOVERY-PUBLICATION-INVALID-TRANSITION-NO-EFFECTS-TOKEN-USABLE
ok    TEST-REQ-AFF-001-CONTROL-RECOVERY-PUBLICATION-CLOSED-EXACT-OLD-INPUT-PRECLAIM-ALIAS-VALID-RETRY
ok    TEST-REQ-AFF-001-CONTROL-RECOVERY-PUBLICATION-FAULTED-EXACT-OLD-INPUT-PRECLAIM-ALIAS-VALID-RETRY
ok    TEST-REQ-AFF-018-CONTROL-RECOVERY-PUBLICATION-FALSE-ASSOCIATION-RENAME-BINDING-STILL-GUARDS
ok    TEST-REQ-AFF-017-CONTROL-RECOVERY-PUBLICATION-OLD-TAIL-AUTHORITATIVE-STABLE-EOF-ALLOWED
ok    TEST-REQ-AFF-004-CONTROL-RECOVERY-PUBLICATION-POSTCLAIM-DIRECTORY-SYSCALL-FAULT-NO-WRAPPER
ok    TEST-REQ-AFF-004-CONTROL-RECOVERY-PUBLICATION-POSTCLAIM-ORIGINAL-DIRECTORY-CONDITION-PRESERVED
ok    TEST-REQ-AFF-004-CONTROL-RECOVERY-PUBLICATION-POSTCLAIM-NONLOCAL-VALUES-PRESERVED
ok    TEST-REQ-AFF-018-CONTROL-RECOVERY-PUBLICATION-RECOVERY-RESULT-USED-TWICE-TOKEN-CONSUMED
ok    TEST-REQ-CON-004-CONTROL-RECOVERY-PUBLICATION-INDEPENDENT-FOUR-WORKERS-TWO-ROUNDS-V1-V2
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-PRIVATE-READ-REJECTS-ZERO-CHUNK
ok    TEST-REQ-AFF-008-CONTROL-RECOVERY-PRIVATE-CONSTRUCTOR-REJECTS-EACH-INVALID-FIELD
138 test CONTROL superati.
ok    TEST-REQ-FOR-003-VALID-LOG-ORACLE-AND-DETERMINISM
ok    TEST-REQ-FOR-003-EMPTY-LOG-AND-EMPTY-BATCHES
ok    TEST-REQ-AFF-009-EVERY-LOG-TRUNCATION
ok    TEST-REQ-AFF-009-FRONTIER-BOUNDARY-AND-FAILED-BATCH-START
ok    TEST-REQ-AFF-009-DAMAGED-WITNESS-BATCH-REMAINS-EVIDENCE
ok    TEST-REQ-AFF-009-INVALID-WITNESSES-ARE-IGNORED
ok    TEST-REQ-AFF-009-CORRUPT-LENGTH-CANNOT-HIDE-WITNESS
ok    TEST-REQ-AFF-009-BROKEN-HEADER-DOES-NOT-END-SEARCH
ok    TEST-REQ-AFF-009-WITNESS-AT-EVERY-ALIGNMENT
ok    TEST-REQ-AFF-009-NESTED-SEAL-AT-LAST-SEARCH-POSITION
ok    TEST-REQ-AFF-008-LOG-AND-BATCH-BUDGETS
ok    TEST-REQ-AFF-008-BATCH-BUDGET-CANNOT-CLASSIFY-UNCHECKED-TAIL
ok    TEST-REQ-AFF-008-SEARCH-BUDGET-COUNTS-POSITIONS
ok    TEST-REQ-AFF-008-EOF-IS-EXPLICIT-AND-COMPLETE
ok    TEST-REQ-AFF-008-INVALID-CONFIGURATION-IS-NEVER-TAIL
ok    TEST-REQ-AFF-009-U64-OFFSETS-AND-OVERFLOW
13504 mutazioni bit prima del testimone durevole verificate.
ok    TEST-REQ-AFF-009-EVERY-BIT-BEFORE-DURABLE-WITNESS
6752 mutazioni bit nel lotto finale senza testimone verificate.
ok    TEST-REQ-AFF-017-EVERY-BIT-IN-FINAL-UNWITNESSED-BATCH
ok    TEST-REQ-AFF-009-OVERLAPPING-SEAL-AFTER-NONCOVERING-FRONTIER
ok    TEST-REQ-TXM-005-DECISION-TABLE-ORDERED-UNORDERED-ORACLE
ok    TEST-REQ-TXM-005-SEEDED-HISTORIES-AND-PERMUTED-DUPLICATES
ok    TEST-REQ-TXM-001-ZERO-MAXIMUM-U64-AND-SHARED-CSN
ok    TEST-REQ-TXM-005-TABLE-OWNS-PARTICIPANT-COPIES
ok    TEST-REQ-TXM-001-PARTICIPANT-EXACT-BYTES-AND-QUERY-RANGES
ok    TEST-REQ-TXM-005-CONFLICTING-CSN-SET-OR-COUNT
ok    TEST-REQ-TXM-005-DUPLICATE-PARTICIPANTS-WITHIN-RECORD
ok    TEST-REQ-TXM-005-EVERY-CUT-KEEPS-ONLY-SEALED-DECISIONS
ok    TEST-REQ-TXM-005-PRESUMED-ABORT-AFTER-COMPLETE-TAIL-SEARCH
ok    TEST-REQ-TXM-005-SCANS-LATER-CORRUPTION-BEFORE-PAYLOAD-OR-BUDGET
ok    TEST-REQ-FOR-003-SEALED-INVALID-DECISION-PAYLOAD-IS-NOT-TAIL
ok    TEST-REQ-AFF-008-EMPTY-DECISIONS-ZERO-AND-LARGE-BUDGETS
ok    TEST-REQ-AFF-008-PHYSICAL-DUPLICATE-RECORD-BUDGETS
ok    TEST-REQ-AFF-008-INVALID-DECISION-BUDGETS-EVEN-EMPTY
ok    TEST-REQ-AFF-008-DECISION-SCANNER-BUDGETS-PROPAGATE
ok    TEST-REQ-AFF-008-DECISION-EOF-AND-VERSION-ERRORS
ok    TEST-REQ-TXM-005-HIGH-FILE-OFFSET-AND-CONFLICT-PROVENANCE
ok    TEST-REQ-TXM-005-FIRST-PHYSICAL-DECISION-CONFLICT-ACROSS-TXID-GROUPS
ok    TEST-REQ-TXM-001-PARTICIPANT-EVERY-BYTE-AND-EVERY-BIT
ok    TEST-REQ-FOR-003-SEALED-TRAILING-DECISION-PAYLOAD
ok    TEST-REQ-FOR-003-SHORT-DECISION-FRAME-REQUIRES-COVERING-WITNESS
ok    TEST-REQ-TXM-005-UNSEALED-SEMANTIC-ERRORS-AND-COVERING-WITNESS
ok    TEST-REQ-AFF-008-DECISION-BUDGET-OFFSETS-BEFORE-COALESCENCE
ok    TEST-REQ-TXM-005-PUBLIC-DEFAULT-BUDGETS-AND-EXPLICIT-VERSION
ok    TEST-REQ-TXM-001-MAXIMUM-U16-PARTICIPANT-COUNT
ok    TEST-REQ-TXM-005-RADIX-PARTICIPANT-CARDINALITIES-AND-PATTERNS
ok    TEST-REQ-TXM-001-RADIX-PARTICIPANT-EVERY-BYTE-AND-BIT
ok    TEST-REQ-TXM-005-RADIX-DUPLICATE-PARTICIPANT-OFFSET
ok    TEST-REQ-TXM-005-RADIX-PARTICIPANT-SHAPE-BEFORE-SORT
ok    TEST-REQ-TXM-005-RADIX-ENTRY-CARDINALITIES-PATTERNS-AND-STABILITY
ok    TEST-REQ-AFF-008-RADIX-ENTRY-65536-BUCKET-COUNTS
ok    TEST-REQ-TXM-001-RADIX-ENTRY-EVERY-TXID-BIT
ok    TEST-REQ-TXM-005-RADIX-ENTRY-SHAPE-BEFORE-SORT
ok    TEST-REQ-TXM-005-CONCURRENT-IMMUTABLE-TABLE-QUERIES
ok    TEST-REQ-AFF-008-RADIX-PREFIX-INVALID-TOTAL
ok    TEST-REQ-AFF-008-RADIX-ENTRY-INVALID-OBJECT-BEFORE-SLOT-ACCESS
ok    TEST-REQ-AFF-008-RADIX-INVALID-DIGIT-BEFORE-ACCESS
ok    TEST-REQ-AFF-008-RADIX-SCATTER-INVALID-ARRAYS
ok    TEST-REQ-AFF-008-RADIX-INVALID-FINAL-CURSORS
ok    TEST-REQ-AFF-008-RADIX-SCATTER-INVALID-CURSORS
ok    TEST-REQ-TXM-005-PUBLIC-PARTICIPANT-SORT-THRESHOLD-BOUNDARIES
ok    TEST-REQ-TXM-005-PUBLIC-ENTRY-SORT-THRESHOLD-BOUNDARIES
ok    TEST-REQ-TXM-005-PUBLIC-RADIX-FIRST-PHYSICAL-CONFLICT-ACROSS-GROUPS
ok    TEST-REQ-AFF-017-MANIFEST-HISTORIES-V1-V2-AND-BATCH-LAYOUTS
ok    TEST-REQ-FOR-003-MANIFEST-SNAPSHOT-SIZES-AND-PERMUTED-SECTIONS
ok    TEST-REQ-AFF-018-MANIFEST-IDEMPOTENT-CLOSURES-REMOVALS-AND-OUTCOMES
ok    TEST-REQ-FOR-003-MANIFEST-CONFLICTING-OUTCOME-AND-CLOSED-PROOF
ok    TEST-REQ-AFF-018-MANIFEST-SECTION-OVERLAP-IS-INVALID
ok    TEST-REQ-AFF-018-MANIFEST-INVALID-TRANSITIONS-NEVER-REACTIVATE
ok    TEST-REQ-FOR-003-MANIFEST-SNAPSHOT-REQUIRED-AND-VALID
ok    TEST-REQ-AFF-017-MANIFEST-EVERY-CUT-KEEPS-WHOLE-SEALED-PREFIX
ok    TEST-REQ-AFF-017-MANIFEST-OWNS-CLOSURE-AND-OUTCOME-COPIES
ok    TEST-REQ-FOR-003-MANIFEST-U64-BOUNDARIES-AND-ID-EXHAUSTION
ok    TEST-REQ-FOR-003-MANIFEST-DIRECT-API-DEFAULTS-AND-REQUIRED-OPTIONS
ok    TEST-REQ-AFF-018-MANIFEST-RESERVED-OLD-IDS-AND-UNCHANGED-ACTIVE
ok    TEST-REQ-AFF-008-MANIFEST-PHYSICAL-DUPLICATE-BUDGETS
ok    TEST-REQ-AFF-008-MANIFEST-ZERO-EMPTY-SECTIONS-AND-INVALID-BUDGETS
ok    TEST-REQ-FOR-003-MANIFEST-SEMANTIC-CORRUPTION-IN-SEALED-PREFIX
ok    TEST-REQ-AFF-009-MANIFEST-WITNESS-PRECEDES-SEMANTIC-ERRORS-AND-BUDGETS
ok    TEST-REQ-AFF-017-MANIFEST-UNSEALED-INVALID-TRANSITION-IS-EXCLUDED
ok    TEST-REQ-AFF-008-MANIFEST-SCANNER-AND-EOF-CONTRACTS
ok    TEST-REQ-AFF-018-MANIFEST-HIGH-FILE-OFFSET-AND-ERROR-PROVENANCE
ok    TEST-REQ-AFF-017-MANIFEST-FOUR-INDEPENDENT-SERIES-IN-PARALLEL
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-ALL-TRUE-V1-V2
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-EMPTY-SETS-AUTHORITATIVE-ACTIVE-CLOSURE
ok    TEST-REQ-AFF-018-MANIFEST-TRANSITION-HIGHWATER-EQUALITY-JUMP-AND-FULL-U64
ok    TEST-REQ-AFF-018-MANIFEST-TRANSITION-ACTIVE-REUSED-BELOW-HIGHWATER
ok    TEST-REQ-AFF-018-MANIFEST-TRANSITION-LAST-ID-THEN-EXHAUSTION
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-OLD-ACTIVE-MISSING-OR-REMOVED
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-OLD-ACTIVE-STILL-ACTIVE-AND-SELF
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-CLOSED-LENGTH-ONLY-FALSE
ok    TEST-REQ-TXM-007-MANIFEST-TRANSITION-CLOSED-OUTCOME-COUNT-ONLY-FALSE
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-CLOSED-STATE-AND-SAME-COUNT-REPLACEMENT
ok    TEST-REQ-TXM-007-MANIFEST-TRANSITION-ZERO-CSN-PRESENT-VERSUS-ABSENT
ok    TEST-REQ-TXM-007-MANIFEST-TRANSITION-CSN-ONLY-FALSE-FULL-U64
ok    TEST-REQ-TXM-007-MANIFEST-TRANSITION-TXID-FULL-U64-SAME-COUNT-REPLACEMENT
ok    TEST-REQ-TXM-007-MANIFEST-TRANSITION-OUTCOME-ORDER-AND-IDENTICAL-DUPLICATES
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-CLOSED-CARDINALITY-ONLY-FALSE
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-REMOVED-CARDINALITY-ONLY-FALSE
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-REMOVED-SAME-COUNT-REPLACEMENT
ok    TEST-REQ-AFF-018-MANIFEST-TRANSITION-PUBLIC-QUERIES-IMMUTABLE-ON-REPEATED-RESULTS
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-BOUNDED-GENERATIVE-MATRIX
ok    TEST-REQ-REC-001-MANIFEST-TRANSITION-PRIVATE-FI-CLOSED-STATE-ONLY-FALSE
ok    TEST-REQ-AFF-004-MANIFEST-TRANSITION-PRIVATE-FI-ORIGINAL-CONDITION-PRESERVED
ok    TEST-REQ-AFF-004-MANIFEST-TRANSITION-PRIVATE-FI-NONLOCAL-PRESERVED
ok    TEST-REQ-REC-001-INVENTORY-ADR-ACTION-TABLE
ok    TEST-REQ-REC-001-INVENTORY-ZERO-CLOSED-AND-REMOVED
ok    TEST-REQ-REC-002-INVENTORY-MISSING-LIVE-AND-HEALTH-PRIORITY
ok    TEST-REQ-REC-002-INVENTORY-BOTH-NAMES-ALWAYS-CONSERVATIVE
ok    TEST-REQ-REC-001-INVENTORY-EXHAUSTIVE-SMALL-MODEL-AND-INPUT-ORDERS
ok    TEST-REQ-AFF-008-INVENTORY-DUPLICATES-AND-INVALID-ENTRIES
ok    TEST-REQ-AFF-008-INVENTORY-PHYSICAL-AND-LIVE-BUDGETS
ok    TEST-REQ-AFF-008-INVENTORY-BUDGET-COUNTS-LIVE-NOT-OUTPUT-ROWS
ok    TEST-REQ-AFF-008-INVENTORY-INVALID-ARGUMENTS-AND-QUERY-RANGE
ok    TEST-REQ-REC-001-INVENTORY-UNSIGNED-U64-ORDER-AND-EXACT-IDENTITIES
ok    TEST-REQ-REC-001-INVENTORY-MAXIMUM-U64-ACTIVE
ok    TEST-REQ-AFF-017-INVENTORY-PLAN-OWNS-DATA-AFTER-INPUT-REUSE
ok    TEST-REQ-AFF-017-INVENTORY-FOUR-PRIVATE-SERIES-AND-SHARED-PLAN
ok    TEST-REQ-REC-001-RECOVERY-ID-FINITE-MODEL
ok    TEST-REQ-REC-001-RECOVERY-ID-HIGH-WATER-AND-ORPHANS
ok    TEST-REQ-REC-001-RECOVERY-ID-U64-FRONTIERS
ok    TEST-REQ-AFF-008-RECOVERY-ID-ORIGINAL-ERRORS-AND-BUDGETS
ok    TEST-REQ-AFF-018-RECOVERY-ID-INDEPENDENT-DECISIONS
ok    TEST-REQ-AFF-018-RECOVERY-ID-EMPTY-PLAN-INJECTION
ok    TEST-REQ-AFF-017-RECOVERY-ID-OWNED-PLAN-NO-RESERVATION
ok    TEST-REQ-AFF-017-RECOVERY-ID-FOUR-PRIVATE-SERIES
ok    TEST-REQ-REC-001-INVENTORY-DIRECTORY-ADR-TABLE-V1-V2
ok    TEST-REQ-REC-001-INVENTORY-DIRECTORY-FULL-U64-AND-MORE-THAN-EIGHT-FILES
ok    TEST-REQ-REC-002-INVENTORY-DIRECTORY-ABSENT-AND-CONFLICTING-LIVE-NAMES
ok    TEST-REQ-AFF-008-INVENTORY-DIRECTORY-THREE-IO-BUDGETS-EXACT-ONE-UNDER
ok    TEST-REQ-AFF-008-INVENTORY-DIRECTORY-IGNORED-NAMES-COUNT-BEFORE-FILTERING
ok    TEST-REQ-AFF-008-INVENTORY-DIRECTORY-INVALID-BUDGETS-BEFORE-ENUMERATION
ok    TEST-REQ-AFF-008-INVENTORY-DIRECTORY-REJECTS-INCOMPLETE-AND-INVALID-BACKEND-NAMES
ok    TEST-REQ-AFF-008-INVENTORY-DIRECTORY-CAPABILITY-AND-CALLBACK-PREFLIGHT
ok    TEST-REQ-AFF-017-INVENTORY-DIRECTORY-OWNED-LATIN1-NAMES-AND-PLAN-SURVIVE-REUSE
ok    TEST-REQ-REC-001-INVENTORY-DIRECTORY-MALFORMED-SEGMENTLIKE-NAMES-REJECTED
ok    TEST-REQ-REC-001-INVENTORY-DIRECTORY-PHYSICAL-ALIAS-AND-DUPLICATE-NAME
ok    TEST-REQ-AFF-001-INVENTORY-DIRECTORY-ORIGINAL-FAULT-AND-CALLBACK-CLOSE
ok    TEST-REQ-AFF-004-INVENTORY-DIRECTORY-NATIVE-OUTCOME-DATA-POLICY-ONLY
ok    TEST-REQ-REC-001-INVENTORY-DIRECTORY-NATIVE-REPEAT-AND-INDEPENDENT-CURSOR-V1-V2
ok    TEST-REQ-REC-002-INVENTORY-DIRECTORY-NATIVE-MISSING-AND-CONFLICTING-NAMES
ok    TEST-REQ-AFF-008-INVENTORY-DIRECTORY-NATIVE-BUDGET-FAILURE-KEEPS-PARENT-REUSABLE
ok    TEST-REQ-REC-001-INVENTORY-DIRECTORY-NATIVE-HARDLINK-ALIAS-UNCHANGED
ok    TEST-REQ-AFF-008-INVENTORY-DIRECTORY-NATIVE-SYMLINK-FIFO-DIRECTORY-REJECTED
ok    TEST-REQ-REC-001-INVENTORY-DIRECTORY-NATIVE-PARENT-RENAME-ANCHORS-ORIGINAL-FD
ok    TEST-REQ-REC-001-DIRECTORY-ID-FINITE-MODEL-ONE-ENUMERATION
ok    TEST-REQ-REC-001-DIRECTORY-ID-HIGH-WATER-ORPHANS-AND-HEALTH
ok    TEST-REQ-REC-001-DIRECTORY-ID-U64-FRONTIERS-AND-ERROR-ORDER
ok    TEST-REQ-AFF-008-DIRECTORY-ID-FIVE-BUDGETS-EXACT-AND-ONE-UNDER
ok    TEST-REQ-AFF-008-DIRECTORY-ID-INVALID-BEFORE-ENUMERATION
ok    TEST-REQ-AFF-001-DIRECTORY-ID-ORIGINAL-ERRORS-NO-PARTIAL-RESULT
ok    TEST-REQ-AFF-017-DIRECTORY-ID-OWNED-PLAN-AND-NO-RESERVATION
ok    TEST-REQ-AFF-017-DIRECTORY-ID-FOUR-PRIVATE-SERIES
ok    TEST-REQ-REC-001-DIRECTORY-ID-NATIVE-REPEAT-BYTE-PRESERVATION-V1-V2
ok    TEST-REQ-REC-001-DIRECTORY-ID-NATIVE-PARENT-RENAME-AND-EXHAUSTION
ok    TEST-REQ-REC-001-SOURCES-ONLY-LIVE-ORDERED-OWNED-V1-V2
ok    TEST-REQ-REC-002-SOURCES-NONREADY-BEFORE-ANY-OPEN
ok    TEST-REQ-REC-001-SOURCES-U64-AND-INPUT-REUSE
ok    TEST-REQ-AFF-008-SOURCES-BUDGETS-EXACT-AND-ONE-UNDER
ok    TEST-REQ-AFF-008-SOURCES-TOTAL-HIGH-BITS-NO-OVERFLOW
ok    TEST-REQ-AFF-008-SOURCES-INVALID-PREFLIGHT-AND-MISSING-CALLBACKS
ok    TEST-REQ-AFF-004-SOURCES-EACH-OPEN-METADATA-AND-ENTRY-FAILURE
ok    TEST-REQ-AFF-004-SOURCES-CLEANUP-PRIMARY-AND-ALL-CLOSE-FAILURES
ok    TEST-REQ-AFF-008-SOURCES-QUERY-AND-DEFENSIVE-PLAN-GUARDS
ok    TEST-REQ-AFF-004-SOURCES-INCOMPLETE-PARENT-AND-NONLOCAL-CLEANUP
ok    TEST-REQ-AFF-004-SOURCES-CURRENT-CHILD-CLEANUP-AND-PRIOR-CLEANUP-PRESERVED
ok    TEST-REQ-AFF-008-SOURCES-TOTAL-FIXNUM-OVERFLOW-REFUSED-BEFORE-ADDITION
ok    TEST-REQ-REC-001-SOURCES-NATIVE-READONLY-REPEAT-AND-BUDGET-CLEANUP
ok    TEST-REQ-REC-001-SOURCES-NATIVE-PARENT-RENAME-KEEPS-ORIGINAL-FD
ok    TEST-REQ-REC-001-SOURCES-FOUR-PRIVATE-SERIES-CONCURRENT
ok    TEST-REQ-REC-001-SOURCES-NATIVE-SYMLINK-AND-HARDLINK-REFUSED
170 test recovery superati.
ok    TEST-REQ-REC-001-ACTIVE-READ-ARV-D01-D06-D11-HEADER-ONLY
ok    TEST-REQ-REC-001-ACTIVE-READ-EXACT-CHUNKS-SHORTS-NO-HEADER-REREAD
ok    TEST-REQ-AFF-008-ACTIVE-READ-ARV-D01-TRUNCATED-HEADER-PREFLIGHT
ok    TEST-REQ-AFF-002-ACTIVE-READ-EARLY-PHYSICAL-EOF-HEADER-AND-BODY
ok    TEST-REQ-AFF-008-ACTIVE-READ-ARV-D01-INVALID-CHUNK-AND-HEADER-BUDGET
ok    TEST-REQ-AFF-008-ACTIVE-READ-ARV-D02-CALLER-AND-FORMAT-BYTE-LIMITS
ok    TEST-REQ-AFF-008-ACTIVE-READ-SCRATCH-ALIAS-BEFORE-RANGE-AND-ONE-BYTE-SHORT
ok    TEST-REQ-AFF-008-ACTIVE-READ-HEADER-AND-BODY-TRANSFER-CAPACITY
ok    TEST-REQ-AFF-008-ACTIVE-READ-INVALID-SCANNER-BUDGETS-BEFORE-IDENTITY
ok    TEST-REQ-AFF-008-ACTIVE-READ-OUT-OF-TYPE-BUDGETS-BEFORE-IDENTITY
ok    TEST-REQ-AFF-008-ACTIVE-READ-EXACT-SCANNER-BUDGETS-NEVER-BECOME-TAIL
ok    TEST-REQ-AFF-002-ACTIVE-READ-BACKEND-MISMATCH-BEFORE-IDENTITY
ok    TEST-REQ-AFF-002-ACTIVE-READ-ARV-D02-PHYSICAL-ALIAS-AND-FULL-IDENTITIES
ok    TEST-REQ-FOR-001-ACTIVE-READ-HEADER-CRC-BEFORE-OTHER-FIELDS-AND-BODY
ok    TEST-REQ-FOR-001-ACTIVE-READ-ENTIRE-UUID-AND-U64-ID-BEFORE-BODY
ok    TEST-REQ-FOR-002-ACTIVE-READ-MAGIC-RESERVED-VERSION-ORIGIN-BEFORE-BODY
ok    TEST-REQ-AFF-009-ACTIVE-READ-ARV-D06-D11-UNSEALED-TAIL-BOUNDARIES
ok    TEST-REQ-AFF-009-ACTIVE-READ-DURABLE-WITNESS-PRECEDES-SEMANTIC-CONFLICT
ok    TEST-REQ-AFF-009-ACTIVE-READ-WITNESS-SEARCH-AND-EXACT-DURABLE-BOUNDARY
ok    TEST-REQ-AFF-002-ACTIVE-READ-EITHER-CAPABILITY-CLOSED-BEFORE-PREFLIGHT
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D04-PREPARED-SAME-BATCH-ZERO-MAX-U64
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D04-PREPARED-DIFFERENT-BATCHES-OFFSET
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D04-OUTCOME-BEFORE-PREPARED-SAME-OTHER-BATCH
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D04-PREPARED-BUDGET-DISTINCT-NOT-PHYSICAL
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D05-IDENTICAL-OUTCOMES-COALESCE
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D05-CONFLICTING-OUTCOMES-ZERO-HIGH-BITS
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D05-OUTCOME-BUDGET-PHYSICAL-INCLUDING-ORPHANS
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D04-D05-ZERO-BUDGETS-ORDINARY-AND-EMPTY
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D07-D08-RESOLUTION-TABLE-ALL-FOUR-CASES
ok    TEST-REQ-TXM-005-ACTIVE-ARV-D07-DECISION-NONPARTICIPANT-WITH-WITHOUT-OUTCOME
ok    TEST-REQ-TXM-005-ACTIVE-ARV-D08-DECISION-CSN-CONFLICTS-LOW-HIGH-ZERO
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D08-ORPHAN-OUTCOMES-IGNORE-UNRELATED-DECISIONS
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D09-MIXED-STATISTICS-EXACT-PARTITION
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D09-UNSEALED-OUTCOME-AND-PREPARED-NOT-COUNTED
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D10-ORDERED-OUTCOMES-BINARY-SEARCH-ALL-GAPS
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D10-U64-ORDER-ALL-BITS-NO-CSN-ORDER-ASSUMPTION
ok    TEST-REQ-FOR-003-ACTIVE-ARV-D12-CLOSURE-LITERAL-BYTES-HIGH-ID-AND-CSN
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D12-SHORT-RANGE-BEFORE-ANY-WRITE
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D12-SERIES-IDENTITY-ALIAS-PRECEDES-RANGE
ok    TEST-REQ-TXM-007-ACTIVE-ARV-D10-D12-RESULT-INDEPENDENT-OF-SCRATCH-AND-DECISION-INTERNALS
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D07-FI-DECISION-PARTICIPANT-COUNT-OUTSIDE-CONTRACT
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D09-FI-EACH-INITIAL-RESOLUTION-COUNTER
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D09-FI-FINAL-RESOLUTION-PARTITION-MISMATCH
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D10-FI-PACK-CSN-TYPE-INVALID
ok    TEST-REQ-AFF-008-ACTIVE-ARV-D12-FI-CLOSURE-AND-QUERY-SHAPE-BEFORE-WRITE
ok    TEST-REQ-REC-001-ACTIVE-PUBLICATION-NATIVE-V1-DERIVED-ZERO-HIGH-U64-LOCAL-ABORT-TAIL
ok    TEST-REQ-REC-001-ACTIVE-PUBLICATION-NATIVE-V2-DERIVED-ZERO-HIGH-U64-LOCAL-ABORT-TAIL
ok    TEST-REQ-REC-001-ACTIVE-PUBLICATION-COMPLETE-FILE-LOCAL-OUTCOME-MATCHES-AUTHORITATIVE-DECISION
ok    TEST-REQ-FOR-003-ACTIVE-PUBLICATION-CLOSURE-SERIALIZED-SORTED-INDEPENDENT-CANARIES
ok    TEST-REQ-REC-001-ACTIVE-PUBLICATION-MISSING-OR-REMOVED-OLD-CLOSED-PRECLAIM
ok    TEST-REQ-REC-001-ACTIVE-PUBLICATION-SHORT-LONG-AND-PHYSICAL-EOF-PREFIX-PRECLAIM
ok    TEST-REQ-TXM-007-ACTIVE-PUBLICATION-FEWER-OR-EXTRA-OUTCOME-COUNT-PRECLAIM
ok    TEST-REQ-TXM-007-ACTIVE-PUBLICATION-ZERO-OR-TRUNCATED-HIGH-CSN-PRECLAIM
ok    TEST-REQ-TXM-007-ACTIVE-PUBLICATION-MISSING-ZERO-OUTCOME-EQUAL-COUNT-PRECLAIM
ok    TEST-REQ-TXM-007-ACTIVE-PUBLICATION-REPLACED-OUTCOME-LOCAL-ABORTED-TAIL-NOT-AUTHORITY
ok    TEST-REQ-AFF-008-ACTIVE-PUBLICATION-CLOSED-ACTIVE-OR-CANONICAL-CONTROL-FD-TOKEN-REUSABLE
ok    TEST-REQ-AFF-018-ACTIVE-PUBLICATION-HISTORICAL-CLOSED-OUTCOMES-AND-REMOVED-PRESERVED
ok    TEST-REQ-AFF-004-ACTIVE-PUBLICATION-NATIVE-DIRECTORY-FSYNC-FAULT-AFTER-RENAME
ok    TEST-REQ-AFF-004-ACTIVE-PUBLICATION-ORIGINAL-CONDITION-AFTER-RENAME-PRESERVED
59 test recovery ACTIVE superati.
ok    TEST-REQ-REC-001-ARCHIVE-READ-HEADER-ONLY-AND-EMPTY-SEALED-BATCHES
ok    TEST-REQ-AFF-002-ARCHIVE-READ-CHUNKS-SHORTS-SAME-FD-AND-LAST-SHORT-CHUNK
ok    TEST-REQ-FOR-001-ARCHIVE-READ-TRUNCATED-HEADER-BEFORE-IO
ok    TEST-REQ-AFF-008-ARCHIVE-READ-INVALID-OPTIONS-AND-WHOLE-FILE-BYTE-BUDGET
ok    TEST-REQ-AFF-008-ARCHIVE-READ-SCALAR-TYPES-BEFORE-IO
ok    TEST-REQ-AFF-008-ARCHIVE-READ-SCRATCH-ALIAS-AND-SHORT-RANGE-BEFORE-IO
ok    TEST-REQ-AFF-008-ARCHIVE-READ-TRANSFER-CAPACITY-EXACT-THRESHOLDS
ok    TEST-REQ-AFF-002-ARCHIVE-READ-CLOSED-CAPABILITY-BEFORE-PREFLIGHT
ok    TEST-REQ-AFF-002-ARCHIVE-READ-REJECTS-APPEND-AND-DIRECTORY-CAPABILITIES
ok    TEST-REQ-AFF-002-ARCHIVE-READ-EARLY-EOF-IS-NOT-A-LOG-TAIL
ok    TEST-REQ-AFF-002-ARCHIVE-READ-BACKEND-ERRORS-AND-IMPOSSIBLE-PROGRESS-NO-RETRY
ok    TEST-REQ-AFF-002-ARCHIVE-READ-REVOCATION-AFTER-PROGRESS-NEVER-RETURNS-RESULT
ok    TEST-REQ-FOR-001-ARCHIVE-READ-HEADER-CRC-PRECEDES-FIELDS-AND-BODY
ok    TEST-REQ-FOR-002-ARCHIVE-READ-MAGIC-ALL-RESERVED-BYTES-AND-UNKNOWN-VERSION
ok    TEST-REQ-FOR-001-ARCHIVE-READ-ENTIRE-ARCHIVE-UUID-DISTINCT-FROM-SERIE
ok    TEST-REQ-TXM-005-ARCHIVE-READ-IDENTICAL-DUPLICATES-CANONICAL-PARTICIPANTS
ok    TEST-REQ-TXM-005-ARCHIVE-READ-FIRST-PHYSICAL-CONFLICT-CSN-OR-PARTICIPANT
ok    TEST-REQ-FOR-003-ARCHIVE-READ-SEALED-SEMANTIC-ERRORS-NEVER-BECOME-TAIL
ok    TEST-REQ-AFF-008-ARCHIVE-READ-PHYSICAL-BUDGETS-BEFORE-COALESCENCE
ok    TEST-REQ-AFF-009-ARCHIVE-READ-UNSEALED-TAIL-AND-CONFLICT-PRESUMED-ABORT
ok    TEST-REQ-AFF-009-ARCHIVE-READ-WITNESS-SEARCH-IGNORES-CORRUPT-LENGTH-AND-EXACT-BOUNDARY
ok    TEST-REQ-AFF-009-ARCHIVE-READ-DURABLE-WITNESS-BEFORE-SEMANTIC-CONFLICT-OR-BUDGET
ok    TEST-REQ-AFF-008-ARCHIVE-TYPES-CONSTRUCTOR-REJECTS-INVALID-IDENTITY-AND-SCOPE
ok    TEST-REQ-AFF-017-ARCHIVE-TYPES-OWNS-CALLER-UUID-WITH-SEPARATE-SERIE-SCOPE
ok    TEST-REQ-TXM-001-ARCHIVE-QUERY-U64-ZERO-HIGH-MAXIMUM-AND-MISSING
ok    TEST-REQ-AFF-017-ARCHIVE-QUERY-OWNS-RESULT-AFTER-SCRATCH-AND-CALLER-REUSE
ok    TEST-REQ-TXM-001-ARCHIVE-QUERY-PARTICIPANT-ALL-BITS-AND-NONZERO-SLICE
ok    TEST-REQ-AFF-008-ARCHIVE-QUERY-INVALID-RANGES-EVEN-FOR-ABSENT-TXID
ok    TEST-REQ-AFF-008-ARCHIVE-QUERY-INVALID-TYPES-HAVE-NO-IO
ok    TEST-REQ-AFF-017-ARCHIVE-QUERY-TWO-ARCHIVES-KEEP-INDEPENDENT-DECISIONS
ok    TEST-REQ-REC-001-ARCHIVE-ACTIVE-SAME-SCOPE-DISTINCT-UUID-V1-V2
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-FOREIGN-SCOPE-SAME-UUID-BEFORE-IO
ok    TEST-REQ-AFF-002-ARCHIVE-ACTIVE-CLOSED-DECISION-BEFORE-IO
ok    TEST-REQ-AFF-002-ARCHIVE-ACTIVE-DECISION-REVOKED-DURING-HEADER-OR-BODY
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-SCRATCH-ALIAS-ARCHIVE-BEFORE-RANGE
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-NIL-OR-BARE-TABLE-TYPE-ERROR
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-ALL-EIGHT-BUDGET-TYPES-BEFORE-IO
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-INVALID-BUDGET-VALUES-BEFORE-IO
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-ALL-POSITIVE-EXACT-BUDGETS
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-BYTE-BUDGET-FORWARDED-BEFORE-IO
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-SCANNER-BUDGETS-PRESERVE-CANONICAL-ERRORS
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-PREPARED-BUDGET-ZERO-AND-ONE
ok    TEST-REQ-AFF-008-ARCHIVE-ACTIVE-OUTCOME-BUDGET-COUNTS-PHYSICAL-DUPLICATES
ok    TEST-REQ-TXM-007-ARCHIVE-ACTIVE-DERIVED-LOCAL-ABORT-CANONICAL-ZERO-MAX-U64
ok    TEST-REQ-TXM-007-ARCHIVE-ACTIVE-UNSEALED-DECISION-DOES-NOT-COMMIT
ok    TEST-REQ-TXM-007-ARCHIVE-ACTIVE-UNSEALED-ACTIVE-OUTCOME-IGNORED
ok    TEST-REQ-REC-001-ARCHIVE-NATIVE-V1-V2-COMPLETE-THROUGH-PUBLISHED-CHECKPOINT
ok    TEST-REQ-TXM-007-ARCHIVE-NATIVE-V1-V2-TAIL-EXCLUDED-THROUGH-PUBLISHED-CHECKPOINT
ok    TEST-REQ-AFF-008-ARCHIVE-GUARDS-BODY-COMPOUND-CONDITIONS-AND-EMPTY-BODY
ok    TEST-REQ-AFF-009-ARCHIVE-GUARDS-PREFLIGHT-INCONSISTENT-END-BEFORE-IO
ok    TEST-REQ-AFF-009-ARCHIVE-GUARDS-IO-RETURN-HEADER-AND-BODY-BEFORE-RESULT
ok    TEST-REQ-AFF-009-ARCHIVE-GUARDS-HEADER-DECODER-INCONSISTENT-END
ok    TEST-REQ-AFF-009-ARCHIVE-GUARDS-PREFIX-RANGE-AND-COMPLETE-TAIL-COHERENCE
ok    TEST-REQ-AFF-008-ARCHIVE-GUARDS-PRIVATE-CONSTRUCTORS-STILL-ENFORCE-TYPES
54 test recovery Archivio superati.
ok    TEST-REQ-REC-001-ACTIVE-RECOVERY-HEADER-ONLY-NATIVE-V1-V2
ok    TEST-REQ-REC-001-ACTIVE-RECOVERY-ORDINARY-PUT-TOMBSTONE-NATIVE-V1-V2
ok    TEST-REQ-TXM-007-ACTIVE-RECOVERY-LOCAL-OUTCOME-NATIVE-V1-V2
ok    TEST-REQ-TXM-005-ACTIVE-RECOVERY-DERIVED-ZERO-HIGH-U64-NATIVE-V1-V2
ok    TEST-REQ-TXM-005-ACTIVE-RECOVERY-PRESUMED-ABORT-NATIVE-V1-V2
ok    TEST-REQ-TXM-007-ACTIVE-RECOVERY-ORPHAN-OUTCOME-NATIVE-V1-V2
ok    TEST-REQ-TXM-007-ACTIVE-RECOVERY-IDENTICAL-OUTCOMES-NATIVE-V1-V2
ok    TEST-REQ-AFF-008-ACTIVE-RECOVERY-SERIALIZER-RANGE-AND-IDENTITY-ALIAS-NO-WRITE
ok    TEST-REQ-TXM-007-ACTIVE-RECOVERY-PREPARED-ACROSS-BATCHES-REJECTED
ok    TEST-REQ-TXM-007-ACTIVE-RECOVERY-PREPARED-AFTER-OUTCOME-REJECTED
ok    TEST-REQ-TXM-007-ACTIVE-RECOVERY-CONFLICTING-OUTCOMES-REJECTED
ok    TEST-REQ-TXM-005-ACTIVE-RECOVERY-DECISION-MUST-NAME-THIS-SERIES
ok    TEST-REQ-TXM-007-ACTIVE-RECOVERY-DECISION-CSN-MUST-MATCH-LOCAL-OUTCOME
ok    TEST-REQ-AFF-008-ACTIVE-RECOVERY-BYTE-BUDGET-EXACT-AND-ONE-UNDER
ok    TEST-REQ-AFF-008-ACTIVE-RECOVERY-RECORD-BUDGET-EXCLUDES-SEAL
ok    TEST-REQ-AFF-008-ACTIVE-RECOVERY-PREPARED-BUDGET-COUNTS-DISTINCT-TXIDS
ok    TEST-REQ-AFF-008-ACTIVE-RECOVERY-OUTCOME-BUDGET-COUNTS-PHYSICAL-DUPLICATES
ok    TEST-REQ-AFF-009-ACTIVE-RECOVERY-TAIL-KEPT-AFTER-LAST-COMPLETE-BATCH
ok    TEST-REQ-AFF-009-ACTIVE-RECOVERY-DURABLE-WITNESS-REJECTS-DAMAGED-MIDDLE-BATCH
ok    TEST-REQ-AFF-008-ACTIVE-RECOVERY-IDENTITY-SCRATCH-ALIAS-REJECTED-BEFORE-RANGE
ok    TEST-REQ-FOR-001-ACTIVE-RECOVERY-HEADER-ID-MUST-MATCH-CONTROL-ACTIVE
ok    TEST-REQ-FOR-001-ACTIVE-RECOVERY-COMPACTION-ORIGIN-IS-NOT-ACTIVE
ok    TEST-REQ-REC-001-ACTIVE-RECOVERY-PUBLICATION-NATIVE-REOPEN-COMPLETE-AND-TAIL
ok    TEST-REQ-REC-001-ACTIVE-RECOVERY-PUBLICATION-REJECTS-WRONG-PREFIX-BEFORE-CLAIM
ok    TEST-REQ-TXM-007-ACTIVE-RECOVERY-PUBLICATION-REJECTS-OMITTED-EXTRA-OR-CHANGED-OUTCOME
ok    TEST-REQ-REC-001-ACTIVE-RECOVERY-PUBLICATION-REJECTS-CLOSED-OLD-SEGMENT-BEFORE-CLAIM
ok    TEST-REQ-AFF-002-ACTIVE-RECOVERY-PUBLICATION-ORIGINAL-FSYNC-FAULT-AFTER-RENAME
27 test RECOVERY ACTIVE superati.
ok    TEST-REQ-REC-001-CLOSED-READ-CDR-D01-HEADER-ONLY-ALL-TRUE
ok    TEST-REQ-AFF-008-CLOSED-READ-CDR-D01-EACH-FALSE-AND-BYTE-BOUNDS
ok    TEST-REQ-FOR-001-CLOSED-READ-HEADER-CRC-PRECEDES-FIELDS-AND-BODY
ok    TEST-REQ-AFF-008-CLOSED-READ-TYPED-ARGUMENTS-BEFORE-IO
ok    TEST-REQ-AFF-002-CLOSED-READ-BACKEND-MISMATCH-BEFORE-IO
ok    TEST-REQ-AFF-002-CLOSED-READ-MODE-BEFORE-BACKEND-AND-IO
ok    TEST-REQ-AFF-002-CLOSED-READ-EITHER-CAPABILITY-CLOSED-BEFORE-IO
ok    TEST-REQ-REC-001-CLOSED-READ-MEMBERSHIP-BEFORE-HEADER
ok    TEST-REQ-AFF-008-CLOSED-READ-SCRATCH-ALIAS-RANGE-AND-CANARIES
ok    TEST-REQ-AFF-008-CLOSED-READ-PREFIX-AND-CLOSURE-BUDGETS-BEFORE-IO
ok    TEST-REQ-AFF-008-CLOSED-READ-TRANSFER-BUDGET-EXACT-AND-MINUS-ONE
ok    TEST-REQ-FOR-001-CLOSED-READ-ENTIRE-UUID-AND-FULL-U64-ID
ok    TEST-REQ-FOR-002-CLOSED-READ-MAGIC-AND-ALL-RESERVED-BYTES-BEFORE-BODY
ok    TEST-REQ-FOR-002-CLOSED-READ-UNKNOWN-VERSION-AND-ORIGIN-BEFORE-BODY
ok    TEST-REQ-FOR-002-CLOSED-READ-VERSION-COMES-FROM-SEGMENT-HEADER
ok    TEST-REQ-AFF-002-CLOSED-READ-CHUNKS-SHORTS-AND-LAST-SHORT
ok    TEST-REQ-STO-006-CLOSED-READ-HEADER-ONLY-PREFIX-IGNORES-PHYSICAL-TAIL
ok    TEST-REQ-STO-006-CLOSED-READ-PREFIX-IS-AUTHORITATIVE-OVER-COMPLETE-OR-BROKEN-TAIL
ok    TEST-REQ-AFF-002-CLOSED-READ-PHYSICAL-EOF-BEFORE-AUTHORITATIVE-PREFIX
ok    TEST-REQ-AFF-002-CLOSED-READ-ORIGINAL-CONDITIONS-PRESERVED-EVEN-AFTER-REVOCATION
ok    TEST-REQ-AFF-002-CLOSED-READ-SYSCALL-AND-INVALID-PROGRESS-STOP-AT-FIRST-ERROR
ok    TEST-REQ-AFF-002-CLOSED-READ-REVOCATION-DURING-HEADER-BODY-AND-FINAL-TRANSFER
ok    TEST-REQ-FOR-003-CLOSED-READ-CORRUPTION-BEFORE-PREFIX-IS-NEVER-TAIL
ok    TEST-REQ-STO-006-CLOSED-READ-INCOMPLETE-PREFIX-IS-REJECTED-WITHOUT-READING-TAIL
ok    TEST-REQ-AFF-008-CLOSED-READ-CDR-D03-BODY-RANGE-EACH-FALSE-AND-EXACT
ok    TEST-REQ-TXM-007-CLOSED-WRITER-OUTCOME-EDIT-TUTTE-LE-PRESENZE
ok    TEST-REQ-TXM-007-CLOSED-WRITER-OUTCOME-EDIT-CONFLITTI-ZERO-BIT-ALTI
ok    TEST-REQ-CMP-009-CLOSED-COMPACTION-PUT-TOMBSTONE-SENZA-SEAL
ok    TEST-REQ-STO-006-CLOSED-INSIEME-VUOTO-SOLO-MANIFEST-VUOTO
ok    TEST-REQ-TXM-007-CLOSED-OUTCOME-DUPLICATI-IDENTICI-UNA-CLASSIFICAZIONE
ok    TEST-REQ-TXM-007-CLOSED-OUTCOME-DUPLICATI-DISCORDI-ANCHE-ORFANI
ok    TEST-REQ-TXM-007-CLOSED-ORDINE-PREPARED-OUTCOME-E-CONFINE-LOTTI
ok    TEST-REQ-TXM-007-CLOSED-CONTEGGI-MISTI-E-METADATI-ORFANI
ok    TEST-REQ-CMP-009-CLOSED-COMPACTION-RIFIUTA-PREPARED-OUTCOME-SEAL
ok    TEST-REQ-STO-006-CLOSED-INSIEME-COMPLETO-ID-U64-ORDINE-LIBERO
ok    TEST-REQ-STO-006-CLOSED-INSIEME-MANCANTE-EXTRA-DUPLICATO
ok    TEST-REQ-STO-006-CLOSED-INSIEME-ALTRO-CONTROL-REALE
ok    TEST-REQ-STO-006-CLOSED-INSIEME-FD-CLOSED-O-CONTROL-CHIUSO
ok    TEST-REQ-AFF-008-CLOSED-INSIEME-BUDGET-ESATTO-E-PRIMA-DEL-COUNT
ok    TEST-REQ-TXM-007-CLOSED-OUTCOME-ORFANO-EDIT-OMONIMO-ACCORDO-E-CONFLITTO
ok    TEST-REQ-MVC-005-CLOSED-CSN-VUOTO-CONTRO-ZERO-PRESENTE
ok    TEST-REQ-MVC-005-CLOSED-SEAL-PREPARED-ONLY-NON-CONFONDE-TXID
ok    TEST-REQ-MVC-005-CLOSED-EDIT-ORFANI-WRITER-COMPACTION-ANCHE-VUOTI
ok    TEST-REQ-MVC-005-CLOSED-WRITER-MASSIMO-ORDINARI-OUTCOME-SEAL-EDIT
ok    TEST-REQ-MVC-005-CLOSED-COMPACTION-MASSIMO-PUT-O-TOMBSTONE-U64
ok    TEST-REQ-MVC-005-CLOSED-MASSIMO-ESCLUDE-TUTTO-OLTRE-P-ANCHE-P64
ok    TEST-REQ-MVC-005-SERIE-INSIEME-VUOTO-E-ZERO-PRESENTE
ok    TEST-REQ-MVC-005-SERIE-MASSIMO-COMPLETO-FONTI-MISTE-ORDINE-LIBERO
ok    TEST-REQ-MVC-005-SERIE-RIFIUTA-MANCANTI-EXTRA-DUPLICATI-ALTRO-CONTROL-BUDGET
ok    TEST-REQ-MVC-005-SERIE-RIFIUTA-ACTIVE-CLOSED-CONTROL-CHIUSI
ok    TEST-REQ-REC-001-CLOSED-PUBLICATION-NATIVE-V1-WRITER-COMPACTION-TAIL-READONLY
ok    TEST-REQ-REC-001-CLOSED-PUBLICATION-NATIVE-V2-COMPLETE-SET-UNORDERED
ok    TEST-REQ-REC-001-CLOSED-PUBLICATION-EMPTY-SET-AND-HEADER-PREFIX-V1-V2
ok    TEST-REQ-REC-001-CLOSED-PUBLICATION-MISSING-EXTRA-BEFORE-CLAIM-TOKEN-REUSABLE
ok    TEST-REQ-REC-001-CLOSED-PUBLICATION-DUPLICATE-ID-SAME-RESULT-OR-DISTINCT-READONLY-ALIAS
ok    TEST-REQ-REC-001-CLOSED-PUBLICATION-DIFFERENT-CONTROL-SAME-BYTES-SAME-OR-ALIAS-FD
ok    TEST-REQ-AFF-008-CLOSED-PUBLICATION-CLOSED-WRITER-OR-COMPACTION-FD-PRECLAIM-REREAD-ALIAS
ok    TEST-REQ-AFF-008-CLOSED-PUBLICATION-CLOSED-CONTROL-OR-ACTIVE-FD-PRECLAIM-RECOVERY
ok    TEST-REQ-AFF-008-CLOSED-PUBLICATION-SET-BUDGET-BEFORE-COUNT-AND-EXACT-BOUNDARY
ok    TEST-REQ-AFF-004-CLOSED-PUBLICATION-PRIVATE-DIRECTORY-FSYNC-ORIGINAL-FAULT-AFTER-RENAME
ok    TEST-REQ-AFF-009-CLOSED-GUARDS-IO-HEADER-BODY-RETURNS
ok    TEST-REQ-AFF-009-CLOSED-GUARDS-HEADER-EACH-CONJUNCT
ok    TEST-REQ-AFF-009-CLOSED-GUARDS-MANIFEST-IMPOSSIBLE-PREFIX
ok    TEST-REQ-AFF-009-CLOSED-GUARDS-BATCH-PROGRESS-AND-FRONTIERS
ok    TEST-REQ-AFF-008-CLOSED-GUARDS-BATCHES-AND-RECORD-BUDGETS
ok    TEST-REQ-AFF-009-CLOSED-GUARDS-COMPACTION-EACH-CONJUNCT
ok    TEST-REQ-AFF-009-CLOSED-GUARDS-LOCAL-STATE-AND-EDIT-VALUE
ok    TEST-REQ-AFF-009-CLOSED-GUARDS-COMPACTION-CSN-COUNT-KIND-CONSUMPTION
ok    TEST-REQ-AFF-008-CLOSED-GUARDS-PRIVATE-RESULT-TYPES-AND-SET-PREFIX
69 test recovery CLOSED superati.
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-SET-ACR-D01-D02-EXACT-SERIES-AND-EIGHT-N
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-SET-ACR-D02-EMPTY-BEFORE-BUDGETS
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-SET-ACR-D02-EACH-BUDGET-FALSE-INDEPENDENTLY
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-SET-ACR-D01-COPY-GUARD-EACH-CONDITION
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-SET-BUDGETS-PRECEDE-INVALID-ELEMENTS
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-SET-TYPED-ARGUMENTS-AND-ELEMENTS
ok    TEST-REQ-REC-002-ARCHIVE-CSN-SET-ACR-D03-OTHER-SCOPE-IN-EACH-POSITION
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-PREFLIGHT-ACR-D04-EACH-OUTER-CARDINALITY
ok    TEST-REQ-REC-002-ARCHIVE-CSN-PREFLIGHT-ACR-D04-EXACT-ARCHIVE-OBJECT
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-PREFLIGHT-TYPED-ARGUMENTS-AND-NESTED-VECTORS
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-PREFLIGHT-ACR-D05-ZERO-CLOSED-AND-ACTIVE-INCLUSIVE-TOTAL
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-PREFLIGHT-ACR-D05-INDEPENDENT-LOCAL-AND-GLOBAL-BUDGETS
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-PREFLIGHT-CARDINALITY-BEFORE-SEGMENT-BUDGETS
ok    TEST-REQ-REC-002-ARCHIVE-CSN-SET-ACR-D03-EQ-UUID-DUPLICATES
ok    TEST-REQ-REC-002-ARCHIVE-CSN-SET-ACR-D11-OWNED-CATALOG-ORDER
ok    TEST-REQ-REC-002-ARCHIVE-CSN-SET-ACR-D11-PLAN-RETAINS-ONLY-ARCHIVE-AND-SCALARS
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-PREFLIGHT-ACR-D05-FOUR-SERIES-FOUR-CLOSED-EXACT
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-PREFLIGHT-COUNT-AND-BUDGETS-BEFORE-CAPACITY-GATES
ok    TEST-REQ-REC-002-ARCHIVE-CSN-SET-ACR-D03-DISTINCT-VIEWS-SAME-UUID
ok    TEST-REQ-REC-002-ARCHIVE-CSN-SET-ACR-D03-REGISTRI-IN-EVERY-POSITION
ok    TEST-REQ-REC-002-ARCHIVE-CSN-SET-ACR-D03-REGISTRI-ABSENT-OR-CLONED
ok    TEST-REQ-REC-002-ARCHIVE-CSN-SET-ACR-D11-OWNED-COPY-SURVIVES-CALLER-MUTATION
ok    TEST-REQ-MVC-006-ACR-D09-ASSENZA-CONTRO-ZERO-IN-OGNI-FONTE
ok    TEST-REQ-MVC-006-ACR-D08-MASSIMO-LOG-E-SERIE-MAGGIORE-MINORE-UGUALE
ok    TEST-REQ-MVC-006-ACR-D09-TXID-ALTI-NON-DIVENTANO-CSN
ok    TEST-REQ-MVC-006-ACR-D08-DECISIONI-ORFANE-ORDINE-TXID-CSN-INDIPENDENTE
ok    TEST-REQ-MVC-006-ACR-D08-CODE-DECISION-ACTIVE-CLOSED-ESCLUSE
ok    TEST-REQ-MVC-006-ACR-D09-SEAL-ED-EDIT-ORFANI-CON-BIT-ALTI
ok    TEST-REQ-TXM-005-ACR-D06-REPLAY-DISTINTO-STESSI-BYTE-ACTIVE-VUOTO-O-PREPARED
ok    TEST-REQ-TXM-005-ACR-D06-VISTA-CLONE-STESSO-UUID-STESSO-AMBITO
ok    TEST-REQ-STO-006-ACR-D07-CLOSED-MANCANTI-EXTRA-DUPLICATI-IN-SERIE-SUCCESSIVA
ok    TEST-REQ-STO-006-ACR-D07-CLOSED-ALTRO-CONTROL-STESSI-BYTE-E-P
ok    TEST-REQ-AFF-008-ACR-D07-FD-DECISION-ACTIVE-CONTROL-CLOSED-CHIUSI
ok    TEST-REQ-MVC-006-ACR-D09-PIANO-CONSEGNATO-INTERROGABILE-DOPO-CHIUSURA-FONTI
ok    TEST-REQ-TXM-005-ACR-D06-ACTIVE-SCAMBIATI-O-RIPETUTI
ok    TEST-REQ-TXM-005-ACR-D06-ALTRO-ARCHIVIO-STESSO-UUID-REPLAY-REALE
ok    TEST-REQ-MVC-006-ACR-D09-CODE-SOLE-NON-CREANO-PRESENZA-CSN
ok    TEST-REQ-TXM-005-ACR-D06-TABELLA-INDIPENDENTE-LOW-LEVEL-ACTIVE-VUOTO
ok    TEST-REQ-TXM-005-ACR-D06-ALTRO-ARCHIVIO-AMBITO-DIVERSO
ok    TEST-REQ-MVC-006-ARCHIVE-CSN-NATIVE-V1-REGISTRI-LAST-ALL-SERIES-TAIL-EXCLUDED
ok    TEST-REQ-MVC-006-ARCHIVE-CSN-NATIVE-V2-REGISTRI-NONFIXED-UNREFERENCED-DECISION-WINS
ok    TEST-REQ-MVC-006-ARCHIVE-CSN-NATIVE-ABSENCE-VERSUS-PRESENT-ZERO-BASE-FIRST-ONE
ok    TEST-REQ-MVC-006-ARCHIVE-CSN-NATIVE-EACH-SOURCE-BASE-U32-CARRY-FIRST-M-PLUS-ONE
ok    TEST-REQ-MVC-006-ARCHIVE-CSN-NATIVE-U64-LIMIT-EMITS-LAST-ONCE-THEN-EXHAUSTED-NO-WRAP
ok    TEST-REQ-MVC-006-ARCHIVE-CSN-NATIVE-CALLER-VECTORS-UUID-SCRATCH-PLAN-REMAIN-INDEPENDENT
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-NATIVE-GATES-COUNT-CLOSED-DUPLICATES-BUDGETS-REGISTRI-SCOPE
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-NATIVE-CLOSED-DECISION-CONTROL-ACTIVE-WRITER-COMPACTION-FD
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-NATIVE-REPLAY-MARKER-ARCHIVE-OWNER-CANONICAL-VIEW-GATES
ok    TEST-REQ-AFF-009-ARCHIVE-CSN-GUARDS-RESULT-CONSUMPTION
ok    TEST-REQ-AFF-009-ARCHIVE-CSN-GUARDS-RESULT-ABSENCE-REQUIRES-ZERO
ok    TEST-REQ-AFF-009-ARCHIVE-CSN-GUARDS-DECISION-LIFETIME-RECHECKED-AFTER-SERIES
ok    TEST-REQ-AFF-009-ARCHIVE-CSN-GUARDS-DECISION-SHAPE-BEFORE-MAXIMUM
ok    TEST-REQ-AFF-008-ARCHIVE-CSN-GUARDS-PRIVATE-CONSTRUCTORS-AND-QUERY-TYPES
ok    TEST-REQ-AFF-009-ARCHIVE-CSN-GUARDS-CLOSED-STATE-AND-PREFIX-DELEGATED
54 test piano CSN Archivio superati.
ok    TEST-REQ-MVC-006-RUNTIME-ASSENZA-E-ZERO-OSSERVATO-PRIMO-CSN-UNO
ok    TEST-REQ-MVC-006-RUNTIME-PIU-SERIE-DECISION-O-CLOSED-DOMINANTI
ok    TEST-REQ-MVC-006-RUNTIME-RIPORTO-U32-E-BIT-ALTI
ok    TEST-REQ-MVC-008-RUNTIME-LIMITE-U64-NESSUN-WRAP-O-MUTAZIONE-SU-ESAURIMENTO
ok    TEST-REQ-MVC-005-RUNTIME-DOPPIO-AVVIO-STESSO-PIANO-O-PIANO-DISTINTO-RIFIUTATO
ok    TEST-REQ-MVC-005-RUNTIME-ARCHIVI-DISTINTI-STESSO-UUID-INDIPENDENTI
ok    TEST-REQ-AFF-008-RUNTIME-CAPACITA-INVALIDE-PRIMA-DEL-BINDING-POI-SUCCESSO
ok    TEST-REQ-AFF-008-RUNTIME-TICK-INVALIDI-PRIMA-DEL-BINDING-POI-SUCCESSO
ok    TEST-REQ-AFF-008-RUNTIME-QUATTRO-CAPACITA-MASSIME-SIMULTANEE
ok    TEST-REQ-AFF-008-RUNTIME-TIPI-PIANO-E-GETTER-ERRATI-SENZA-BINDING-PARZIALE
ok    TEST-REQ-MVC-007-RUNTIME-DURATE-MASSIME-U64-VALIDE
ok    TEST-REQ-REC-001-RUNTIME-PIANO-CHIUSO-FONTI-CHIUSE-NESSUNA-RILETTURA
ok    TEST-REQ-MVC-007-RUNTIME-SNAPSHOT-CATTURA-CSN-CANONICO-ATTENDE-ORIZZONTE
ok    TEST-REQ-MVC-005-RUNTIME-GET-CORRENTE-E-SNAPSHOT-LEGAMI-E-BYTE-COERENTI
ok    TEST-REQ-MVC-005-RUNTIME-GET-RIFIUTA-VISTA-E-SNAPSHOT-DEL-BOOTSTRAP-SENZA-PIN
ok    TEST-REQ-MVC-006-RUNTIME-TWO-PLANS-ONE-CANONICAL-PUBLICATION
ok    TEST-REQ-MVC-007-RUNTIME-SHARED-CSN-OUT-OF-ORDER-RESOLUTION-AND-SNAPSHOT
ok    TEST-REQ-MVC-006-RUNTIME-NATIVE-COMPLETE-PLAN-FACTORY-FIRST-M-PLUS-ONE
ok    TEST-REQ-MVC-007-RUNTIME-NATIVE-CONFIGURED-CAPACITIES-ISOLATED-FROM-RECOVERY-SCOPE
ok    TEST-REQ-MVC-006-RUNTIME-NATIVE-BINDING-AND-GETTERS-AFTER-SOURCE-FDS-CLOSED
ok    TEST-REQ-AFF-009-RUNTIME-GUARDS-SLOT-ESTRANEO-RIPRISTINATO
ok    TEST-REQ-AFF-009-RUNTIME-GUARDS-PIANO-CONTEGGI-INCOERENTI
ok    TEST-REQ-AFF-009-RUNTIME-GUARDS-PIANO-ASSENZA-RICHIEDE-ZERO
ok    TEST-REQ-AFF-009-RUNTIME-GUARDS-SNAPSHOT-ALTRO-CSN-BASE-IDENTICA
ok    TEST-REQ-AFF-009-RUNTIME-GUARDS-VECCHIO-AMBITO-CON-LINK-CSN-CORRETTO
ok    TEST-REQ-AFF-009-RUNTIME-GUARDS-BASE-HIGH-LOW-INDIPENDENTI
ok    TEST-REQ-AFF-009-RUNTIME-GUARDS-ULTIMO-CORRETTO-ORIZZONTE-DIVERSO
ok    TEST-REQ-MVC-006-RUNTIME-ADOPTION-NATIVE-V1-V2-DEFAULT-SINGLETON-NOEFFECTS
ok    TEST-REQ-AFF-008-RUNTIME-ADOPTION-CAPACITY-PREFLIGHT-NO-PARTIAL-BINDING
ok    TEST-REQ-MVC-005-RUNTIME-ADOPTION-EXACT-SCOPE-EVEN-SAME-CSN-AND-EPOCHS
ok    TEST-REQ-AFF-008-RUNTIME-ADOPTION-CLOSED-READONLY-OR-APPEND-NO-BINDING
ok    TEST-REQ-MVC-008-RUNTIME-ADOPTION-ADVANCED-WRITTEN-AND-DURABLE-REFUSED
ok    TEST-REQ-AFF-008-RUNTIME-ADOPTION-EXACT-FILE-CAPABILITIES-NOT-INODE-ONLY
ok    TEST-REQ-AFF-008-RUNTIME-ADOPTION-LOG-ID-VERSION-AND-KIND-PREFLIGHT
ok    TEST-REQ-AFF-008-RUNTIME-ADOPTION-REAL-COMPACTION-HEADER-IS-NOT-WRITER
ok    TEST-REQ-AFF-001-RUNTIME-ADOPTION-FAULTED-LOG-NO-PARTIAL-BINDING
ok    TEST-REQ-CON-002-RUNTIME-ADOPTION-REFUSES-LOG-ALREADY-BOUND-BY-GENERIC-FACTORY
ok    TEST-REQ-MVC-008-RUNTIME-ADOPTION-NATIVE-FIRST-COMMIT-AND-COMMON-SNAPSHOT-TWO-SERIES
38 test bootstrap runtime superati.
ok    TEST-REQ-WAL-005-CODEC-V1-V2-AND-HIGH-U64
ok    TEST-REQ-WAL-005-PRESERVE-PREPARED-OUTCOME-DECISION-TXID
ok    TEST-REQ-WAL-005-EMPTY-AND-SEAL-EXACT-CAPACITY
ok    TEST-REQ-AFF-008-BUILDER-PREFLIGHT-AND-SEALED-IMMUTABILITY
ok    TEST-REQ-WAL-002-TWO-LOTS-ONE-FLUSH-AND-REUSE
ok    TEST-REQ-AFF-008-GROUP-BUDGET-IDENTITY-AND-ORDER
ok    TEST-REQ-AFF-008-FILE-BUDGET-BEFORE-ANY-WRITE
ok    TEST-REQ-WAL-005-OFFSET-AND-DURABLE-WITNESS-BEFORE-WRITE
ok    TEST-REQ-WAL-003-CONTROL-LOG-NEVER-ASYNC
ok    TEST-REQ-AFF-008-CANCEL-UNSENT-GROUP-RELEASES-CAPACITY
ok    TEST-REQ-AFF-001-WRITE-FAILURE-STOPS-LOG-AND-ALL-BATCHES
ok    TEST-REQ-AFF-001-FLUSH-FAILURE-NEVER-ADVANCES-DURABILITY
ok    TEST-REQ-WAL-005-CRASH-AT-EVERY-WRITTEN-BYTE-V1-V2
ok    TEST-REQ-AFF-001-PRIVATE-OWNERSHIP-VIOLATION-STOPS-BEFORE-FLUSH
ok    TEST-REQ-WAL-002-SECOND-GROUP-REJECTED-UNTIL-FLUSH
ok    TEST-REQ-WAL-002-CONCURRENT-GROUPS-AT-MOST-ONE-WRITE
ok    TEST-REQ-WAL-002-CONCURRENT-FLUSH-AT-MOST-ONE-SYSCALL
ok    TEST-REQ-WAL-002-NATIVE-GROUP-AND-DURABLE-WITNESS-V1-V2
ok    TEST-REQ-AFF-009-SUBSEQUENT-BATCH-WITNESS-DETECTS-OLD-CORRUPTION
ok    TEST-REQ-MVC-008-WAL-CSN-FREE-ASSOCIATION-REJECTIONS
ok    TEST-REQ-MVC-008-WAL-CSN-LIMB-BOUNDARIES-V1-V2
ok    TEST-REQ-WAL-005-WAL-CSN-PREPARED-AND-ORDINARY-STAMPS
ok    TEST-REQ-WAL-005-WAL-CSN-MANUAL-API-REMAINS-UNBOUND
ok    TEST-REQ-MVC-008-WAL-CSN-EMPTY-AND-CONTROL-CONTENT-BEFORE-ASSIGNMENT
ok    TEST-REQ-MVC-008-WAL-CSN-LOG-LAYOUT-BEFORE-ASSIGNMENT
ok    TEST-REQ-AFF-008-WAL-CSN-OFFSETS-BEFORE-ASSIGNMENT
ok    TEST-REQ-AFF-004-WAL-CSN-PRIVATE-SHAPE-AND-SEAL-BUDGET-BEFORE-ASSIGNMENT
ok    TEST-REQ-AFF-001-WAL-CSN-FAULTED-LOG-BEFORE-ASSIGNMENT
ok    TEST-REQ-AFF-008-WAL-CSN-FULL-BUSY-AND-EXHAUSTED-BEFORE-ASSIGNMENT
ok    TEST-REQ-MVC-008-WAL-CSN-REPEAT-SEAL-BEFORE-ASSIGNMENT
ok    TEST-REQ-WAL-006-WAL-CSN-FULL-WRITE-AND-PUBLICATION-LEVELS
ok    TEST-REQ-WAL-006-WAL-CSN-ASYNC-BEFORE-FLUSH-CANNOT-REUSE
ok    TEST-REQ-MVC-008-WAL-CSN-DURABLE-BEFORE-PUBLICATION-AND-REUSE
ok    TEST-REQ-MVC-008-WAL-CSN-HORIZON-GAP-ACROSS-INDEPENDENT-LOGS
ok    TEST-REQ-MVC-008-WAL-CSN-BUSY-PUBLICATION-KEEPS-TOKEN
ok    TEST-REQ-MVC-008-WAL-CSN-DOUBLE-RESOLVER-AND-OWNED-REUSE
ok    TEST-REQ-MVC-008-WAL-CSN-STALE-EVENT-AFTER-REUSE
ok    TEST-REQ-MVC-008-WAL-CSN-WRONG-REGISTRY-AND-TOKEN-IDENTITY
ok    TEST-REQ-MVC-008-WAL-CSN-NONLIVE-REGISTRY-TOKEN
ok    TEST-REQ-WAL-006-WAL-CSN-HEALTHY-ANNULMENT-ALWAYS-REFUSED
ok    TEST-REQ-AFF-001-WAL-CSN-PARTIAL-WRITE-FAULT-ANNULMENT
ok    TEST-REQ-AFF-001-WAL-CSN-FLUSH-FAULT-BUSY-ANNULMENT
ok    TEST-REQ-AFF-001-WAL-CSN-LATER-LOG-FAULT-REJECTS-OLD-PUBLICATION
ok    TEST-REQ-MVC-008-WAL-CSN-BOUND-LOG-IDENTITY-BEFORE-OWNERSHIP
ok    TEST-REQ-AFF-004-WAL-CSN-INCOMPLETE-ASSOCIATION-BEFORE-RESOLUTION
ok    TEST-REQ-AFF-008-WAL-CSN-FILE-BUDGET-AND-AVAILABILITY-BEFORE-ASSIGNMENT
ok    TEST-REQ-AFF-004-WAL-CSN-INVALID-RECORD-OFFSET-RETAINS-OBLIGATION
  WAL/CSN: 4 Serie x 500 cicli, 584 busy, 144 full, H convergente.
ok    TEST-REQ-MVC-008-FOUR-SERIES-SHARED-CSN-WAL-LIFECYCLE
48 test WAL superati.
ok    TEST-REQ-WAL-006-SERIES-BOOTSTRAP-CAPACITY-OFFSET-CSN-AND-EFFECT-BOUNDARIES
ok    TEST-REQ-WAL-006-SERIES-BOOTSTRAP-ACCEPTS-OPAQUE-NON-NIL-VALUES
ok    TEST-REQ-AFF-004-SERIES-BOOTSTRAP-NIL-STALE-AND-REPEATED-BEFORE-EFFECT
ok    TEST-REQ-AFF-004-SERIES-BOOTSTRAP-VIRGIN-GUARDS-AND-EXISTING-READER-ROOT
ok    TEST-REQ-WAL-006-SERIES-BOOTSTRAP-REFUSES-USED-EMPTY-RING-WITH-NIL-ROOT
ok    TEST-REQ-WAL-006-SERIES-BOOTSTRAP-FIRST-COMMIT-REQUIRES-INITIAL-ROOT-IDENTITY
ok    TEST-REQ-AFF-001-SERIES-BOOTSTRAP-HEALTH-AND-RING-PRECEDE-EFFECT
ok    TEST-REQ-AFF-001-SERIES-BOOTSTRAP-ACQUIRED-EFFECT-EXIT-PRESERVES-CAUSE-AND-ROOTS
ok    TEST-REQ-AFF-001-SERIES-BOOTSTRAP-PREEXISTING-EFFECT-KEEPS-OUTER-OWNERSHIP
ok    TEST-REQ-AFF-001-SERIES-BOOTSTRAP-CAS-CORRUPTION-KEEPS-FIRST-CONDITION-AND-FAULTS-ARCHIVE
ok    TEST-REQ-AFF-001-SERIES-BOOTSTRAP-INCOMPLETE-END-PRESERVES-ERROR-AND-NONLOCAL-EXIT
ok    TEST-REQ-AFF-008-SERIES-DEFAULT-AND-CAPACITY-BOUNDARIES
ok    TEST-REQ-AFF-008-SERIES-INVALID-CONFIGURATION-PRESERVES-WAL
ok    TEST-REQ-CON-001-SERIES-LEASE-BUSY-STALE-AND-SINGLE-RELEASE
ok    TEST-REQ-WAL-005-SERIES-ADOPTS-SEALED-BEFORE-IO-AND-CAPTURES-TOKEN
ok    TEST-REQ-WAL-005-SERIES-REFUSES-OPEN-UNBOUND-AND-POST-DISPATCH-LOTS
ok    TEST-REQ-AFF-004-SERIES-REGISTRY-AND-LOG-BINDING-BEFORE-ADOPTION
ok    TEST-REQ-WAL-005-SERIES-OFFSET-GAP-AND-DUPLICATE-PRESERVE-OBLIGATION
ok    TEST-REQ-MVC-008-SERIES-CSN-STRICT-ORDER-EVEN-AT-CONTIGUOUS-OFFSETS
ok    TEST-REQ-WAL-006-SERIES-PLANNED-ROOT-EQ-AND-NIL-ARE-DISTINCT-PRECONDITIONS
ok    TEST-REQ-AFF-008-SERIES-FULL-KEEPS-SEALED-TOKEN-FOR-LATER-ADOPTION
ok    TEST-REQ-WAL-006-SERIES-PUBLICATION-FIFO-UNRESOLVED-AND-RETURNED-H
ok    TEST-REQ-WAL-006-SERIES-GROUP-STRONG-COVERAGE-BEFORE-ROOT-CAS
ok    TEST-REQ-WAL-006-SERIES-ASYNC-SEPARATE-PUBLICATION-AND-RETIREMENT-CURSORS
ok    TEST-REQ-AFF-004-SERIES-IO-BEGIN-ONCE-AND-WRITTEN-IS-NOT-COMPLETION
ok    TEST-REQ-WAL-005-SERIES-RETIREMENT-FIFO-RESOLVED-DURABLE-UNOWNED
ok    TEST-REQ-AFF-004-SERIES-FREE-AND-STALE-PREALLOCATED-EVENT-AFTER-WRAP
ok    TEST-REQ-AFF-004-SERIES-FOREIGN-EVENT-SAME-GENERATION-AND-CSN
ok    TEST-REQ-AFF-004-SERIES-FALSE-EVENT-AND-INVALID-GENERATION-BEFORE-MUTATION
ok    TEST-REQ-MVC-008-SERIES-BUSY-AFTER-CAS-KEEPS-ROOT-ONCE-AND-CAPTURED-TOKEN
ok    TEST-REQ-MVC-008-SERIES-HIGH-CSN-CARRY-AND-DELAYED-GLOBAL-HORIZON
ok    TEST-REQ-AFF-001-SERIES-KNOWN-WRITE-AND-FLUSH-FAULT-DRAIN-AND-ANNUL
ok    TEST-REQ-AFF-001-SERIES-TERMINAL-FAULT-AND-SCOPE-ONLY-UPGRADES
ok    TEST-REQ-AFF-001-SERIES-ANNUL-REQUIRES-LOCAL-FAULT-AND-GLOBAL-QUIESCENCE
ok    TEST-REQ-MVC-008-SERIES-ANNUL-FIFO-BUSY-PRESERVES-CAPTURED-OBLIGATION
ok    TEST-REQ-AFF-001-SERIES-ARCHIVE-FAULT-REFUSES-AUTOMATIC-ANNUL
ok    TEST-REQ-AFF-004-SERIES-CAPTURED-TOKEN-NEVER-RECONSTRUCTED-FROM-MUTATED-LOT
ok    TEST-REQ-AFF-004-SERIES-REGISTRY-INVARIANT-AFTER-ROOT-CAS-FAULTS-ARCHIVE
ok    TEST-REQ-AFF-001-SERIES-UNEXPECTED-ROOT-CAS-AND-NONLOCAL-EXIT-FAULT-ARCHIVE
ok    TEST-REQ-AFF-008-SERIES-LEASE-AND-EVENT-GENERATIONS-EXHAUST-WITHOUT-WRAP
ok    TEST-REQ-WAL-006-SERIES-INVALID-LEVEL-AND-PUBLICATION-REPLAY-PRESERVE-STATE
ok    TEST-REQ-WAL-006-SERIES-REJECTED-DISPATCH-WITHDRAWS-WITHOUT-IO-AND-H-CONVERGES
ok    TEST-REQ-AFF-004-SERIES-WITHDRAW-REFUSES-HEALTHY-OWNED-WRITTEN-STALE-AND-DOUBLE
ok    TEST-REQ-AFF-004-SERIES-WAL-PREFLIGHT-INVARIANTS-FAULT-BEFORE-ADOPTION-OR-RELEASE
ok    TEST-REQ-AFF-004-SERIES-UNCERTAIN-GETTER-FAULTS-ARCHIVE-BEFORE-AND-AFTER-CAS
ok    TEST-REQ-AFF-008-SERIES-RING-INVALID-CAPACITY-BEFORE-INDEXING
ok    TEST-REQ-CON-002-SERIES-RING-CURSORS-FAIL-SEPARATELY
ok    TEST-REQ-CON-002-SERIES-RING-COUNTS-FAIL-SEPARATELY
ok    TEST-REQ-MVC-008-SERIES-CSN-AFTER-EXPLICIT-TRUTH-PAIRS
ok    TEST-REQ-CON-002-SERIES-BOOTSTRAP-READERS-SEE-ONLY-NIL-OR-COMPLETE-ROOT
ok    TEST-REQ-CON-001-SERIES-BOOTSTRAP-FOREIGN-THREAD-CANNOT-USE-OWNER-LEASE
ok    TEST-REQ-CON-001-SERIES-FOREIGN-THREAD-LEASE-AND-RELEASE-REACQUIRE-TRANSFER
ok    TEST-REQ-CON-002-SERIES-CAS-EIGHT-CONTENDERS-ONE-OWNER
  Serie: 4 controller x 64 lotti, K=3, 10 busy, 11 full, H convergente.
ok    TEST-REQ-CON-004-SERIES-FOUR-CONTROLLERS-SHARED-BOUNDED-CSN
ok    TEST-REQ-CON-002-SERIES-IMMUTABLE-ROOT-PARALLEL-READER-AFTER-HANDOFF
ok    TEST-REQ-WAL-006-SERIES-IO-FINISH-JOINED-BEFORE-DRAIN-AND-ANNUL
ok    TEST-REQ-CON-004-SERIES-HELD-CSN-GUARD-PUBLISH-NEVER-WAITS
ok    TEST-REQ-CON-001-WORKER-SERIE-DOUBLE-LEASE-FIFO-ACK-AND-IDLE
ok    TEST-REQ-CON-005-WORKER-SERIE-QUANTUM-ROTATION-MONOTONE-TRACT-AND-BATCH
ok    TEST-REQ-CON-005-WORKER-SERIE-FIRST-LEASE-BUSY-DOES-NOT-TOUCH-SERIE
ok    TEST-REQ-CON-005-WORKER-SERIE-SECOND-LEASE-BUSY-CLOSES-WITHOUT-POP
ok    TEST-REQ-CON-005-WORKER-SERIE-SECOND-LEASE-BUSY-AND-END-BUSY-KEEP-OBLIGATION
ok    TEST-REQ-CON-005-WORKER-SERIE-RELEASES-SERIE-BEFORE-BUSY-WRITER-END
ok    TEST-REQ-AFF-004-WORKER-SERIE-BATCH-DEBT-AND-STALE-ACK-RETAIN-BOTH-LEASES
ok    TEST-REQ-AFF-004-WORKER-SERIE-TRACT-TOKEN-REFUSED-BEFORE-POP-ACK-OR-CLOSE
ok    TEST-REQ-AFF-004-WORKER-SERIE-TARGET-SPAN-AND-ALIAS-REFUSALS-BEFORE-POP
ok    TEST-REQ-AFF-004-WORKER-SERIE-STATIC-BINDING-REFUSES-OTHER-CLAIMED-WRITER
ok    TEST-REQ-AFF-008-WORKER-SERIE-LOCAL-GENERATION-EXHAUSTION-PRECEDES-WRITER-BEGIN
ok    TEST-REQ-AFF-008-WORKER-SERIE-CONTROLLER-GENERATION-LIMIT-REQUIRES-EXPLICIT-CLOSE
ok    TEST-REQ-CON-002-WORKER-SERIE-FOREIGN-OWNER-IN-IDLE-ACTIVE-BATCH-AND-CLOSING
ok    TEST-REQ-AFF-008-WORKER-SERIE-RELEASE-FAULT-RETAINS-TWO-LEASES-AND-ORIGINAL-CONDITION
ok    TEST-REQ-AFF-008-WORKER-SERIE-ERROR-BETWEEN-RELEASES-PRESERVES-CONDITION-AND-WRITER
ok    TEST-REQ-AFF-004-WORKER-SERIE-STALE-CONTROLLER-LEASE-NEVER-POISONS-NEW-OWNER
ok    TEST-REQ-AFF-004-WORKER-SERIE-OWNED-FAULT-THREE-INDEPENDENT-TRUTH-PAIRS
ok    TEST-REQ-AFF-008-WORKER-SERIE-BOUNDARY-ONCE-VALUES-AND-EXACT-CONDITION
ok    TEST-REQ-AFF-008-WORKER-SERIE-PRESERVES-EARLIER-WORKER-FAULT-ON-RAW-BEGIN
ok    TEST-REQ-AFF-008-WORKER-SERIE-ACQUIRE-BOUNDARY-UNKNOWN-REASONS-NEVER-REMAIN-RECOVERABLE
ok    TEST-REQ-AFF-008-WORKER-SERIE-RELEASE-BOUNDARY-UNKNOWN-REASONS-RETAIN-BOTH-LEASES
ok    TEST-REQ-AFF-008-WORKER-SERIE-LOWER-WORKER-FAULT-CANNOT-MATCH-BENIGN-OUTER-TOKEN-REASON
ok    TEST-REQ-AFF-008-WORKER-SERIE-ZERO-ACTIVE-GENERATION-FAULTS-ONLY-OWNED-CONTROLLER
ok    TEST-REQ-WAL-006-WORKER-SERIE-FAULTED-CONTROLLER-STILL-DRAINS-FINISHED-IO
ok    TEST-REQ-CON-002-WORKER-SERIE-TWO-WRITERS-ONE-CONTROLLER-HAVE-ONE-ACTIVE-LEASE
ok    TEST-REQ-CON-002-WORKER-SERIE-INDEPENDENT-CONTROLLERS-ACTIVE-CONCURRENTLY
ok    TEST-REQ-CON-005-ROUTING-WRITER-ORDINAL-AND-LEGACY-DEFAULT
ok    TEST-REQ-CON-005-ROUTING-REGISTRY-MAXIMUM-SHAPE-REACHES-ENTRY-VALIDATION
ok    TEST-REQ-CON-005-ROUTING-REGISTRY-REJECTS-SHAPE-AND-BUDGET-WITHOUT-EFFECTS
ok    TEST-REQ-CON-005-ROUTING-REGISTRY-OVERSIZE-REFUSAL-HAS-ITERATIVE-PREIMAGE
ok    TEST-REQ-AFF-008-ROUTING-CORRUPT-PRIVATE-SHAPE-REJECTS-BEFORE-LEASE
ok    TEST-REQ-AFF-001-ROUTING-SELECTS-FAULTED-SERIE-FOR-EXPLICIT-DRAIN
ok    TEST-REQ-CON-005-ROUTING-REGISTRY-ENTRY-TYPES-AND-EXACT-ORDINALS
ok    TEST-REQ-CON-002-ROUTING-REGISTRY-REFUSES-CONTROLLER-ALIAS-BEFORE-ANY-LEASE
ok    TEST-REQ-CON-002-ROUTING-REGISTRY-COPIES-INPUT-VECTORS-AND-PRESERVES-IDENTITIES
ok    TEST-REQ-CON-005-ROUTING-TABLE-CONSTRUCTION-REQUIRES-IDLE-OWNER
ok    TEST-REQ-CON-005-ROUTING-READY-FULL-RECYCLE-SWITCHES-SERIES-AND-PRESERVES-FIFO
ok    TEST-REQ-AFF-008-ROUTING-UNKNOWN-UNROUTED-AND-OUT-OF-RANGE-RETAIN-OBLIGATION
ok    TEST-REQ-AFF-008-ROUTING-CORRUPT-LINK-IS-DETECTED-BEFORE-LEASE-OR-POP
ok    TEST-REQ-CON-005-ROUTING-LOOKUP-REJECTS-RUNNING-BATCH-AND-RESCHEDULE
ok    TEST-REQ-CON-005-ROUTING-LOOKUP-REJECTS-FINISHING-WITHOUT-CHANGING-DEBT
ok    TEST-REQ-CON-002-ROUTING-FOREIGN-OWNER-FACTORY-AND-LOOKUP-PRESERVE-ALL-FIELDS
ok    TEST-REQ-CON-002-ROUTING-SHARED-REGISTRY-READY-TWO-SERIES-ACTIVE-IN-PARALLEL
ok    TEST-REQ-AFF-008-ROUTING-LOOKUP-REASON-CANNOT-BYPASS-TERMINAL-BOUNDARY
ok    TEST-REQ-CON-002-SERIES-LOG-BINDING-FRESH-GETTER-AND-DEFAULT-FACTORY
ok    TEST-REQ-AFF-008-SERIES-LOG-BINDING-PRESERVES-CAPACITY-GENERAL-ROOT-AND-OFFSET
ok    TEST-REQ-CON-002-SERIES-LOG-BINDING-DUPLICATE-FACTORY-EVEN-OTHER-REGISTRY
ok    TEST-REQ-AFF-008-SERIES-LOG-BINDING-INVALID-CONFIG-PRECEDES-BINDING
ok    TEST-REQ-CON-002-SERIES-LOG-BINDING-REJECTS-NONSEGMENT-BEFORE-BINDING
ok    TEST-REQ-CON-002-SERIES-LOG-BINDING-NEW-CANONICAL-LOG-INDEPENDENT
ok    TEST-REQ-AFF-009-SERIES-LOG-BINDING-FOREIGN-SLOT-FI-RESTORED
ok    TEST-REQ-CON-004-SERIES-LOG-BINDING-TWO-FOUR-WORKERS-ONE-PUBLICATION-AND-OBSERVER
109 test del controller Serie superati.
ok    TEST-REQ-AFF-003-SLOT-DEFTEST-EXPANSION-REGISTERS-WITHOUT-RUNNING
ok    TEST-REQ-LIM-001-SLOT-V2-FORMAT-LIMITS-MATCH-ADR-0048
ok    TEST-REQ-IDX-001-SLOT-DEFAULT-BANK-ZEROED-FIXED-U64-LAYOUT
ok    TEST-REQ-AFF-008-SLOT-MAXIMUM-CAPACITY-AND-LAST-INDEX
ok    TEST-REQ-AFF-008-SLOT-NEGATIVE-CAPACITY-CONFIGURATION
ok    TEST-REQ-AFF-008-SLOT-ZERO-CAPACITY-CONFIGURATION
ok    TEST-REQ-AFF-008-SLOT-OVER-CAPACITY-CONFIGURATION
ok    TEST-REQ-AFF-008-SLOT-NEGATIVE-BUDGET-CONFIGURATION
ok    TEST-REQ-AFF-008-SLOT-ZERO-BUDGET-CONFIGURATION
ok    TEST-REQ-AFF-008-SLOT-PAYLOAD-BUDGET-EXACT-AND-ONE-BYTE-SHORT
ok    TEST-REQ-AFF-008-SLOT-RANGE-REFUSED-BY-EVERY-INDEXED-API
ok    TEST-REQ-IDX-001-SLOT-CSN-FULL-U64-BEYOND-FIXNUM
ok    TEST-REQ-IDX-003-SLOT-REPUBLISH-REMOVE-AND-REUSE-ISOLATES-NEIGHBORS
ok    TEST-REQ-IDX-006-SLOT-REMOVAL-CLEARS-EVERY-RETAINED-WORD
ok    TEST-REQ-LIM-001-SLOT-KEY-LENGTH-BOUNDARIES-1-255-256-65535
ok    TEST-REQ-LIM-001-SLOT-ZERO-KEY-LENGTH-REFUSED
ok    TEST-REQ-LIM-001-SLOT-KEY-RESERVED-BITS-REFUSED
ok    TEST-REQ-IDX-001-SLOT-KEY-LIVE-FLAG-REQUIRED
ok    TEST-REQ-LIM-001-SLOT-KEY-ARENA-END-AT-U32-EXCLUSIVE-LIMIT
ok    TEST-REQ-LIM-001-SLOT-KEY-ARENA-OVERFLOW-BY-ONE-REFUSED
ok    TEST-REQ-LIM-001-SLOT-RECORD-RESERVED-BITS-REFUSED
ok    TEST-REQ-LIM-001-SLOT-MINIMUM-RECORD-HEADER-PLUS-KEY-ACCEPTED
ok    TEST-REQ-LIM-001-SLOT-RECORD-SHORTER-THAN-HEADER-PLUS-KEY-REFUSED
ok    TEST-REQ-LIM-001-SLOT-EXACT-DOCUMENT-AND-RECORD-MAXIMA-ACCEPTED
ok    TEST-REQ-LIM-003-SLOT-DOCUMENT-OVERFLOW-BELOW-RECORD-MAXIMUM-REFUSED
ok    TEST-REQ-LIM-001-SLOT-RECORD-MAXIMUM-PLUS-ONE-REFUSED
ok    TEST-REQ-LIM-001-SLOT-RECORD-END-EXACT-SEGMENT-LIMIT-ACCEPTED
ok    TEST-REQ-LIM-001-SLOT-RECORD-END-OVERFLOW-BY-ONE-REFUSED
ok    TEST-REQ-IDX-003-SLOT-ZERO-CSN-LIVE-PAYLOAD-REFUSED
ok    TEST-REQ-IDX-003-SLOT-PRIMARY-END-MUST-BE-ZERO
ok    TEST-REQ-IDX-003-SLOT-RETAINED-EXCLUSIVE-INTERVAL-FULL-U64
ok    TEST-REQ-IDX-003-SLOT-RETAINED-ZERO-EQUAL-AND-EARLIER-END-REFUSED
ok    TEST-REQ-IDX-003-SLOT-RETAINED-U64-MAX-START-HAS-NO-VALID-END
ok    TEST-REQ-IDX-003-SLOT-EMPTY-PREDICATE-CHECKS-ALL-FIVE-FIELDS
ok    TEST-REQ-IDX-003-SLOT-INTERNAL-VALIDATION-EMPTY-LIVE-AND-MALFORMED
ok    TEST-REQ-IDX-005-SLOT-FREEZE-IDEMPOTENT-READABLE-AND-ALL-WRITERS-REFUSED
ok    TEST-REQ-AFF-004-SLOT-INVALIDATION-IDEMPOTENT-TERMINAL-AND-PRESERVES-DATA
ok    TEST-REQ-AFF-004-SLOT-FAULT-AFTER-FREEZE-KEEPS-BOTH-TERMINAL-STATES
ok    TEST-REQ-CON-004-SLOT-ODD-RETRY-LIMIT-PRESERVES-OUTPUT-AND-SKIPS-TRANSIENT-VALIDATION
ok    TEST-REQ-AFF-004-SLOT-READER-CORRUPT-SEQUENCE-THRESHOLD-AND-U64-MAX
ok    TEST-REQ-AFF-004-SLOT-WRITER-ODD-AND-THRESHOLD-SEQUENCES-FAULT
ok    TEST-REQ-AFF-008-SLOT-INITIAL-CREDIT-AND-ONE-PER-MUTATION
ok    TEST-REQ-AFF-008-SLOT-LAST-CREDIT-CONSUMED-WITHOUT-WRAP
ok    TEST-REQ-AFF-008-SLOT-EXHAUSTED-LIVE-PUBLISH-REMOVE-AND-RELOCATE-REFUSED
ok    TEST-REQ-AFF-008-SLOT-EXHAUSTED-EMPTY-REMOVAL-IS-IDEMPOTENT
ok    TEST-REQ-AFF-008-SLOT-EXHAUSTED-RELOCATION-NOOPS-NEED-NO-CREDIT
ok    TEST-REQ-AFF-004-SLOT-STABLE-CORRUPT-FIELDS-FAULT-READER-BEFORE-COPY
ok    TEST-REQ-AFF-004-SLOT-PARTIAL-EMPTY-FAULTS-READER-AND-WRITER
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-PRIMARY-AND-RETAINED-CHANGES-ONLY-LOCATION
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-STALE-CSN-DOES-NOT-OVERWRITE
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-STALE-LOCATION-DOES-NOT-OVERWRITE
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-STALE-KEY-METADATA-DOES-NOT-OVERWRITE
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-STALE-RECORD-LENGTH-DOES-NOT-OVERWRITE
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-STALE-RETAINED-END-DOES-NOT-OVERWRITE
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-CSN-CHANGE-REFUSED
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-KEY-CHANGE-REFUSED
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-RECORD-LENGTH-CHANGE-REFUSED
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-RETAINED-END-CHANGE-REFUSED
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-INVALID-EXPECTED-AND-REPLACEMENT-REFUSED
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-EMPTY-IS-A-NOOP
ok    TEST-REQ-IDX-004-SLOT-RELOCATION-EQUAL-LOCATION-NEVER-CONSUMES-CREDIT
ok    TEST-REQ-IDX-003-SLOT-PRIMARY-WRITER-THREE-READERS-CORRELATED-U64-SNAPSHOTS
ok    TEST-REQ-IDX-003-SLOT-RETAINED-WRITER-THREE-READERS-CORRELATED-FIVE-WORD-SNAPSHOTS
ok    TEST-REQ-IDX-006-SLOT-RETAINED-CONCURRENT-REMOVE-REPUBLISH-PRESERVES-EMPTY-OUTPUT
64 test degli slot indice v2 superati.
ok    TEST-REQ-AFF-003-PRIMARY-HARNESS-AND-EMPTY-ROOT
ok    TEST-REQ-IDX-001-PRIMARY-BINARY-COLLISIONS-AND-SPAN
ok    TEST-REQ-IDX-001-PRIMARY-FULL-GROUP-WRAP-AND-DELETED-NOT-EMPTY
ok    TEST-REQ-IDX-006-PRIMARY-DELETE-IDEMPOTENCE-AND-REUSE-NEW-FINGERPRINT
ok    TEST-REQ-IDX-001-PRIMARY-UPSERT-CSN-INCREASING-AND-KEY-STABLE
ok    TEST-REQ-IDX-005-PRIMARY-PREFIX-REFUSALS-BEFORE-MUTATION
ok    TEST-REQ-IDX-005-PRIMARY-OWNER-REFUSALS-PRESERVE-BOTH-DOMAINS
ok    TEST-REQ-IDX-005-PRIMARY-FROZEN-FRAGMENT-READABLE-NEVER-WRITABLE
ok    TEST-REQ-IDX-005-PRIMARY-ARENA-GROWTH-BUDGET-AND-OFFSETS
ok    TEST-REQ-LIM-003-PRIMARY-KEY-65535-AND-INVALID-LENGTHS
ok    TEST-REQ-IDX-001-PRIMARY-U64-CSN-THROUGH-MAXIMUM
ok    TEST-REQ-IDX-003-PRIMARY-EIGHT-COLLISION-SAMPLES-ONE-BUDGET
ok    TEST-REQ-IDX-003-PRIMARY-COLLISIONS-AND-ODD-RETRIES-SHARE-EIGHT
ok    TEST-REQ-CON-004-PRIMARY-OUTPUT-PRESERVED-MISS-AND-CONTEXT-REFUSALS
ok    TEST-REQ-IDX-005-PRIMARY-LOAD-SLOT-CREDIT-AND-REVISION-PREFLIGHT
ok    TEST-REQ-IDX-003-PRIMARY-MUTATION-PREFLIGHT-SPAN-PROBE-AND-NO-RESERVATION
ok    TEST-REQ-IDX-005-PRIMARY-MUTATION-PREFLIGHT-LOAD-AND-UPDATE
ok    TEST-REQ-IDX-005-PRIMARY-MUTATION-PREFLIGHT-ARENA-AND-DELETED-KEY
ok    TEST-REQ-IDX-003-PRIMARY-MUTATION-PREFLIGHT-CREDIT-AND-ABSENT-DELETE
ok    TEST-REQ-IDX-007-PRIMARY-MUTATION-PREFLIGHT-REVISION-AND-ABSENT-DELETE
ok    TEST-REQ-IDX-005-PRIMARY-MUTATION-PREFLIGHT-DOMAIN-SPAN-AND-CONTEXT-GUARDS
ok    TEST-REQ-IDX-003-PRIMARY-MUTATION-PREFLIGHT-CANONICAL-FAULT-AND-CLEANUP
ok    TEST-REQ-IDX-005-PRIMARY-MANUAL-REBUILD-COMPACTS-AND-PUBLISHES-CURRENT-ROOT
ok    TEST-REQ-IDX-005-PRIMARY-MANUAL-SPLIT-ROUTES-MSB-PREFIXES
ok    TEST-REQ-IDX-005-PRIMARY-SHALLOW-SPLIT-NO-DOUBLING-AND-UNRELATED-MUTABLE
ok    TEST-REQ-IDX-007-PRIMARY-STALE-PLAN-AFTER-SOURCE-UPDATE-NO-FREEZE
ok    TEST-REQ-IDX-007-PRIMARY-STALE-PLAN-AFTER-CANDIDATE-UPDATE-AND-ARENA-GROWTH
ok    TEST-REQ-IDX-007-PRIMARY-TWO-PLANS-OLD-ROOT-AND-CONSUMED-PLAN-REFUSED
ok    TEST-REQ-IDX-007-PRIMARY-DIRECTORY-CANDIDATES-AND-EXACT-BUDGET
ok    TEST-REQ-IDX-004-PRIMARY-RELOCATION-MESSAGE-SURVIVES-REBUILD-NOT-NEW-VERSION
ok    TEST-REQ-IDX-007-PRIMARY-ROOT-CHANGES-HIT-MISS-AND-COMMON-BUDGET
ok    TEST-REQ-IDX-007-PRIMARY-FINAL-CONFIRMATION-EXHAUSTED-NO-RESTART
ok    TEST-REQ-IDX-003-PRIMARY-WRITER-UPDATES-THREE-READERS-NO-TORN-PAYLOAD
ok    TEST-REQ-IDX-007-PRIMARY-MANUAL-REBUILDS-AND-ARENA-GROWTH-WITH-READERS
ok    TEST-REQ-IDX-005-REBUILD-ORIGINAL-SLOTS-AND-COMPACTED-OFFSETS
ok    TEST-REQ-IDX-005-REBUILD-SPLIT-VERIFIED
ok    TEST-REQ-IDX-005-REBUILD-U64-MAX-KEY-AND-RESET-SEQUENCE
ok    TEST-REQ-IDX-005-REBUILD-DELETION-COMPACTS-LIVE-BYTES
ok    TEST-REQ-IDX-005-REBUILD-EMPTY-FRAGMENT
ok    TEST-REQ-IDX-005-REBUILD-EMPTY-SPLIT
ok    TEST-REQ-IDX-005-REBUILD-SPLIT-ONE-EMPTY-CHILD
ok    TEST-REQ-AFF-008-REBUILD-TRANSIENT-BUDGET
ok    TEST-REQ-AFF-008-REBUILD-DIRECTORY-BUDGET-BEFORE-CANDIDATES
ok    TEST-REQ-AFF-008-REBUILD-FRAGMENT-BUDGET-CONDITIONS
ok    TEST-REQ-AFF-008-REBUILD-INVALID-SHAPE-AND-BUDGET
ok    TEST-REQ-AFF-008-REBUILD-DEPTH-EXHAUSTED-ONLY-FOR-SPLIT
ok    TEST-REQ-IDX-005-REBUILD-WRONG-DIGEST-FINGERPRINT
ok    TEST-REQ-IDX-005-REBUILD-WRONG-DIGEST-LOOKUP-GROUP
ok    TEST-REQ-IDX-005-REBUILD-WRONG-DIGEST-SOURCE-PREFIX
ok    TEST-REQ-IDX-005-REBUILD-PLAN-STALE-AFTER-SOURCE-UPDATE
ok    TEST-REQ-IDX-005-REBUILD-SECOND-CONSTRUCTION-STALES-FIRST-PLAN
ok    TEST-REQ-AFF-008-REBUILD-REVISION-EXHAUSTION-BEFORE-CANDIDATES
ok    TEST-REQ-AFF-008-REBUILD-GENERATION-EXHAUSTION-BEFORE-CANDIDATES
ok    TEST-REQ-IDX-005-REBUILD-CORRUPTED-COPY-LOCATION
ok    TEST-REQ-IDX-005-REBUILD-COPY-COMPARISON
ok    TEST-REQ-IDX-005-REBUILD-DUPLICATE-SOURCE-KEY
ok    TEST-REQ-IDX-005-REBUILD-SOURCE-CONTROL-CORRUPTION
ok    TEST-REQ-IDX-005-REBUILD-SOURCE-BANK-CORRUPTION-PROPAGATES
ok    TEST-REQ-IDX-005-REBUILD-PROBE-BANK-CORRUPTION-BEFORE-SLOT-SCAN
ok    TEST-REQ-IDX-005-REBUILD-SOURCE-ARENA-AND-LIVE-COUNT-CORRUPTION
ok    TEST-REQ-IDX-005-REBUILD-COPY-LOOKUP-FALSE-IS-TERMINAL
ok    TEST-REQ-IDX-005-REBUILD-COLD-ABORT-PRESERVES-SOURCE
ok    TEST-REQ-IDX-005-HASH-MAP-PHYSICAL-SLOTS
ok    TEST-REQ-IDX-005-HASH-MAP-NONLIVE-SENTINELS-AND-EXACT-COUNTS
ok    TEST-REQ-IDX-005-HASH-MAP-OUTPUT-ARITY-EMPTY-AND-UNCONFIGURED
ok    TEST-REQ-IDX-005-HASH-MAP-SEED-CONSTRUCTOR-AND-IMMUTABILITY
ok    TEST-REQ-IDX-005-HASH-MAP-OUTPUT-TYPES-PREFLIGHT
ok    TEST-REQ-IDX-005-HASH-MAP-OUTPUT-LENGTHS-PREFLIGHT
ok    TEST-REQ-IDX-005-HASH-MAP-OUTPUT-ALIAS-PREFLIGHT
ok    TEST-REQ-IDX-005-HASH-MAP-INVALID-SEED-TYPES-PREFLIGHT
ok    TEST-REQ-IDX-005-HASH-MAP-SEED-MISMATCH
ok    TEST-REQ-IDX-005-HASH-MAP-STALE-SOURCE
ok    TEST-REQ-IDX-005-HASH-MAP-BUILDING-SOURCE
ok    TEST-REQ-IDX-005-HASH-MAP-FOREIGN-SOURCE
ok    TEST-REQ-IDX-005-HASH-MAP-CANONICAL-ROOT-AND-BANK-GUARDS
ok    TEST-REQ-IDX-005-HASH-MAP-CORRUPT-BANK-FAULTS-IMMEDIATELY
ok    TEST-REQ-IDX-005-HASH-MAP-CORRUPT-ARENA-AND-LIVE-COUNT
ok    TEST-REQ-IDX-005-HASH-MAP-MISSING-ROOT-FAULTS
ok    TEST-REQ-IDX-005-HASH-MAP-INTERNAL-DIGEST-FAULTS
ok    TEST-REQ-IDX-001-HASH-KERNEL-FAULT-PROPAGATES-OWNER
80 test dell'indice primario superati.
ok    REQ-IDX-008-AVVIO-RESIDENTE-SENZA-PAGINAZIONE-FORZATA
ok    REQ-IDX-008-CRESCITA-PRIMA-DEL-PROSSIMO-LAVORO
ok    REQ-IDX-008-RIENTRO-E-BANDA-STABILE
ok    REQ-IDX-008-QUOTE-DINAMICHE-E-SERIE-INDIPENDENTI
ok    REQ-IDX-008-ARROTONDAMENTO-E-LIMITI-ARITMETICI
ok    REQ-IDX-008-RIFIUTI-PRIMA-DEGLI-EFFETTI
ok    REQ-IDX-008-PREFLIGHT-DELLA-SOLA-TRANSIZIONE
  Modo indice: 10000 decisioni, 0 byte Lisp osservati.
ok    REQ-IDX-008-FINESTRA-SENZA-ALLOCAZIONE
8 test del modo automatico superati.
ok    REQ-IDX-009-FIXTURE-INDIPENDENTI-TRE-TAGLIE-E-TIPI
ok    REQ-IDX-009-COLLISIONI-OVERFLOW-E-SATURAZIONE
ok    REQ-IDX-009-DIRECTORY-RADIX-E-MASSIMI
ok    REQ-IDX-009-IDENTITA-COPIATA-E-RIFERIMENTI-ATTESI
ok    REQ-IDX-009-PREFLIGHT-SENZA-EFFETTI
ok    REQ-IDX-009-DOMINI-DESCRITTORE
ok    REQ-IDX-009-INTERI-GRANDI-E-GEOMETRIA-ALLINEATA
ok    REQ-IDX-009-RECORD-AI-LIMITI-V2
ok    REQ-IDX-009-CORRUZIONE-OGNI-BYTE-PAGINA-4K
ok    REQ-IDX-009-HEADER-E-CRC-VALIDI-NON-BASTANO
ok    REQ-IDX-009-SLOT-E-CHIAVI-SEMANTICAMENTE-INCOERENTI
ok    REQ-IDX-009-RIFERIMENTI-DIRECTORY-NON-CANONICI
ok    REQ-IDX-009-TRONCAMENTI-E-GUARDIE
ok    REQ-IDX-009-CHIAVE-MASSIMA-FRAMMENTATA
ok    REQ-IDX-009-CHIAVI-INLINE-ESTERNE-E-ARENA-ESATTA
ok    REQ-IDX-009-CODA-CHIAVE-E-CATENA-INVALIDE
ok    REQ-IDX-009-SPLIT-DIRECTORY-E-BUCKET-IMMUTABILI
ok    REQ-IDX-009-RIFERIMENTI-ESTERNI-E-IDENTITA-ALLINEATA
18 test delle pagine indice superati.
CHILD v1 write-COMMITTED status=:EXITED code=1
Unhandled SIMPLE-ERROR in thread #<SB-THREAD:THREAD tid=259 \"main thread\" RUNNING
                                    {80053B0483}>:
  Avviso non ammesso: reading an ignored variable: STREAM

Backtrace for: #<SB-THREAD:THREAD tid=259 \"main thread\" RUNNING {80053B0483}>
0: (SB-DEBUG::DEBUGGER-DISABLED-HOOK #<SIMPLE-ERROR \"Avviso non ammesso: ~A\" {800B920CC3}> #<unused argument> :QUIT T)
1: (SB-DEBUG::RUN-HOOK SB-EXT:*INVOKE-DEBUGGER-HOOK* #<SIMPLE-ERROR \"Avviso non ammesso: ~A\" {800B920CC3}>)
2: (INVOKE-DEBUGGER #<SIMPLE-ERROR \"Avviso non ammesso: ~A\" {800B920CC3}>)
3: (ERROR \"Avviso non ammesso: ~A\" #<SB-INT:SIMPLE-STYLE-WARNING \"reading an ignored variable: ~S\" {800B920C83}>)
4: ((LAMBDA (CONDITION) :IN \"/Users/runner/work/ArcDocDB/ArcDocDB/tools/vertical-crash.lisp\") #<SB-INT:SIMPLE-STYLE-WARNING \"reading an ignored variable: ~S\" {800B920C83}>)
5: (SB-KERNEL::%SIGNAL #<SB-INT:SIMPLE-STYLE-WARNING \"reading an ignored variable: ~S\" {800B920C83}>)
6: (SB-C::COMPILER-STYLE-WARNING-HANDLER #<SB-INT:SIMPLE-STYLE-WARNING \"reading an ignored variable: ~S\" {800B920C83}>)
7: (SB-KERNEL::%SIGNAL #<SB-INT:SIMPLE-STYLE-WARNING \"reading an ignored variable: ~S\" {800B920C83}>)
8: ((FLET SB-KERNEL::%WARN :IN \"SYS:SRC;CODE;WARM-ERROR.LISP\") \"reading an ignored variable: ~S\" #<SB-KERNEL::CONDITION-CLASSOID STYLE-WARNING> SB-INT:SIMPLE-STYLE-WARNING STREAM)
9: (SB-C:COMPILER-STYLE-WARN \"reading an ignored variable: ~S\" STREAM)
10: (SB-C::IR1-CONVERT #<SB-C::CTRAN 1 {800B9207C3}> #<SB-C::CTRAN 2 {800B920953}> #<SB-C::LVAR 3 {800B920993}> STREAM)
11: (SB-C::IR1-CONVERT-IF #<SB-C::CTRAN 1 {800B9207C3}> #<SB-C::CTRAN 4 {800B920913}> NIL (IF STREAM (CLOSE STREAM :ABORT #:G3)))
12: (SB-C::IR1-CONVERT #<SB-C::CTRAN 1 {800B9207C3}> #<SB-C::CTRAN 4 {800B920913}> NIL (IF STREAM (CLOSE STREAM :ABORT #:G3)))
13: (SB-C::IR1-CONVERT-COMMON-FUNCTOID #<SB-C::CTRAN 1 {800B9207C3}> #<SB-C::CTRAN 4 {800B920913}> NIL (WHEN STREAM (CLOSE STREAM :ABORT #:G3)) WHEN)
14: (SB-C::IR1-CONVERT #<SB-C::CTRAN 1 {800B9207C3}> #<SB-C::CTRAN 4 {800B920913}> NIL (WHEN STREAM (CLOSE STREAM :ABORT #:G3)))
15: (SB-C::IR1-CONVERT-PROGN-BODY #<SB-C::CTRAN 1 {800B9207C3}> #<SB-C::CTRAN 5 {800B920393}> #<SB-C::LVAR 6 {800B9203D3}> ((WHEN STREAM (CLOSE STREAM :ABORT #:G3)) (VALUES)))
16: (SB-C::IR1-CONVERT-BLOCK #<SB-C::CTRAN 7 {800B920643}> #<SB-C::CTRAN 5 {800B920393}> #<SB-C::LVAR 6 {800B9203D3}> (BLOCK #:CLEANUP-FUN-4 (WHEN STREAM (CLOSE STREAM :ABORT #:G3)) (VALUES)))
17: (SB-C::IR1-CONVERT #<SB-C::CTRAN 7 {800B920643}> #<SB-C::CTRAN 5 {800B920393}> #<SB-C::LVAR 6 {800B9203D3}> (BLOCK #:CLEANUP-FUN-4 (WHEN STREAM (CLOSE STREAM :ABORT #:G3)) (VALUES)))
18: (SB-C::IR1-CONVERT-PROGN-BODY #<SB-C::CTRAN 7 {800B920643}> #<SB-C::CTRAN 5 {800B920393}> #<SB-C::LVAR 6 {800B9203D3}> ((BLOCK #:CLEANUP-FUN-4 (WHEN STREAM (CLOSE STREAM :ABORT #:G3)) (VALUES))))
19: (SB-C::IR1-CONVERT-AUX-BINDINGS #<SB-C::CTRAN 7 {800B920643}> #<SB-C::CTRAN 5 {800B920393}> #<SB-C::LVAR 6 {800B9203D3}> ((BLOCK #:CLEANUP-FUN-4 (WHEN STREAM (CLOSE STREAM :ABORT #:G3)) (VALUES))) NIL NIL NIL :VALUE-SOURCE-FORMS NIL)
20: (SB-C::IR1-CONVERT-SPECIAL-BINDINGS #<SB-C::CTRAN 7 {800B920643}> #<SB-C::CTRAN 5 {800B920393}> #<SB-C::LVAR 6 {800B9203D3}> ((BLOCK #:CLEANUP-FUN-4 (WHEN STREAM (CLOSE STREAM :ABORT #:G3)) (VALUES))) NIL NIL NIL NIL :VALUE-SOURCE-FORMS NIL)
21: (SB-C::IR1-CONVERT-LAMBDA-BODY ((BLOCK #:CLEANUP-FUN-4 (WHEN STREAM (CLOSE STREAM :ABORT #:G3)) (VALUES))) NIL :AUX-VARS NIL :AUX-VALS NIL :SOURCE-NAME #:CLEANUP-FUN-4 :DEBUG-NAME (FLET \"CLEANUP-FUN-4\" :IN LAUNCH) :NOTE-LEXICAL-BINDINGS T :POST-BINDING-LEXENV NIL :LOCAL-POLICY NIL :VALUE-SOURCE-FORMS NIL)
22: (SB-C::IR1-CONVERT-LAMBDA (LAMBDA NIL (BLOCK #:CLEANUP-FUN-4 (WHEN STREAM (CLOSE STREAM :ABORT #:G3)) (VALUES))) :SOURCE-NAME #:CLEANUP-FUN-4 :DEBUG-NAME (FLET \"CLEANUP-FUN-4\" :IN LAUNCH) :MAYBE-ADD-DEBUG-CATCH T :FTYPE NIL)
23: (SB-C::IR1-CONVERT-FLET #<SB-C::CTRAN 8 {800B90FDF3}> #<SB-C::CTRAN 9 {800B90FB43}> #<SB-C::LVAR 10 {800B90FB83}> (FLET ((#1=#:CLEANUP-FUN-4 NIL (WHEN STREAM (CLOSE STREAM :ABORT #:G3)) (VALUES))) (DECLARE (DYNAMIC-EXTENT (FUNCTION #1#))) (BLOCK #2=#:DROP-THRU-TAG-5 (BLOCK #:EXIT-TAG-6 (SB-C::%WITHIN-CLEANUP :UNWIND-PROTECT (SB-C::%UNWIND-PROTECT # #) (RETURN-FROM #2# #))) (LOCALLY (DECLARE (OPTIMIZE #)) (#1#) (SB-C:%CONTINUE-UNWIND)))))
24: (SB-C::IR1-CONVERT #<SB-C::CTRAN 8 {800B90FDF3}> #<SB-C::CTRAN 9 {800B90FB43}> #<SB-C::LVAR 10 {800B90FB83}> (FLET ((#1=#:CLEANUP-FUN-4 NIL (WHEN STREAM (CLOSE STREAM :ABORT #:G3)) (VALUES))) (DECLARE (DYNAMIC-EXTENT (FUNCTION #1#))) (BLOCK #2=#:DROP-THRU-TAG-5 (BLOCK #:EXIT-TAG-6 (SB-C::%WITHIN-CLEANUP :UNWIND-PROTECT (SB-C::%UNWIND-PROTECT # #) (RETURN-FROM #2# #))) (LOCALLY (DECLARE (OPTIMIZE #)) (#1#) (SB-C:%CONTINUE-UNWIND)))))
25: (SB-C::IR1-CONVERT-UNWIND-PROTECT #<SB-C::CTRAN 8 {800B90FDF3}> #<SB-C::CTRAN 9 {800B90FB43}> #<SB-C::LVAR 10 {800B90FB83}> (UNWIND-PROTECT (MULTIPLE-VALUE-PROG1 (PROGN) (SETQ #1=#:G3 NIL)) (WHEN STREAM (CLOSE STREAM :ABORT #1#))))
26: (SB-C::IR1-CONVERT #<SB-C::CTRAN 8 {800B90FDF3}> #<SB-C::CTRAN 9 {800B90FB43}> #<SB-C::LVAR 10 {800B90FB83}> (UNWIND-PROTECT (MULTIPLE-VALUE-PROG1 (PROGN) (SETQ #1=#:G3 NIL)) (WHEN STREAM (CLOSE STREAM :ABORT #1#))))
27: (SB-C::IR1-CONVERT-PROGN-BODY #<SB-C::CTRAN 8 {800B90FDF3}> #<SB-C::CTRAN 9 {800B90FB43}> #<SB-C::LVAR 10 {800B90FB83}> ((UNWIND-PROTECT (MULTIPLE-VALUE-PROG1 (PROGN) (SETQ #1=#:G3 NIL)) (WHEN STREAM (CLOSE STREAM :ABORT #1#)))))
28: (SB-C::IR1-CONVERT-AUX-BINDINGS #<SB-C::CTRAN 8 {800B90FDF3}> #<SB-C::CTRAN 9 {800B90FB43}> #<SB-C::LVAR 10 {800B90FB83}> ((UNWIND-PROTECT (MULTIPLE-VALUE-PROG1 (PROGN) (SETQ #1=#:G3 NIL)) (WHEN STREAM (CLOSE STREAM :ABORT #1#)))) NIL NIL NIL :VALUE-SOURCE-FORMS NIL)
29: (SB-C::IR1-CONVERT-SPECIAL-BINDINGS #<SB-C::CTRAN 8 {800B90FDF3}> #<SB-C::CTRAN 9 {800B90FB43}> #<SB-C::LVAR 10 {800B90FB83}> ((UNWIND-PROTECT (MULTIPLE-VALUE-PROG1 (PROGN) (SETQ #1=#:G3 NIL)) (WHEN STREAM (CLOSE STREAM :ABORT #1#)))) NIL NIL NIL NIL :VALUE-SOURCE-FORMS NIL)
30: (SB-C::IR1-CONVERT-LAMBDA-BODY ((UNWIND-PROTECT (MULTIPLE-VALUE-PROG1 (PROGN) (SETQ #1=#:G3 NIL)) (WHEN STREAM (CLOSE STREAM :ABORT #1#)))) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME STREAM :FLAGS (IGNORE) {800B90F5D3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME #:G3 {800B90F6E3}>) :AUX-VARS NIL :AUX-VALS NIL :SOURCE-NAME SB-C::.ANONYMOUS. :DEBUG-NAME (LET (STREAM #:G3)) :NOTE-LEXICAL-BINDINGS T :POST-BINDING-LEXENV NIL :LOCAL-POLICY NIL :VALUE-SOURCE-FORMS NIL)
31: (SB-C::IR1-CONVERT-LET #<SB-C::CTRAN 11 {800B90EEB3}> #<SB-C::CTRAN 12 {800B90F4A3}> NIL (LET ((STREAM (OPEN PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR :AUTO-CLOSE . #1=(NIL))) (#2=#:G3 T)) (DECLARE (IGNORE STREAM)) (UNWIND-PROTECT (MULTIPLE-VALUE-PROG1 (PROGN) (SETQ #2# . #1#)) (WHEN STREAM (CLOSE STREAM :ABORT #2#)))))
32: (SB-C::IR1-CONVERT #<SB-C::CTRAN 11 {800B90EEB3}> #<SB-C::CTRAN 12 {800B90F4A3}> NIL (LET ((STREAM (OPEN PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR :AUTO-CLOSE . #1=(NIL))) (#2=#:G3 T)) (DECLARE (IGNORE STREAM)) (UNWIND-PROTECT (MULTIPLE-VALUE-PROG1 (PROGN) (SETQ #2# . #1#)) (WHEN STREAM (CLOSE STREAM :ABORT #2#)))))
33: (SB-C::IR1-CONVERT-COMMON-FUNCTOID #<SB-C::CTRAN 11 {800B90EEB3}> #<SB-C::CTRAN 12 {800B90F4A3}> NIL (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM))) WITH-OPEN-FILE)
34: (SB-C::IR1-CONVERT #<SB-C::CTRAN 11 {800B90EEB3}> #<SB-C::CTRAN 12 {800B90F4A3}> NIL (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM))))
35: (SB-C::IR1-CONVERT-PROGN-BODY #<SB-C::CTRAN 11 {800B90EEB3}> #<SB-C::CTRAN 13 {800B90EA83}> #<SB-C::LVAR 14 {800B90EAC3}> ((WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM))) NIL))
36: (SB-C::IR1-CONVERT-TAGBODY #<SB-C::CTRAN 11 {800B90EEB3}> #<SB-C::CTRAN 13 {800B90EA83}> #<SB-C::LVAR 14 {800B90EAC3}> (TAGBODY (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))))
37: (SB-C::IR1-CONVERT #<SB-C::CTRAN 11 {800B90EEB3}> #<SB-C::CTRAN 13 {800B90EA83}> #<SB-C::LVAR 14 {800B90EAC3}> (TAGBODY (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))))
38: (SB-C::IR1-CONVERT-PROGN-BODY #<SB-C::CTRAN 15 {800B90ED33}> #<SB-C::CTRAN 13 {800B90EA83}> #<SB-C::LVAR 14 {800B90EAC3}> ((SETQ #1=#:LIST1 (CDR #1#)) (TAGBODY (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM))))))
39: (SB-C::IR1-CONVERT-AUX-BINDINGS #<SB-C::CTRAN 15 {800B90ED33}> #<SB-C::CTRAN 13 {800B90EA83}> #<SB-C::LVAR 14 {800B90EAC3}> ((SETQ #1=#:LIST1 (CDR #1#)) (TAGBODY (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM))))) NIL NIL NIL :VALUE-SOURCE-FORMS NIL)
40: (SB-C::IR1-CONVERT-SPECIAL-BINDINGS #<SB-C::CTRAN 15 {800B90ED33}> #<SB-C::CTRAN 13 {800B90EA83}> #<SB-C::LVAR 14 {800B90EAC3}> ((SETQ #1=#:LIST1 (CDR #1#)) (TAGBODY (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM))))) NIL NIL NIL NIL :VALUE-SOURCE-FORMS NIL)
41: (SB-C::IR1-CONVERT-LAMBDA-BODY ((SETQ #1=#:LIST1 (CDR #1#)) (TAGBODY (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM))))) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME PATH {800B90E623}>) :AUX-VARS NIL :AUX-VALS NIL :SOURCE-NAME SB-C::.ANONYMOUS. :DEBUG-NAME (LET (PATH)) :NOTE-LEXICAL-BINDINGS T :POST-BINDING-LEXENV NIL :LOCAL-POLICY NIL :VALUE-SOURCE-FORMS NIL)
42: (SB-C::IR1-CONVERT-LET #<SB-C::CTRAN 16 {800B90DAD3}> #<SB-C::CTRAN 17 {800B90E513}> NIL (LET ((PATH (CAR #1=#:LIST1))) (DECLARE (IGNORABLE PATH)) (SETQ #1# (CDR #1#)) (TAGBODY (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM))))))
43: (SB-C::IR1-CONVERT #<SB-C::CTRAN 16 {800B90DAD3}> #<SB-C::CTRAN 17 {800B90E513}> NIL (LET ((PATH (CAR #1=#:LIST1))) (DECLARE (IGNORABLE PATH)) (SETQ #1# (CDR #1#)) (TAGBODY (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM))))))
44: (SB-C::IR1-CONVERT-PROGN-BODY #<SB-C::CTRAN 16 {800B90DAD3}> #<SB-C::CTRAN 18 {800B90D8F3}> NIL ((LET ((PATH (CAR #1=#:LIST1))) (DECLARE (IGNORABLE PATH)) (SETQ #1# (CDR #1#)) (TAGBODY (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE #)))) (GO #:START2)))
45: (SB-C::IR1-CONVERT-PROGN #<SB-C::CTRAN 16 {800B90DAD3}> #<SB-C::CTRAN 18 {800B90D8F3}> NIL (PROGN (LET ((PATH (CAR #1=#:LIST1))) (DECLARE (IGNORABLE PATH)) (SETQ #1# (CDR #1#)) (TAGBODY (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE #)))) (GO #:START2)))
46: (SB-C::IR1-CONVERT #<SB-C::CTRAN 16 {800B90DAD3}> #<SB-C::CTRAN 18 {800B90D8F3}> NIL (PROGN (LET ((PATH (CAR #1=#:LIST1))) (DECLARE (IGNORABLE PATH)) (SETQ #1# (CDR #1#)) (TAGBODY (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE #)))) (GO #:START2)))
47: (SB-C::IR1-CONVERT-IF #<SB-C::CTRAN 19 {800B90D6E3}> #<SB-C::CTRAN 18 {800B90D8F3}> NIL (IF (ENDP #1=#:LIST1) NIL (PROGN (LET ((PATH #)) (DECLARE (IGNORABLE PATH)) (SETQ #1# (CDR #1#)) (TAGBODY (WITH-OPEN-FILE # #))) (GO #:START2))))
48: (SB-C::IR1-CONVERT #<SB-C::CTRAN 19 {800B90D6E3}> #<SB-C::CTRAN 18 {800B90D8F3}> NIL (IF (ENDP #1=#:LIST1) NIL (PROGN (LET ((PATH #)) (DECLARE (IGNORABLE PATH)) (SETQ #1# (CDR #1#)) (TAGBODY (WITH-OPEN-FILE # #))) (GO #:START2))))
49: (SB-C::IR1-CONVERT-COMMON-FUNCTOID #<SB-C::CTRAN 19 {800B90D6E3}> #<SB-C::CTRAN 18 {800B90D8F3}> NIL (UNLESS (ENDP #1=#:LIST1) (LET ((PATH (CAR #1#))) (DECLARE (IGNORABLE PATH)) (SETQ #1# (CDR #1#)) (TAGBODY (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE #)))) (GO #:START2)) UNLESS)
50: (SB-C::IR1-CONVERT #<SB-C::CTRAN 19 {800B90D6E3}> #<SB-C::CTRAN 18 {800B90D8F3}> NIL (UNLESS (ENDP #1=#:LIST1) (LET ((PATH (CAR #1#))) (DECLARE (IGNORABLE PATH)) (SETQ #1# (CDR #1#)) (TAGBODY (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE #)))) (GO #:START2)))
51: (SB-C::IR1-CONVERT-PROGN-BODY #<SB-C::CTRAN 19 {800B90D6E3}> #<SB-C::CTRAN 20 {800B90D1E3}> #<SB-C::LVAR 21 {800B90D223}> ((UNLESS (ENDP #1=#:LIST1) (LET ((PATH #)) (DECLARE (IGNORABLE PATH)) (SETQ #1# (CDR #1#)) (TAGBODY (WITH-OPEN-FILE # #))) (GO #:START2)) NIL))
52: (SB-C::IR1-CONVERT-TAGBODY #<SB-C::CTRAN 22 {800B90D493}> #<SB-C::CTRAN 20 {800B90D1E3}> #<SB-C::LVAR 21 {800B90D223}> (TAGBODY #1=#:START2 (UNLESS (ENDP #2=#:LIST1) (LET ((PATH #)) (DECLARE (IGNORABLE PATH)) (SETQ #2# (CDR #2#)) (TAGBODY (WITH-OPEN-FILE # #))) (GO #1#))))
53: (SB-C::IR1-CONVERT #<SB-C::CTRAN 22 {800B90D493}> #<SB-C::CTRAN 20 {800B90D1E3}> #<SB-C::LVAR 21 {800B90D223}> (TAGBODY #1=#:START2 (UNLESS (ENDP #2=#:LIST1) (LET ((PATH #)) (DECLARE (IGNORABLE PATH)) (SETQ #2# (CDR #2#)) (TAGBODY (WITH-OPEN-FILE # #))) (GO #1#))))
54: (SB-C::IR1-CONVERT-PROGN-BODY #<SB-C::CTRAN 22 {800B90D493}> #<SB-C::CTRAN 20 {800B90D1E3}> #<SB-C::LVAR 21 {800B90D223}> ((TAGBODY #1=#:START2 (UNLESS (ENDP #2=#:LIST1) (LET (#) (DECLARE #) (SETQ #2# #) (TAGBODY #)) (GO #1#)))))
55: (SB-C::IR1-CONVERT-AUX-BINDINGS #<SB-C::CTRAN 22 {800B90D493}> #<SB-C::CTRAN 20 {800B90D1E3}> #<SB-C::LVAR 21 {800B90D223}> ((TAGBODY #1=#:START2 (UNLESS (ENDP #2=#:LIST1) (LET (#) (DECLARE #) (SETQ #2# #) (TAGBODY #)) (GO #1#)))) NIL NIL NIL :VALUE-SOURCE-FORMS NIL)
56: (SB-C::IR1-CONVERT-SPECIAL-BINDINGS #<SB-C::CTRAN 22 {800B90D493}> #<SB-C::CTRAN 20 {800B90D1E3}> #<SB-C::LVAR 21 {800B90D223}> ((TAGBODY #1=#:START2 (UNLESS (ENDP #2=#:LIST1) (LET (#) (DECLARE #) (SETQ #2# #) (TAGBODY #)) (GO #1#)))) NIL NIL NIL NIL :VALUE-SOURCE-FORMS NIL)
57: (SB-C::IR1-CONVERT-LAMBDA-BODY ((TAGBODY #1=#:START2 (UNLESS (ENDP #2=#:LIST1) (LET (#) (DECLARE #) (SETQ #2# #) (TAGBODY #)) (GO #1#)))) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME #:LIST1 {800B90CE13}>) :AUX-VARS NIL :AUX-VALS NIL :SOURCE-NAME SB-C::.ANONYMOUS. :DEBUG-NAME (LET (#:LIST1)) :NOTE-LEXICAL-BINDINGS T :POST-BINDING-LEXENV NIL :LOCAL-POLICY NIL :VALUE-SOURCE-FORMS NIL)
58: (SB-C::IR1-CONVERT-LET #<SB-C::CTRAN 23 {800B90CBF3}> #<SB-C::CTRAN 24 {800B90CA93}> NIL (LET ((#1=#:LIST1 (SB-KERNEL:THE* (LIST :USE-ANNOTATIONS T :SOURCE-FORM #2=#) #2#))) (TAGBODY #3=#:START2 (UNLESS (ENDP #1#) (LET (#) (DECLARE #) (SETQ #1# #) (TAGBODY #)) (GO #3#)))))
59: (SB-C::IR1-CONVERT #<SB-C::CTRAN 23 {800B90CBF3}> #<SB-C::CTRAN 24 {800B90CA93}> NIL (LET ((#1=#:LIST1 (SB-KERNEL:THE* (LIST :USE-ANNOTATIONS T :SOURCE-FORM #2=#) #2#))) (TAGBODY #3=#:START2 (UNLESS (ENDP #1#) (LET (#) (DECLARE #) (SETQ #1# #) (TAGBODY #)) (GO #3#)))))
60: (SB-C::IR1-CONVERT-PROGN-BODY #<SB-C::CTRAN 23 {800B90CBF3}> #<SB-C::CTRAN 24 {800B90CA93}> NIL ((LET ((#1=#:LIST1 (SB-KERNEL:THE* # #))) (TAGBODY #2=#:START2 (UNLESS (ENDP #1#) (LET # # # #) (GO #2#))))))
61: (SB-C::IR1-CONVERT-BLOCK #<SB-C::CTRAN 25 {800B90B983}> #<SB-C::CTRAN 24 {800B90CA93}> NIL (BLOCK NIL (LET ((#1=#:LIST1 (SB-KERNEL:THE* # #))) (TAGBODY #2=#:START2 (UNLESS (ENDP #1#) (LET # # # #) (GO #2#))))))
62: (SB-C::IR1-CONVERT #<SB-C::CTRAN 25 {800B90B983}> #<SB-C::CTRAN 24 {800B90CA93}> NIL (BLOCK NIL (LET ((#1=#:LIST1 (SB-KERNEL:THE* # #))) (TAGBODY #2=#:START2 (UNLESS (ENDP #1#) (LET # # # #) (GO #2#))))))
63: (SB-C::IR1-CONVERT-COMMON-FUNCTOID #<SB-C::CTRAN 25 {800B90B983}> #<SB-C::CTRAN 24 {800B90CA93}> NIL (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) DOLIST)
64: (SB-C::IR1-CONVERT #<SB-C::CTRAN 25 {800B90B983}> #<SB-C::CTRAN 24 {800B90CA93}> NIL (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))))
65: (SB-C::IR1-CONVERT-PROGN-BODY #<SB-C::CTRAN 26 {800B90B803}> #<SB-C::CTRAN 27 {800B90B553}> #<SB-C::LVAR 28 {800B90B593}> ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD))
66: (SB-C::IR1-CONVERT-AUX-BINDINGS #<SB-C::CTRAN 26 {800B90B803}> #<SB-C::CTRAN 27 {800B90B553}> #<SB-C::LVAR 28 {800B90B593}> ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) NIL NIL NIL :VALUE-SOURCE-FORMS NIL)
67: (SB-C::IR1-CONVERT-SPECIAL-BINDINGS #<SB-C::CTRAN 26 {800B90B803}> #<SB-C::CTRAN 27 {800B90B553}> #<SB-C::LVAR 28 {800B90B593}> ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) NIL NIL NIL NIL :VALUE-SOURCE-FORMS NIL)
68: (SB-C::IR1-CONVERT-LAMBDA-BODY ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) :AUX-VARS NIL :AUX-VALS NIL :SOURCE-NAME SB-C::.ANONYMOUS. :DEBUG-NAME (SB-C::&AUX-BINDINGS (CHILD)) :NOTE-LEXICAL-BINDINGS T :POST-BINDING-LEXENV NIL :LOCAL-POLICY NIL :VALUE-SOURCE-FORMS NIL)
69: (SB-C::IR1-CONVERT-AUX-BINDINGS #<SB-C::CTRAN 29 {800B90B1E3}> #<SB-C::CTRAN 30 {800B90AF33}> #<SB-C::LVAR 31 {800B90AF73}> ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) ((MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...)) NIL :VALUE-SOURCE-FORMS ((CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))))
70: (SB-C::IR1-CONVERT-SPECIAL-BINDINGS #<SB-C::CTRAN 29 {800B90B1E3}> #<SB-C::CTRAN 30 {800B90AF33}> #<SB-C::LVAR 31 {800B90AF73}> ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) ((MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...)) NIL NIL :VALUE-SOURCE-FORMS ((CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))))
71: (SB-C::IR1-CONVERT-LAMBDA-BODY ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGV {800B9091D3}>) :AUX-VARS (#<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) :AUX-VALS ((MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...)) :SOURCE-NAME SB-C::.ANONYMOUS. :DEBUG-NAME (SB-C::&AUX-BINDINGS (ARGV CHILD)) :NOTE-LEXICAL-BINDINGS T :POST-BINDING-LEXENV NIL :LOCAL-POLICY NIL :VALUE-SOURCE-FORMS ((CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))))
72: (SB-C::IR1-CONVERT-AUX-BINDINGS #<SB-C::CTRAN 32 {800B90ABC3}> #<SB-C::CTRAN 33 {800B90A913}> #<SB-C::LVAR 34 {800B90A953}> ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGV {800B9091D3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) ((APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING (ASDF/SYSTEM:SYSTEM-RELATIVE-PATHNAME \"arcdocdb\" SCRIPT))) ARGUMENTS) (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...)) NIL :VALUE-SOURCE-FORMS ((ARGV (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING #)) ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))))
73: (SB-C::IR1-CONVERT-SPECIAL-BINDINGS #<SB-C::CTRAN 32 {800B90ABC3}> #<SB-C::CTRAN 33 {800B90A913}> #<SB-C::LVAR 34 {800B90A953}> ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGV {800B9091D3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) ((APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING (ASDF/SYSTEM:SYSTEM-RELATIVE-PATHNAME \"arcdocdb\" SCRIPT))) ARGUMENTS) (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...)) NIL NIL :VALUE-SOURCE-FORMS ((ARGV (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING #)) ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))))
74: (SB-C::IR1-CONVERT-LAMBDA-BODY ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME STDERR {800B9090C3}>) :AUX-VARS (#<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGV {800B9091D3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) :AUX-VALS ((APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING (ASDF/SYSTEM:SYSTEM-RELATIVE-PATHNAME \"arcdocdb\" SCRIPT))) ARGUMENTS) (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...)) :SOURCE-NAME SB-C::.ANONYMOUS. :DEBUG-NAME (SB-C::&AUX-BINDINGS (STDERR ARGV CHILD)) :NOTE-LEXICAL-BINDINGS T :POST-BINDING-LEXENV NIL :LOCAL-POLICY NIL :VALUE-SOURCE-FORMS ((ARGV (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING #)) ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))))
75: (SB-C::IR1-CONVERT-AUX-BINDINGS #<SB-C::CTRAN 35 {800B90A5A3}> #<SB-C::CTRAN 36 {800B90A2F3}> #<SB-C::LVAR 37 {800B90A333}> ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME STDERR {800B9090C3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGV {800B9091D3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) ((MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*) (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING (ASDF/SYSTEM:SYSTEM-RELATIVE-PATHNAME \"arcdocdb\" SCRIPT))) ARGUMENTS) (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...)) NIL :VALUE-SOURCE-FORMS ((STDERR (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*)) (ARGV (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING #)) ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))))
76: (SB-C::IR1-CONVERT-SPECIAL-BINDINGS #<SB-C::CTRAN 35 {800B90A5A3}> #<SB-C::CTRAN 36 {800B90A2F3}> #<SB-C::LVAR 37 {800B90A333}> ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME STDERR {800B9090C3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGV {800B9091D3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) ((MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*) (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING (ASDF/SYSTEM:SYSTEM-RELATIVE-PATHNAME \"arcdocdb\" SCRIPT))) ARGUMENTS) (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...)) NIL NIL :VALUE-SOURCE-FORMS ((STDERR (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*)) (ARGV (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING #)) ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))))
77: (SB-C::IR1-CONVERT-LAMBDA-BODY ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME STDOUT {800B908FB3}>) :AUX-VARS (#<SB-C::LAMBDA-VAR :%SOURCE-NAME STDERR {800B9090C3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGV {800B9091D3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) :AUX-VALS ((MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*) (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING (ASDF/SYSTEM:SYSTEM-RELATIVE-PATHNAME \"arcdocdb\" SCRIPT))) ARGUMENTS) (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...)) :SOURCE-NAME SB-C::.ANONYMOUS. :DEBUG-NAME (SB-C::&AUX-BINDINGS (STDOUT STDERR ARGV CHILD)) :NOTE-LEXICAL-BINDINGS T :POST-BINDING-LEXENV NIL :LOCAL-POLICY NIL :VALUE-SOURCE-FORMS ((STDERR (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*)) (ARGV (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING #)) ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))))
78: (SB-C::IR1-CONVERT-AUX-BINDINGS #<SB-C::CTRAN 38 {800B909F83}> #<SB-C::CTRAN 39 {800B909CD3}> #<SB-C::LVAR 40 {800B909D13}> ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME STDOUT {800B908FB3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME STDERR {800B9090C3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGV {800B9091D3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) ((MERGE-PATHNAMES (FORMAT NIL \"~A.stdout\" PREFIX) *ROOT*) (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*) (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING (ASDF/SYSTEM:SYSTEM-RELATIVE-PATHNAME \"arcdocdb\" SCRIPT))) ARGUMENTS) (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...)) NIL :VALUE-SOURCE-FORMS ((STDOUT (MERGE-PATHNAMES (FORMAT NIL \"~A.stdout\" PREFIX) *ROOT*)) (STDERR (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*)) (ARGV (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING #)) ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))))
79: (SB-C::IR1-CONVERT-SPECIAL-BINDINGS #<SB-C::CTRAN 38 {800B909F83}> #<SB-C::CTRAN 39 {800B909CD3}> #<SB-C::LVAR 40 {800B909D13}> ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME STDOUT {800B908FB3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME STDERR {800B9090C3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGV {800B9091D3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) ((MERGE-PATHNAMES (FORMAT NIL \"~A.stdout\" PREFIX) *ROOT*) (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*) (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING (ASDF/SYSTEM:SYSTEM-RELATIVE-PATHNAME \"arcdocdb\" SCRIPT))) ARGUMENTS) (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...)) NIL NIL :VALUE-SOURCE-FORMS ((STDOUT (MERGE-PATHNAMES (FORMAT NIL \"~A.stdout\" PREFIX) *ROOT*)) (STDERR (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*)) (ARGV (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING #)) ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))))
80: (SB-C::IR1-CONVERT-LAMBDA-BODY ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME PREFIX {800B908EA3}>) :AUX-VARS (#<SB-C::LAMBDA-VAR :%SOURCE-NAME STDOUT {800B908FB3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME STDERR {800B9090C3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGV {800B9091D3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) :AUX-VALS ((MERGE-PATHNAMES (FORMAT NIL \"~A.stdout\" PREFIX) *ROOT*) (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*) (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING (ASDF/SYSTEM:SYSTEM-RELATIVE-PATHNAME \"arcdocdb\" SCRIPT))) ARGUMENTS) (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...)) :SOURCE-NAME SB-C::.ANONYMOUS. :DEBUG-NAME (SB-C::&AUX-BINDINGS (PREFIX STDOUT STDERR ARGV CHILD)) :NOTE-LEXICAL-BINDINGS T :POST-BINDING-LEXENV NIL :LOCAL-POLICY NIL :VALUE-SOURCE-FORMS ((STDOUT (MERGE-PATHNAMES (FORMAT NIL \"~A.stdout\" PREFIX) *ROOT*)) (STDERR (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*)) (ARGV (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING #)) ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))))
81: (SB-C::IR1-CONVERT-AUX-BINDINGS #<SB-C::CTRAN 41 {800B909963}> #<SB-C::CTRAN 42 {800B9096B3}> #<SB-C::LVAR 43 {800B9096F3}> ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME PREFIX {800B908EA3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME STDOUT {800B908FB3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME STDERR {800B9090C3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGV {800B9091D3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) ((FORMAT NIL \"~3,'0D-~A\" ID NAME) (MERGE-PATHNAMES (FORMAT NIL \"~A.stdout\" PREFIX) *ROOT*) (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*) (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING (ASDF/SYSTEM:SYSTEM-RELATIVE-PATHNAME \"arcdocdb\" SCRIPT))) ARGUMENTS) (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...)) NIL :VALUE-SOURCE-FORMS ((PREFIX (FORMAT NIL \"~3,'0D-~A\" ID NAME)) (STDOUT (MERGE-PATHNAMES (FORMAT NIL \"~A.stdout\" PREFIX) *ROOT*)) (STDERR (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*)) (ARGV (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING #)) ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))))
82: (SB-C::IR1-CONVERT-SPECIAL-BINDINGS #<SB-C::CTRAN 41 {800B909963}> #<SB-C::CTRAN 42 {800B9096B3}> #<SB-C::LVAR 43 {800B9096F3}> ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME PREFIX {800B908EA3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME STDOUT {800B908FB3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME STDERR {800B9090C3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGV {800B9091D3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) ((FORMAT NIL \"~3,'0D-~A\" ID NAME) (MERGE-PATHNAMES (FORMAT NIL \"~A.stdout\" PREFIX) *ROOT*) (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*) (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING (ASDF/SYSTEM:SYSTEM-RELATIVE-PATHNAME \"arcdocdb\" SCRIPT))) ARGUMENTS) (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...)) NIL NIL :VALUE-SOURCE-FORMS ((PREFIX (FORMAT NIL \"~3,'0D-~A\" ID NAME)) (STDOUT (MERGE-PATHNAMES (FORMAT NIL \"~A.stdout\" PREFIX) *ROOT*)) (STDERR (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*)) (ARGV (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING #)) ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))))
83: (SB-C::IR1-CONVERT-LAMBDA-BODY ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME ID {800B908D93}>) :AUX-VARS (#<SB-C::LAMBDA-VAR :%SOURCE-NAME PREFIX {800B908EA3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME STDOUT {800B908FB3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME STDERR {800B9090C3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGV {800B9091D3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) :AUX-VALS ((FORMAT NIL \"~3,'0D-~A\" ID NAME) (MERGE-PATHNAMES (FORMAT NIL \"~A.stdout\" PREFIX) *ROOT*) (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*) (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING (ASDF/SYSTEM:SYSTEM-RELATIVE-PATHNAME \"arcdocdb\" SCRIPT))) ARGUMENTS) (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...)) :SOURCE-NAME SB-C::.ANONYMOUS. :DEBUG-NAME (SB-C::&AUX-BINDINGS (ID PREFIX STDOUT STDERR ARGV CHILD)) :NOTE-LEXICAL-BINDINGS T :POST-BINDING-LEXENV NIL :LOCAL-POLICY NIL :VALUE-SOURCE-FORMS ((PREFIX (FORMAT NIL \"~3,'0D-~A\" ID NAME)) (STDOUT (MERGE-PATHNAMES (FORMAT NIL \"~A.stdout\" PREFIX) *ROOT*)) (STDERR (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*)) (ARGV (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING #)) ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))))
84: (SB-C::IR1-CONVERT-AUX-BINDINGS #<SB-C::CTRAN 44 {800B9079F3}> #<SB-C::CTRAN 45 {800B907473}> #<SB-C::LVAR 46 {800B9074B3}> ((PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME ID {800B908D93}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME PREFIX {800B908EA3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME STDOUT {800B908FB3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME STDERR {800B9090C3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGV {800B9091D3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME CHILD {800B9092E3}>) ((1+ (LENGTH *CHILDREN*)) (FORMAT NIL \"~3,'0D-~A\" ID NAME) (MERGE-PATHNAMES (FORMAT NIL \"~A.stdout\" PREFIX) *ROOT*) (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*) (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING (ASDF/SYSTEM:SYSTEM-RELATIVE-PATHNAME \"arcdocdb\" SCRIPT))) ARGUMENTS) (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...)) NIL :VALUE-SOURCE-FORMS ((ID (1+ (LENGTH *CHILDREN*))) (PREFIX (FORMAT NIL \"~3,'0D-~A\" ID NAME)) (STDOUT (MERGE-PATHNAMES (FORMAT NIL \"~A.stdout\" PREFIX) *ROOT*)) (STDERR (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*)) (ARGV (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" (NAMESTRING #)) ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))))
85: (SB-C::IR1-CONVERT-LET* #<SB-C::CTRAN 44 {800B9079F3}> #<SB-C::CTRAN 45 {800B907473}> #<SB-C::LVAR 46 {800B9074B3}> (LET* ((ID (1+ (LENGTH *CHILDREN*))) (PREFIX (FORMAT NIL \"~3,'0D-~A\" ID NAME)) (STDOUT (MERGE-PATHNAMES (FORMAT NIL \"~A.stdout\" PREFIX) *ROOT*)) (STDERR (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*)) (ARGV (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #) ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))) (PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD))
86: (SB-C::IR1-CONVERT #<SB-C::CTRAN 44 {800B9079F3}> #<SB-C::CTRAN 45 {800B907473}> #<SB-C::LVAR 46 {800B9074B3}> (LET* ((ID (1+ (LENGTH *CHILDREN*))) (PREFIX (FORMAT NIL \"~3,'0D-~A\" ID NAME)) (STDOUT (MERGE-PATHNAMES (FORMAT NIL \"~A.stdout\" PREFIX) *ROOT*)) (STDERR (MERGE-PATHNAMES (FORMAT NIL \"~A.stderr\" PREFIX) *ROOT*)) (ARGV (APPEND (LIST \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #) ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))) (PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE (IGNORE STREAM)))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD))
87: (SB-C::IR1-CONVERT-PROGN-BODY #<SB-C::CTRAN 47 {800B9078A3}> #<SB-C::CTRAN 45 {800B907473}> #<SB-C::LVAR 46 {800B9074B3}> ((CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID (1+ #)) (PREFIX (FORMAT NIL \"~3,'0D-~A\" ID NAME)) (STDOUT (MERGE-PATHNAMES # *ROOT*)) (STDERR (MERGE-PATHNAMES # *ROOT*)) (ARGV (APPEND # ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))) (PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE #))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD)))
88: (SB-C::IR1-CONVERT-BLOCK #<SB-C::CTRAN 48 {800B907723}> #<SB-C::CTRAN 45 {800B907473}> #<SB-C::LVAR 46 {800B9074B3}> (BLOCK LAUNCH (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID (1+ #)) (PREFIX (FORMAT NIL \"~3,'0D-~A\" ID NAME)) (STDOUT (MERGE-PATHNAMES # *ROOT*)) (STDERR (MERGE-PATHNAMES # *ROOT*)) (ARGV (APPEND # ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))) (PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE #))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD)))
89: (SB-C::IR1-CONVERT #<SB-C::CTRAN 48 {800B907723}> #<SB-C::CTRAN 45 {800B907473}> #<SB-C::LVAR 46 {800B9074B3}> (BLOCK LAUNCH (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID (1+ #)) (PREFIX (FORMAT NIL \"~3,'0D-~A\" ID NAME)) (STDOUT (MERGE-PATHNAMES # *ROOT*)) (STDERR (MERGE-PATHNAMES # *ROOT*)) (ARGV (APPEND # ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))) (PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE #))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD)))
90: (SB-C::IR1-CONVERT-PROGN-BODY #<SB-C::CTRAN 48 {800B907723}> #<SB-C::CTRAN 45 {800B907473}> #<SB-C::LVAR 46 {800B9074B3}> ((BLOCK LAUNCH (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID #) (PREFIX #) (STDOUT #) (STDERR #) (ARGV #) (CHILD #)) (PUSH CHILD *CHILDREN*) (DOLIST (PATH #) (WITH-OPEN-FILE # #)) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM # ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID #)) CHILD))))
91: (SB-C::IR1-CONVERT-AUX-BINDINGS #<SB-C::CTRAN 48 {800B907723}> #<SB-C::CTRAN 45 {800B907473}> #<SB-C::LVAR 46 {800B9074B3}> ((BLOCK LAUNCH (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID #) (PREFIX #) (STDOUT #) (STDERR #) (ARGV #) (CHILD #)) (PUSH CHILD *CHILDREN*) (DOLIST (PATH #) (WITH-OPEN-FILE # #)) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM # ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID #)) CHILD))) NIL NIL NIL :VALUE-SOURCE-FORMS NIL)
92: (SB-C::IR1-CONVERT-SPECIAL-BINDINGS #<SB-C::CTRAN 48 {800B907723}> #<SB-C::CTRAN 45 {800B907473}> #<SB-C::LVAR 46 {800B9074B3}> ((BLOCK LAUNCH (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID #) (PREFIX #) (STDOUT #) (STDERR #) (ARGV #) (CHILD #)) (PUSH CHILD *CHILDREN*) (DOLIST (PATH #) (WITH-OPEN-FILE # #)) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM # ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID #)) CHILD))) NIL NIL NIL NIL :VALUE-SOURCE-FORMS NIL)
93: (SB-C::IR1-CONVERT-LAMBDA-BODY ((BLOCK LAUNCH (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID #) (PREFIX #) (STDOUT #) (STDERR #) (ARGV #) (CHILD #)) (PUSH CHILD *CHILDREN*) (DOLIST (PATH #) (WITH-OPEN-FILE # #)) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM # ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID #)) CHILD))) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME EXPECTED-FAILURE :ARG-INFO #<SB-C::ARG-INFO  :KIND :KEYWORD :KEY :EXPECTED-FAILURE {800B906923}> {800B906853}>) :AUX-VARS NIL :AUX-VALS NIL :SOURCE-NAME SB-C::.ANONYMOUS. :DEBUG-NAME (SB-C::&AUX-BINDINGS (EXPECTED-FAILURE)) :NOTE-LEXICAL-BINDINGS T :POST-BINDING-LEXENV NIL :LOCAL-POLICY NIL :VALUE-SOURCE-FORMS NIL)
94: (SB-C::IR1-CONVERT-AUX-BINDINGS #<SB-C::CTRAN 49 {800B907103}> #<SB-C::CTRAN 50 {800B906E53}> #<SB-C::LVAR 51 {800B906E93}> ((BLOCK LAUNCH (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID #) (PREFIX #) (STDOUT #) (STDERR #) (ARGV #) (CHILD #)) (PUSH CHILD *CHILDREN*) (DOLIST (PATH #) (WITH-OPEN-FILE # #)) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM # ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID #)) CHILD))) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME EXPECTED-FAILURE :ARG-INFO #<SB-C::ARG-INFO  :KIND :KEYWORD :KEY :EXPECTED-FAILURE {800B906923}> {800B906853}>) (#:.DEFAULTING-TEMP.) NIL :VALUE-SOURCE-FORMS NIL)
95: (SB-C::IR1-CONVERT-SPECIAL-BINDINGS #<SB-C::CTRAN 49 {800B907103}> #<SB-C::CTRAN 50 {800B906E53}> #<SB-C::LVAR 51 {800B906E93}> ((BLOCK LAUNCH (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID #) (PREFIX #) (STDOUT #) (STDERR #) (ARGV #) (CHILD #)) (PUSH CHILD *CHILDREN*) (DOLIST (PATH #) (WITH-OPEN-FILE # #)) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM # ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID #)) CHILD))) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME EXPECTED-FAILURE :ARG-INFO #<SB-C::ARG-INFO  :KIND :KEYWORD :KEY :EXPECTED-FAILURE {800B906923}> {800B906853}>) (#:.DEFAULTING-TEMP.) NIL NIL :VALUE-SOURCE-FORMS NIL)
96: (SB-C::IR1-CONVERT-LAMBDA-BODY ((BLOCK LAUNCH (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID #) (PREFIX #) (STDOUT #) (STDERR #) (ARGV #) (CHILD #)) (PUSH CHILD *CHILDREN*) (DOLIST (PATH #) (WITH-OPEN-FILE # #)) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM # ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID #)) CHILD))) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME NAME {800B9064C3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME ROLE {800B906593}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME SCRIPT {800B906663}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGUMENTS {800B906733}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME #:.DEFAULTING-TEMP. {800B906BB3}>) :AUX-VARS (#<SB-C::LAMBDA-VAR :%SOURCE-NAME EXPECTED-FAILURE :ARG-INFO #<SB-C::ARG-INFO  :KIND :KEYWORD :KEY :EXPECTED-FAILURE {800B906923}> {800B906853}>) :AUX-VALS (#:.DEFAULTING-TEMP.) :SOURCE-NAME LAUNCH :DEBUG-NAME NIL :NOTE-LEXICAL-BINDINGS T :POST-BINDING-LEXENV NIL :LOCAL-POLICY NIL :VALUE-SOURCE-FORMS NIL)
97: (SB-C::IR1-CONVERT-HAIRY-ARGS #<SB-C::OPTIONAL-DISPATCH :%SOURCE-NAME LAUNCH :%DEBUG-NAME NIL :TYPE #<SB-KERNEL:BUILT-IN-CLASSOID FUNCTION (read-only)> :WHERE-FROM :DEFINED :ARGLIST (#<SB-C::LAMBDA-VAR :%SOURCE-NAME NAME {800B9064C3}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME ROLE {800B906593}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME SCRIPT {800B906663}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGUMENTS {800B906733}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME EXPECTED-FAILURE :ARG-INFO #<SB-C::ARG-INFO  :KIND :KEYWORD :KEY :EXPECTED-FAILURE {800B906923}> {800B906853}>) :ALLOWP NIL :KEYP T :MIN-ARGS 0 :MAX-ARGS 0 :MAIN-ENTRY NIL {800B906A93}> (#<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGUMENTS {800B906733}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME SCRIPT {800B906663}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME ROLE {800B906593}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME NAME {800B9064C3}>) (ARGUMENTS SCRIPT ROLE NAME) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME ARGUMENTS {800B906733}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME SCRIPT {800B906663}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME ROLE {800B906593}> #<SB-C::LAMBDA-VAR :%SOURCE-NAME NAME {800B9064C3}>) (ARGUMENTS SCRIPT ROLE NAME) (#<SB-C::LAMBDA-VAR :%SOURCE-NAME EXPECTED-FAILURE :ARG-INFO #<SB-C::ARG-INFO  :KIND :KEYWORD :KEY :EXPECTED-FAILURE {800B906923}> {800B906853}>) NIL ((BLOCK LAUNCH (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID #) (PREFIX #) (STDOUT #) (STDERR #) (ARGV #) (CHILD #)) (PUSH CHILD *CHILDREN*) (DOLIST (PATH #) (WITH-OPEN-FILE # #)) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM # ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID #)) CHILD))) NIL NIL LAUNCH NIL NIL NIL)
98: (SB-C::IR1-CONVERT-LAMBDA (LAMBDA (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID #) (PREFIX #) (STDOUT #) (STDERR #) (ARGV #) (CHILD #)) (PUSH CHILD *CHILDREN*) (DOLIST (PATH #) (WITH-OPEN-FILE # #)) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM # ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID #)) CHILD))) :SOURCE-NAME LAUNCH :DEBUG-NAME NIL :MAYBE-ADD-DEBUG-CATCH T :FTYPE NIL)
99: (SB-C::IR1-CONVERT-LAMBDA-FOR-DEFUN (LAMBDA (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID #) (PREFIX #) (STDOUT #) (STDERR #) (ARGV #) (CHILD #)) (PUSH CHILD *CHILDREN*) (DOLIST (PATH #) (WITH-OPEN-FILE # #)) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM # ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID #)) CHILD))) #<SB-C::DEFINED-FUN :%SOURCE-NAME LAUNCH :INLINEP NIL :SAME-BLOCK-P T {800B9052B3}> T)
100: (SB-C::IR1-CONVERT-LAMBDALIKE (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID #) (PREFIX #) (STDOUT #) (STDERR #) (ARGV #) (CHILD #)) (PUSH CHILD *CHILDREN*) (DOLIST (PATH #) (WITH-OPEN-FILE # #)) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM # ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID #)) CHILD))) :SOURCE-NAME SB-C::.ANONYMOUS. :DEBUG-NAME LAUNCH :FTYPE NIL)
101: (SB-C::FIND-OR-CONVERT-FUN-LEAF (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID #) (PREFIX #) (STDOUT #) (STDERR #) (ARGV #) (CHILD #)) (PUSH CHILD *CHILDREN*) (DOLIST (PATH #) (WITH-OPEN-FILE # #)) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM # ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID #)) CHILD))) #<SB-C::CTRAN 52 {800B906013}>)
102: (SB-C::IR1-CONVERT-FUNCTION #<SB-C::CTRAN 52 {800B906013}> #<SB-C::CTRAN 53 {800B9061A3}> #<SB-C::LVAR 54 {800B9061E3}> (FUNCTION (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK (< # 256) \"Limite processi della fixture superato.\") (LET* (# # # # # #) (PUSH CHILD *CHILDREN*) (DOLIST # #) (SETF # # # #) CHILD)))))
103: (SB-C::IR1-CONVERT #<SB-C::CTRAN 52 {800B906013}> #<SB-C::CTRAN 53 {800B9061A3}> #<SB-C::LVAR 54 {800B9061E3}> (FUNCTION (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK (< # 256) \"Limite processi della fixture superato.\") (LET* (# # # # # #) (PUSH CHILD *CHILDREN*) (DOLIST # #) (SETF # # # #) CHILD)))))
104: (SB-C::IR1-CONVERT-COMMON-FUNCTOID #<SB-C::CTRAN 52 {800B906013}> #<SB-C::CTRAN 53 {800B9061A3}> #<SB-C::LVAR 54 {800B9061E3}> (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID #) (PREFIX #) (STDOUT #) (STDERR #) (ARGV #) (CHILD #)) (PUSH CHILD *CHILDREN*) (DOLIST (PATH #) (WITH-OPEN-FILE # #)) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM # ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID #)) CHILD))) SB-INT:NAMED-LAMBDA)
105: (SB-C::IR1-CONVERT #<SB-C::CTRAN 52 {800B906013}> #<SB-C::CTRAN 53 {800B9061A3}> #<SB-C::LVAR 54 {800B9061E3}> (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID #) (PREFIX #) (STDOUT #) (STDERR #) (ARGV #) (CHILD #)) (PUSH CHILD *CHILDREN*) (DOLIST (PATH #) (WITH-OPEN-FILE # #)) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM # ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID #)) CHILD))))
106: (SB-C::IR1-CONVERT-COMBINATION-ARGS #<SB-C::LVAR 55 {800B905E83}> #<SB-C::CTRAN 56 {800B905E43}> #<SB-C::CTRAN 57 {800B905D33}> NIL ((QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK (< # 256) \"Limite processi della fixture superato.\") (LET* (# # # # # #) (PUSH CHILD *CHILDREN*) (DOLIST # #) (SETF # # # #) CHILD)))) :PASS-NARGS T :ARG-SOURCE-FORMS NIL)
107: (SB-C::IR1-CONVERT-COMBINATION #<SB-C::CTRAN 58 {800B905BB3}> #<SB-C::CTRAN 57 {800B905D33}> NIL (SB-IMPL::%DEFUN (QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK (< # 256) \"Limite processi della fixture superato.\") (LET* (# # # # # #) (PUSH CHILD *CHILDREN*) (DOLIST # #) (SETF # # # #) CHILD)))) #<SB-C::GLOBAL-VAR :%SOURCE-NAME SB-IMPL::%DEFUN :TYPE #<SB-KERNEL:BUILT-IN-CLASSOID FUNCTION (read-only)> :DEFINED-TYPE #<SB-KERNEL:FUN-TYPE (FUNCTION (T FUNCTION &OPTIONAL T T) (VALUES (OR CONS SYMBOL) &OPTIONAL))> :WHERE-FROM :DEFINED :KIND :GLOBAL-FUNCTION {800B905DD3}>)
108: (SB-C::IR1-CONVERT-COMBINATION-CHECKING-TYPE #<SB-C::CTRAN 58 {800B905BB3}> #<SB-C::CTRAN 57 {800B905D33}> NIL (SB-IMPL::%DEFUN (QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK (< # 256) \"Limite processi della fixture superato.\") (LET* (# # # # # #) (PUSH CHILD *CHILDREN*) (DOLIST # #) (SETF # # # #) CHILD)))) #<SB-C::GLOBAL-VAR :%SOURCE-NAME SB-IMPL::%DEFUN :TYPE #<SB-KERNEL:BUILT-IN-CLASSOID FUNCTION (read-only)> :DEFINED-TYPE #<SB-KERNEL:FUN-TYPE (FUNCTION (T FUNCTION &OPTIONAL T T) (VALUES (OR CONS SYMBOL) &OPTIONAL))> :WHERE-FROM :DEFINED :KIND :GLOBAL-FUNCTION {800B905DD3}>)
109: (SB-C::IR1-CONVERT #<SB-C::CTRAN 58 {800B905BB3}> #<SB-C::CTRAN 57 {800B905D33}> NIL (SB-IMPL::%DEFUN (QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK (< # 256) \"Limite processi della fixture superato.\") (LET* (# # # # # #) (PUSH CHILD *CHILDREN*) (DOLIST # #) (SETF # # # #) CHILD)))))
110: (SB-C::IR1-CONVERT-PROGN-BODY #<SB-C::CTRAN 58 {800B905BB3}> #<SB-C::CTRAN 59 {800B905903}> #<SB-C::LVAR 60 {800B905943}> ((SB-IMPL::%DEFUN (QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK # \"Limite processi della fixture superato.\") (LET* # # # # CHILD)))) NIL))
111: (SB-C::IR1-CONVERT-AUX-BINDINGS #<SB-C::CTRAN 58 {800B905BB3}> #<SB-C::CTRAN 59 {800B905903}> #<SB-C::LVAR 60 {800B905943}> ((SB-IMPL::%DEFUN (QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK # \"Limite processi della fixture superato.\") (LET* # # # # CHILD)))) NIL) NIL NIL NIL :VALUE-SOURCE-FORMS NIL)
112: (SB-C::IR1-CONVERT-SPECIAL-BINDINGS #<SB-C::CTRAN 58 {800B905BB3}> #<SB-C::CTRAN 59 {800B905903}> #<SB-C::LVAR 60 {800B905943}> ((SB-IMPL::%DEFUN (QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK # \"Limite processi della fixture superato.\") (LET* # # # # CHILD)))) NIL) NIL NIL NIL NIL :VALUE-SOURCE-FORMS NIL)
113: (SB-C::IR1-CONVERT-LAMBDA-BODY ((SB-IMPL::%DEFUN (QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK # \"Limite processi della fixture superato.\") (LET* # # # # CHILD)))) NIL) NIL :AUX-VARS NIL :AUX-VALS NIL :SOURCE-NAME SB-C::.ANONYMOUS. :DEBUG-NAME \"top level form\" :NOTE-LEXICAL-BINDINGS T :POST-BINDING-LEXENV NIL :LOCAL-POLICY NIL :VALUE-SOURCE-FORMS NIL)
114: (SB-C::IR1-TOPLEVEL (SB-IMPL::%DEFUN (QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK (< # 256) \"Limite processi della fixture superato.\") (LET* (# # # # # #) (PUSH CHILD *CHILDREN*) (DOLIST # #) (SETF # # # #) CHILD)))) (#1=(SB-IMPL::%DEFUN (QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK # \"Limite processi della fixture superato.\") (LET* # # # # CHILD)))) (PROGN (EVAL-WHEN (:COMPILE-TOPLEVEL) (SB-C:%COMPILER-DEFUN (QUOTE LAUNCH) T NIL NIL)) #1#) SB-C::ORIGINAL-SOURCE-START 0 32) NIL T)
115: (SB-C::CONVERT-AND-MAYBE-COMPILE (SB-IMPL::%DEFUN (QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK (< # 256) \"Limite processi della fixture superato.\") (LET* (# # # # # #) (PUSH CHILD *CHILDREN*) (DOLIST # #) (SETF # # # #) CHILD)))) (#1=(SB-IMPL::%DEFUN (QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK # \"Limite processi della fixture superato.\") (LET* # # # # CHILD)))) (PROGN (EVAL-WHEN (:COMPILE-TOPLEVEL) (SB-C:%COMPILER-DEFUN (QUOTE LAUNCH) T NIL NIL)) #1#) SB-C::ORIGINAL-SOURCE-START 0 32))
116: (SB-C::PROCESS-TOPLEVEL-FORM (SB-IMPL::%DEFUN (QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK (< # 256) \"Limite processi della fixture superato.\") (LET* (# # # # # #) (PUSH CHILD *CHILDREN*) (DOLIST # #) (SETF # # # #) CHILD)))) ((PROGN (EVAL-WHEN (:COMPILE-TOPLEVEL) (SB-C:%COMPILER-DEFUN (QUOTE LAUNCH) T NIL NIL)) (SB-IMPL::%DEFUN (QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE #) (BLOCK LAUNCH # #)))) SB-C::ORIGINAL-SOURCE-START 0 32) NIL)
117: (SB-C::PROCESS-TOPLEVEL-PROGN ((EVAL-WHEN (:COMPILE-TOPLEVEL) (SB-C:%COMPILER-DEFUN (QUOTE LAUNCH) T NIL NIL)) (SB-IMPL::%DEFUN (QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK # \"Limite processi della fixture superato.\") (LET* # # # # CHILD))))) ((PROGN (EVAL-WHEN (:COMPILE-TOPLEVEL) (SB-C:%COMPILER-DEFUN (QUOTE LAUNCH) T NIL NIL)) (SB-IMPL::%DEFUN (QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE #) (BLOCK LAUNCH # #)))) SB-C::ORIGINAL-SOURCE-START 0 32) NIL)
118: (SB-C::PROCESS-TOPLEVEL-FORM (PROGN (EVAL-WHEN (:COMPILE-TOPLEVEL) (SB-C:%COMPILER-DEFUN (QUOTE LAUNCH) T NIL NIL)) (SB-IMPL::%DEFUN (QUOTE LAUNCH) (SB-INT:NAMED-LAMBDA LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (DECLARE (SB-C::TOP-LEVEL-FORM)) (BLOCK LAUNCH (CHECK # \"Limite processi della fixture superato.\") (LET* # # # # CHILD))))) (SB-C::ORIGINAL-SOURCE-START 0 32) NIL)
119: (SB-C::PROCESS-TOPLEVEL-FORM (DEFUN LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID (1+ #)) (PREFIX (FORMAT NIL \"~3,'0D-~A\" ID NAME)) (STDOUT (MERGE-PATHNAMES # *ROOT*)) (STDERR (MERGE-PATHNAMES # *ROOT*)) (ARGV (APPEND # ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))) (PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE #))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD)) (SB-C::ORIGINAL-SOURCE-START 0 32) NIL)
120: ((LAMBDA (SB-KERNEL:FORM &KEY :CURRENT-INDEX &ALLOW-OTHER-KEYS) :IN SB-C::SUB-COMPILE-FILE) (DEFUN LAUNCH (NAME ROLE SCRIPT ARGUMENTS &KEY EXPECTED-FAILURE) (CHECK (< (LENGTH *CHILDREN*) 256) \"Limite processi della fixture superato.\") (LET* ((ID (1+ #)) (PREFIX (FORMAT NIL \"~3,'0D-~A\" ID NAME)) (STDOUT (MERGE-PATHNAMES # *ROOT*)) (STDERR (MERGE-PATHNAMES # *ROOT*)) (ARGV (APPEND # ARGUMENTS)) (CHILD (MAKE-CHILD :NAME NAME :ROLE ROLE :ARGUMENTS ARGV :STDOUT STDOUT :STDERR STDERR :STARTED ...))) (PUSH CHILD *CHILDREN*) (DOLIST (PATH (LIST STDOUT STDERR)) (WITH-OPEN-FILE (STREAM PATH :DIRECTION :OUTPUT :IF-EXISTS :ERROR) (DECLARE #))) (SETF (CHILD-PROCESS CHILD) (SB-EXT:RUN-PROGRAM (NAMESTRING SB-EXT:*RUNTIME-PATHNAME*) ARGV :WAIT NIL :INPUT NIL :OUTPUT STDOUT :ERROR STDERR :IF-OUTPUT-EXISTS ...) (CHILD-PID CHILD) (SB-EXT:PROCESS-PID (CHILD-PROCESS CHILD))) CHILD)) :CURRENT-INDEX 32)
121: (SB-C::%DO-FORMS-FROM-INFO #<FUNCTION (LAMBDA (SB-KERNEL:FORM &KEY :CURRENT-INDEX &ALLOW-OTHER-KEYS) :IN SB-C::SUB-COMPILE-FILE) {80034DBF4B}> #<SB-C::SOURCE-INFO {8006A67783}> SB-C::INPUT-ERROR-IN-COMPILE-FILE)
122: ((LAMBDA NIL :IN SB-C::SUB-COMPILE-FILE))
123: ((FLET SB-C::WITH-IT :IN SB-C::%WITH-COMPILATION-UNIT))
124: (SB-C::SUB-COMPILE-FILE #<SB-C::SOURCE-INFO {8006A67783}> NIL)
125: (COMPILE-FILE #P\"/Users/runner/work/ArcDocDB/ArcDocDB/tests/local/processes.lisp\" :OUTPUT-FILE #P\"/Users/runner/.cache/common-lisp/sbcl-2.6.9-macosx-arm64/Users/runner/work/ArcDocDB/ArcDocDB/tests/local/processes-tmp6WQCTWZY.fasl\" :VERBOSE NIL :PRINT NIL :EXTERNAL-FORMAT :UTF-8 :PROGRESS NIL :TRACE-FILE NIL :BLOCK-COMPILE NIL :ENTRY-POINTS NIL :EMIT-CFASL NIL)
126: (UIOP/UTILITY:CALL-WITH-MUFFLED-CONDITIONS #<FUNCTION (LAMBDA NIL :IN UIOP/LISP-BUILD:COMPILE-FILE*) {8006ACBE6B}> NIL)
127: (UIOP/PATHNAME:CALL-WITH-ENOUGH-PATHNAME #P\"/Users/runner/work/ArcDocDB/ArcDocDB/tests/local/processes.lisp\" NIL #<FUNCTION (LAMBDA (UIOP/LISP-BUILD::INPUT-FILE) :IN UIOP/LISP-BUILD:COMPILE-FILE*) {8006ACBBAB}>)
128: (UIOP/LISP-BUILD:COMPILE-FILE* #P\"/Users/runner/work/ArcDocDB/ArcDocDB/tests/local/processes.lisp\" :OUTPUT-FILE #P\"/Users/runner/.cache/common-lisp/sbcl-2.6.9-macosx-arm64/Users/runner/work/ArcDocDB/ArcDocDB/tests/local/processes.fasl\" :EXTERNAL-FORMAT :UTF-8 :WARNINGS-FILE NIL)
129: (ARCDOCDB.CI.TESTS::CALL-WITH-REGISTRATION-AUDIT #<FUNCTION (LAMBDA (&REST ASDF/LISP-ACTION::FLAGS) :IN ASDF/LISP-ACTION:PERFORM-LISP-COMPILATION) {8006AC730B}>)
130: (ASDF/LISP-ACTION:PERFORM-LISP-COMPILATION #<ASDF/LISP-ACTION:COMPILE-OP > #<ASDF/LISP-ACTION:CL-SOURCE-FILE \"arcdocdb/tests\" \"local\" \"processes\">)
131: ((SB-PCL::EMF ASDF/ACTION:PERFORM) #<unused argument> #<unused argument> #<ASDF/LISP-ACTION:COMPILE-OP > #<ASDF/LISP-ACTION:CL-SOURCE-FILE \"arcdocdb/tests\" \"local\" \"processes\">)
132: ((LAMBDA NIL :IN ASDF/ACTION:CALL-WHILE-VISITING-ACTION))
133: ((:METHOD ASDF/ACTION:PERFORM-WITH-RESTARTS :AROUND (T T)) #<ASDF/LISP-ACTION:COMPILE-OP > #<ASDF/LISP-ACTION:CL-SOURCE-FILE \"arcdocdb/tests\" \"local\" \"processes\">) [fast-method]
134: ((:METHOD ASDF/PLAN:PERFORM-PLAN (T)) #<ASDF/PLAN:SEQUENTIAL-PLAN {80053509E3}>) [fast-method]
135: ((FLET SB-C::WITH-IT :IN SB-C::%WITH-COMPILATION-UNIT))
136: ((:METHOD ASDF/PLAN:PERFORM-PLAN :AROUND (T)) #<ASDF/PLAN:SEQUENTIAL-PLAN {80053509E3}>) [fast-method]
137: ((:METHOD ASDF/OPERATE:OPERATE (ASDF/OPERATION:OPERATION ASDF/COMPONENT:COMPONENT)) #<ASDF/LISP-ACTION:LOAD-OP > #<ASDF/SYSTEM:SYSTEM \"arcdocdb/tests\"> :PLAN-CLASS NIL :PLAN-OPTIONS NIL) [fast-method]
138: ((SB-PCL::EMF ASDF/OPERATE:OPERATE) #<unused argument> #<unused argument> #<ASDF/LISP-ACTION:LOAD-OP > #<ASDF/SYSTEM:SYSTEM \"arcdocdb/tests\">)
139: ((LAMBDA NIL :IN ASDF/OPERATE:OPERATE))
140: ((:METHOD ASDF/OPERATE:OPERATE :AROUND (T T)) #<ASDF/LISP-ACTION:LOAD-OP > #<ASDF/SYSTEM:SYSTEM \"arcdocdb/tests\">) [fast-method]
141: ((SB-PCL::EMF ASDF/OPERATE:OPERATE) #<unused argument> #<unused argument> ASDF/LISP-ACTION:LOAD-OP \"arcdocdb/tests\")
142: ((LAMBDA NIL :IN ASDF/OPERATE:OPERATE))
143: ((:METHOD ASDF/OPERATE:OPERATE :AROUND (T T)) ASDF/LISP-ACTION:LOAD-OP \"arcdocdb/tests\") [fast-method]
144: (ASDF/SESSION:CALL-WITH-ASDF-SESSION #<FUNCTION (LAMBDA NIL :IN ASDF/OPERATE:OPERATE) {800535084B}> :OVERRIDE T :KEY NIL :OVERRIDE-CACHE T :OVERRIDE-FORCING NIL)
145: ((LAMBDA NIL :IN ASDF/OPERATE:OPERATE))
146: (ASDF/SESSION:CALL-WITH-ASDF-SESSION #<FUNCTION (LAMBDA NIL :IN ASDF/OPERATE:OPERATE) {800535073B}> :OVERRIDE NIL :KEY NIL :OVERRIDE-CACHE NIL :OVERRIDE-FORCING NIL)
147: ((:METHOD ASDF/OPERATE:OPERATE :AROUND (T T)) ASDF/LISP-ACTION:LOAD-OP \"arcdocdb/tests\") [fast-method]
148: (ASDF/OPERATE:LOAD-SYSTEM \"arcdocdb/tests\")
149: (\"top level form\") [toplevel]
150: ((FLET \"G\" :IN SB-C::%COMPILE-IN-LEXENV))
151: (SB-C::%COMPILE-IN-LEXENV (LET ((SB-KERNEL:*HANDLER-CLUSTERS* (CONS (LIST #) . #1=(SB-KERNEL:*HANDLER-CLUSTERS*)))) (DECLARE (DYNAMIC-EXTENT . #1#)) (PROGN (ASDF/FIND-SYSTEM:LOAD-ASD (MERGE-PATHNAMES \"../arcdocdb.asd\" *LOAD-TRUENAME*)) (ASDF/OPERATE:LOAD-SYSTEM \"arcdocdb/tests\"))) #<NULL-LEXENV> NIL #<SB-C::SOURCE-INFO {8005350423}> 3 NIL T T)
152: (SB-C:EVAL-WITH-COMPILE-IN-LEXENV (LET ((SB-KERNEL:*HANDLER-CLUSTERS* (CONS (LIST #) . #1=(SB-KERNEL:*HANDLER-CLUSTERS*)))) (DECLARE (DYNAMIC-EXTENT . #1#)) (PROGN (ASDF/FIND-SYSTEM:LOAD-ASD (MERGE-PATHNAMES \"../arcdocdb.asd\" *LOAD-TRUENAME*)) (ASDF/OPERATE:LOAD-SYSTEM \"arcdocdb/tests\"))) #<NULL-LEXENV> #<SB-C::SOURCE-INFO {8005350423}> 3 NIL)
153: (SB-IMPL::%SIMPLE-EVAL (LET ((SB-KERNEL:*HANDLER-CLUSTERS* (CONS (LIST #) . #1=(SB-KERNEL:*HANDLER-CLUSTERS*)))) (DECLARE (DYNAMIC-EXTENT . #1#)) (PROGN (ASDF/FIND-SYSTEM:LOAD-ASD (MERGE-PATHNAMES \"../arcdocdb.asd\" *LOAD-TRUENAME*)) (ASDF/OPERATE:LOAD-SYSTEM \"arcdocdb/tests\"))) #<NULL-LEXENV>)
154: (SB-INT:SIMPLE-EVAL-IN-LEXENV (HANDLER-BIND ((WARNING (LAMBDA (CONDITION) (UNLESS # #)))) (ASDF/FIND-SYSTEM:LOAD-ASD (MERGE-PATHNAMES \"../arcdocdb.asd\" *LOAD-TRUENAME*)) (ASDF/OPERATE:LOAD-SYSTEM \"arcdocdb/tests\")) #<NULL-LEXENV>)
155: (SB-EXT:EVAL-TLF (HANDLER-BIND ((WARNING (LAMBDA (CONDITION) (UNLESS # #)))) (ASDF/FIND-SYSTEM:LOAD-ASD (MERGE-PATHNAMES \"../arcdocdb.asd\" *LOAD-TRUENAME*)) (ASDF/OPERATE:LOAD-SYSTEM \"arcdocdb/tests\")) 3 NIL)
156: ((LABELS SB-FASL::EVAL-FORM :IN SB-INT:LOAD-AS-SOURCE) (HANDLER-BIND ((WARNING (LAMBDA (CONDITION) (UNLESS # #)))) (ASDF/FIND-SYSTEM:LOAD-ASD (MERGE-PATHNAMES \"../arcdocdb.asd\" *LOAD-TRUENAME*)) (ASDF/OPERATE:LOAD-SYSTEM \"arcdocdb/tests\")) 3)
157: ((LAMBDA (SB-KERNEL:FORM &KEY :CURRENT-INDEX &ALLOW-OTHER-KEYS) :IN SB-INT:LOAD-AS-SOURCE) (HANDLER-BIND ((WARNING (LAMBDA (CONDITION) (UNLESS # #)))) (ASDF/FIND-SYSTEM:LOAD-ASD (MERGE-PATHNAMES \"../arcdocdb.asd\" *LOAD-TRUENAME*)) (ASDF/OPERATE:LOAD-SYSTEM \"arcdocdb/tests\")) :CURRENT-INDEX 3)
158: (SB-C::%DO-FORMS-FROM-INFO #<FUNCTION (LAMBDA (SB-KERNEL:FORM &KEY :CURRENT-INDEX &ALLOW-OTHER-KEYS) :IN SB-INT:LOAD-AS-SOURCE) {100E80F1B}> #<SB-C::SOURCE-INFO {8005350423}> SB-C::INPUT-ERROR-IN-LOAD)
159: (SB-INT:LOAD-AS-SOURCE #<SB-SYS:FD-STREAM for \"file /Users/runner/work/ArcDocDB/ArcDocDB/tools/vertical-crash.lisp\" {8005350043}> :VERBOSE NIL :PRINT NIL :CONTEXT \"loading\")
160: ((LABELS SB-FASL::LOAD-STREAM-1 :IN LOAD) #<SB-SYS:FD-STREAM for \"file /Users/runner/work/ArcDocDB/ArcDocDB/tools/vertical-crash.lisp\" {8005350043}> NIL)
161: (SB-FASL::CALL-WITH-LOAD-BINDINGS #<FUNCTION (LABELS SB-FASL::LOAD-STREAM-1 :IN LOAD) {100E809EB}> #<SB-SYS:FD-STREAM for \"file /Users/runner/work/ArcDocDB/ArcDocDB/tools/vertical-crash.lisp\" {8005350043}> NIL #<SB-SYS:FD-STREAM for \"file /Users/runner/work/ArcDocDB/ArcDocDB/tools/vertical-crash.lisp\" {8005350043}>)
162: ((LABELS SB-FASL::LOAD-STREAM :IN LOAD) #<SB-SYS:FD-STREAM for \"file /Users/runner/work/ArcDocDB/ArcDocDB/tools/vertical-crash.lisp\" {8005350043}> NIL)
163: (LOAD #<SB-SYS:FD-STREAM for \"file /Users/runner/work/ArcDocDB/ArcDocDB/tools/vertical-crash.lisp\" {8005350043}> :VERBOSE NIL :PRINT NIL :IF-DOES-NOT-EXIST :ERROR :EXTERNAL-FORMAT :DEFAULT)
164: ((FLET SB-IMPL::LOAD-SCRIPT :IN SB-IMPL::PROCESS-SCRIPT) #<SB-SYS:FD-STREAM for \"file /Users/runner/work/ArcDocDB/ArcDocDB/tools/vertical-crash.lisp\" {8005350043}>)
165: ((FLET SB-UNIX::BODY :IN SB-IMPL::PROCESS-SCRIPT))
166: ((FLET \"WITHOUT-INTERRUPTS-BODY-\" :IN SB-IMPL::PROCESS-SCRIPT))
167: (SB-IMPL::PROCESS-SCRIPT \"/Users/runner/work/ArcDocDB/ArcDocDB/tools/vertical-crash.lisp\")
168: (SB-IMPL::TOPLEVEL-INIT)
169: ((FLET SB-UNIX::BODY :IN SB-IMPL::START-LISP))
170: ((FLET \"WITHOUT-INTERRUPTS-BODY-3\" :IN SB-IMPL::START-LISP))
171: (SB-IMPL::%START-LISP)

unhandled condition in --disable-debugger mode, quitting
; 
; compilation unit aborted
;   caught 2 fatal ERROR conditions
"
 :STDERR
 "VERTICAL-ROOT-RETAINED /var/folders/nj/vtw8zd2j31d1gdrtntc5y4600000gn/T/arcdocdb-active-4001699360-7268-0/
"
 :EXIT-CODE 1 :LIMITS
 (:COMMAND-OUTPUT-IS-RAW :WALL-TIME-INCLUDES-ENTIRE-COMMAND
  :NO-AUTOMATIC-REQUIREMENT-PROMOTION))
